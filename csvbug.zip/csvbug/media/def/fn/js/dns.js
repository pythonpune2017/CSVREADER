/* JS for Manage Keyword page in admin interface
 * */
/*function add_social_media(){
	$("a#add_social_media").live("click", function(){
		var elem_to_add =  $("div#social_media_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#social_media_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}*/

/*function add_video_media(){
	$("a#add_video_media").live("click", function(){
		var elem_to_add =  $("div#video_media_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#video_media_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}*/


function add_dns()
{
	$("input#add_dns").live("click", function(){
		var elem_to_add =  $("div#dns_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		var parent_length = "dns_" + ($("div#dnsdata_values").children().length + 1);
		elem_to_add.attr("id",parent_length);
		a = elem_to_add.find('a#dns_add_floppy')
		a.attr('rel' ,parent_length)
		
		settings = {
				parent: $("div#dnsdata_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		settings.parent.find("div.add_record").data("is_new_entry",true);
//		settings.parent.find("div.edit_record").toggle(edit_dns_record , update_dns_record);
		settings.parent.find("div.add_record").bind("click", update_dns_record);
		return false;
	});
}
/*function deleteRecord(){
	$("div.j-del-record").live("click", function(){
		$(this).parent().remove();
	})
}
*/

var save_dns_record = function(){

/*	$("div.edit_record").live("click", function()
	{
		
	    if($(this).data("is_even_click")){
	    	$(this).data("is_even_click", false);
	    	edit_dns_record(this);
	           
	}
	else
	    {
	    	  $(this).data("is_even_click", true);
	    	  update_dns_record(this);
	          
	    }
	    return false;
	});
*/	
	
	$("div.edit_record").toggle(edit_dns_record , update_dns_record)
}

var edit_dns_record = function(){
	var elem = $(this);
	var parent = elem.parent().parent();
	if(elem.data("is_new_entry")){update_dns_record(elem);
	elem.data("is_new_entry", false);
	}
	old_type = parent.find("div#hid_type");
	old_type.addClass('hidden_property');
	old_type.hide();
	type = parent.find("select#type");
	type.removeClass('hidden_property');
	
	old_host = parent.find("div#hid_host");
	old_host.addClass('hidden_property');
	old_host.hide();
	host = parent.find("input#host");
	host.removeClass('hidden_property');
	
	old_content = parent.find("div#hid_content");
	old_content.addClass('hidden_block');
	old_content.hide();
	content = parent.find("textarea#content");
	content.removeClass('hidden_block');
	elem.removeClass("pen_edit");
	elem.addClass("dns_flopy");
	parent.find("div.dns_flopy").attr("href", "{%url editdns%}");
	var del_elem = parent.find("div.j-del-indus-category")
	del_elem.append($("<a/>").attr("href", "{%url editdns%}"));
}

var update_dns_record = function(elem){
	/*var elem = elem || $(this);*/
	var elem =  $(this);
	
	var parent = elem.parent().parent();
	var form_data = parent.find("input").serialize();
	var host = parent.find("input#host").val()
	if (host == "host=" || host == '')
	{
		alert("Please Enter some values.");
		return false;
	}
	var type = parent.find("select#type").val()
	if (type == "type=" || type == '')
	{
		alert("Please Enter some values.");
		return false;
	}
	var content = parent.find("textarea").serialize();
	if (content == "content=")
		{
			alert("Please Enter Content.");
			return false;
		}
	var type = parent.find("select").serialize();
	url = elem.find("a").attr("href");
	if(form_data){
		form_data = form_data+ "&" + type + "&" +content + "&"
	}else{
		Alert("Please Enter some Value.")
	}
	postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();	
	
	$.ajax({
		url:url, 
		data:postdata, 
		type:"POST",
		success:function(data, textStatus, jqXHR){
			if(data.status){
				elem.removeClass("dns_flopy");
				elem.addClass("pen_edit");
				parent.find("div.pen_edit a").attr("href", data.edit_url);
				var del_elem = parent.find("div.j-del-indus-category")
				del_elem.append($("<a/>").attr("href", data.delete_url));
				alert(data.msg);
				type = parent.find("select#type");
				type.addClass('hidden_property');
				type_val = type.val()
				type.hide();
				old_type = parent.find("div#hid_type");
				old_type.removeClass('hidden_property');
				old_type.html(type_val)
				old_type.show();
				
				
				host = parent.find("input#host");
				host.addClass('hidden_property');
				host_val = host.val()
				host.hide();
				old_host = parent.find("div#hid_host");
				old_host.removeClass('hidden_property');
				old_host.html(host_val)
				old_host.show();
				
				
				content = parent.find("textarea#content");
				content.addClass('hidden_block');
				content_val = content.val()
				content.hide();
				old_content = parent.find("div#hid_content");
				old_content.removeClass('hidden_block');
				old_content.html(content_val)
				old_content.show();
				
				if(elem.data("is_new_entry")){
					elem.unbind("click");
					elem.addClass("edit_record");
					elem.removeClass("add_record");
					elem.toggle(edit_dns, add_dns);
					elem.data("is_new_entry", false);
				}
				
				
			}else
			{
				if(data.msg)
				{
					alert(data.msg);
					return false;
				}
			}
		},
//		error:function(data, textStatus, jqXHR)
//		{
//			
//		}
	});
}

var save_dns = function(){
	$("div.hid_edit.dns_flopy").live("click", function(){
		var elem = $(this);
		var parent = elem.parent().parent();
		var form_data = parent.find("input").serialize();
		var host = parent.find("input#hidden_host").val()
		if (host == "" || host == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var type = parent.find("select#hidden_type").val()
		if (type == "" || type == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var content = parent.find("textarea#hidden_content").serialize();
		if (content == "content=")
			{
				alert("Please Enter Content.");
				return false;
			}
		var type = parent.find("select#hidden_type").serialize();
		url = elem.find("a").attr("href");
		if(form_data){
			form_data = form_data+ "&" + type + "&" +content + "&"
		}else{
			alert("Please Enter some Value.")
		}
		postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();	
		
		$.ajax({
			url:url, 
			data:postdata, 
			type:"POST",
			success:function(data, textStatus, jqXHR){
				if(data.status){
					elem.removeClass("hid_edit.dns_flopy");
					elem.addClass("pen_edit");
					parent.find("div.pen_edit a").attr("href", "{% url editdns %}");
					var del_elem = parent.find("div.j-del-indus-category")
					del_elem.append($("<a/>").attr("href", data.delete_url));
					alert(data.msg);
					
					type = parent.find("select#type");
					type_val = type.val()
					type.hide()
					new_type = parent.find("div#hid_type");
					new_type.removeClass('hidden_property');
					new_type.html(type_val)
					
					host = parent.find("input#host");
					host_val = host.val()
					host.hide()
					new_host = parent.find("div#hid_host");
					new_host.removeClass('hidden_property');
					new_host.html(host_val)
					
					content = parent.find("textarea#content");
					content_val = content.val()
					content.hide()
					new_content = parent.find("div#hid_content");
					new_content.removeClass('hidden_block');
					new_content.html(content_val)
				}else
				{
					if(data.msg)
					{
						alert(data.msg);
						return false;
					}
				}
			},
			//error:function(data, textStatus, jqXHR)
			//{
			//}
		});
	
	});
}

/*var save_dns = function(){
	$("div.hid_edit.dns_flopy").live("click", function(){
		var elem = $(this);
		var parent = elem.parent().parent();
		var form_data = parent.find("input").serialize();
		var host = parent.find("input#hidden_host").val()
		if (host == "" || host == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var type = parent.find("select#hidden_type").val()
		if (type == "" || type == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var content = parent.find("textarea#hidden_content").serialize();
		if (content == "content=")
			{
				alert("Please Enter Content.");
				return false;
			}
		var type = parent.find("select#hidden_type").serialize();
		url = elem.find("a").attr("href");
		if(form_data){
			form_data = form_data+ "&" + type + "&" +content + "&"
		}else{
			alert("Please Enter some Value.")
		}
		postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();	
		
		$.ajax({
			url:url, 
			data:postdata, 
			type:"POST",
			success:function(data, textStatus, jqXHR){
				if(data.status){
					elem.removeClass("hid_edit.dns_flopy");
					elem.addClass("pen_edit");
					parent.find("div.pen_edit a").attr("href", "{% url editdns %}");
					var del_elem = parent.find("div.j-del-indus-category")
					del_elem.append($("<a/>").attr("href", data.delete_url));
					alert(data.msg);
					
					type = parent.find("select#type");
					type_val = type.val()
					type.hide()
					new_type = parent.find("div#hid_type");
					new_type.removeClass('hidden_property');
					new_type.html(type_val)
					
					host = parent.find("input#host");
					host_val = host.val()
					host.hide()
					new_host = parent.find("div#hid_host");
					new_host.removeClass('hidden_property');
					new_host.html(host_val)
					
					content = parent.find("textarea#content");
					content_val = content.val()
					content.hide()
					new_content = parent.find("div#hid_content");
					new_content.removeClass('hidden_block');
					new_content.html(content_val)
					
				}else
				{
					if(data.msg)
					{
						alert(data.msg);
						return false;
					}
				}
			},
			//error:function(data, textStatus, jqXHR)
			//{
			//}
		});
	
	});
}*/

var edit_dns= function(){
	$("div.pen_edit").live("click", function(){
		var elem = $(this);
		var parent = elem.parent().parent();
		old_type = parent.find("div#type");
		old_type.hide();
		type = parent.find("select#type");
		type.removeClass('hidden_property');
		old_host = parent.find("div#host");
		old_host.hide();
		host = parent.find("input#host");
		host.removeClass('hidden_property');
		old_content = parent.find("div#content");
		old_content.hide();
		content = parent.find("textarea#content");
		content.removeClass('hidden_block');
		elem.removeClass("pen_edit");
		elem.addClass("dns_flopy");
		parent.find("div.dns_flopy").attr("href", "{%url editdns%}");
		var del_elem = parent.find("div.j-del-indus-category")
		del_elem.append($("<a/>").attr("href", "{%url editdns%}"));
	});
}

var update_dns = function(){
	$("div.dns_flopy").live("click", function(){
		var elem = $(this);
		var parent = elem.parent().parent();
		var form_data = parent.find("input").serialize();
		var host = parent.find("input#host").val()
		if (host == "" || host == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var type = parent.find("select#type").val()
		if (type == "" || type == '')
		{
			alert("Please Enter some values.");
			return false;
		}
		var content = parent.find("textarea").serialize();
		if (content == "content=")
			{
				alert("Please Enter Content.");
				return false;
			}
		var type = parent.find("select").serialize();
		url = elem.find("a").attr("href");
		if(form_data){
			form_data = form_data+ "&" + type + "&" +content + "&"
		}else{
			alert("Please Enter some Value.")
		}
		postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();	
		
		$.ajax({
			url:url, 
			data:postdata, 
			type:"POST",
			success:function(data, textStatus, jqXHR){
				if(data.status = true ){
					elem.removeClass("dns_flopy");
					elem.addClass("pen_edit");
					parent.find("div.pen_edit a").attr("href", data.edit_url);
					var del_elem = parent.find("div.j-del-indus-category")
					del_elem.append($("<a/>").attr("href", data.delete_url));
					alert(data.msg);
					type = parent.find("select#type");
					type.hide();
					old_type = parent.find("div#type");
					old_type.show();
					host = parent.find("input#host");
					host.hide();
					old_host = parent.find("div#host");
					old_host.show();
					content = parent.find("textarea#content");
					content.hide();
					old_content = parent.find("div#content");
					old_content.show();
				}else
				{
					if(data.msg)
					{
						alert(data.msg);
						return false;
					}
				}
			},
			//error:function(data, textStatus, jqXHR)
			//{
			//}
		});
	
	});
}


/*var edit_industry_keyword = function(){
	 associates popup model box with edit industry button
	 url : url to call for getting the form
	 
	 $("div.j-edit-industry.pen_edit").modelBox({
	  close_selector:"div.close",
	  height:'470px',
	  width:'380px',
	   onload:function(elem, content_div){
		  url = elem.find("a").attr("href");
		  $.get(url, function(data, textStatus, jqXHR){
				content_div.html(data);
			});
	  } 
	 });
}
*/
/*var update_industry_keywords=function(){
	$(':input[name^=update_industry_keywords]').live("click", function(event){//[name|="submit_add_user_form"]
		var editform = $("form[name|='edit_industry_keywords']");
		var formdata = editform.serialize();
		if(!url){
			url = editform.attr("action");
		}	  
		var postdata= formdata + "&csrfmiddlewaretoken=" + getCsrfCookie()
		$.ajax({
			url:url,
			type:"POST",
			data: postdata,
			success:function(data, textStatus, jqXHR){
				if(data.status){	
					$("a div.close").trigger("click");
					location.reload();
				}else{
					var html_container = $('#le_model_box').children().first();
					html_container.html(data1.elements);
				}
			},
			error:function(data, textStatus, jqXHR){
			}
		});
				
	});
	
}*/

var delete_dns = function(){
	$("div.j-del-indus-category").live("click", function(){
		var elem = $(this);
		var parent = elem.parent().parent().parent();
		var domain_id = parent.find("input#domain_id").serialize();
		var recordid = parent.find("input#recordid").serialize();
		var form_data = domain_id+ "&" + recordid + "&"
		var url = elem.find("a").attr("href"),
		//postdata = {'csrfmiddlewaretoken': getCsrfCookie()};
		postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();
		$.ajax({
			type:"POST",
			url:url,
			data : postdata,
			success : function(data, textStatus, jqXHR){
				if(data.status == true)
				{	
					var a = elem.find('a');
					var rel_data = a.attr('rel');
					$(rel_data).remove();
//					alert(elem);
//					t = elem.parent().parent().parent()
//					t.remove()
					alert(data.message);
				}
				else
				{
					alert(data.message);
				}
				
			},
		})
	});
}



$(document).ready(function()
{
	
	//add_social_media();
	//add_video_media();
	add_dns();
	//deleteRecord();
	//save_dns();
	save_dns_record();
	//edit_industry_keyword();
	//edit_dns();
	//update_industry_keywords();
	delete_dns();
	//update_dns();
});
