var edit_case_record = function(){
	$("form[name^=edit_case_details_form] input[name|='edit_case_details']").live("click", function(event){
		webip_select();
		$("div.cases").addClass("hidden_block");
		$(".case_login_input").removeClass("hidden_block");
		$(".edit_input").addClass("hidden_block");
		$(".save_case").removeClass("hidden_block")
	});
}

var edit_infringer_record = function(){
	$("form[name^=edit_infringer_details_form] input[name|='edit_infringer_details']").live("click", function(event){
		$("div.infringer").addClass("hidden_block");
		$(".case_login_input").removeClass("hidden_block");
		$(".edit_infringer").addClass("hidden_block");
		$(".edit_infringer").addClass("hidden_block");
		$(".save_infringer").removeClass("hidden_block")
	});
}

var add_new_note = function(){
	$("form[name^=edit_infringer_details_form] div[id|='add_new_note']").live("click", function(event){
		$("#edit_notes").removeClass("hidden_block");
	});
}


var add_team_details = function(){
	$("form[name^=edit_case_team_details_form] input[name|='add_team']").live("click", function(event){
		$("#add_team1").removeClass("hidden_block");
	/*	$(".case_login_input").removeClass("hidden_block");*/
	/*	$("div.cases").addClass("hidden_block");*/
		$(".add_team_div").addClass("hidden_block");
		$(".edit_team_div").addClass("hidden_block");
		$(".save_team").removeClass("hidden_block")
		$(".cancel_team").removeClass("hidden_block")
		$(".update_team").addClass("hidden_block")
		

	});
}

var notes_save = function(url){
	 $("form[name^=edit_infringer_details_form] a[id|='edit_case_notes']").live("click", function(event){//[name|="submit_add_user_form"]
		 var notes = $("form[name^=edit_infringer_details_form] textarea[name|='notes']").val();
		 var data = {notes: notes , csrfmiddlewaretoken:getCsrfCookie()};
		 var elem = $(this);
		 var url = elem.attr('href');
		 $.ajax({
		 url: url,
		 type: "POST",
		 cache: false,
		 data:data ,
		 success: function(data, textStatus, jqXHR)
		 {
			 if(data){
				 window.location.reload();
			 }
		 }
		 });
	 });
}
function validate()
{
//	alert("hhi");
//	debugger;
	var  alert_alt_email = "", alert_phone="",alert_alt_name="";
	
	var alt_name = $("#team_name").val();
    //var alt_email_val = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,4}$/.test(alt_email);
    //var alt_name_val = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(alt_name);
    
	if(!alt_name)
    {
       
        alert_alt_name = "Name is mandatory.";
       
    }
    else
    {
    	alert_alt_name="";
    	
    }
	
	
	var alt_email = $("#team_email").val();
    //var alt_email_val = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,4}$/.test(alt_email);
    var alt_email_val = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test(alt_email);
    if(alt_email)
    {
        if(!alt_email_val){
            alert_alt_email = "Please enter a valid alternate email address.";
        }
        else 
        {
            alert_alt_email = ""
        }
    }
    else
    	{
    		
    		alert_alt_email = "Email is mandatory.";
    	}

    var phone = $("#team_phone").val();
    var phone_val = /^([0-9\(\)\/\+ \-]*)$/.test(phone);
    if(phone)
    {
        if(! phone_val){
            alert_phone = "\nPlease enter a valid phone number.";
        }
        else {
            alert_phone =  "" 
        }
    }
//    else
//    {
//    	alert_phone="Phone,";
//    	
//    }
    data =   alert_alt_name+alert_alt_email+alert_phone;
    if(data) { 
    	if(!alert_alt_email)
    		jAlert(alert_alt_email);
    	
    	jAlert(data);
    	return false;
    }
	
    return true;
}


function validate_edit()
{
	var alert_team_name = "", alert_team_email="";
	$('input.team_name_class').each(function(index) {
//		console.log($(this).val());
		if (!$(this).val()) {
			alert_team_name = "Name is mandatory.";
		
		}
	});

	$('input.team_email_class').each(function(index) {
//		console.log($(this).val());
		var email_val = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/.test($(this).val());
		if (!$(this).val()) {
			alert_team_email = "Email is mandatory.";
			
		}
		if (!email_val) {
			alert_team_email = "Please enter a valid alternate email address.";
			
		}
	});

    data = alert_team_name +alert_team_email;
    if(data) { 
    	jAlert(data);
    	return false;
    }
	
    return true;
}



var add_team_save = function(url)
{
	 $("input[name|='Save']").live("click", function(event){
	 var status_validate=''
	 status_validate=validate()
	 if (!status_validate)
		 return false;
	 var teamform = $("form[name|='edit_case_team_details_form']");
	 var formdata = teamform.serialize();
	 abc=$("input[name|='Save']").val()
	 formdata=formdata+'&'+abc
//	 var data = {notes: notes , csrfmiddlewaretoken:getCsrfCookie()};
	 var elem = $(this);
	 var url = elem.attr('href');
	 $.ajax({
	 url: url,
	 type: "POST",
	 cache: false,
	 data:formdata ,
	 success: function(data, textStatus, jqXHR)
	 {
		 if(data){
			 window.location.reload();
		 }
	 }
	 });
	 });
}




var add_attachment = function(){
	$("#add_more_attachment_link").live("click", function(event){
		$("#add_more_attachment").removeClass("hidden_block");
	});
}



var edit_team_record = function(){
	$("form[name^=edit_case_team_details_form] input[name|='edit_caseteam']").live("click", function(event){
		$("#add_team").removeClass("hidden_block");
		$("div.cases").addClass("hidden_block");
		$(".case_login_input").removeClass("hidden_block");
		$(".edit_team_div ").addClass("hidden_block");
		$(".add_team_div").addClass("hidden_block");
		$(".save_team").addClass("hidden_block");
		$(".update_team").removeClass("hidden_block");
		$(".cancel_team").removeClass("hidden_block");
		$("#cancel_case_team").addClass("pad_rgt");
//		cancel_case_team
	});
}




var cancel_team_record = function(){
	$("form[name^=edit_case_team_details_form] input[name|='cancel_caseteam']").live("click", function(event){
		window.location.reload();
	
	});
}




var edit_team_record_save = function(url){
	 $("form[name^=edit_case_team_details_form] input[name|='Update_caseteam']").live("click", function(event){
		 form_val=$("form[name|='edit_case_team_details_form']").val();
		 var status_validate=''
		 status_validate=validate_edit()
		 if (!status_validate)
			return false;
		 var teamform = $("form[name|='edit_case_team_details_form']");
		 var formdata = teamform.serialize();
		 temp=$("input[name|='Update_caseteam']").val()
		 formdata=formdata+'&'+temp
//		 var data = {notes: notes , csrfmiddlewaretoken:getCsrfCookie()};
		 var elem = $(this);
		 var url = elem.attr('href');
		 $.ajax({
		 url: url,
		 type: "POST",
		 cache: false,
		 data:formdata ,
		 success: function(data, textStatus, jqXHR)
		 {
			 if(data){
				 window.location.reload();
			 }
		 }
		 });
		 });
	}

var select_case_type = function(){
	$("form[name^=add-case-form] select[name|='case_type']").live("change", function(event){
		var case_type = $("form[name^=add-case-form] select[name|='case_type']").val();
		if(case_type == "domain"){
			$("#type_domain_name").removeClass("hidden_block");
			$("#type_tm_number").addClass("hidden_block");
			$("#type_tm_name").addClass("hidden_block");
			$("#type_url").addClass("hidden_block");
		}
		else if(case_type == "trademark"){
			$("#type_tm_number").removeClass("hidden_block");
			$("#type_tm_name").removeClass("hidden_block");
			$("#type_url").addClass("hidden_block");
			$("#type_domain_name").addClass("hidden_block");
		}
		else if(case_type == "brand"){
			$("#type_url").removeClass("hidden_block");
			$("#type_tm_number").addClass("hidden_block");
			$("#type_tm_name").addClass("hidden_block");
			$("#type_domain_name").addClass("hidden_block");
		}
		else{
			jAlert("Please select a case type..!!");
			$("#type_tm_number").addClass("hidden_block");
			$("#type_tm_name").addClass("hidden_block");
			$("#type_domain_name").addClass("hidden_block");
			$("#type_url").addClass("hidden_block");
		}
	});
}

$(document).ready(function(){
	edit_case_record();
	edit_infringer_record();
	add_new_note();
	//notes_save();
	add_attachment();
	add_team_details();
	add_team_save();
	edit_team_record();
	edit_team_record_save();
	select_case_type();
	cancel_team_record();
});