/*Functions for view all ssl form*/

var add_more = function(){
	$("form[name^=nameserverform] a[id|='add_more_nameserver']").live("click", function(event){//[name|="submit_add_user_form"]
		var nameserver_html = $("form[name^=nameserverform] div[id|='nameserver_hidden_block']").children();
		var elem_to_add = $(nameserver_html).clone();
		var server_details = $("form[name^=nameserverform] div[id|='nameserver_details']");
		var detail_length = server_details.children().length;
		var nameserever_label = $(elem_to_add).find("strong").first().html();
		nameserever_label = nameserever_label + (detail_length + 1);
		$(elem_to_add).find("strong").first().html(nameserever_label);
		$(elem_to_add).find("input").attr("id" , "nameserver_"+(detail_length+1));
		$(elem_to_add).find("input").attr("name" , "nameserver_"+(detail_length+1));
		server_details.append(elem_to_add);
	});
}

var get_nameserver_details = function(url){
  	$("select[name^=nameserver_profile]").live("change", function(event){//[name|="submit_add_user_form"]
  	 var nameserver_id = $("select[name^=nameserver_profile]").val();
  	  if(nameserver_id == '' ||  nameserver_id == "Please Select")
  	  {
		$("#nameserver_viewonly_details").addClass("hidden_block");
  	  	jAlert("Please select a profile");	
  	  	$(".login_input").attr('value' , '');
  	  	return false;
  	  }
  	});
  	
  	$("#get_nameserver_profile_details").live("click", function(event){//[name|="submit_add_user_form"]
  		var nameserver_id = $("select[name^=nameserver_profile]").val();
		if(nameserver_id == '' ||  nameserver_id == "Please Select")
		{
			$("#nameserver_viewonly_details").addClass("hidden_block");
			jAlert("Please select a profile");	
			$(".login_input").attr('value' , '');
			return false;
		}
  	    $("#popup_image").show();	
  		var data = {nameserver_id : nameserver_id , csrfmiddlewaretoken:getCsrfCookie()};
  		$.ajax({
  			url: url,
  			type: "POST",
  			cache: false,
  			data:data ,
  			success: function(data, textStatus, jqXHR){
  				if(data){
  					$("#nameserver_viewonly_details").removeClass("hidden_block");
  					$("div#nameserver_viewonly_details").html(data);
                    $("#popup_image").hide();
  				}
  				else{
                    $("#popup_image").hide();
  					jAlert("Please select correct value");
  				}
  			}
  		});  
	 return false;
});
}


$(document).ready(function(){
	add_more();
	get_nameserver_details("/fn/domain/serverprofile/");
});
