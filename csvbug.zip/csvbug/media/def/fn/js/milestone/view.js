// js functions for milestone view
$(document).ready(function(){
        addMilestone();
        updateMilestone();
        $(".red_close").click(function() { return deleteMilestone() } );
        datepick() ;
        });

// function to delete milestone
function deleteMilestone() {
    del = confirm("Do you want to Delete") ;
    if (del ) {  return true ;
    }
    else { return false ;
    }
}

// function for milestone add popup
var addMilestone = function(){
    $("#add_milestone").modelBox({
        close_selector:"div.close",
        height:'457px',
        width:'745px',
        cache : false,
        onBeforeLoad: function (elem)
        {
            $("#popup_image").show();
        },
        onload:function(elem, content_div){
	        // get case id
	        var caseId = $('#add_milestone').attr('rel');
	        // set url
	        var url = '/fn/cases/'+caseId+'/milestone/add/' ;
	        $.get(url, function(data, textStatus, jqXHR){
	            content_div.html(data);
	            $("#popup_image").hide();
	            });
	        }
    });
}

// function for milestone update popup
function updateMilestone() {
    $('.edit_milestone').modelBox({
        close_selector:"div.close",
        height:'457px',
        width:'745px',
        onBeforeLoad: function (elem)
        {
            $("#popup_image").show();
        },
        onload:function(ele, content_div){
        	// get ele
	        var updateEle = $(ele).find("input");
	        // get case id
	        var caseId = $(updateEle).attr('rel');
	        // get milestone id
	        var milestoneId = $(updateEle).val() ;
	        // set url
	        var url = '/fn/cases/'+caseId+'/milestone/update/'+milestoneId+'/' ;
	        $.get(url, function(data, textStatus, jqXHR){
	            content_div.html(data);
	            $("#popup_image").hide();
	            });
	        }
    });
    return false ;
}

// function for data picker widget
var datepick= function(){
    $(".datepicker").datepicker({ dateFormat: 'dd-mm-yy',minDate:0 });
}
