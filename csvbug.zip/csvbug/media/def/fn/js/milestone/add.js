// js functions for milestone add
$(document).ready(function(){

        datepick() ;
        $("#milestone_add_submit").click(function() { return milestoneAddSubmit(this) } );
        $("#close_form").click(function() { return closePopup() } );
        $("#milestone_update_submit").click(function() { return milestoneUpdateSubmit(this) } );

        });

// function for data picker widget
var datepick= function()
{
    $(".datepicker").datepicker(
            { dateFormat: 'dd-mm-yy',minDate:0 }		
            );
}

// function used to submit milestone add form
function milestoneAddSubmit(ele) {
    // get case ID
    var caseId = $(ele).attr('rel') ;
    // set url
    var url = '/fn/cases/'+caseId+'/milestone/add/' ;
    // get form data
    var formData = $('#milestone_add_form').serialize();
    // send post request
    $.post(url, formData, function(responseData, textStatus, jqXHR) {
            // set responseData in a div
            $("#amb-content-N").html(responseData);
            });
}

// function used to submit milestone update form
function milestoneUpdateSubmit(ele) {
    // get id's
    var idHolder = $(ele).attr('rel') ;
    var splitedId = idHolder.split('+') ;
    // get case ID
    var caseId = splitedId[0] ;
    // get milestoneId
    var milestoneId = splitedId[1]
    // set url
    var url = '/fn/cases/'+caseId+'/milestone/update/'+milestoneId+'/' ;
    // get form data
    var formData = $('#milestone_add_form').serialize();
    // send post request
    $.post(url, formData, function(responseData, textStatus, jqXHR) {
            // set responseData in a div
            $("#amb-content-N").html(responseData);
            });
}

// function to close popup
function closePopup() {
    $("a div.close").trigger("click");
}
