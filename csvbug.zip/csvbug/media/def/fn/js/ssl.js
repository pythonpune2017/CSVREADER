/*Functions for view all ssl form*/
var view_more = function(url){
  	$(".view_more_ssl").live("click", function(event) {//[name|="submit_add_user_form"]
		 var elem = $(this);
		 //var parent = elem.parent();
		 var ssl = elem.siblings("div#ssl_id");
		 //var ssl = parent.find("div#ssl_id");
		 var ssl_id = ssl.html();
		 var domain = elem.siblings("div#domain_name");
		 //var domain = parent.find("div#domain_name");
		 domain_name = domain.html();
		 var url = elem.find("a").attr("href");

		 var data = { ssl_id: ssl_id,domain_name: domain_name };
		 $.ajax({
			 url: url,
			 type: "GET",
			 cache: false,
			 data:data ,
			 success: function(data, textStatus, jqXHR){
				 if(data) {
					 var a = elem.find('a');
					 var rel_data = a.attr('rel');
					 var ssl_form = $(rel_data);
					 ssl_form.html(data);
					 //parent = elem.parent();
		             cancel = elem.siblings("div#ssl_cancel");
					 //cancel = parent.find("div#ssl_cancel");
					 elem.hide();
					 cancel.show();
				 }
				 else{
					 jAlert("Please select correct value");
				 }
		         $(".datepicker").datepicker({ dateFormat: 'dd-mm-yy', minDate: 0 });
			}
		 });  
		 return false;
	});
}
	  
	  
var edit_ssl_save = function(){
  $('form[name^=view_ssl_form] input[name|="sslupdatebutton"]').live('click', function(event) {
	  var editform = $("form[id|='view_ssl_form']");
	  var formdata = editform.serialize();
	  var url = editform.attr("action");
	  $.post(url, formdata, function(data2, textStatus, jqXHR) {
		  if(data2.status) {	
			  alert(data2.message);
			  /*$("a div.close").trigger("click");
			  location.reload();*/
			  //$("div#msg_box").removeClass("hidden_block");
			  //$("div#success_message").html(data2.message)
		  }
		  else {
			  var html_container = $('#amb-modelbox-N').children().first();
			  html_container.html(data2.elements);
		  }
	  });
  });
  
  $("input[name|='cancel_delete']").live('click', function(event){
  	$("a div.close").trigger("click");
  });
}
	    
var cancel = function(url){
	$(".ssl_cancel").live("click", function(event) {//[name|="submit_add_user_form"]
		 var elem = $(this);
		 //var a = elem.find('a');
		 var rel_data = $(this).children('a').attr('rel')
		 var ssl_form = $(rel_data);
		 ssl_form.html("")
		 //parent = elem.parent();
		 view_more = elem.siblings("div#view_more_ssl");
		 //view_more = parent.children("div#view_more_ssl");
		 elem.hide();
		 view_more.show();
	});
}


$(document).ready(function(){
	view_more();
	edit_ssl_save();
	cancel();
});
