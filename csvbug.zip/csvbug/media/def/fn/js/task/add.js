// js functions for milestone add
$(document).ready(function(){
        $("#task_update_submit").click(function() { return taskUpdateSubmit(this) } );
        $("#task_add_submit").click(function() { return taskAddSubmit(this) } );
        $("#close_form").click(function() { return closePopup() } );
});

// function used to submit milestone add form
function taskAddSubmit(ele) {
    
    var idHolder = $(ele).attr('rel') ;
    var splitedId = idHolder.split('+') ;
    // get case ID
    var caseId = splitedId[0] ;
    // get milestoneId
    var MileId = splitedId[1] ;
    // get case ID
    // caseId = $(ele).attr('rel') ;
    // set url
    var url = '/fn/cases/'+caseId+'/'+MileId+'/task/add/' ;
    // get form data
    var formData = $('#task_add_form').serialize();
    // send post request
    $.post(url, formData, function(responseData, textStatus, jqXHR) {
            // set responseData in a div
            $("#amb-content-N").html(responseData);
    });
}

// function to close popup
function closePopup() {
    $("a div.close").trigger("click");
}

// function used to submit task update form
function taskUpdateSubmit(ele) {
    // get id's
    var idHolder = $(ele).attr('rel') ;
    var splitedId = idHolder.split('+') ;
    // get case ID
    var caseId = splitedId[0] ;
    // get MilestoneoneId
    var MileId = splitedId[1] ;
    // get taskoneId
    var taskId = splitedId[2] ;
    // set url
    var url = '/fn/cases/'+caseId+'/'+MileId+'/'+taskId+'/task/update/' ;
    // get form data
    var formData = $('#task_add_form').serialize();
    // send post request
    $.post(url, formData, function(responseData, textStatus, jqXHR) {
            // set responseData in a div
            $("#amb-content-N").html(responseData);
    });
}
