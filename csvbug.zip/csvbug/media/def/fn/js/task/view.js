// js functions for task view

$(document).ready(function(){

        addTask();
        updateTask() ;
        $(".plus").live("click",function() { $("#wait_image").show(); return displayTask(this) } );
        $(".minus").live("click",function() { $("#wait_image").show(); return clearTask(this) } );
        $(".delete_task").live("click",function() { return deleteTask() } );
        $("input[name=checkbox]").live("click",function() { return getSelectedVals(this) } );
        });



function getSelectedVals(ele){
    var url=$(ele).val();
	$.ajax({
	        type: "GET",
	        url: url,
	        cache: false,
	        
	        success:function(response)
	        {
	        	$(ele).attr("checked",true);
	        	$(ele).attr("readonly",true);
	        },
	        error:function()
	        {
	        	
	        	
	        },
	        complete:function(){
	        	
	        	
	        },
	    });
	    return false ;
	
	}
		




// function to delete task
function deleteTask() {
    del = confirm("Do you want to Delete") ;
    if (del ) {  return true ;
    }
    else { return false ;
    }
}

// function for task add popup
var addTask = function(){
    $("#add_task").modelBox({
        close_selector:"div.close",
        height:'457px',
        width:'573px',
        cache : false,
        onBeforeLoad: function (elem)
        {
            $("#popup_image").show();
        },
        onload:function(elem, content_div){
        	// get case id
        	var caseId = $('#add_task').attr('rel');
        	// MileId= $('#milstone_id').val() // old milestone value 
        	var MileId= elem.siblings().val() ;
        
        	var url = '/fn/cases/'+caseId+'/'+MileId+'/task/add/' ;
	        // set url
	        //url = '/fn/cases/'+caseId+'/task/add/' ;

	        $.get(url, function(data, textStatus, jqXHR){
	            content_div.html(data);
	            $("#popup_image").hide();
	            });
	        }
    });
}

// function for task update popup
function updateTask() {
    $('.edit_task').modelBox({
        close_selector:"div.close",
        height:'457px',
        width:'573px',
        cache : false,
        onBeforeLoad: function (elem)
        {
            $("#popup_image").show();
        },
        onload:function(ele, content_div){
        	// get id's
	        var idHolder = $(ele).attr('rel') ;
	        var splitedId = idHolder.split('+') ;
	        
	        // get case_id
	        var caseId = splitedId[0] ;
	        
	        // get milestoneId 
	        var MileId = splitedId[1] ;
	        // get task id
	        var taskId = splitedId[2] ;
	
	        // set url
	        var url = '/fn/cases/'+caseId+'/'+MileId+'/'+taskId+'/task/update/' ;
	
	        $.get(url, function(data, textStatus, jqXHR){
	            content_div.html(data);
	            $("#popup_image").hide();
	            });
	        }
    });

    //return false ;
}

function displayTask(ele) {
    
	var ref_ele = ele ;
	// get id's
	var containerid = $(ref_ele).attr("id");
	var splitedId = containerid.split("-");
    
    // get milestoneId 
    var caseId = splitedId[2] ;
    // get milestoneId 
    var milestoneId = splitedId[3] ;

    // set url
    var url = '/fn/cases/'+caseId+'/'+milestoneId+'/task/view/' ;
    $.get(url, function(data, textStatus, jqXHR){
        // append data
        $(data).insertAfter($(ref_ele).parent())

        // change css ( plus to minus )
        $(ref_ele).attr('class','milestone_div40 minus') ;
        $("#wait_image").hide();
    });
}

function clearTask(ele) {
    // remove taks
    $(ele).parent().next().remove() ;
    
    // change css ( minus to plus )
    $(ele).attr('class','milestone_div40 plus') ;
    $("#wait_image").hide();
}
