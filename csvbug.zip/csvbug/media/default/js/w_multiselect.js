
var multichoiceselector = function(){
	$("input[name^=multi-move-right]").live("click", function(){
		var left_select = $("select[id^=multi-select-left]");
		var right_select = $("select[id^=multi-select-right]");
		var selected = left_select.find("option:selected");
		if(selected.length){
			right_select.append(selected);
		}
	});
	
	$("input[name^=multi-move-left]").live("click", function(){
		var left_select = $("select[id^=multi-select-left]");
		var right_select = $("select[id^=multi-select-right]");
		var selected = right_select.find("option:selected");
		if(selected.length){
			left_select.append(selected);
		}
	});
	
	
	
}

var selectAll = function(elem){
	/*mark all the options in selet input as seleceted*/
	var select = elem;
	if(select.length){
		select.children().each(function(index, element){
			$(element).attr("selected", true);
		});
	}
}

multichoiceselector();