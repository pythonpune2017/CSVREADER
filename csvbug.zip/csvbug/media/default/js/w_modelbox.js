/*
 * modelBox is a function for creating a Popup Box when a some element is clicked.
 * 
 * Version: 0.1 (Beta)
 * 
 * How to use: $(selector).modelBox(map);
 * 
 * Required arguments: onload, closeId
 * 
 * Created By : Arun Mittal
 * */

(function($){
	$.fn.modelBox = function(settings){
		var defaults = {
			onload:function(){},
			onBeforeLoad:function(){},
			onClose:function(){},
			height:'10px',
			width:'10px',
			overlayId:"amb-overlay-N",
			overlayClass:"",
			modelboxId:"amb-modelbox-N",
			modelboxClass:"",
			contentDivId:"amb-content-N",
			close_selector: "div.close"
		};
		var config = $.extend(defaults, settings),
		params = {
				modelDiv:"",//$("<div/>").attr({"id": config.modelboxId,"class": config.modelboxClass}),
				overlay:"",//$("<div/>").attr({"id":config.overlayId,"class":config.overlayClass}),
				content_div : ""//$("<div/>").attr("id", config.contentDivId)
		};
		var createmodelbox = function(config,params){
			var model_css_props = {position: 'absolute', 'z-index': 100001,'background-color':'transparent', display:'none', 'border-radius':'15px',
					height:config.height,width:config.width};
			params.modelDiv = $("<div/>").attr({"id": config.modelboxId,"class": config.modelboxClass});
			params.content_div = $("<div/>").attr("id", config.contentDivId);
			params.modelDiv.css(model_css_props);
			params.modelDiv.append(params.content_div);
			
			toCenter(params.modelDiv);
			$("body").append(params.modelDiv);
		};
		var bindUserIdToClose = function(params){
			if(config.close_selector){
				$(config.close_selector).live('click', function(){
					closeModelBox(params);
					return false;
				});
			}
		},
		showModelBox = function(){
			params.modelDiv.css("display", "block");
			toCenter(params.modelDiv);
			
		},
		closeModelBox = function(params){
//			params.modelDiv.html("");
//			params.modelDiv.css("display", "none");
			config.onClose();
			params.modelDiv.remove();
			params.overlay.remove();
		},
		bindEscToClose = function(params){
			$(document).keydown(function(event){
				if(event.keyCode ==27){
					closeModelBox(params);	
				}
			});
		},
		createCloseDiv = function(params){
			var close_css = {'top':'-7px', 'right':'-7px','cursor': 'pointer', 'position':'absolute'};
			var close_div = $("<div class='modelboxClose'><img src='/media/images/icon1.jpg'></div>");
			close_div.css(close_css);
			params.modelDiv.append(close_div);
			$("div.modelboxClose").live("click", function(){
				closeModelBox(params);
				return false;
			});
		},
		createoverlay = function(params){
			var screen_height = $(document).height(),
			screen_width = $(document).width();
			params.overlay = $("<div/>").attr({"id":config.overlayId,"class":config.overlayClass});
			var overlaycss = {	opacity: 0.5, 
								left: 0,
								top: 0,
								right:0,
								bottom:0,
								height: screen_height,
								width:screen_width,
								position: 'absolute', 
								'z-index': 100000,
								'background-color': '#000000'};
			params.overlay.css(overlaycss);
			//$overlay.css({'height':'100%', width:'100%'});
			$("body").append(params.overlay);
		};
	
			$(this).live("click", function(){
				config.onBeforeLoad(this);
				
				createmodelbox(config,params);
				config.onload($(this), params.content_div);
				bindUserIdToClose(params);
				bindEscToClose(params);
				showModelBox();
				if(!settings.close_selector){createCloseDiv(params);}
				createoverlay(params);
				return false;
			});
	};
	
	var toCenter=function(elem){
		/*var screenwidth = $(window).outerWidth(),
		screenheight = $(window).outerHeight(),*/
		var elemwidth = elem.width(),
		elemheight = elem.height();
		var params = getdeadcenter(elemwidth, elemheight);
		/*var left = (screenwidth/2 - elemwidth/2),
		top = (screenheight/2 - elemheight/2);
		if(top<0)top='10px';
		if(left<0)left=0;*/
		elem.css({'left':params[0], 'top':params[1]});
		
	},
	getdeadcenter=  function(Xwidth,Yheight) {
		// First, determine how much the visitor has scrolled

		var scrolledX, scrolledY;
		if( self.pageYoffset ) {
		scrolledX = self.pageXoffset;
		scrolledY = self.pageYoffset;
		} else if( document.documentElement && document.documentElement.scrollTop ) {
		scrolledX = document.documentElement.scrollLeft;
		scrolledY = document.documentElement.scrollTop;
		} else if( document.body ) {
		scrolledX = document.body.scrollLeft;
		scrolledY = document.body.scrollTop;
		}

		// Next, determine the coordinates of the center of browser's window

		var centerX, centerY;
		if( self.innerHeight ) {
		centerX = self.innerWidth;
		centerY = self.innerHeight;
		} else if( document.documentElement && document.documentElement.clientHeight ) {
		centerX = document.documentElement.clientWidth;
		centerY = document.documentElement.clientHeight;
		} else if( document.body ) {
		centerX = document.body.clientWidth;
		centerY = document.body.clientHeight;
		}

		// Xwidth is the width of the div, Yheight is the height of the
		// div passed as arguments to the function:
		var leftoffset = scrolledX + (centerX - Xwidth) / 2;
		var topoffset = scrolledY + (centerY - Yheight) / 2;
		// The initial width and height of the div can be set in the
		// style sheet with display:none; divid is passed as an argument to // the function
		return [leftoffset, topoffset];
		},
		get_elem_size = function(elem){
			var elemwidth = elem.width(),
			elemheight = elem.height();
			return [elemwidth, elemheight];
		};
})(jQuery);