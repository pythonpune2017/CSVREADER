var display_error = function(msg, elem) {
  var msg_div = $('<div class="error_msg"><p>'+msg+'</p></div>');
  msg_div.insertAfter(elem).fadeIn('slow').animate({opacity: 1.0}, 5000).fadeOut('slow',function() { msg_div.remove(); });
};
var display_success = function(msg, elem) {
  var msg_div = $('<div class="success_msg"><p>'+msg+'</p></div>');
  msg_div.insertAfter(elem).fadeIn('slow').animate({opacity: 1.0}, 5000).fadeOut('slow',function() { msg_div.remove(); });
};


$(".msg_div3").live('click', function(){
    $(this).parent().css('display','none');
    return false;
});


function getCsrfCookie(name){
	 var cookie = "";
	 var name = name || "csrftoken";
	 var coo_list = document.cookie.split(';');
	 $(coo_list).each(function(index, elem){
	  if(elem.charAt(0)==' ') elem = elem.substring(1,elem.length);
	  if(elem.match(name)){
	   key_value = elem.split("=");
	   cookie=key_value[1];
	  }
	 });
	 return cookie;
	 
	}

function addBlock(settings){
	/*adds the given element to the parent elements passed in settings*/
	var options = {
		elem_to_add: null, // jquery element to add
		parent: null // jquery parent in wich element is to be added
	};
	options = $.extend(options, settings);

	add_to_parent = function(){
		if(options.elem_to_add && options.elem_to_add.length){
			if(options.parent && options.parent.length){
				var div =options.elem_to_add.clone();
				options.parent.append( div);
			}
		}
	}

	add_to_parent();
}


$.fn.web_datepicker = function(){
	$(this).datepicker(
        { dateFormat: 'dd-mm-yy',minDate:0 }
    );
}

$("#datepicker3").datepicker(
        { dateFormat: 'dd-mm-yy',minDate:0 }
);

function webip_select(){
    var speedA = $('select#speedA,select#speedB,select#speedC,select#speedD,select#speedE,select#speedF,.webip_select').selectmenu();
}

function bindSelectBox(){
	//just for backward compatibility
	webip_select();
}

var adminsearchform = function(){
	/*submit the search form */
	$("input[name|='searchbutton']").live("click", function(){
		$("form[name|='searchform']").submit();
	});
}

var setPerPageVal = function(){
	/* on change in select PerPage set the hidden field in Serach Form*/
	$("select[name|='numOfResults']").bind("change", function(){
		var searchform = $("form[name|='searchform']");
		if(searchform){
			var $numOfResults = searchform.find("input:hidden[name|='numOfResults']");
			$numOfResults.val($(this).val());
		}
	});
}

function perpage(){
	//if there is a keyword set, reloads the page on change of per page select field
	$("select[name|=numOfResults]").change(function () {
		if($('form[name=searchform]').find("input[name=keyword]").val()){
			$("#wait").show();
		    $('form[name=searchform]').submit();
		}
	});
}

function emptyperpage(){
	//reloads the page on change of number of selector, even if there is no serach keyword
	$("select[name|=numOfResults]").change(function () {
			$("#wait").show();
		    $('form[name=searchform]').submit();

	});
}

function reset_search_form(){
	$("#clearfields,#searchclear").live("click", function(){
		$("#wait").show();
		$('form[name=searchform]').find(".webip_select").selectmenu("value", "");
		document.location = document.location.pathname;
	})
}

function setupadvancsearch(){
	var closeimage = wjs_settings.STATIC_URL + "default/images/search-box/arrow.png";
	var openimage = wjs_settings.STATIC_URL + "default/images/search-box/arrow-up.png";
	var closetext="Expand Search Options", opentext="Close Search Options";
	
	$("#adv-search-bttn").toggle(function(){
		//show the advance serach options
		$(this).find("#advsearchtext").html(opentext);
		$(this).find("#advsearchimg img").attr("src", openimage);
		$('#expand_div').show();
		$.cookie("showadvancesearch", true, {path:$(location).attr("pathname")});
	},function(){
		$(this).find("#advsearchtext").html(closetext);
		$(this).find("#advsearchimg img").attr("src", closeimage);	
		$('#expand_div').hide();
		$.removeCookie("showadvancesearch", {path:$(location).attr("pathname")});
	});
	
	if($.cookie("showadvancesearch", {path:$(location).attr("pathname")})=="true"){
		$("#adv-search-bttn").trigger("click");
	}
}


function resize_table_coulmn(){
	$("table").colResizable();
}
    

