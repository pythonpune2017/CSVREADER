/* JS for Manage Keyword page in admin interface
 * */
function add_social_media(){
	$("a#add_social_media").live("click", function(){
		var elem_to_add =  $("div#social_media_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#social_media_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}

function add_video_media(){
	$("a#add_video_media").live("click", function(){
		var elem_to_add =  $("div#video_media_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#video_media_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}


function add_exclude_urls(){
	$("a#add_exclude_domains").live("click", function(){
		var elem_to_add =  $("div#exclude_url_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#exclude_url_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}


function add_industry_keyword(){
	$("a#add_industry_keyword").live("click", function(){
		var elem_to_add =  $("div#industry_keyword_hidden.hidden_block").clone();
		elem_to_add.removeClass("hidden_block");
		elem_to_add.attr("id", "");
		settings = {
				parent: $("div#industry_keyword_values"),
				elem_to_add: elem_to_add
		};
		addBlock(settings)
		return false;
	});
}
function deleteRecord(){
	$("div.j-del-record").live("click", function(){
		$(this).parent().remove();
	})
}


var add_industry_category = function(){
	$("div.j-edit-industry.dns_flopy").live("click", function(){
		var elem = $(this);
		var parent = elem.parent();
		var form_data = parent.find("input").serialize();
		url = elem.find("a").attr("href");
		if(form_data){
			form_data = form_data+ "&"
		}else{
			alert("Please Enter some Value.")
		}
		postdata = form_data + "csrfmiddlewaretoken=" + getCsrfCookie();	
		
		$.ajax({
			url:url, 
			data:postdata, 
			type:"POST",
			success:function(data, textStatus, jqXHR){
				if(data.status){
					elem.removeClass("dns_flopy");
					elem.addClass("pen_edit");
					parent.find("div.pen_edit a").attr("href", data.edit_url);
					var del_elem = parent.find("div.j-del-indus-category")
					del_elem.append($("<a/>").attr("href", data.delete_url));
				}else{
					if(data.msg){
						alert(data.msg);
					}
				}
			},
			error:function(data, textStatus, jqXHR){
			}
		});
	
	});
}

var edit_industry_keyword = function(){
	 /*associates popup model box with edit industry button
	 url : url to call for getting the form
	 */
	 $("div.j-edit-industry.pen_edit").modelBox({
	  close_selector:"div.close",
	  height:'470px',
	  width:'380px',
      onBeforeLoad: function (elem) {
          $("#popup_image").show();
      },
	   onload:function(elem, content_div){
		  url = elem.find("a").attr("href");
		  $.get(url, function(data, textStatus, jqXHR){
				content_div.html(data);
				$("#popup_image").hide();
			});
	  } 
	 });
}

var update_industry_keywords=function(){
	$(':input[name^=update_industry_keywords]').live("click", function(event){//[name|="submit_add_user_form"]
		var editform = $("form[name|='edit_industry_keywords']");
		var formdata = editform.serialize();
		if(!url){
			url = editform.attr("action");
		}	  
		var postdata= formdata + "&csrfmiddlewaretoken=" + getCsrfCookie()
		$.ajax({
			url:url,
			type:"POST",
			data: postdata,
			success:function(data, textStatus, jqXHR){
				if(data.status){	
					$("a div.close").trigger("click");
					location.reload();
				}else{
					var html_container = $('#le_model_box').children().first();
					html_container.html(data1.elements);
				}
			},
			error:function(data, textStatus, jqXHR){
				
			}
		});
				
	});
	
}

var delete_industry_category = function(){

	$("div.j-del-indus-category").live("click", function(){
		var elem = $(this);
		var url = elem.find("a").attr("href"),
		postdata = {'csrfmiddlewaretoken': getCsrfCookie()};
		$.ajax({
			type:"POST",
			url:url,
			data : postdata,
			success : function(data, textStatus, jqXHR){
				elem.parent().remove();
			}
		});
	});
}



$(document).ready(function(){
	add_social_media();
	add_video_media();
	add_exclude_urls();
	add_industry_keyword();
	deleteRecord();
	add_industry_category();
	edit_industry_keyword();
	update_industry_keywords();
	delete_industry_category();
});
