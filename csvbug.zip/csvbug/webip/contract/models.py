from django.db import models
from client.models import ClientModel


class Contract(models.Model):
    """
        Maintains trademarks
    """
    
    
    def __unicode__(self):
        return self.id
    
    class Meta:
        permissions = (("view_contract", "Can view contract"),)