from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User,check_password
from django.template import RequestContext
from django.contrib.auth import logout
from django.contrib.auth import login as auth_login
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from webip_auth.form import LoginForm
from webip_auth.form import PasswordResetForm
from webip_auth.form import ResetNewPasswordForm,ChangeUsernameForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm, SetPasswordForm
from django.contrib.auth.views import password_reset,password_reset_done,password_reset_confirm, password_reset_complete
from django.contrib.auth.tokens import default_token_generator
from django.views.decorators.csrf import csrf_protect
from client.models import ClientUser,ClientModel,SubcriptionPlan,ClientUserProfile
from admin_app.models import UserProfileModel
import json
from settings import DEFAULT_FROM_EMAIL,EMAIL_HOST_USER
from django.core.mail import send_mail
from utils.send_mail import SendMail
from django.contrib import messages
from django.template.loader import render_to_string
from datetime import datetime
from django.conf import settings
from django.core.cache import cache
from webip_auth.form import ChangePasswordForm
import ast
from utils.admin_data_info import GetDataInfo
from webip.users.users import ClientUsers
import twitter
@login_required
def home(request, *args, **kwargs):
    context={}
    context["is_selected"] = "curent"
    client_data={}
    ''' get a client information'''
    try:
        client_user_obj=ClientUser.objects.get(user=request.user)
    except:
        redirect_to = reverse("fn_login")
        return HttpResponseRedirect(redirect_to)
    client_data['cname']=client_user_obj.client.name
    user_profile_obj=UserProfileModel.objects.get(user=request.user)
    client_data['mobile']=user_profile_obj.mobile
    client_data['email']=request.user.email
    client_data['phone']=user_profile_obj.phone

    try:
        #get a role and department
        client_userprofile_obj=ClientUserProfile.objects.get(client=client_user_obj)
        client_data['role']=client_userprofile_obj.role
        client_data['department']=client_userprofile_obj.department
    except:
        client_userprofile_obj=None
        client_data['role']='-'
        client_data['department']='-'

#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'add_casedetailmodel':False,'change_casedetailmodel':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list

    ''' get a client Account manager information'''

    account_mgr_ids=client_user_obj.client.accountmangers.values('user__first_name','user__email','user__userprofilemodel__phone','user__userprofilemodel__mobile','user__userprofilemodel__department','user__userprofilemodel__role')

    try:
        # getting time duration in days as per client expiry date
       
        import datetime
        today = (datetime.datetime.now()).date()
        expiry_date = client_user_obj.client.clientsubscription_set.values()
        expiry_date = (expiry_date[0]['expiry_date']).date()
        duration = (expiry_date-today).days
        if int(duration) > 0:
            context['duration'] = int(duration)
        else:
            user = User.objects.get(username=request.user.username)
            try:
                client_obj=ClientModel.objects.get(user=user)
                client_obj.is_active=False
                client_obj.save()
            except:
                pass
            user.is_active = False
            user.save()
            return HttpResponseRedirect('/')
    except:
        context['duration'] = 0


    # logic for check client plan type
    subscription_data = client_user_obj.client.clientsubscription_set.values()
    sub_plan_obj=SubcriptionPlan.objects.get(id=subscription_data[0]['plan_id'])
    planname=sub_plan_obj.plan_type
    if planname in ['free','trial']:
        plan=True
    else:
        plan=False

    context['plan']=plan
    context['obj']=client_data
    context['client_obj']=account_mgr_ids

    home_template=kwargs.get('template')
    if home_template=='fn/FE_home.html':
        subject='Enquiry'
    else:
        subject='Support'

    if request.method=='POST':
        to_list = [request.user.email]
#        to_list = []
        bcc_list = ['priteshm@leosys.in',]
        to_list = ['support@webip.com.au']
        f_obj=SendMail()
        message_text = request.POST.get('textarea')
        message = """<p>Hello %s,</p>
                <p>Your Request for %s has been send Successfully.</p>

                <br></br>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """%(str(request.user.first_name + " "+ request.user.last_name),message_text)
        fixed_text= 'Portal Request by %s'%(request.user.first_name)
        from_email=DEFAULT_FROM_EMAIL

        try :
            f_obj._send_mail(fixed_text, message, from_email, to_list,[],bcc_list, '', content_subtype='html')
#            send_mail('Enquiry', message, settings.EMAIL_HOST_USER, to_list, fail_silently=False)
        except:
            pass
        messages.success(request, 'Your Message has been sent successfully !')
        return render_to_response(kwargs.get("template"),context,RequestContext(request))
    if request.method=='GET':
        pass

    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def twitter_info(request,*args,**kwargs):
#    tweet = cache.get( 'tweet' )
    context={}
    try:
        tweet = twitter.Api().GetUserTimeline( settings.TWITTER_USER )
        for i in tweet:
            i.date = datetime.strptime( i.created_at, "%a %b %d %H:%M:%S +0000 %Y" )
            cache.set('tweet', i, settings.TWITTER_TIMEOUT )
    except:
        tweet=None
    context['tweet']=tweet[0:4]
    #return {"tweet": tweet[0:4]}
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def new_subscription(request,*args, **kwargs):
    context={}
    if request.method == "POST":
        to_list = [request.user.email]
        #bcc_list = ['alerts@webip.com.au','priteshm@leosys.in',,'gauravm@leosys.in']
        bcc_list = ['gauravm@leosys.in','alerts@webip.com.au','priteshm@leosys.in','gauravm@leosys.in']
        f_obj=SendMail()
#        to_list.append(DEFAULT_FROM_EMAIL)
        fixed_text= 'Portal Request by %s'%(request.user.first_name)
        from_email = str(request.user.email)
        subject = request.POST.get('subject')
#        message = request.POST.get('message')
        message = """<p>Hello %s,</p>
                <p>Your Request for New subscription plan has been send Successfully.</p>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """%(str(request.user.first_name + " "+ request.user.last_name))

        try :
#            send_mail(subject, message, from_email, to_list, fail_silently=False)
             f_obj._send_mail(subject, message, from_email, to_list,[],bcc_list,'', content_subtype='text')
        except Exception,e:
            print "errors",str(e)
            #pass
        messages.success(request, 'Your request for new subscription has been sent successfully !')
        #return render_to_response(kwargs.get("template"),context,RequestContext(request))
        redirect_to = reverse("client_home_page")
        return HttpResponseRedirect(redirect_to)
    return render_to_response(kwargs.get("template"),context,RequestContext(request))


#
#def profile(request, *args, **kwargs):
#    context={}
#    data_dict = {}
#    context['email']=request.user.email
#    if request.method == "GET":
#
#        data_dict = {'Email':request.user.email,'Username':request.user.username}
#        userchangeform=ChangeUsernameForm(data_dict)
#
#        context['changeusernameform']=userchangeform
#        change_password_form = ChangePasswordForm()
#        context['changepasswordform'] = change_password_form
#
#    if request.method == "POST":
#
#
#        change_password_form= ChangePasswordForm(request.POST)
#        if change_password_form.is_valid():
#            currentpassword = ast.literal_eval(change_password_form.cleaned_data.get('currentpassword'))[0]
#            newpassword = ast.literal_eval(change_password_form.cleaned_data.get('newpassword'))[0]
#            confirmpassword = ast.literal_eval(change_password_form.cleaned_data.get('confirmpassword'))[0]
#
#            if request.user:
#                #verify current password
#                if request.user.check_password(currentpassword):
#                    request.user.set_password(newpassword.strip())
#                    request.user.save()
#                    messages.success(request, 'Password resets successfully !')
#                    changepasswordform = ChangePasswordForm()
#                    response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#                    data_dict['status']=True
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#        else:
#            context['changepasswordform'] = change_password_form
#            response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#            data_dict['status']=False
#            data_dict['html']= response
#            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#
#    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def myaccount(request, *args, **kwargs):
    """Render the Myaccount Backend page"""
    context={}
    data_dict = {}
    context['email']=request.user.email
    if request.method == "GET":

        data_dict = {'Email':request.user.email,'Username':request.user.username}
        userchangeform=ChangeUsernameForm(data_dict)

        context['changeusernameform']=userchangeform
        change_password_form = ChangePasswordForm()
        context['changepasswordform'] = change_password_form


    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def change_user(request, *args, **kwargs):
    """ Render Backend  Change Username-MyAccount profile page"""

    context={}
    data_dict = {}
    context['email']=request.user.email
    if request.method == "GET":
        data_dict = {'Username':request.user.username}
        userchangeform=ChangeUsernameForm(data_dict)
        context['changeusernameform']=userchangeform

    if request.method == "POST":
        change_password_form = {}

        userchangeform=ChangeUsernameForm(request.POST)
        if userchangeform.is_valid():
            user = User.objects.get(id=request.user.id)
            user.username=userchangeform.cleaned_data['Username']
            user.save()
            messages.success(request, 'Username resets successfully !')
            context['status']=True

    context['changeusernameform']=userchangeform
    return render_to_response('webip_auth/change_username.html',context,RequestContext(request))

@login_required
def change_password(request, *args, **kwargs):
    """ Render Backend  Change password MyAccount profile page"""

    context={}
    data_dict = {}

    change_password_form = ChangePasswordForm()
    if request.method == "GET":
        context['changepasswordform'] = change_password_form

    if request.method =="POST":
        request_dict = dict (zip(request.POST.keys(),request.POST.values()))
        # temp fix , added user to reqeust dict
        request_dict['user'] = request.user
        change_password_form= ChangePasswordForm(request_dict)
        if change_password_form.is_valid():

            #currentpassword = ast.literal_eval(change_password_form.cleaned_data.get('currentpassword'))[0]
            #newpassword = ast.literal_eval(change_password_form.cleaned_data.get('newpassword'))[0]
            #confirmpassword = ast.literal_eval(change_password_form.cleaned_data.get('confirmpassword'))[0]

            currentpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('currentpassword')))
            newpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('newpassword')))
            confirmpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('confirmpassword')))

            if request.user:
                #verify current password
                if request.user.check_password(currentpassword):
                    request.user.set_password(newpassword.strip())
                    request.user.save()
                    messages.success(request, 'Password resets successfully !')
                    context['message'] = "Password resets successfully !"
                    context['status']=True
                    response=render_to_string('webip_auth/change_userpassword.html',context,RequestContext(request))
                    #return HttpResponse(json.dumps(data_dict),mimetype="application/json")
        else:
            context['message'] = "Errors while changing password!"
            context['status'] = False
            context['changepasswordform'] = change_password_form
            response=render_to_string('webip_auth/change_userpassword.html',context,RequestContext(request))
        dict_obj={}
        dict_obj['status']=context['status']
        dict_obj['message']=context['message']
        dict_obj['elements']= response
        return HttpResponse(json.dumps(dict_obj),mimetype="application/json")
    return render_to_response('webip_auth/change_userpassword.html',context,RequestContext(request))

#    context['changepasswordform']=change_password_form
#    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#    return render_to_response(kwargs.get("template"),context,RequestContext(request))


#login_required
#def profile(request, *args, **kwargs):
#    context={}
#    data_dict = {}
#    context['email']=request.user.email
#    if request.method == "GET":
#
#        data_dict = {'Email':request.user.email,'Username':request.user.username}
#        userchangeform=ChangeUsernameForm(data_dict)
#
#        context['changeusernameform']=userchangeform
#        change_password_form = ChangePasswordForm()
#        context['changepasswordform'] = change_password_form
#
#    if request.method == "POST":
#        import pdb
#        pdb.set_trace()
#        change_password_form = {}
#
#        username_changeform=ChangeUsernameForm(request.POST)
#        if username_changeform.is_valid():
#            print "USERNAME FORM IS VALID"
#            user = User.objects.get(id=request.user.id)
#            user.username=username_changeform.cleaned_data['Username']
#            user.save()
#            messages.success(request, 'Username resets successfully !')
#            changeusernameform=ChangeUsernameForm()
#            response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#            data_dict['status']=True
#            data_dict['html']= response
#            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#
#        else:
#            username_changeform=ChangeUsernameForm()
#            context['changeusernameform'] = username_changeform
#            response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#            data_dict['status']=False
#            data_dict['html']= response
#            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#
#
#        change_password_form= ChangePasswordForm(request.POST)
#        if change_password_form.is_valid():
#            currentpassword = ast.literal_eval(change_password_form.cleaned_data.get('currentpassword'))[0]
#            newpassword = ast.literal_eval(change_password_form.cleaned_data.get('newpassword'))[0]
#            confirmpassword = ast.literal_eval(change_password_form.cleaned_data.get('confirmpassword'))[0]
#
#            if request.user:
#                #verify current password
#                if request.user.check_password(currentpassword):
#                    request.user.set_password(newpassword.strip())
#                    request.user.save()
#                    messages.success(request, 'Password resets successfully !')
#                    changepasswordform = ChangePasswordForm()
#                    response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#                    data_dict['status']=True
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#        else:
#            context['changepasswordform'] = change_password_form
#            response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#            data_dict['status']=False
#            data_dict['html']= response
#            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#
#    return render_to_response(kwargs.get("template"),context,RequestContext(request))




#def profile1(request, *args, **kwargs):
#    context={}
#    data_dict = {}
#
#    if request.method == "GET":
#
#        userchangeform=ChangeUsernameForm()
#        context['changeusernameform']=userchangeform
#
#    if request.method == "POST":
#        import pdb
#        pdb.set_trace()
#
#        change_password_form = {}
#        data_dict_obj = {}
#        data_dict_obj.update(request.POST)
#        data_dict_obj.update({'user':request.user})
#        userchangeform= ChangeUsernameForm(data_dict_obj)
#        if userchangeform.is_valid():
#            currentpassword = ast.literal_eval(change_password_form.cleaned_data.get('currentpassword'))[0]
#            newpassword = ast.literal_eval(change_password_form.cleaned_data.get('newpassword'))[0]
#            confirmpassword = ast.literal_eval(change_password_form.cleaned_data.get('confirmpassword'))[0]
#
#            if request.user:
#                #verify current password
#                if request.user.check_password(currentpassword):
#                    request.user.set_password(newpassword.strip())
#                    request.user.save()
#                    messages.success(request, 'Password resets successfully !')
#                    changepasswordform = ChangePasswordForm()
#                    response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#                    data_dict['status']=True
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#        else:
#            context['changepasswordform'] = change_password_form
#            response = render_to_string("webip_auth/BE_MyAccount.html",context,RequestContext(request))
#            data_dict['status']=False
#            data_dict['html']= response
#            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
#
#    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def domain_pageunderconstruction(request,*args, **kwargs):
    context={}
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def trademark_pageunderconstruction(request,*args, **kwargs):
    context={}

#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def contracts_pageunderconstrunction(request,*args, **kwargs):
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def infringement_pageunderconstrunction(request,*args, **kwargs):
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def help_pageunderconstrunction(request,*args, **kwargs):
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def controlpanel(request,*args, **kwargs):
    context={}
    obj =  GetDataInfo()
    data_dict = obj.main()
    context['data_dict'] = data_dict
    context["is_selected"] = "curent"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))
