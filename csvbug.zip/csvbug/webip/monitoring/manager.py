'''
Created on Feb 6, 2012

@author: arun
'''

from monitoring.models import Keyword, KeywordsCategory

class MonitoringManager:
    
    def save_keywords(self, data):
        """
            save all the keywords as per there categorization
            @data: dict with categoried data
        """
       
        category_map = {"social_media": KeywordsCategory.objects.get(code="social_media"),
                        "video_media": KeywordsCategory.objects.get(code="video_media"), 
                        'offensive': KeywordsCategory.objects.get(code="offensive"),
                        'exclude_domains': KeywordsCategory.objects.get(code="exclude_domains")}
        
        def delete_extra_keywords(exclude_list):
            """
                deletes all the extra keywords from which are in category listed by category_map.keys()
                @exclude_list: keywords to exculde from delete
            """
            keywords = Keyword.objects.filter(category__in = category_map.values())
            keywords.exclude(name__in = exclude_list).delete()
            
        
        current_industry=data.getlist('industry_category')[1:]
        
        all_values = []
        for key in data.keys():
            values=[]
            if key in category_map.keys() and not key in ['offensive','exclude_domains']:
                values = data.getlist(key)
                all_values.extend(values)
                

            if key in category_map.keys() and key=='exclude_domains':
				raw_value = data.get(key)
				values = raw_value.split("\r\n")
				values = [elem for elem in values if elem]
				all_values.extend(values)
                
            if key in category_map.keys() and key=='offensive':
                
                raw_value = data.get(key)
                values = raw_value.split("\r\n")
                values = [elem for elem in values if elem]
                all_values.extend(values)
            
            if key =='categoryid':
                val=data.getlist(key)
                k=0
                for i in val:
                    category_obj=KeywordsCategory.objects.get(id=int(i))
                    category_obj.name=current_industry[k]
                    category_obj.save()
                    k=k+1
                    
            
            for elem in values:
                if elem:
                    keyword, is_created = Keyword.objects.get_or_create(category=category_map.get(key), name=elem)
            delete_extra_keywords(all_values)
           
           
           
