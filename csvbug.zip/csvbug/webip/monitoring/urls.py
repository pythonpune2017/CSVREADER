'''
Created on Feb 6, 2012

@author: arun
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('monitoring.views',
     url(r'^domainmonitoring/$','manage_domain_monitoring',name="manage_domainmonitoring"),
     url(r'^domainmonitoring/import_domain/$','import_domain_monitoring',name="import_domain_monitoring"),     
     url(r'^keywords/$',        'manage_keywords',           name="manage_keywords"),     
     url(r'^keywords/save/$',        'manage_keywords',           name="save_keywords"),  
     url(r'^keywords/industry/add/$',        'add_industry_keyword',           name="add_industry_keyword"), 
     url(r'^keywords/industry/edit/(?P<id>\d+)/$',        'edit_industry_keyword',           name="edit_industry_keyword"),
     url(r'^keywords/industry/delete/(?P<id>\d+)/$',        'delete_industry_category',           name="delete_industry_category"),  
     )
