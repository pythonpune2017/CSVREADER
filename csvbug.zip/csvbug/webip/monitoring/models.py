from django.db import models

# Create your models here.


class KeywordsCategory(models.Model):
    """
        
    """
    name = models.CharField(unique=True, max_length=200,null=False, blank=False)
    code = models.CharField(unique=True, max_length=200, null=False, blank = False,db_index=True, help_text="tech code")
    sub_category = models.ForeignKey('KeywordsCategory', null=True, blank=True)
    
    def __unicode__(self):
        return self.name

	class Meta:
		permissions = ( 
					( "monitoring_brand", "Monitoring Brand" ),
					( "monitoring_domain", "Monitoring Domain" ),
                    ( "monitoring_trademark", "Monitoring Trademark" ),
	   )
		
    def get_parent_category(self):
        """
            returns the oldest parent/ansestor(value of sub_category)   
        """
        abc = self
        while abc.sub_category :
            abc = abc.sub_category
        return abc
        
def get_all_sub_categories(category):
    category = [category]
    categories = []
    def get_categories(category):
        return KeywordsCategory.objects.filter(sub_category=category)

    abc=True
    while(abc):
        category_list=[]
        for elem in category:
            category_list.extend(get_categories(elem))
        if not category_list:
            abc=False
        else:
            category =  category_list
        categories.extend(category_list)
        
    return categories
        
    
class Keyword(models.Model):
    """
    """
    name = models.CharField(max_length=200, null=False, blank = True)
    category = models.ForeignKey(KeywordsCategory)
    
    def __unicode__(self):
        return self.name
    
    def get_keywords_by_main_category(self, category):
        cat = KeywordsCategory.objects.filter(id =category)
#        sub_categories = KeywordsCategory.objects