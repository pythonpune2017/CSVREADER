 # Create your views here.
import os, time, json, re, urllib, math, string,datetime
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from django.contrib.auth.models import User
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
from django.forms.formsets import formset_factory
from django.core.servers.basehttp import FileWrapper

from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from utils.get_instra_domain import InstraDNSManager
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
from utils.paginator import paginate
from utils.get_instra_domain import InstraDomainManager
from domain.fn_manager import FrontEndDomainManager , FrontEndSSLManager
from domain.fn_forms import DomainForm, SSLForm
from webip.client.models import *
from monitoring.models import Keyword, KeywordsCategory
from trademark.models import Trademark
from domain.models import GlobalDomains
from cases.models import CasedetailModel,CaseAttachmentDetails,InfrigementNotesModel,CaseTeamModel,CaseMilestoneModel,CaseTaskModel
from cases.case_manager import CaseManager
from cases.forms import AddCaseForm
from admin_app.models import CountryModel
from webip.domain.models import *
from utils.filewrapper_info import FixedFileWrapper
from utils.trademark_api import TrademarkAPIManager

import types
from utils import getDateObject

TRADEMARK_API = settings.TRADEMARK_API
MEDAI_ROOT = settings.MEDIA_ROOT
TRADEMARK_IMAGE_PATH = settings.TRADEMARK_IMAGE_PATH

@login_required
def monitoring_brand(request,*args, **kwargs):
    """ function to monitor brand """
    
    context={}
    daterestrictval=''
    context["is_selected"] = "curent"
    context['offensive'] = True
    country_obj = CountryModel.objects.all().order_by('country_name')
    context["countries"] = country_obj
    if request.method == "POST":
        include_keyword = request.POST.get('include-keywords')
        exclude_keyword = request.POST.get('exclude-keywords')
        offensive = request.POST.get('offensive')
        country = request.POST.get('country')
        social_media = request.POST.get('social_media')
        video_media = request.POST.get('video_media')
        general_content = request.POST.get('general_content')
        all_content = request.POST.get('all')
        keyword = request.POST.get('keyword')
        keyword1=keyword.replace(' ','+')
        page = request.POST.get('page')
        page = page if page else 1
        daterestricttype = request.POST['daterestrict_type']

        if request.POST['daterestrict_type']:
            if request.POST['daterestrict_type'] == '0':
                current_date=datetime.now()
                cdate=current_date.strftime('%Y%m%d')
                daterestrictval='date:r:'+cdate+':'+cdate
            if request.POST['daterestrict_type'] == '1':
                current_date=datetime.now()
                cdate=current_date.strftime('%Y%m%d')
                yesterdaydate=timedelta(days=-1)
                yesterdaydate=yesterdaydate+current_date
                yesterdaydate=yesterdaydate.strftime('%Y%m%d')
                daterestrictval='date:r:'+yesterdaydate+':'+cdate
            if request.POST['daterestrict_type'] == '2':
                current_date=datetime.now()
                cdate=current_date.strftime('%Y%m%d')
                pastweek=timedelta(weeks=-1)
                pastweekdate=pastweek+current_date
                pastweekdate=pastweekdate.strftime('%Y%m%d')
                daterestrictval='date:r:'+pastweekdate+':'+cdate
            if request.POST['daterestrict_type'] == '3':
                current_date=datetime.now()
                cdate=current_date.strftime('%Y%m%d')
                pastmonth=timedelta(weeks=-4)
                pastmonthdate=pastmonth+current_date
                pastmonthdate=pastmonthdate.strftime('%Y%m%d')
                daterestrictval='date:r:'+pastmonthdate+':'+cdate
            if request.POST['daterestrict_type'] == '4':
                current_date=datetime.now()
                cdate=current_date.strftime('%Y%m%d')
                pastyear=timedelta(weeks=-52)
                pastyeardate=pastyear+current_date
                pastyeardate=pastyeardate.strftime('%Y%m%d')
                daterestrictval='date:r:'+pastyeardate+':'+cdate


        sitesearch = []

        #logic for exclude URLS
        exclude_url_list=''
        exclude_url_object = Keyword.objects.filter(category__name='exclude_domains')
        exclude_url_list = [str(i['name']) for i in exclude_url_object.values()]
        excludeurl='+'.join(exclude_url_list[0:8])
       
        
        if all_content:
            #if select all, then search for all contents including social & video media
            social_media_object = Keyword.objects.filter(category__name='social_media')
            social_media_list = [str(i['name']) for i in social_media_object.values()]
            sitesearch.extend(social_media_list)
            video_media_object = Keyword.objects.filter(category__name='video_media')
            video_media_list = [str(i['name']) for i in video_media_object.values()]
            sitesearch.extend(video_media_list)
            
        else:
            if social_media:
                social_media_object = Keyword.objects.filter(category__name='social_media')
                social_media_list = [str(i['name']) for i in social_media_object.values()]
                sitesearch.extend(social_media_list)
            if video_media:
                video_media_object = Keyword.objects.filter(category__name='video_media')
                video_media_list = [str(i['name']) for i in video_media_object.values()]
                sitesearch.extend(video_media_list)
        include_terms = ''
        include_keywords = ''
        exclude_keywords = ''
        include_keywords_list=''
        offensive_keyword_list=''

        try:
            if offensive:
                offensive_keywords = []
                keyword_object = Keyword.objects.filter(category__code='offensive')
                offensive_keywords = [ str(i['name']) for i in keyword_object.values()]
                include_terms = '+'.join(offensive_keywords)
#                include_terms = include_terms.replace('+','+OR+')
                offensive_keyword_list=include_terms
#                offensive_keyword_list.strip('+')
               
        except:
            include_terms = ''

        try:
            if include_keyword:
                include_keywords=include_keyword.split(',')
                include_keywords = '+'.join(include_keywords)
                include_keywords_list=include_keywords
        except:
            include_keywords = ''

        try:
            if exclude_keyword:
                #exclude_keywords = '+'.join(exclude_keyword.rsplit())
                exclude_keywords='+'.join(exclude_keyword.rsplit())
                excludeurl=excludeurl+'+'+exclude_keywords
        except:
            exclude_keywords = ''

        if include_keyword or include_terms:
            include_keywords = str(include_keywords)+'+'+include_terms
            include_keywords = include_keywords.strip('+')
        else:
            include_keywords = include_terms
       
        try:
            if keyword:
                result_dict = []
                exclude_result_dict=[]
                try:
                    client_search_limit=''
                    #currect_count=0
#                    print "in the search limit start"
                    client_id = FrontEndDomainManager().get_client_id(request.user.id)
#                    print "clientid",client_id
                    client_obj=FrontEndDomainManager().get_client_obj(client_id)
#                    print "client_obj",client_obj
                    if client_obj and client_obj.searchlimit:
#                        print "in the if"
                        client_search_limit=int(client_obj.searchlimit)
                        searchlimitdate=client_obj.searchlimitdate
                        current_date=datetime.now()
                        diff_date=current_date-searchlimitdate
                        if diff_date.days == 0:
                            current_count=client_obj.searchlimitcount
                        else:
                            client_obj.searchlimitcount=0
                            client_obj.searchlimitdate=current_date
                            client_obj.save()

                        current_count=client_obj.searchlimitcount
                        if current_count >= client_search_limit:
                            messages.warning(request,"Your Accounts search limit has been exceed")
                            return render_to_response(kwargs.get("template"),context,RequestContext(request))
                        else:
                            current_count=current_count+1
                            client_obj.searchlimitcount=current_count
                            client_obj.save()
#                            print "in the search limit end"
                    else:
#                        print "-----in the else"
                        pass

                except Exception , e:
                    print "in the exception-----------:",str(e)
                    client_id=None
                    client_obj=None

            
#                if sitesearch:
#                    for site in sitesearch:
#                        result =''
#                        input_set = {'keyword':keyword, 'page':page, 'include_keyword':include_keywords, 'exclude_keyword':exclude_keywords,'country':country,'sitesearch':site,'daterestrictval':daterestrictval,'excludeurl':excludeurl,'client':client_obj}
#                        result, current, cur_page, start, end  = google_search(input_set)
#                        result_dict.extend(result)
#
#                else:
#                    input_set = {'keyword':keyword, 'page':page, 'include_keyword':include_keywords, 'exclude_keyword':exclude_keywords,'country':country,'daterestrictval':daterestrictval,'excludeurl':excludeurl,'client':client_obj}
#                    result, current, cur_page, start, end  = google_search(input_set)
#                    result_dict.extend(result)
                if sitesearch:
                    for site in sitesearch:
                        result =''
                        input_set = {'keyword':keyword1, 'page':page, 'include_keyword':include_keywords, 'exclude_keyword':exclude_keywords,'country':country,'sitesearch':site,'daterestrictval':daterestrictval,'excludeurl':excludeurl,'client':client_obj,'offensive_list':offensive_keyword_list,'include_list':include_keywords_list}
                        result, current, cur_page, start, end  = google_search(input_set)
                        result_dict.extend(result)

                else:
                    input_set = {'keyword':keyword1, 'page':page, 'include_keyword':include_keywords, 'exclude_keyword':exclude_keywords,'country':country,'daterestrictval':daterestrictval,'excludeurl':excludeurl,'client':client_obj,'offensive_list':offensive_keyword_list,'include_list':include_keywords_list}
                    result, current, cur_page, start, end  = google_search(input_set)
                    result_dict.extend(result)

               
                result_dict1=[]
                for x in result_dict:
                    if x not in result_dict1:
                        result_dict1.append(x)
                print "\n\n"
#                print "*"*100
#                print input_set
#                print "*"*100
#                print "\n\n"
                
                #result_dict1=list(set(result_dict))
                if not result_dict1:
                    messages.warning(request,"No Results found !")
                context['search_results'] = result_dict1
                context['keyword'] = keyword
                context['offensive'] = offensive if offensive else False
                context['social_media'] = social_media if social_media else False
                context['video_media'] = video_media if video_media else False
                context['general_content'] = general_content if general_content else False
                context['all_content'] = all_content if all_content else False
                context['start'] = start
                context['end'] = end
                context['cur_page'] = cur_page
                context['current'] = int(current)
                context['include_keyword'] = include_keyword if include_keyword else ''
                context['exclude_keyword'] = exclude_keyword if exclude_keyword else ''
                context['country'] = country if country else ''
                context['daterestrict_type'] = daterestricttype
#                context['dateval'] = dateval
        except Exception, e:
                print "Search failed: %s" % e

    #context['keyword'] = keyword
    context["active_sub_menu"] = "curnt"
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def monitoring_domain(request,*args,**kwargs):
    """
        function to monitor domain
    """
    context={}
    try:
        client_obj=request.user.clientmodel
    except:
        client_obj=None
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    usr_permisssions = request.user.user_permissions.all()
#    for i in usr_permisssions:
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"

    request.method = "GET" if request.method == "POST" else "GET"
    if request.method == "GET":
        per_page = request.GET.get('numOfResults',25)
        cur_page = int(request.GET.get('page', 1))
        keyword = request.GET.get('keyword','')
        include_keyword = request.GET.get('include-keyword')
        exclude_keyword = request.GET.get('exclude-keyword')
        associated_keyword = request.GET.get('associated_keyword')
        offensive = request.GET.get('offensive')
        exclude_hyphen = request.GET.get('exclude-hyphen')
        exclude_domain = request.GET.get('exclude-domain')
        left_anchor = request.GET.get('left-anchor',False)
        if left_anchor == 'on':left_anchor = True
        right_anchor = request.GET.get('right-anchor',False)
        if right_anchor == 'on':right_anchor = True
        exclude_numeric = request.GET.get('exclude-numeric')
        spaces = request.GET.get('spaces', 'com')
        order=request.GET.get('order')
        try :
#            keywordscategory = Keyword.objects.filter(category__name='industry_keyword')
            keywordscategory = KeywordsCategory.objects.filter(sub_category__name='industry_keyword').order_by('code')
            context['keywords'] = keywordscategory
        except:
            context['keywords'] = None
        context['spaces'] = spaces

        if spaces in ['comau','netau']:
            domain_list, domain_list_new, temp_lst, new_list = [],[],[],[]
#            global_domain_object = GlobalDomains.objects.all()

            if keyword:
                domain_type = 1 if spaces == 'comau' else 2
                global_domain_object = GlobalDomains.objects.filter(domain_type=domain_type, name__icontains=keyword).values('name')

                #-- Do changes For Domain Type.
#                global_domain_object_list = global_domain_object.filter(domain_type=domain_type).values('name')

                status_instra,list_domain,domain_list_new = [],[],[]

                if not isinstance(global_domain_object, list):
                    global_domain_object_list = list(global_domain_object)

                if offensive:
                    keyword_object = Keyword.objects.filter(category__code='offensive').values('name')
                    keyword_object = list(keyword_object)
                    offensive_keywords = [str(i['name']) for i in keyword_object]
                else:
                    offensive_keywords = []

                if exclude_domain:
                    domain_object = Domain.objects.filter(client__id=request.user.clientmodel.id).values('name')
                    domain_object = list(domain_object)
                    user_domain_list_new = [i['name'] for i in domain_object]
                else:
                    user_domain_list_new = []

                if associated_keyword:
                    associated_keyword_object = Keyword.objects.filter(category__code=associated_keyword).values('name')
                    associated_keyword_object = list(associated_keyword_object)
                    associated_keywords = [str(i['name']) for i in associated_keyword_object]

                if 1:
                    domain_list = [d['name'] + '.au' for d in global_domain_object_list]
                    info_dict = InstraDomainManager().check_domain_available(domain_list)

                    for i in info_dict[1]:
                        try:
                            if i['status'] == 'taken':
                                status_instra.append(i)
                        except:
                            pass

                    for stat in status_instra:
                        domain_dict={}
                        domain_name = stat['domain']

                        if offensive:
                            for t in offensive_keywords:
                                if not t in domain_name:
                                   domain_name = ''
                                   break

                        if exclude_domain and domain_name:
                            for i in user_domain_list_new:
                                if i == domain_name:
                                    domain_name = ''
                                    break

                        if exclude_hyphen and domain_name:
                            domain_name = '' if '-' in domain_name else domain_name

                        if exclude_numeric and domain_name:
                            for t in range(10):
                                if str(t) in domain_name:
                                    domain_name = ''
                                    break

                        if left_anchor and domain_name:
                            if not domain_name.startswith(keyword):
                                domain_name = ''

                        if right_anchor and domain_name:
                            value = os.path.splitext(domain_name)
                            value = os.path.splitext(value[0])
                            if not value[0].endswith(keyword):
                               domain_name = ''
                    
                        if include_keyword and domain_name:
                            include_keyword_list = include_keyword.rsplit()
                            for t in include_keyword_list:
                                if domain_name.count(t) == 0:
                                    domain_name = ''
                                    break

                        if exclude_keyword and domain_name:
                            exclude_keyword_list = exclude_keyword.rsplit()
                            for i in exclude_keyword_list:
                                if not domain_name.count(i) == 0:
                                    domain_name = ''
                                    break

                        if associated_keyword and domain_name:
                            for i in associated_keywords:
                                if not domain_name.count(associated_keyword) == 0:
                                    domain_name = ''

                        if domain_name:
                            domain_dict['domain'] = domain_name

                            if domain_name not in temp_lst:
                                list_domain.append(domain_dict)

                if not list_domain and keyword:
                    messages.warning(request,"No Results found.")

#                print "*"*100
#                print new_list
#                print "*"*100
                context['domain_list'] = list_domain
            else:
                context['domain_list'] = []
                messages.warning(request,"No Results found.")

        else:
            if keyword:
                domain_type = getSpacesValue(spaces)
                global_domain_object = GlobalDomains.objects.filter(domain_type=domain_type, name__icontains=keyword)\
                .select_related('name','domain_type','id','casedetailmodel__id')\
                .values('name','domain_type','id','casedetailmodel__id', 'casedetailmodel__client')

                if exclude_hyphen:
                    global_domain_object = global_domain_object.exclude(name__icontains='-')

                if exclude_numeric:
                    for t in range(10):
                        global_domain_object = global_domain_object.exclude(name__icontains=t)

                if left_anchor:
                    global_domain_object = global_domain_object.filter(name__istartswith=keyword)

                if right_anchor:
                    if spaces:
                        spaces = spaces.upper() if spaces.islower() else spaces.lower()
                        key = keyword + '.' + spaces
                    else:
                        key = keyword
                    global_domain_object = global_domain_object.filter(name__iendswith=key)

                if include_keyword:
                    include_keyword_list = include_keyword.rsplit()
                    tstr = ''
                    for t in include_keyword_list:
                          tstr += " | Q(name__icontains = '%s')" %(str(t))
                          tstr = tstr.lstrip(' | ')
                    if tstr:
                        global_domain_object = global_domain_object.filter(eval(tstr))

                if exclude_keyword:
                    exclude_keyword_list = exclude_keyword.rsplit()
                    for i in exclude_keyword_list:
                        global_domain_object = global_domain_object.exclude(name__icontains=i)

                if associated_keyword:
                    associated_keyword_object = Keyword.objects.filter(category__code=associated_keyword).values('name')
                    associated_keyword_object = list(associated_keyword_object)
                    associated_keywords = [str(i['name']) for i in associated_keyword_object]
                    tstr = ''
                    for t in associated_keywords:
                          tstr += " | Q(name__icontains = '%s')" %(str(t))
                          tstr = tstr.lstrip(' | ')
                    if tstr:
                        global_domain_object = global_domain_object.filter(eval(tstr))


                if offensive:
                    offensive_keywords = []
                    keyword_object = Keyword.objects.filter(category__code='offensive').values('name')
                    offensive_keywords = [str(i['name']) for i in keyword_object]
                    tstr = ''
                    for t in offensive_keywords:
                          tstr += " | Q(name__icontains = '%s')" %(str(t))
                          tstr = tstr.lstrip(' | ')
                    if tstr:
                          global_domain_object = global_domain_object.filter(eval(tstr))

                if exclude_domain:
                    domain_object = Domain.objects.filter(client__id=request.user.clientmodel.id).values('name')
                    domain_list = [ i['name'] for i in domain_object]
                    global_domain_object = global_domain_object.exclude(name__in=domain_list)

                sort_by = "name" if request.GET.get('sort') == 'domain' else ''
                global_domain_object = sortQuerySet(sort_by, order, global_domain_object)

    #            global_domain_object = global_domain_object.values('id', 'name', 'casedetailmodel__id', 'casedetailmodel__name')
    #            count=global_domain_object.count()
    #            if per_page=='ALL':
    #                 per_page=count

#                if keyword or include_keyword or exclude_keyword or associated_keyword \
#                     or offensive or exclude_hyphen or exclude_domain or left_anchor \
#                     or right_anchor or exclude_numeric or spaces:
#                        global_domain_object = global_domain_object
            else:
                global_domain_object = []

#            paginated = paginate(global_domain_object, cur_page, int(per_page))
            context['global_domain_object'] = list(global_domain_object[:1000])

            try:
                qs = global_domain_object[0]
            except:
                qs = None
            if not qs and keyword:
                messages.warning(request,"No Results found")


        context['include_keyword'] = include_keyword if include_keyword else ''
        context['exclude_keyword'] = exclude_keyword if exclude_keyword else ''
        context['associated_keyword'] = associated_keyword if associated_keyword else ''
        context['keyword'] = keyword if keyword else ''
        context['offensive'] = offensive if offensive else False
        context['exclude_hyphen'] = exclude_hyphen if exclude_hyphen else False
        context['exclude_numeric'] = exclude_numeric if exclude_numeric else False
        context['exclude_domain'] = exclude_domain if exclude_domain else False
        context['left_anchor'] = left_anchor if left_anchor else False
        context['right_anchor'] = right_anchor if right_anchor else False
        context['order']="asc" if order=="desc" else "desc"
        context['numOfResults'] = per_page
        context['client']=client_obj
    return render_to_response(kwargs.get("template"),context, RequestContext(request))

def sortQuerySet(sort_by, order, model_instance):
    """
    """
    if sort_by:
        if order=='asc':
            model_instance = model_instance.order_by(str(sort_by))
        else:
            model_instance = model_instance.order_by("-" + str(sort_by))
    return model_instance

def getSpacesValue(spaces):
    """
    [(1,'com'), (2,'net'), (3,'biz'), (4,'info'), (5,'org'), (6,'comau'), (7,'netau')]
    """
    domain_types = settings.DOMAIN_TYPES
    return [i[0] for i in domain_types if i[1] == spaces][0]

@login_required
def monitoring_trademark(request,*args, **kwargs):
    """ function to monitor trademark """
    context={}
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "currnt"
    
    keyword = request.REQUEST.get('keyword')
    include_keyword = request.REQUEST.get('include-keyword')
    exclude_keyword = request.REQUEST.get('exclude-keyword')
    tclass = request.REQUEST.get('tclass')
    per_page = request.REQUEST.get('numOfResults',25)
    cur_page = int(request.REQUEST.get('page', 1))
    order=request.REQUEST.get('order')
    
    include_keyword_list, exclude_keyword_list, tclass_keyword_list=[],[], []
    tclass_list, keyword_list, include_list, exclude_list=[], [], [], []
    
    client_obj = request.client
    if TRADEMARK_API == True:
        t_api_obj=TrademarkAPIManager()
        if include_keyword:
            include_keyword_list = include_keyword.rsplit(',')
            include_keyword_list.append(keyword)
            include_list= '|'.join(include_keyword_list)
        if exclude_keyword:
            exclude_keyword_list = exclude_keyword.rsplit(',')
            #exclude_keyword_list.append(keyword)
            exclude_list= '|'.join(exclude_keyword_list)
        if tclass:
            tclass_keyword_list = tclass.rsplit(',')
            tclass_list=','.join(tclass_keyword_list)
            #tclass_keyword_list.append(keyword)
            #tclass_list='|'.join(tclass_keyword_list)
            
#                merge_list=include_keyword_list+exclude_keyword_list
#                merge_list.append(keyword)
#                keyword_list= '|'.join(merge_list)
        
        trademark_object=t_api_obj.get_tradmarkInfo(keyword,include_list,exclude_list,tclass_list,client_obj,per_page)                        
#        if keyword or include_keyword or exclude_keyword or tclass:
#            if not trademark_object:
#                messages.warning(request, "No Records found !")
        
    else:
        trademark_object = Trademark.objects.filter(client=None)
        if keyword:
            trademark_object = trademark_object.filter(name__icontains=keyword)
        if include_keyword:
            include_keyword_list = include_keyword.rsplit()
            tstr = ''
            for t in include_keyword_list:
                tstr += " | Q(name__icontains = '%s')" %(str(t))
            tstr = tstr.lstrip(' | ')
            if tstr:
                trademark_object = trademark_object.filter(eval(tstr))
        if exclude_keyword:
            exclude_keyword_list = exclude_keyword.rsplit()
            tstr = ''
            for t in exclude_keyword_list:
                tstr += " | Q(name__icontains = '%s')" %(str(t))
            tstr = tstr.lstrip(' | ')
            if tstr:
                trademark_object = trademark_object.exclude(eval(tstr))
        if tclass:
            tclass_list = tclass.rsplit()
            tstr = ''
            for t in tclass_list:
                tstr += " | Q(t_class = '%s')" %(str(t))
            tstr = tstr.lstrip(' | ')
            if tstr:
                trademark_object = trademark_object.filter(eval(tstr))
                

        sort_by = request.GET.get('sort')
        if sort_by:
            order_field_dict = {"tmnumber": "number", "tmname": "name", "tmclass": "t_class", "tmstatus": "status"}
            sort_field = order_field_dict[sort_by]
            if not order=="asc":
                sort_field = "-" + sort_field
            trademark_object = trademark_object.order_by(sort_field) 
                
        trademark_object = trademark_object.values('image','id', 'number', 'name', 't_class', 'status', 't_type', 'casedetailmodel__id','casedetailmodel__client','casedetailmodel__name')
        sys_path=TRADEMARK_IMAGE_PATH
        for i in trademark_object:
            i['image_exists'] = os.path.exists(sys_path+i['image'])


    if keyword or include_keyword or exclude_keyword or tclass:
        if not trademark_object:
            messages.warning(request, "No Records found !")

                 
    paginated = paginate(trademark_object, cur_page, int(per_page))
    
    context['keyword'] = keyword if keyword else ''
    context['include_keyword'] = include_keyword if include_keyword else ''
    context['exclude_keyword'] = exclude_keyword if exclude_keyword else ''
    context['tclass'] = tclass if tclass else ''
    context['objects'] = paginated
#        context['image_url'] = MEDIA_ROOT
    context['order']="asc" if order=="desc" else "desc"
    context['client']=client_obj
    
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

#    
#    if request.method == "GET":
#        if TRADEMARK_API == True:
#    
#            if keyword:
#                trademark_search=keyword
#                try:
#                    client_id = FrontEndDomainManager().get_client_id(request.user.id)
#                    client_obj=FrontEndDomainManager().get_client_obj(client_id)
#                except:
#                    client_id=None
#                    client_obj=None
#                t_api_obj=TrademarkAPIManager()
#                if include_keyword:
#                    include_keyword_list = include_keyword.rsplit(',')
#                    include_keyword_list.append(keyword)
#                    include_list= '|'.join(include_keyword_list)
#                if exclude_keyword:
#                    exclude_keyword_list = exclude_keyword.rsplit(',')
#                    #exclude_keyword_list.append(keyword)
#                    exclude_list= '|'.join(exclude_keyword_list)
#                if tclass:
#                    tclass_keyword_list = tclass.rsplit(',')
#                    tclass_list=','.join(tclass_keyword_list)
#                    #tclass_keyword_list.append(keyword)
#                    #tclass_list='|'.join(tclass_keyword_list)
#                    
##                merge_list=include_keyword_list+exclude_keyword_list
##                merge_list.append(keyword)
##                keyword_list= '|'.join(merge_list)
#                
#                response_data=t_api_obj.get_tradmarkInfo(trademark_search,include_list,exclude_list,tclass_list,client_obj,per_page)                        
#                if keyword or include_keyword or exclude_keyword or tclass:
#                        if not response_data:
#                            messages.warning(request, "No Records found !")
#                
#                if keyword or include_keyword or exclude_keyword or tclass :
#                    response_data = response_data
#                else:
#                    response_data = []
#            else:
#                response_data = []
#            paginated = paginate(response_data, cur_page, int(per_page))
#            context['order']="asc" if order=="desc" else "desc"
#            context['keyword'] = keyword if keyword else ''
#            context['include_keyword'] = include_keyword if include_keyword else ''
#            context['exclude_keyword'] = exclude_keyword if exclude_keyword else ''
#            context['tclass'] = tclass if tclass else ''
#            context['objects'] = paginated
#            context["is_selected"] = "curent"
#            context["active_sub_menu"] = "currnt"
#            return render_to_response(kwargs.get("template"),context,RequestContext(request))
#    
#        else:
#        
#            try:
#                client_obj=request.user.clientmodel
#            except:
#                client_obj=None
#            
#            
#            if request.method == "POST":
#                request.method="GET"
#                #pass
#        
#            if request.method == "GET":
#                keyword = request.GET.get('keyword')
#                include_keyword = request.GET.get('include-keyword')
#                exclude_keyword = request.GET.get('exclude-keyword')
#                tclass = request.GET.get('tclass')
#                per_page = request.GET.get('numOfResults',25)
#                cur_page = int(request.GET.get('page', 1))
#                trademark_object = Trademark.objects.filter(client=None)
#                
#                if keyword:
#                    trademark_object = trademark_object.filter(name__icontains=keyword)
#                if include_keyword:
#                    include_keyword_list = include_keyword.rsplit()
#                    tstr = ''
#                    for t in include_keyword_list:
#                        tstr += " | Q(name__icontains = '%s')" %(str(t))
#                    tstr = tstr.lstrip(' | ')
#                    if tstr:
#                        trademark_object = trademark_object.filter(eval(tstr))
#                if exclude_keyword:
#                    exclude_keyword_list = exclude_keyword.rsplit()
#                    tstr = ''
#                    for t in exclude_keyword_list:
#                        tstr += " | Q(name__icontains = '%s')" %(str(t))
#                    tstr = tstr.lstrip(' | ')
#                    if tstr:
#                        trademark_object = trademark_object.exclude(eval(tstr))
#                if tclass:
#                    tclass_list = tclass.rsplit()
#                    tstr = ''
#                    for t in tclass_list:
#                        tstr += " | Q(t_class = '%s')" %(str(t))
#                    tstr = tstr.lstrip(' | ')
#                    if tstr:
#                        trademark_object = trademark_object.filter(eval(tstr))
#                order=request.GET.get('order')
#                if request.GET.get('sort') == 'tmnumber':
#                    if order=='asc':
#                        trademark_object = trademark_object.order_by("number")
#                    else:
#                        trademark_object = trademark_object.order_by("-number")
#                elif request.GET.get('sort') == 'tmname':
#                    if order=='asc':
#                        trademark_object = trademark_object.order_by("name")
#                    else:
#                        trademark_object = trademark_object.order_by("-name")
#        
#                elif request.GET.get('sort') == 'tmclass':
#                    if order=='asc':
#                        trademark_object = trademark_object.order_by("t_class")
#                    else:
#                        trademark_object = trademark_object.order_by("-t_class")
#        
#                elif request.GET.get('sort') == 'tmstatus':
#                    if order=='asc':
#                        trademark_object = trademark_object.order_by("status")
#                    else:
#                        trademark_object = trademark_object.order_by("-status")
#                if keyword or include_keyword or exclude_keyword or tclass:
#                    if not trademark_object:
#                        messages.warning(request, "No Records found !")
#                trademark_object = trademark_object.values('image','id', 'number', 'name', 't_class', 'status', 't_type', 'casedetailmodel__id','casedetailmodel__client','casedetailmodel__name')
#                sys_path=TRADEMARK_IMAGE_PATH
#                for i in trademark_object:
#                     i['image_exists'] = os.path.exists(sys_path+i['image'])
#        
#                count=trademark_object.count()
#                if per_page=='ALL':
#                   per_page=count
#        
#                if keyword or include_keyword or exclude_keyword or tclass :
#                    trademark_object = trademark_object
#                else:
#                    trademark_object = []
#                paginated = paginate(trademark_object, cur_page, int(per_page))
#                context['keyword'] = keyword if keyword else ''
#                context['include_keyword'] = include_keyword if include_keyword else ''
#                context['exclude_keyword'] = exclude_keyword if exclude_keyword else ''
#                context['tclass'] = tclass if tclass else ''
#                context['objects'] = paginated
#                context['image_url'] = MEDIA_ROOT
#                context['order']="asc" if order=="desc" else "desc"
#                context['client']=client_obj
#            return render_to_response(kwargs.get("template"),context,RequestContext(request))

def monitoring_trademark_info(request,*args, **kwargs):
    """ function to monitor domain """
    context={}
    
    trademark_info = request.GET.get('trademark_object','')

#    sys_path=TRADEMARK_IMAGE_PATH
#    if trademark_object.image:
#        trademark_object.image_exists= os.path.exists(trademark_object.image.path)
#    else:
#        trademark_object.image_exists=False

    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"
    context["trademark"] = eval(trademark_info) if isinstance(trademark_info,str) or isinstance(trademark_info,unicode) else trademark_info
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

#def google_search(args):
#    """ function to call google search api for keyword """
#    page = args.get('page')
#    keyword = args.get('keyword')
#    sitesearch = args.get('sitesearch')
#    include_keyword = args.get('include_keyword')
#    exclude_keyword = args.get('exclude_keyword')
#    country = args.get('country')
#    daterestrictval=args.get('daterestrictval')
#    excludeurl=args.get('excludeurl')
#    client=args.get('client')
#    offensive_list=args.get('offensive_list')
#    include_list=args.get('include_list')
#    google_key=settings.GOOGLE_API_KEY
#   
#    if sitesearch:
#        url = 'https://www.googleapis.com/customsearch/v1?key='+google_key+'&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&siteSearch='+str(sitesearch)+'&excludeTerms=%s'%excludeurl
#        #url = 'https://www.google.com/cse?key=AIzaSyBycgu-SqRyO0gNR5u6YTJp30WiGUTOD3A&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&siteSearch='+str(sitesearch)+'&excludeTerms=%s'%excludeurl
#    else:
#        url = 'https://www.googleapis.com/customsearch/v1?key='+google_key+'&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&excludeTerms=%s'%excludeurl
#        #url = 'https://www.google.com/cse?key=AIzaSyBycgu-SqRyO0gNR5u6YTJp30WiGUTOD3A&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&excludeTerms=%s'%excludeurl
#
#
#    if include_keyword:
#       url += '&orTerms=' + str(include_keyword)
#    else:
#        url+='&q='+str(keyword)
#
#    if daterestrictval:
#        url+='&sort='+daterestrictval
#    if country:
#       url += '&cr=country'+str(country.upper())
#    
#  
#    print "URL",url
#    data = urllib.urlopen(url).read()
#    results = json.loads(data)
##    if results['error']['code']==403:
##        messages.warning(request,"Your Google Account Daily search limit Exceeded")
##        return render_to_response(kwargs.get("template"),context,RequestContext(request))
#    results =results.values()
#    res_dict = []
#
#    try:
#        start=0; end=0; current=0;
#        try:
#            for value in results[2]:
#
#                try:
#                    casedetailobject = CasedetailModel.objects.get(url=value['link'],client=client)
#                except:
#                    casedetailobject = None
#                if casedetailobject:
#                    tmp = {'description':(value['snippet']).encode("utf8"),'title':(value['title']).encode("utf8"), 'urllink':(value['link']).encode("utf8"), 'keyword':keyword, 'action':'view'}
#                else:
#                    tmp = {'description':(value['snippet']).encode("utf8"),'title':(value['title']).encode("utf8"), 'urllink':(value['link']).encode("utf8"), 'keyword':keyword, 'action':'add'}
#                res_dict.append(tmp)
#        except:
#            pass
#        try:
#            if results[4]['previousPage']:
#                 start = results[4]['previousPage'][0]['startIndex']
#        except:
#            start = 0
#        try:
#            if results[4]['nextPage']:
#                end = results[4]['nextPage'][0]['startIndex']
#        except:
#            end = 0
#        try:
#            if results[4]['request']:
#                current =math.floor(int(results[4]['request'][0]['startIndex'])/10)+1
#                cur_page = math.floor(int(results[4]['request'][0]['startIndex']))
#        except:
#            current = 0
#            cur_page = 1
#    except Exception,e:
#        print "str eerrros",str(e)
#        pass
#    return res_dict, current, cur_page, start, end

def google_search(args):
    """ function to call google search api for keyword """
    page = args.get('page')
    keyword = args.get('keyword')
    sitesearch = args.get('sitesearch')
    include_keyword = args.get('include_keyword')
    exclude_keyword = args.get('exclude_keyword')
    country = args.get('country')
    daterestrictval=args.get('daterestrictval')
    excludeurl=args.get('excludeurl')
    client=args.get('client')
    offensive_list=args.get('offensive_list')
    include_list=args.get('include_list')
    google_key=settings.GOOGLE_API_KEY
    if sitesearch:
        url = 'https://www.googleapis.com/customsearch/v1?key='+google_key+'&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&siteSearch='+str(sitesearch)+'&excludeTerms=%s'%excludeurl
        #url = 'https://www.google.com/cse?key=AIzaSyBycgu-SqRyO0gNR5u6YTJp30WiGUTOD3A&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&siteSearch='+str(sitesearch)+'&excludeTerms=%s'%excludeurl
    else:
        url = 'https://www.googleapis.com/customsearch/v1?key='+google_key+'&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&excludeTerms=%s'%excludeurl
        #url = 'https://www.google.com/cse?key=AIzaSyBycgu-SqRyO0gNR5u6YTJp30WiGUTOD3A&cx=013036536707430787589:_pqjad5hr1a&q='+str(keyword)+'&alt=json&start='+str(page)+'&excludeTerms=%s'%excludeurl

    if include_list:
       url += '&orTerms=' + str(include_list)+'+'+str(offensive_list)
    if include_keyword:
       url += '&orTerms='+str(include_keyword)
    
       #url += '&orTerms=' + str(include_list)+'+'+'OR'+'+'+str(offensive_list)


#    if include_list or offensive_list:
#       if include_list and offensive_list:
#             url += '&q='+str(keyword)+'+'+str(include_list)+'+'+'OR'+'+'+ str(offensive_list)
#       else:
#            if include_list:
#                  url += '&q='+str(keyword)+'+'+str(include_list)
#            if offensive_list:
#                url += '&q='+str(keyword)+'+'+str(include_list)+'OR'+'+'+ str(offensive_list)     
#    else:
#        url+='&q='+str(keyword)
#
    if daterestrictval:
        url+='&sort='+daterestrictval
    if country:
       url += '&cr=country'+str(country.upper())
    

    print "URL",url
    data = urllib.urlopen(url).read()
    results = json.loads(data)
#    if results['error']['code']==403:
#        messages.warning(request,"Your Google Account Daily search limit Exceeded")
#        return render_to_response(kwargs.get("template"),context,RequestContext(request))
    results =results.values()
    res_dict = []

    try:
        start=0; end=0; current=0;
        try:
            for value in results[2]:

                try:
                    casedetailobject = CasedetailModel.objects.get(url=value['link'],client=client)
                except:
                    casedetailobject = None
                if casedetailobject:
                    tmp = {'description':(value['snippet']).encode("utf8"),'title':(value['title']).encode("utf8"), 'urllink':(value['link']).encode("utf8"), 'keyword':keyword, 'action':'view'}
                else:
                    tmp = {'description':(value['snippet']).encode("utf8"),'title':(value['title']).encode("utf8"), 'urllink':(value['link']).encode("utf8"), 'keyword':keyword, 'action':'add'}
                res_dict.append(tmp)
        except:
            pass
        try:
            if results[4]['previousPage']:
                 start = results[4]['previousPage'][0]['startIndex']
        except:
            start = 0
        try:
            if results[4]['nextPage']:
                end = results[4]['nextPage'][0]['startIndex']
        except:
            end = 0
        try:
            if results[4]['request']:
                current =math.floor(int(results[4]['request'][0]['startIndex'])/10)+1
                cur_page = math.floor(int(results[4]['request'][0]['startIndex']))
        except:
            current = 0
            cur_page = 1
    except Exception,e:
        print "str eerrros",str(e)
        pass
    return res_dict, current, cur_page, start, end

def add_trademark_case(request, *args, **kwargs):
    """ function to add case for  trademark """
    context={}

    #trademark_object = Trademark.objects.get()
    tm_number= request.GET.get('tm_number','')
    tm_name= request.GET.get('tm_name','')
    tm_class=request.GET.get('tm_class','')
    renewal_date=request.GET.get('tm_renewal_date','')
    trademark_info = {"number": tm_number, "name": tm_name}


#    try:
#        if renewal_date:
#            trademark_object=Trademark(number=tm_number,name=tm_name,t_class=tm_class,renewal_date=getDateObject(renewal_date))
#        else:
#            trademark_object=Trademark(number=tm_number,name=tm_name,t_class=tm_class)
#        trademark_object.save()
#    except:
#        trademark_object=None
    
       
    addcaseform = AddCaseForm()
    context['trademark_info'] = trademark_info
#    context['trademark_id'] = trademark_id
    context['case'] = 'trademark'
    context['case_type'] = 'Trademark Infringement'

    if request.method == "POST":
        tm_number = request.POST.get("tm_number")
        tm_name = request.POST.get("tm_name")
        addcaseform = AddCaseForm(request.POST)
        if addcaseform.is_valid():
            client_object = request.user.clientuser.client
            filename = request.FILES.get("attachment" , '')
            alt_email = request.POST.get("alt_email")
            alt_email = alt_email if alt_email else ''
            alt_phone = request.POST.get("alt_phone")
            alt_phone = alt_phone if alt_phone else None
            notes = request.POST.get("notes")
            notes = notes if notes else ''
            fax = request.POST.get("fax")
            fax = fax if fax else None
            try :
                # save case for trademark
                case_object_trademark = CasedetailModel()
                case_object_trademark.name = request.POST.get("name")
                if request.POST.get("tm_number"):
                    case_object_trademark.tm_number = request.POST.get("tm_number")
                if request.POST.get("tm_name"):
                    case_object_trademark.tm_name = request.POST.get("tm_name")

                case_object_trademark.client = client_object
                case_object_trademark.trademark = trademark_object
                case_object_trademark.client_user = request.user.clientuser
                case_object_trademark.case_type = request.POST.get("case")
                case_object_trademark.company = request.POST.get("company")
                case_object_trademark.infringer_name = request.POST.get("infringer_name")
                case_object_trademark.email = request.POST.get("email")
                case_object_trademark.alt_email = alt_email
                case_object_trademark.phone = request.POST.get("phone")
                case_object_trademark.alt_phone = alt_phone
                case_object_trademark.address = request.POST.get("address")
                case_object_trademark.is_active = True
                case_object_trademark.status = request.POST.get("status")
                case_object_trademark.fax = fax
                case_object_trademark.budget = request.POST.get("budget") if request.POST.get("budget") else 0
                case_object_trademark.spent_todate = request.POST.get("spent_date") if request.POST.get("spent_date") else 0
                case_object_trademark.save()

                if filename:
                    try:
                        cm = CaseManager()
                        cm.add_attachemnt(case_object_trademark.id, filename)
                    except:
                        pass

                add_notes(case_object_trademark, notes)
            except:
                pass
            messages.success(request, "Case added Successfully.")
            context['message'] = "Case added Successfully."
            context['status'] = True
            redirect_url = reverse("monitoring_trademark")
            return HttpResponseRedirect(redirect_url)
    context['addcaseform'] = addcaseform
#    context['number']=tm_number
#    context['name']=tm_name
    
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def add_domain_case(request, domain_id, *args, **kwargs):
    """ function to add case for  domain """
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True

    global_domain_object = GlobalDomains.objects.get(id=domain_id)
    addcaseform = AddCaseForm()
#    context['permissions'] = permissions_list
    context['global_domain_object'] = global_domain_object
    context['domain_id'] = domain_id
    context['case'] = 'domain'
    context['case_type'] = 'Domain Infringement'

    if request.method == "POST":
        addcaseform = AddCaseForm(request.POST)
        if addcaseform.is_valid():
            client_object = ClientModel.objects.get(id=request.user.clientuser.client.id)
            filename = request.FILES.get("attachment" , '')
            domain_name = request.POST.get("domain_name")
            alt_email = request.POST.get("alt_email")
            alt_email = alt_email if alt_email else ''
            alt_phone = request.POST.get("alt_phone")
            alt_phone = alt_phone if alt_phone else None
            notes = request.POST.get("notes")
            notes = notes if notes else ''
            fax = request.POST.get("fax")
            fax = fax if fax else None
            try :
                # save case for trademark
                case_object_trademark = CasedetailModel()
                case_object_trademark.name = request.POST.get("name")
                case_object_trademark.client = client_object
                case_object_trademark.domain = global_domain_object
                if request.POST.get("domain_name"):
                    case_object_trademark.domain_name = request.POST.get("domain_name")
                case_object_trademark.client_user = request.user.clientuser
                case_object_trademark.case_type = request.POST.get("case")
                case_object_trademark.company = request.POST.get("company")
                case_object_trademark.infringer_name = request.POST.get("infringer_name")
                case_object_trademark.email = request.POST.get("email")
                case_object_trademark.alt_email = alt_email
                case_object_trademark.phone = request.POST.get("phone")
                case_object_trademark.alt_phone = alt_phone
                case_object_trademark.address = request.POST.get("address")
                case_object_trademark.is_active = True
                case_object_trademark.status = request.POST.get("status")
                case_object_trademark.fax = fax
                case_object_trademark.budget = request.POST.get("budget") if request.POST.get("budget") else 0
                case_object_trademark.spent_todate = request.POST.get("spent_date") if request.POST.get("spent_date") else 0
                case_object_trademark.save()
                if filename:
                    try:
                        cm = CaseManager()
                        cm.add_attachemnt(case_object_trademark.id, filename)
                    except:
                        pass

                add_notes(case_object_trademark, notes)
            except:
                pass
            messages.success(request, "Case added Successfully.")
            context['message'] = "Case added Successfully."
            context['status'] = True
            redirect_url = reverse("monitoring_domain")
            return HttpResponseRedirect(redirect_url)

    context['addcaseform'] = addcaseform
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def add_brand_case(request, **kwargs):
    """ function to add case for  brand """
    context={}
#    import ipdb
#    ipdb.set_trace()
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True

    #global_domain_object = GlobalDomains.objects.get(id=domain_id)
    addcaseform = AddCaseForm()
    url = request.GET.get('url','')

#    context['permissions'] = permissions_list
    #context['domain_id'] = domain_id
    context['case'] = 'brand'
    context['case_type'] = 'Brand Related'

    if request.method == "POST":
        url = request.POST.get("url")
        addcaseform = AddCaseForm(request.POST)
        if addcaseform.is_valid():
            client_object = ClientModel.objects.get(id=request.user.clientuser.client.id)
            filename = request.FILES.get("attachment" , '')
            domain_name = request.POST.get("domain_name")
            alt_email = request.POST.get("alt_email")
            alt_email = alt_email if alt_email else ''
            alt_phone = request.POST.get("alt_phone")
            alt_phone = alt_phone if alt_phone else None
            notes = request.POST.get("notes")
            notes = notes if notes else ''
            fax = request.POST.get("fax")
            fax = fax if fax else None
            try :
                # save case for trademark
                case_object_trademark = CasedetailModel()
                case_object_trademark.name = request.POST.get("name")
                case_object_trademark.client = client_object
                case_object_trademark.url = url
                case_object_trademark.client_user = request.user.clientuser
                case_object_trademark.case_type = request.POST.get("case")
                case_object_trademark.company = request.POST.get("company")
                case_object_trademark.infringer_name = request.POST.get("infringer_name")
                case_object_trademark.email = request.POST.get("email")
                case_object_trademark.alt_email = alt_email
                case_object_trademark.phone = request.POST.get("phone")
                case_object_trademark.alt_phone = alt_phone
                case_object_trademark.address = request.POST.get("address")
                case_object_trademark.is_active = True
                case_object_trademark.status = request.POST.get("status")
                case_object_trademark.fax = fax
                case_object_trademark.budget = request.POST.get("budget") if request.POST.get("budget") else 0
                case_object_trademark.spent_todate = request.POST.get("spent_date") if request.POST.get("spent_date") else 0
                case_object_trademark.save()
                if filename:
                    try:
                        cm = CaseManager()
                        cm.add_attachemnt(case_object_trademark.id, filename)
                    except:
                        pass

                add_notes(case_object_trademark, notes)
            except:
                pass
            messages.success(request, "Case added Successfully.")
            context['message'] = "Case added Successfully."
            context['status'] = True
            redirect_url = reverse("monitoring_home_page")
            return HttpResponseRedirect(redirect_url)
    context['url'] = url
    context['addcaseform'] = addcaseform
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def add_domain_case_instra(request, **kwargs):
    """ function to add case for  domain """
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
    domain = request.GET.get('domain')
    addcaseform = AddCaseForm()

#    context['permissions'] = permissions_list
    context['global_domain_object'] = None
    context['domain'] = domain
    context['case'] = 'domain'
    context['case_type'] = 'Domain Infringement'

    if request.method == "POST":
        addcaseform = AddCaseForm(request.POST)
        domain_name = request.POST.get("domain_name")
        if addcaseform.is_valid():
            client_object = ClientModel.objects.get(id=request.user.clientuser.client.id)
            filename = request.FILES.get("attachment" , '')
            alt_email = request.POST.get("alt_email")
            alt_email = alt_email if alt_email else ''
            alt_phone = request.POST.get("alt_phone")
            alt_phone = alt_phone if alt_phone else None
            notes = request.POST.get("notes")
            notes = notes if notes else ''
            fax = request.POST.get("fax")
            fax = fax if fax else None
            try :
                # save case for trademark
                case_object_trademark = CasedetailModel()
                case_object_trademark.name = request.POST.get("name")
                case_object_trademark.client = client_object
                case_object_trademark.domain_name = domain_name
                case_object_trademark.client_user = request.user.clientuser
                case_object_trademark.case_type = request.POST.get("case")
                case_object_trademark.company = request.POST.get("company")
                case_object_trademark.infringer_name = request.POST.get("infringer_name")
                case_object_trademark.email = request.POST.get("email")
                case_object_trademark.alt_email = alt_email
                case_object_trademark.phone = request.POST.get("phone")
                case_object_trademark.alt_phone = alt_phone
                case_object_trademark.address = request.POST.get("address")
                case_object_trademark.is_active = True
                case_object_trademark.status = request.POST.get("status")
                case_object_trademark.fax = fax
                case_object_trademark.budget = request.POST.get("budget") if request.POST.get("budget") else 0
                case_object_trademark.spent_todate = request.POST.get("spent_date") if request.POST.get("spent_date") else 0
                case_object_trademark.save()
                if filename:
                    try:
                        cm = CaseManager()
                        cm.add_attachemnt(case_object_trademark.id, filename)
                    except:
                        pass

                add_notes(case_object_trademark, notes)
            except:
                raise


            messages.success(request, "Case added Successfully.")
            context['message'] = "Case added Successfully."
            context['status'] = True
            redirect_url = reverse("monitoring_domain")
            return HttpResponseRedirect(redirect_url)

    context['addcaseform'] = addcaseform
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def view_domain_case(request, domain_id, *args, **kwargs):
    """ function to monitor domain """
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True

    global_domain_object = GlobalDomains.objects.get(id=domain_id)
    casedetailmodel = CasedetailModel.objects.get(domain=global_domain_object)
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"
    context['casedetailmodel'] = casedetailmodel
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def view_domain_case_instra(request, **kwargs):
    """ function to monitor domain """
    context={}
    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
    for i in request.user.user_permissions.all():
        if i.codename in permissions_list:
            permissions_list[i.codename] = True
    domain = request.GET.get('domain')
    casedetailmodel = CasedetailModel.objects.get(domain_name=domain)
    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"
    context['casedetailmodel'] = casedetailmodel
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def view_trademark_case(request, *args, **kwargs):
    """ function to monitor domain """
    context={}

#    trademark_object = Trademark.objects.get(id=trademark_id)
    tm_number = request.GET.get('tm_number','')
    tm_name = request.GET.get('tm_name','')
    casedetailmodel = CasedetailModel.objects.get(tm_number=tm_number,tm_name=tm_name)
#    casedetailmodel = CasedetailModel.objects.get(trademark=trademark_object)
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"
    context['casedetailmodel'] = casedetailmodel
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

def view_brand_case(request, **kwargs):
    """ function to monitor domain """
    context={}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
    url = request.GET.get('url')
    casedetailmodel = CasedetailModel.objects.get(url=url)
#    context['permissions'] = permissions_list
    context["is_selected"] = "curent"
    context["active_sub_menu"] = "current"
    context['casedetailmodel'] = casedetailmodel
    return render_to_response(kwargs.get("template"),context,RequestContext(request))


def add_notes(case_obj, notes):
        """
            add notes for the cases in infringement
        """
        try:
            notes_obj = InfrigementNotesModel()
            notes_obj.cases = case_obj
            notes_obj.notes = notes
            notes_obj.save()
        except:
            notes_obj = None
        return notes_obj
