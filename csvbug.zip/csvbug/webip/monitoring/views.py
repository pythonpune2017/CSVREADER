# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.shortcuts import render,render_to_response
from django.core.urlresolvers import reverse
from django.template import RequestContext
from django.contrib import messages
from monitoring.models import Keyword, KeywordsCategory, get_all_sub_categories
from monitoring.manager import MonitoringManager
import json
from monitoring import domain_manager
from monitoring import DOMAIN_IPAUS_TXT as DOMAIN_IPAUS_TXT_DIR
from monitoring.domain_manager import DomainImportManager 
def manage_keywords(request, *args, **kwargs):
    """
        list keywords page
    """
   
    context = {}
    context["active_sub_menu"] = "currnt"
    if request.method == "GET":
        keywords = Keyword.objects.all()
        categoried_keywords = {
                "social_media": keywords.filter(category__code="social_media"),
                "video_media":keywords.filter(category__code="video_media"),
                "exclude_domains":keywords.filter(category__code="exclude_domains"),
                "offensive": keywords.filter(category__code="offensive")}
        industry = KeywordsCategory.objects.get(code="industry_keyword")
        industry_categories=get_all_sub_categories(industry)
        context['industry_categories']=industry_categories
        context["categoried_keywords"] = categoried_keywords
        
    elif request.method == "POST":
        mm = MonitoringManager()
#        Keyword.objects.all().delete()
        
        mm.save_keywords(request.POST)
        redirect_to = reverse("manage_keywords")
        return HttpResponseRedirect(redirect_to)
    return render(request, "keyword.html", context)

def add_industry_keyword(request, *args, **kwargs):
    """
        Adds a Industry Keyword Category
    """

    if request.is_ajax() and request.method == "POST":
        category = request.POST.get("industry_category")
        parent_category = KeywordsCategory.objects.get(code="industry_keyword")
        try:
            ajax_context = {}
            if category.strip():
                cat_obj, is_created = KeywordsCategory.objects.get_or_create(name=category, sub_category=parent_category)
                if is_created:
                    cat_obj.code = category.lower();
                    cat_obj.save()
                    ajax_context['msg'] = "Industry keyword category created"
                    ajax_context['status'] = True
                    ajax_context['edit_url'] = reverse("edit_industry_keyword", args=[cat_obj.id])
                    ajax_context['delete_url'] = reverse("delete_industry_category", args=[cat_obj.id])
                else:
                    ajax_context['status'] = False
                    ajax_context['msg'] = "Industry keyword category already exists!"
            else:
                ajax_context['status'] = False
                ajax_context['msg'] = "Empty value not allowed."
            return HttpResponse(json.dumps(ajax_context), mimetype="application/json")
        except Exception, ex:
            
            raise Http404
    else:
        raise Http404
        
def edit_industry_keyword(request, *args, **kwargs):
    """
        edits the Industry Keywords associated with one Industry Type(category)
    """
  
    id = kwargs.get("id")
    context = {}
    if request.method == "GET":
        cat = KeywordsCategory.objects.get(id = id)
        keywords = Keyword.objects.filter(category__id = id)
        context["keywords"] = keywords
        context['form_action'] = reverse("edit_industry_keyword", args=[id])
        context['page_title'] = cat.name
        return render(request, "industry_keywords.html", context)
    elif request.method=="POST":
        
        try:
            new_keywords = request.POST.get("keywords")
            new_keywords = new_keywords.split("\r\n")
            new_keywords = [elem for elem in new_keywords if elem.strip()]
            keywords_by_category = Keyword.objects.filter(category__id = id)
            keywords_to_delete = keywords_by_category.exclude(name__in=new_keywords)
            for elem in new_keywords:
                k_obj, is_created  = Keyword.objects.get_or_create(category_id = id, name = elem)
            keywords_to_delete.delete()
            ajax_context = {'status':True}
            messages.success(request, "Keywords Updated.")
        except:
            ajax_context = {'status':False}
            messages.error(request, "Some Error has occured while saving the data")
        return HttpResponse(json.dumps( ajax_context),mimetype="application/json")
    
def delete_industry_category(request, *args, **kwargs):
    """
        Delete the Industry Keyword's sub_category by id aling with the keywords related to it
    """
    ajax_context ={}
    ajax_context['success'] = False
    if request.method=="POST":
        category_id = kwargs.get('id')
        if category_id:
            KeywordsCategory.objects.get(id = category_id).delete()
            ajax_context['success'] = True
        return HttpResponse(json.dumps( ajax_context),mimetype="application/json")
    return HttpResponse(json.dumps( ajax_context),mimetype="application/json")



def manage_domain_monitoring(request):
    """
    Manages of Domains from Ip Austrail Db 
    
    """
    context = {}
    context["active_sub_menu"] = "curnt"
   
    return render(request, "domain_monitoring.html", context)


def import_domain_monitoring(request):
    """
    Importing of Domains txt file data from Ip Austrail Db 
    
    """
#    redirect_to = reverse("show_processing")
    redirect_to = reverse("manage_domainmonitoring")
    
    if request.FILES.has_key('domain_file'):
        fileHandle = request.FILES['domain_file']
        file_flag = True
    else:
        msg = "Please upload file..."
        messages.error(request, msg)
        redirect_to = reverse("manage_domainmonitoring")
        return HttpResponseRedirect(redirect_to)
        file_flag = False
    
    
    if file_flag:
        if not fileHandle.content_type == "text/plain":
            msg = "Only .text files are permitted."
            messages.error(request, msg)
            redirect_to = reverse("manage_domainmonitoring")
            return HttpResponseRedirect(redirect_to)
        else:
            fileHandle = domain_manager.save_uploaded_file(fileHandle)
            file_path=domain_manager.process_dir()
            dm_manager = DomainImportManager(file_path)
            dm_manager.main()
            msg = "Domainfile is Imported sucessfully.."
            messages.success(request,msg)
                
            
    return HttpResponseRedirect(redirect_to)


def show_processing(request):
    return HttpResponse("Import In Process...")