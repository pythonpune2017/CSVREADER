import os
from django.conf import settings




DOMAIN_IPAUS_TXT = os.path.abspath(os.path.join(settings.APPLICATION_DOMAIN_DIR, "monitoring/ipaus/domains/"))




def create_dirs():
    """
        Creates the DIRS on first initialization
    """
    dirs_to_process = [DOMAIN_IPAUS_TXT]
    
    for path in dirs_to_process:
        if not os.path.exists(path):
            os.makedirs(path)
            
create_dirs();