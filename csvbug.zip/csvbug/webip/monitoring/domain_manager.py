import re
import datetime
from domain.models import *
import tempfile, os, lxml, shutil
from datetime import datetime
from lxml import etree
from monitoring import DOMAIN_IPAUS_TXT as DOMAIN_IPAUS_TXT_DIR


class DomainImportManager(object):
    """
        Read text from given text file and convert into list
    """
    def __init__(self, filename):
        """
        """
        self.filename = filename
    def read_file(self):
        """
            Read the given filename
        """
        fp = open(self.filename,"r")
        contents = fp.readlines()
        fp.close()
        return contents
    
    
    
    def process_contents(self, contents):
        """
            Purpose : Process the text contents to convet into a list
            Input : file_contents(string)
            Output : List
        """
        new_content = []
        for item in contents:
            new_item = item.strip().strip("\n").strip("\n").strip("\n")
            if not new_item == "" :
                new_content.append(new_item)
            
        return new_content
    
    def update_domains(self, name):
        """
        """
        try:
            global_domain = GlobalDomains.objects.get(name=name)
        except Exception , e:
#            self.write_log(e)
            global_domain = GlobalDomains(name = name)
            global_domain.save()
        return True
    
    def write_log(self, data):
        """
        function to write a log of all domain is importing
        """
        fp = open("/home/pritesh/Desktop/domainmonitoring/updatedomainlog.log", "a")
        fp.write("\n"+str(datetime.strftime(datetime.now() , "%d-%m-%Y | %H-%M-%S"))+" | "+str(data)+"\n")
        fp.close()
        return True
    
    def main(self):
        """
        """
        contents = self.read_file()
        domain_list = self.process_contents(contents)
#        self.write_log(len(domain_list))
        for item in domain_list:
            self.update_domains(item)
        return True
    
    
def save_uploaded_file(f):
    """
        Saves the XMl file uploaded from UI to predefined DIR
    """
    file_path = os.path.join(DOMAIN_IPAUS_TXT_DIR, f.name)
    
    destination = open(file_path, "w+b")
    for chunk in f.chunks():
        destination.write(chunk)
    destination.close()
    return destination

def process_dir():
        """
            Start Processsing from here
        """
        files_2_process = os.listdir(DOMAIN_IPAUS_TXT_DIR)
        
        for f in files_2_process:
            filepath = os.path.join(DOMAIN_IPAUS_TXT_DIR, f)
        return filepath