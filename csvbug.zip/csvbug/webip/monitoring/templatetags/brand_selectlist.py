'''

Purpose: Template Tags for Various list needed for present select html widget in Forms
'''
from django.template import Library, Node, TemplateSyntaxError
from django.utils.translation import ugettext as _
register = Library()



def get_daterestrict_list( parser, token ):
    """
         get list of daterestrict option list
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError(
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )

    return DateRestrictNode( bits[2] )

class DateRestrictNode( Node ):
    """
        get list of DateRestrict Parameters
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        daterestrict_type_list = [(0,"Past hour"),(1,"Past 24 hours"),(2,"Past week"),(3,"Past month"),(4,"Past year")]
        context[self.context_name] = daterestrict_type_list
        return ''

register.tag( "daterestrict_type_list", get_daterestrict_list )




