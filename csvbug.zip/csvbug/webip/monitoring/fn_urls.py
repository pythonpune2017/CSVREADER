from django.conf.urls.defaults import patterns, include, url
urlpatterns = patterns('monitoring.fn_views',
        url(r'^brand/$','monitoring_brand',{'template':"fn/monitoring/brand_monitoring.html"},name="monitoring_home_page"),
        url(r'^domain/$','monitoring_domain',{'template':"fn/monitoring/domain_monitoring.html"},name="monitoring_domain"),
        url(r'^trade/$','monitoring_trademark',{'template':"fn/monitoring/trademark_monitoring.html"},name="monitoring_trademark"),
        url(r'^trademark_info/(?P<trademark_id>\d+)/$','monitoring_trademark_info',{'template':"fn/monitoring/trademark_info.html"},name="showtrademarkinfo"),
        url(r'^trademark_info/$','monitoring_trademark_info',{'template':"fn/monitoring/trademark_info.html"},name="showtrademarkinfo"),
        #url(r'^add_case_trademark/(?P<trademark_id>\d+)/$','add_trademark_case',{'template':"fn/monitoring/add_trademark_case.html"},name="add_case_trademark"),
        url(r'^trademark/add_case/$','add_trademark_case',{'template':"fn/monitoring/add_trademark_case.html"},name="add_case_trademark"),
        url(r'^trademark/view_case/$','view_trademark_case',{'template':"fn/monitoring/view_trademark_case.html"},name="view_case_trademark"),
        
        url(r'^add_case_domain/(?P<domain_id>\d+)/$','add_domain_case',{'template':"fn/monitoring/add_trademark_case.html"},name="add_case_domain"),
        url(r'^add_case_domain_instra/$','add_domain_case_instra',{'template':"fn/monitoring/add_trademark_case.html"},name="add_case_domain_instra"),
        url(r'^add_case_brand/$','add_brand_case',{'template':"fn/monitoring/add_trademark_case.html"},name="add_case_brand"),
        url(r'^view_case_domain/(?P<domain_id>\d+)/$','view_domain_case',{'template':"fn/monitoring/view_domain_case.html"},name="view_case_domain"),
        url(r'^view_case_domain_instra/$','view_domain_case_instra',{'template':"fn/monitoring/view_domain_case_instra.html"},name="view_case_domain_instra"),
        url(r'^view_case_brand/$','view_brand_case',{'template':"fn/monitoring/view_brand_case.html"},name="view_case_brand"),
#        url(r'^view_case_trademark/(?P<trademark_id>\d+)/$','view_trademark_case',{'template':"fn/monitoring/view_trademark_case.html"},name="view_case_trademark")
        
     )
