'''
Created on Feb 6, 2012

@author: arun
'''
from django.contrib import admin 
from monitoring.models import KeywordsCategory, Keyword

class KeywordsCategoryAdmin(admin.ModelAdmin):
    list_display = ( 'name','code','sub_category')

class KeywordAdmin(admin.ModelAdmin):
    list_display = ( 'name','category')
    
admin.site.register( KeywordsCategory, KeywordsCategoryAdmin)
admin.site.register( Keyword, KeywordAdmin)