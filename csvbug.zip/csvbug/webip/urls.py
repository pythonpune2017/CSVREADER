from django.conf.urls.defaults import patterns, include, url
from django.conf.urls.defaults import *
# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = patterns('',


    (r'^admin/', include('webip.webip_auth.urls')),
    (r'^admin/user/', include('webip.admin_app.urls')),
    (r'^admin/user/', include('webip.client.urls')),
    (r'^admin/domain/', include('webip.domain.urls')),
    (r'^admin/monitor/', include('monitoring.urls')),
    (r'^fn/monitor/', include('monitoring.fn_urls')),
    (r'^admin/monitor/', include('trademark.urls')),
    (r'^admin/viewlog/', include('object_log.urls')),
    url(r'^admin/controlpanel/$','tempview.controlpanel',{'template':"control_panel.html"},name="controlpanel"),
    url(r'^djangoadmin/doc/', include('django.contrib.admindocs.urls')),
    # Uncomment the next line to enable the admin:
    url(r'^djangoadmin/', include(admin.site.urls)),



)


urlpatterns = urlpatterns + patterns("",
#    URLs for UI for clients
    url(r'^$', 'webip_auth.views.login', {'template': "fn/login.html"}, name="fn_login"),
    url(r'^login/$', 'webip_auth.views.login', {'template': "fn/login.html"}, name="fn_login"),
    url(r'^home/logout/$', 'webip_auth.views.logout_view', {'redirect_to':'fn_login'}, name="fn_logout"),
    url(r'^home/$', "tempview.home", {'template': "fn/FE_home.html"},name="client_home_page"),
    url(r'^home/twitter/$', "tempview.twitter_info", {'template': "fn//twitterinfo.html"},name="twitter_info"),
    url(r'^home/newsubscription$',"tempview.new_subscription", {'template':"fn/signupsubscription.html"},name="signupsubscription"),

    url(r'^registration/$', "webip_auth.views.registration",name="registration"),
    url(r'^registration_complete/$', "webip_auth.views.registration_complete",name="success_registration"),
    url(r'^captcha/', include('captcha.urls')),
    url(r'^activate/(?P<activation_key>\w+)/$',"webip_auth.views.activate",name='registration_activate'),

    (r'^users/', include('webip.users.urls')),
    (r'^fn/domain/', include('webip.domain.fn_urls')),
    (r'^fn/vendor/', include('webip.vendor.urls')),
    (r'^fn/trademark/', include('webip.trademark.fn_urls')),
    (r'^fn/cases/', include('webip.cases.urls')),
#    (r'^$', include('webip_auth.urls')),

    url(r'^fn/myaccount/$','users.views.manage_myaccount',name="managemyaccount"),
    url(r'^fn/myaccount/changepassword/$','users.views.manage_password',name="fnchange_password"),
    url(r'^ChangeMyAccount/$','tempview.myaccount',{'template':"webip_auth/BE_MyAccount.html"},name="changemyaccount"),
    url(r'^ChangeMyAccount/changeuser/','tempview.change_user',name="change_user"),
    url(r'^ChangeMyAccount/changepassword/','tempview.change_password',name="change_password"),

    url(r'^domain/$','tempview.domain_pageunderconstruction',{'template':"fn/page_underconstruction.html"},name="domain_page_underconstruction"),
    url(r'^trademark/$','tempview.trademark_pageunderconstruction',{'template':"fn/page_underconstruction.html"},name="trademark_page_underconstruction"),
    url(r'^contracts/$','tempview.contracts_pageunderconstrunction',{'template':"fn/page_underconstruction.html"},name="contracts_page_underconstruction"),
    url(r'^infringements/$','tempview.infringement_pageunderconstrunction',{'template':"fn/page_underconstruction.html"},name="infrigement_page_underconstruction"),
    url(r'^help/$', "tempview.home", {'template':"fn/page_underconstruction.html"},name="help_pageunderconstrunction"),
#    url(r'^help/$','tempview.help_pageunderconstrunction',{'template':"fn/page_underconstruction.html"},name="help_pageunderconstrunction"),




#    url(r'^passwordreset/$','webip_auth.views.user_password_reset',name="password_reset"),
#    url(r'^passwordreset/done/$','webip_auth.views.user_password_reset_done',name="password_reset_done"),
#    url(r'^password/reset/confirm/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$','webip_auth.views.user_password_reset_confirm',name="password_reset_conform"),
#    url(r'^password/reset/confirm/done/$','webip_auth.views.user_password_reset_complete',name="resetdone"),
#    url(r'^logout/$','logout_view',{'redirect_to':'index'},name="logout"),


)
if settings.DEBUG:
    urlpatterns += staticfiles_urlpatterns()
    urlpatterns += patterns("",
      (r'^data/(?P<path>.*)$' , 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT, "show_indexes":True}),
      (r'^admin-media/(?P<path>.*)$' , 'django.views.static.serve', {'document_root': settings.ADMIN_MEDIA_ROOT}),
    )