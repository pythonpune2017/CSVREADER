from django.db import models

# Create your models here.

class MailTemplate( models.Model ):
    """
        Templates for various mails
    """
    code = models.CharField( max_length=5, unique=True, help_text="to be used by developers" )
    title = models.CharField( max_length=50, help_text="Name of the template" )
    subject = models.CharField( max_length=200 )
    plain_text = models.TextField( blank=True, null=True )
    rich_text = models.TextField( blank=True, null=True )
    sender = models.EmailField()

    def __unicode__( self ):
        return self.code
