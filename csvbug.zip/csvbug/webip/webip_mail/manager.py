'''
Created on Feb 14, 2012

@author: arun
'''
from django.core.mail import send_mail, EmailMultiAlternatives
from django.core.exceptions import ImproperlyConfigured
from django.template import Template, Context
from django.core.mail import mail_admins

from webip_mail.models import MailTemplate

class WebipSendMail:
    """
        Manager for sending preset mails
    """

    def __init__( self, mail_code ):
        try:
            self.mail = MailTemplate.objects.get( code=mail_code )
        except:
            raise ImproperlyConfigured("No mail Template with specified code '%s'" % mail_code)
            

    def sendmail( self, to_list, context ):
        """
            @tolist: recievers email addresses
            context: dict. values to be updated in template
        """
        self._feed_mail_contents( context )
        subject = self.mail.subject
        from_email = self.mail.sender
        msg = EmailMultiAlternatives( subject, self.plain_text, from_email, to_list )
        msg.attach_alternative( self.html_text, "text/html" )
        msg.send()

    def _feed_mail_contents( self, context ):
        plain_text = Template( self.mail.plain_text )
        html_text = Template( self.mail.rich_text )
        self.plain_text = plain_text.render( Context( context ) )
        self.html_text = html_text.render( Context( context ) )

    def mailadmins( self, context ):
        self._feed_mail_contents( context )
        subject = self.mail.subject
#        from_email = self.mail.sender
        msg = self.plain_text
        mail_admins( subject, msg )

