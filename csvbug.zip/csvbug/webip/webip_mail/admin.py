'''
Created on Feb 14, 2012

@author: arun
'''
from django.contrib import admin
from webip_mail.models import MailTemplate

class MailTemplateAdmin(admin.ModelAdmin):
    list_display = ('title','code')
    ordering = ('title',)
    search_fields=('code',)
    
admin.site.register(MailTemplate, MailTemplateAdmin)