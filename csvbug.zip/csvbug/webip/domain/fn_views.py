'''
Created on Jan 31, 2012

@author: shweta
'''
# Create your views here.
import os
import time
import json
from domain.models import *
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from utils.paginator import paginate
from django.contrib.auth.models import User
from datetime import datetime
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
from django.core.urlresolvers import reverse
#from domain.domain_manager import DomainManager , SSLManager
from domain.fn_forms import DomainForm, SSLForm
from django.forms.formsets import formset_factory
from utils.paginator import paginate
from django.core.servers.basehttp import FileWrapper
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from utils.get_instra_domain import InstraDNSManager
from domain.fn_manager import FrontEndDomainManager , FrontEndSSLManager, RegisterNewDomain
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
from utils.send_mail import SendMail
from settings import DEFAULT_FROM_EMAIL ,EMAIL_HOST_USER
from object_log.models import LogItem
log = LogItem.objects.log_action
from django.views.decorators.csrf import csrf_exempt
from client.models import DomainRegistration, NameServerProfiles
from utils.filewrapper_info import FixedFileWrapper

@login_required
def manage_domains(request):
    """
        renders page to list clients
    """
    context ={}


#    if request.method == "GET":
    req_dict = {}

    req_dict['country'] = request.GET.get('country')
    req_dict['client'] = request.GET.get('client')
    req_dict['costcenter'] = request.GET.get('costcenter')
    req_dict['expiry_in'], req_dict['expiry_out'], req_dict['per_page'] = request.GET.get('expiry_in'), request.GET.get('expiry_out'),request.GET.get('numOfResults', 25)
    req_dict['keyword'] = request.GET.get("keyword")
    req_dict['cur_page']=request.GET.get('page', 1)
    try:
        req_dict['user_id']=request.user.id
    except:
        req_dict['user_id'] = ''

    obj = FrontEndDomainManager()
    req_dict['main'] = True
    
    domain_list = obj.get_all_domains(data_dict=req_dict)
    order=request.GET.get('order', 'desc')

    sort_key_field_map = {  'domain':'name','country':'country__country_name','costcenter':'costcentre',
                            'expirydate':'expiry_date','register':'registrar', 'autorenew':'auto_renew',
                            'annual_cost':'cost_per_annum' }

    sort_key = request.GET.get('sort','')
    if sort_key_field_map.has_key(sort_key):
		sort_by = sort_key_field_map[sort_key]
    else:
		sort_by = ''

    domain_list = sortQuerySet(sort_by, order, domain_list)
    count=domain_list.count()
    if req_dict['per_page']=='ALL':
        req_dict['per_page']=count

    #Get paginated result
    paginated = paginate(domain_list,req_dict['cur_page'], req_dict['per_page'])
    domains = paginated.object_list

#    ssl_details_list = []
#    for domain in domains:
#        ssl_details = domain.ssldetails_set.all()
#        ssl_details_list.append({"ssl_details" : ssl_details})

    #Get all domain objects values
    domains_info = domains#.values("id", "name", "registrar","brand_name","expiry_date","auto_renew","costcentre","client__country__country_name", "cost_per_annum","notes")

    if req_dict['keyword'] or req_dict['country'] or req_dict['costcenter'] or req_dict['expiry_in'] or req_dict['expiry_out']:
        if not domains_info:
            messages.warning(request,"No Records found!")

#    print "domains_info" , domains_info
#        domains_info = domains.values("id", "name", "registrar","brand_name","expiry_date","auto_renew","costcentre", "cost_per_annum","notes", "client__name","client__clientuser__user__first_name")
#    print "domains_info ----------\n " , domains_info
#    for index, domain in enumerate(domains_info):
#        try:
#            domain.update(ssl_details_list[index])
#        except:
#            pass

    paginated.object_list = domains_info

    context["is_selected"] = "currnt"
    context["result_set"] = paginated
    context['order']="asc" if order=="desc" else "desc"

    return render(request, "fn/domain/domain_management.html", context)


def sortQuerySet(sort_by, order, model_instance):
	"""sort queryset function"""
	if sort_by:
		if order=='asc':
			model_instance = model_instance.order_by(str(sort_by))
		else:
			model_instance = model_instance.order_by("-" + str(sort_by))
	return model_instance


@login_required
def add_domains(request, **kwargs):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    try:
        user_id = request.user.id
    except:
        user_id = ''
    client_id = FrontEndDomainManager().get_client_id(user_id)
    client, brand_name, currency = FrontEndDomainManager().get_client(client_id)
    info_dict = {'brand_name':brand_name, "currency" :currency}
    if request.method =='GET':
    	info_dict.update({'auto_renew':'no'})
        domain_form= DomainForm(initial=info_dict)
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet()
        context['sslformset'] = sslformset
        context['domainform'] = domain_form
        context["page_title"] = "Add Domain"
        return render_to_response("fn/domain/edit_domain.html",context,RequestContext(request))
    if request.method=='POST':
        data_dict={}
        registrar_val=None
        domain_form= DomainForm(request.POST)
        domain_info=request.POST
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
        if domain_form.is_valid():
            d_obj = DomainForm()
            if request.POST.get('other_registrar'):
                registrar_val=request.POST.get('other_registrar')
            status, domain_obj = d_obj.save_domain(user_id, domain_form,registrar_val)
            if status:
                if sslformset.is_valid():
                    for form in sslformset:
                        if form.is_valid():
                            ssl_obj = SSLForm().save_ssl(domain_obj,form)
                            if ssl_obj:
                                log('CREATE', request.user, ssl_obj)
                        else:
                            pass
                else:
                    context['sslformset'] = sslformset
                    context['domainform'] = domain_form
                    context['domain_info'] = domain_info
                    context["page_title"] = "Add Domain"
                    response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
                    data_dict['status']=False
                    data_dict['html']= response
                    log('ERROR', request.user, domain_obj, data="SSL Formset is not valid.")
                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
                context['message'] = "Domain Successfully Created !"
                context['status'] = True
                domain_form= DomainForm()
                messages.add_message(request, messages.SUCCESS, "Domain Successfully Created !")
                log('CREATE', request.user, domain_obj)
                return HttpResponse(json.dumps(context),mimetype="application/json")
            else:
                context['sslformset'] = sslformset
                context['domainform'] = domain_form
                context['domain_info'] = domain_info
                context["page_title"] = "Add Domain"
                if request.POST.has_key('show_ssl_form'):
                    if request.POST['show_ssl_form']:
                        context['show_ssl_form']=request.POST['show_ssl_form']
                response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
                data_dict['status']=False
                data_dict['html']= response
                log('ERROR', request.user, request.user, data= domain_obj)
                return HttpResponse(json.dumps(data_dict),mimetype="application/json")
        else:
            context['sslformset'] = sslformset
            context['domainform'] = domain_form
            context['domain_info'] = domain_info
            context["page_title"] = "Add Domain"
            if request.POST.has_key('show_ssl_form'):
                if request.POST['show_ssl_form']:
                    context['show_ssl_form']=request.POST['show_ssl_form']
            response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
            log('ERROR', request.user, request.user, data= "Mandatory Fields are missing.")
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("fn/domain/add_domain.html",context,RequestContext(request))


@login_required
def edit_domains(request, domain_id):
    """
        Add or edit a Client information
    """
    context = {}
    domain_info, ssl_info = FrontEndDomainManager().get_domain_info(domain_id)
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        domain_form= DomainForm(data = domain_info, edit=True)
        ssl_length = len(ssl_info)
        if ssl_length>0:
            context['show_ssl_form']='on'
        if ssl_length == 0:
            ssl_length = 1
        SSLFormSet = formset_factory(SSLForm, max_num=ssl_length)
        sslformset = SSLFormSet(initial=ssl_info)
        context['ssl_data_length'] = len(ssl_info)
        context['sslformset'] = sslformset
        context['domainform'] = domain_form
        context["page_title"] = "Edit Domain"
        context["edit"] = True
        context['domain_info']=domain_info
        context['domain_id'] = int(domain_id)
        return render_to_response("fn/domain/edit_domain.html",context,RequestContext(request))
    if request.method=='POST':
        data_dict={}
        registrar_val = ''
        domain_form= DomainForm(request.POST,edit=True)
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
        # code for start edit history
        from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
        history = {}
        domain_obj = Domain.objects.get(id =domain_id)
        if domain_obj:
            history.update(
                           {
                            'registrar':domain_obj.registrar,
                            'costcentre':domain_obj.costcentre,
                            'auto_renew':domain_obj.auto_renew,
                            'notes':domain_obj.notes,
                            'cost_per_annum':domain_obj.cost_per_annum,
                            'country':domain_obj.country
                            })

        
        result_array_new, result_array_old = Diff_match(history, request.POST)
        try:
            old_expiry_date=domain_obj.expiry_date.strftime("%d-%m-%Y")
            new_expiry_date=str(request.POST.get('expiry_date'))
            new_date_dict, ex_date_dict = Date_match(old_expiry_date,new_expiry_date)
        except:
                old_expiry_date=''
        result_array_new.update(new_date_dict)
        result_array_old.update(ex_date_dict)

        if result_array_new or result_array_old:
            data = {'old':result_array_old, 'new':result_array_new}
        else:
             data = None
        # code for end edit
        if domain_form.is_valid():
            d_obj = DomainForm()
            try:
                 user_id = request.user.id
            except:
                user_id = ''
            try:
                client_user_id = FrontEndDomainManager().get_clientuser_id(user_id)
            except:
                client_user_id=None
            if request.POST.get('other_registrar'):
                registrar_val=request.POST.get('other_registrar')
            status, domain_obj = d_obj.modify(domain_form,registrar_val,domain_id,client_user_id)
            if status:
                if sslformset.is_valid():
                    for form in sslformset:
                        if form.is_valid():
                            try:
                                ssl_obj,data = SSLForm().update_ssl(domain_obj,form)
                                if ssl_obj:
                                    pass
                                    #log('EDIT', request.user,ssl_obj, data=data)
                            except:
                                pass
                        else:
                            pass
                else:
                    context["page_title"] = "Edit Domain"
                    context["edit"] = True
                    context['sslformset'] = sslformset
                    context['domainform'] = domain_form
                    response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
                    data_dict['status']=False
                    data_dict['html']= response
                    #log('ERROR', request.user, domain_obj, data= "SSL Formset is not valid.")
                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
                context['message'] = "Domain Successfully Updated !"
                context['status'] = True
                domain_form= DomainForm()
                messages.add_message(request, messages.SUCCESS, "Domain Successfully Updated !")
                #log('EDIT', request.user, domain_obj,data=data)
                return HttpResponse(json.dumps(context),mimetype="application/json")
            else:
                context["page_title"] = "Edit Domain"
                context["edit"] = True
                context['sslformset'] = sslformset
                context['domainform'] = domain_form
                response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
                data_dict['status']=False
                data_dict['html']= response
#                log('ERROR', request.user, request.user, data= domain_obj)
                return HttpResponse(json.dumps(data_dict),mimetype="application/json")
        else:
            context['domain_id'] = int(domain_id)
            context["page_title"] = "Edit Domain"
            context["edit"] = True
            context['sslformset'] = sslformset
            context['domainform'] = domain_form
            context['domain_info']=domain_info
            if request.POST.has_key('show_ssl_form'):
                if request.POST['show_ssl_form']:
                    context['show_ssl_form']=request.POST['show_ssl_form']
            response = render_to_string("fn/domain/edit_domain.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
#            log('ERROR', request.user, request.user, data= "Mandatory Fields are missing.")
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("fn/domain/edit_domain.html",context,RequestContext(request))

@login_required
def get_instra_domain_info(request):
    """
        To get domain info
    """
    context = {}
    if request.method == 'GET' :
        pass
    if request.method== 'POST':
        domainname = request.POST['name']
        try:
            data = FrontEndDomainManager().get_domain_info_from_instra(domainname)
            context['status'] = "Domain Info"
        except:
            context["message"] = "No record exists!"
    return HttpResponse(json.dumps(data),mimetype="application/json")

@login_required
def order_ssl(request,domain_id,**kwargs):

    """
    Order SSL function..
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context['domain_name'] = FrontEndDomainManager().get_domain_name_by_id(int(domain_id))
    context['domain_id'] = int(domain_id)
    if request.method=='POST':
        context['domain_id'] = request.POST.get('domain_id','')
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        data_dict={}
        #to_list = ['support@webip.com.au']
        bcc=['priteshm@leosys.in','gauravm@leosys.in']
        sender = str(request.user.email)
        to_list = ['support@webip.com.au',sender]
        f_obj=SendMail()
#        to_list.append(DEFAULT_FROM_EMAIL)
        common_name=''
        comment=''
        common_name = request.POST.get('common_name')
        comment = request.POST.get('comment')
        try:
            message = """<p>Hello %s,</p>
                    <p>Thank you for contacting us.Your request for New SSL order has been send Successfully to Web IP Support Team.</p>
                    <p>One of our agents will get back to you.</p>
                    <br>
                    <p>SSL Request Details:</p>
                    <p>Domain Name:%s</p>
                    <p>common:%s</p>
                    <p>comments:%s</p>
                    <br></br>
                    <br></br>
                    <p>Regards,</p>
                    <p>Web IP.</p>
                    """%(str(request.user.first_name + " "+ request.user.last_name),domain_obj.name,common_name,comment)
        except:
             pass   
        subject= 'Portal Request by %s'%(request.user.first_name)
        subject+=' '+ 'for New SSL order'
        try :
#            send_mail(subject, message, from_email, to_list, fail_silently=False)
            f_obj._send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, to_list, [], bcc,'', content_subtype='html')
        except:
            pass
        messages.success(request, 'Your request for SSL order has been sent successfully.')
        msg = "SSL order request mail request successfully."
        log('SENDMAIL',request.user,domain_obj, data={'mail': msg})
        redirect_to = reverse("domain_home_page")
        return HttpResponseRedirect(redirect_to)
    return render_to_response(kwargs.get("template"),context,RequestContext(request))


@login_required
def edit_ssl(request, domain_id):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        ssl_info = FrontEndSSLManager().get_ssl_info(domain_id)
        ssl_length = len(ssl_info)
        if ssl_length == 0:
            ssl_length = 1
        SSLFormSet = formset_factory(SSLForm, extra = 0)
        sslformset = SSLFormSet(initial=ssl_info)
        context['ssl_data_length'] = len(ssl_info)
        context['sslformset'] = sslformset
        context["page_title"] = "Edit SSL"
        context["edit"] = True
        context['domain_id'] = int(domain_id)
        context['domain_name'] = FrontEndDomainManager().get_domain_name_by_id(int(domain_id))
        return render_to_response("fn/domain/edit_ssl.html",context,RequestContext(request))
    if request.method=='POST':
        context['domain_id'] = request.POST.get('domain_id','')
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        data_dict={}
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
        if sslformset.is_valid():
            for form in sslformset:
                if form.cleaned_data:
                    ssl_obj,data = SSLForm().update_ssl(domain_obj,form)
                    if ssl_obj:
                        log('EDIT', request.user,ssl_obj, data=data)
                    pass
#                else:
#                    context['sslformset'] = sslformset
#                    context['domain_id'] = request.POST.get('domain_id','')
#                    response = render_to_string("domain/edit_ssl.html",context,RequestContext(request))
#                    data_dict['status']=False
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
            context['domain_id'] = request.POST.get('domain_id','')
            context['message'] = "SSL Successfully Updated !"
            context['status'] = True
            messages.add_message(request, messages.SUCCESS, "SSL Successfully Updated !")
#            log('EDIT', request.user, domain_obj, data=data)
            return HttpResponse(json.dumps(context),mimetype="application/json")
        else:
            context['sslformset'] = sslformset
            context['domain_id'] = request.POST.get('domain_id','')
            response = render_to_string("fn/domain/edit_ssl.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
            log('ERROR', request.user, domain_obj, data= "Mandatory Fields are missing.")
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("fn/domain/edit_ssl.html",context,RequestContext(request))


def view_dns(request, domain_id):
    """
            add dns view function
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        domain_id = int(domain_id)
        context['domain_id'] = domain_id
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        try:
            name = domain_obj.name
        except:
            name = ''
        try:
            response , dnsinfo = InstraDNSManager().get_domain_info(name)
#            pass
#            response , dnsinfo = True, {}
        except:
            response = False
#            dnsinfo = "There is some issue with the Server. Please try again later!"
            dnsinfo = "DNS appears to be unavailable for this domain name. Please contact your Account Manager."
        if dnsinfo:
            context['dnsinfo'] = dnsinfo
        else:
            context['message'] = "DNS unavailable for this domain name. Please contact your Account Manager."
        if response == False:
            context['message'] = dnsinfo
        return render_to_response("fn/domain/dns.html",context,RequestContext(request))
    if request.method =='POST':
        pass
    return render_to_response("fn/domain/dns.html",context,RequestContext(request))


def add_dns(request, *args, **kwargs):
    """
        Adds a DNS to instra
    """
   
    if request.is_ajax() and request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict['domain_id'])
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        status , content = InstraDNSManager().add_dns(req_dict)
        msg = "DNS Successfully Added for  %s." %(domain_name) if status else content
        log('CREATE', request.user, domain_obj, data= content)
        try:
            ajax_context = {}
            ajax_context['msg'] = content
            ajax_context['status'] = status
            ajax_context['domain_id'] = domain_id
#            ajax_context['edit_url'] = reverse("edit_industry_keyword", args=[cat_obj.id])
#            ajax_context['delete_url'] = reverse("delete_industry_category", args=[cat_obj.id])
            return HttpResponse(json.dumps(ajax_context), mimetype="application/json")
        except Exception, ex:
            raise Http404
    else:
        raise Http404


def edit_dns(request, *args, **kwargs):
    """
        Adds a DNS to instra
    """

    if request.is_ajax() and request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict['domain_id'])
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        status , content = InstraDNSManager().update_dns(req_dict)
        msg = "DNS Successfully Updated for  %s." %(domain_name) if status else content
        log('EDIT',request.user, domain_obj, data={'dns':msg})
        try:
            ajax_context = {}
            ajax_context['msg'] = content
            ajax_context['status'] = status
            ajax_context['domain_id'] = domain_id
            ajax_context['edit_url'] = reverse("fn_editdns")
#            ajax_context['delete_url'] = reverse("delete_industry_category", args=[cat_obj.id])
            return HttpResponse(json.dumps(ajax_context), mimetype="application/json")
        except Exception, ex:
            raise Http404
    else:
        raise Http404


def delete_dns(request, *args, **kwargs):
    """
        Delete the Industry Keyword's sub_category by id aling with the keywords related to it
    """
    ajax_context ={}
    ajax_context['success'] = False
    ajax_context['message'] = "Some issues occurred while deletion. Please try again"
    if request.method=="POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict.get('domain_id'))
        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        if domain_id:
            status , content = InstraDNSManager().delete_dns(req_dict)
            ajax_context['status'] = status
            ajax_context['message'] = "DNS Successfully Deleted"
            msg = "DNS Successfully Deleted  %s." %(domain_name) if status else content
            log('DELETE',request.user, domain_obj, data={'dns':msg})
        return HttpResponse(json.dumps( ajax_context),mimetype="application/json")
    return HttpResponse(json.dumps( ajax_context),mimetype="application/json")


@login_required
def edit_notes(request, domain_id):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    domain_obj = FrontEndDomainManager()
    if request.method =='GET':
        domain = domain_obj.get_domain_by_id(int(domain_id))
        context['object'] = domain
        return render_to_response("fn/domain/edit_notes.html",context,RequestContext(request))
    if request.method == "POST":
        status , domain,data = domain_obj.modify_notes(domain_id, request.POST)
        if status:
            context['message'] = "Notes is Updated Successfully!"
            context['status'] = True
            log('EDIT', request.user,domain, data=data)
            messages.add_message(request, messages.SUCCESS, "Notes is Updated Successfully!")
        else:
            context['message'] = "Error while updating notes!"
            context['status'] = False
        context['object'] = domain
        response=render_to_string('fn/domain/edit_notes.html',context,RequestContext(request))
        _dict={}
        _dict['status']=context['status']
        _dict['message']=context['message']
        _dict['elements']= response
        return HttpResponse(json.dumps(_dict),mimetype="application/json")
    return render_to_response("fn/domain/edit_notes.html",context,RequestContext(request))


def export_domains(request):
    response= None
    if request.method =="GET":
        pass
    if request.method =="POST":
        #request dictionary
        req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
        try:
            req_dict['user_id']=request.user.id
        except:
            req_dict['user_id'] = ''
        data_dict = {}
        search = str(req_dict['search_data'])
        search_data = search.split('&')
        for item in search_data:
            item = item.split('=')
            data_dict[item[0]] = item[1]
        req_dict.update(data_dict)
        #get client information list
        domain_obj = FrontEndDomainManager()
        domain_data = domain_obj.export_domain(req_dict)
        #Data required for creating spreadsheet
        sequence_list = SpreadsheetMapping.DOMAIN_SEQUENCE_LIST
        title_dict = SpreadsheetMapping.DOMAIN_TITLE_LIST
        #Create XLS
        if request.POST.get("format") == "xls":
            status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, domain_data, "domain_")
            msg = "Domain XLS Export Successful." if status else "Error in Domain XLS Export."
            log('EXPORT', request.user, request.user, data={'export':msg})
            if not status:
                pass
        #Create CSV
        elif request.POST.get("format") == "csv":
            location = os.path.join(settings.TEMP_DIR , "domain.csv" )
            status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , domain_data , location )
            if status:
                wrapper = FixedFileWrapper(file(location))
                filename = 'attachment; filename=' + str(time.strftime("Domain_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
                response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
                response['Content-Disposition'] = filename
            if status:
                msg="Domain CSV Export Successful."
            else:
                msg="Error in Domain CSV Export."
            log('EXPORT', request.user, request.user, data={'export':msg})
    return response


def import_domains(request):
    """
        To import domain in xls or csv format
    """
    message = ''
    errors = []
    context = {}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method == "GET":
        pass
    if request.method == "POST":
        if request.FILES.has_key('import_file'):
            file_obj = request.FILES['import_file']
            file_flag = True
        else:
            message = "Please upload file..."
            file_flag = False

        try:
            user_id= request.user.id
        except:
            user_id = None

        client_id = FrontEndDomainManager().get_client_id(user_id)
        client, brand_name, currency = FrontEndDomainManager().get_client(client_id)
        if client:
            client = client[0]
        if file_flag:
            location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))

            Import_obj = FrontEndDomainManager()
            status = Import_obj.save_uploaded_file(file_obj, location)
            if not status:
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
            
            format = Import_obj.checkForFormat(location)

            if format == "xls":
                obj = SpreadSheetDictonaryConversion()

                spreadsheet_column_list = ['Domain Name','Cost Centre','Country','Registrar',
                                           'Expiry Date','Notes','Cost Per Annum','Auto Renew',
                                           'SSL Details']
                result_dict = obj.spreadsheet_converter(location , spreadsheet_column_list)
                status, message, errors = Import_obj.processXLSImportedDomain(result_dict , client)
                msg = "Domain XLS Import Successful for %s." %(file_obj.name) if status else errors
                log('IMPORT', request.user, request.user, data={'import':msg})
            if format == "csv":
                csvobj = CSVDictionaryConversion()
                result_dict = csvobj.csvConverter(location)
#                return HttpResponse(str(result_dict))
                status, message, errors = Import_obj.processCSVImportedDomain(result_dict, client)
                msg = "Domain CSV Import Successful for %s." %(file_obj.name) if status else errors
                log('IMPORT', request.user, request.user, data={'import':msg})
            Import_obj.delete_processed_file(location)

        context['message'] =  str(message)
        context['domain_errors']= errors
        pass
    return render_to_response('fn/domain/import_domain.html', context, RequestContext(request))

#def register_new_domain(request):
#    """
#    """
#    context = {}
#    if request.method == "GET":
#        pass
#    if request.method == "POST":
#        req_dict =  dict(zip(request.POST.keys(), request.POST.values()))
#        domain_list = RegisterNewDomain().get_domain_list(req_dict)
#        return HttpResponse(str(req_dict))
#        pass
#    return render_to_response('fn/domain/new_domain_order1.html', context, RequestContext(request))
#
#
@csrf_exempt
@login_required
def view_all_ssl(request):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        client_id = FrontEndDomainManager().get_client_id(user_id)
        client, brand_name, currency = FrontEndDomainManager().get_client(client_id)
        if client:
            client = client[0]
        edit = True
        ssl_info = FrontEndSSLManager().get_all_ssl_info(client)
        ssl_length = len(ssl_info)
        context["page_title"] = "Edit SSL"
        context['ssl_info'] = ssl_info
    if request.method=='POST':
        pass
    return render_to_response("fn/domain/view_all_ssl.html",context,RequestContext(request))



@login_required
def get_ssl_info(request):
    """
    """
    context= {}
    if request.method =='GET':
        ssl_id = request.GET['ssl_id']
        domain_name =  request.GET['domain_name']
        ssl_info = FrontEndSSLManager().get_ssl_info_by_id(ssl_id)
        ssl_form= SSLForm(initial = ssl_info)
        context['sslform'] = ssl_form
        context['domain_name'] = domain_name
        return render_to_response("fn/domain/ssl.html",context,RequestContext(request))
    if request.method=='POST':
        domain_name = request.POST.get('domain_name','')
        context['domain_name'] = domain_name
        domain_obj = FrontEndDomainManager().get_domain_by_name(domain_name)
        data_dict={}
        ssl_form= SSLForm(request.POST)
        if ssl_form.is_valid():
            ssl_obj,data = SSLForm().update_ssl(domain_obj,ssl_form)
            if ssl_obj:
                    log('EDIT', request.user,ssl_obj, data=data)

#            pass
#                else:
#                    context['sslformset'] = sslformset
#                    context['domain_id'] = request.POST.get('domain_id','')
#                    response = render_to_string("domain/edit_ssl.html",context,RequestContext(request))
#                    data_dict['status']=False
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
            context['message'] = "SSL Successfully Updated !"
            context['status'] = True
            #messages.add_message(request, messages.SUCCESS, "SSL Successfully Updated !")
            return HttpResponse(json.dumps(context),mimetype="application/json")
        else:
            context['sslform'] = ssl_form
            response = render_to_string("fn/domain/ssl.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("fn/domain/ssl.html",context,RequestContext(request))


@login_required
def download_domain_spreadsheet(request, format):
    """
        Purpose: Export staff details on the basis of filtered results
    """
    response =None
    filename=''
    req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
    data_dict = {}
    #Create XLS
    if format == "xls":
        filename = "Fn_Domain_Import_Format.xls"
    elif format == "csv":
        filename = "Fn_Domain_Import_Format.csv"
    location = os.path.join(settings.SPREADSHEET_FORMAT_PATH , filename)
    wrapper = FixedFileWrapper(file(location))
    filename = 'attachment; filename=' + str(filename)
    response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
    response['Content-Disposition'] = filename
    return response



@login_required
def register_new_domain(request):
    """
    """
    context = {}
    info_dict={}
    cur_page = request.GET.get('page', 1)
    per_page = request.GET.get('numOfResults',25)
    if request.method == "GET":
        req_dict =  dict(zip(request.GET.keys(), request.GET.values()))
        domain_list = RegisterNewDomain().get_domain_list(req_dict)
        if domain_list:
            info_dict = RegisterNewDomain().check_for_domain_existance(domain_list)
#            paginated = paginate(info_dict,cur_page,per_page)
        else:
            if req_dict:
                messages.error(request,"Instra API is down.")
    context["result_set"] = info_dict
    context["domain_list"] = domain_list
    context["domain_data"] = info_dict
    return render_to_response('fn/domain/new_domain_order2.html', context, RequestContext(request))

   
@login_required
def get_order_domain_page(request):
    """
    """
    context = {}
    client = request.client
      
    reg_obj = RegisterNewDomain()
    registration_profiles = reg_obj.get_all_registration_profiles(client)
    namerserver_profiles = reg_obj.get_all_nameserver_profiles(client)
    context['registration_profiles'] = registration_profiles
    context['namerserver_profiles'] = namerserver_profiles

    domain_list = request.session.get("selecteddomains", [])

    if request.method == "POST":
        req_dict =  dict(zip(request.POST.keys(), request.POST.values()))
        domain_list = request.POST.getlist('domain_names')
        request.session["selecteddomains"] = domain_list
        
    context['selected_domains'] = domain_list
#        req_dict['cur_page']=request.GET.get('page', 1)
#        req_dict['per_page'] = request.GET.get('numOfResults',10)
    return render_to_response('fn/domain/new_domain_order3.html', context, RequestContext(request))


@login_required
def create_new_profile(request):
    """
    """
    context = {}
    if request.method == "GET":
         #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        obj = FrontEndDomainManager()
        client_id = obj.get_client_id(user_id)
        client, brand_name, currency = obj.get_client(client_id)
        countries = RegisterNewDomain().get_all_countries()
        context['countries'] = countries
#        status = RegisterNewDomain().checkForClientsRegistrationProfile(client)
#        if not status:
#            countries = RegisterNewDomain().get_all_countries()
#            context['countries'] = countries
#        else:
#            context['profile_message'] = 'The registration proflie already exists. If you want you can edit the details by selectiing the profile from the given profiles drop down!'
        return render_to_response('fn/domain/create_registration_profile.html', context, RequestContext(request))
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        obj = FrontEndDomainManager()
        client_id = obj.get_client_id(user_id)
        client, brand_name, currency = obj.get_client(client_id)
        reg_obj = RegisterNewDomain()
        registration_profiles = reg_obj.get_all_registration_profiles(client)
        namerserver_profiles = reg_obj.get_all_nameserver_profiles(client)
        if client:
            client = client[0]
        prof_obj = RegisterNewDomain().save_profile_details(client, req_dict)
        reg_prof_obj = RegisterNewDomain().save_registration_profile(client, req_dict)
        context['selected_domains'] = request.POST.getlist("selected_domains")
#        context['registration_profiles'] = registration_profiles
#        context['namerserver_profiles'] = namerserver_profiles
        context['status'] = True
        context['message'] = "Registration Profile Successfully Created !"
        messages.success(request,"Registration Profile Successfully Created !")
        response = render_to_string("fn/domain/new_domain_order2.html",context,RequestContext(request))
        return HttpResponse(json.dumps(context),mimetype="application/json")
#        return render_to_response('fn/domain/new_domain_order3.html', context, RequestContext(request))


@login_required
def create_nameserver_profile(request):
    """
    """
    context = {}
    if request.method =="GET":
        #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        obj = FrontEndDomainManager()
        client_id = obj.get_client_id(user_id)
        client, brand_name, currency = obj.get_client(client_id)
        profile_details = [{"id":"","nameserver":"","order":""}for i in range(1,7)]
        context['profile_details'] = profile_details
#        status = RegisterNewDomain().checkForClientsNameServerProfile(client)
#        if not status:
#            profile_details = [{"id":"","nameserver":"","order":""}for i in range(1,7)]
#            context['profile_details'] = profile_details
#        else :
#            context['profile_message'] = 'The nameserver proflie already exists. If you want you can edit the details by selectiing the profile from the given profiles drop down!'
        return render_to_response('fn/domain/create_nameserver_profile.html', context, RequestContext(request))
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        nameserverlist = request.POST.getlist('nameserver')
        req_dict['nameserverlist'] = nameserverlist
        #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        obj = FrontEndDomainManager()
        client_id = obj.get_client_id(user_id)
        client, brand_name, currency = obj.get_client(client_id)
        if client:
            client = client[0]
        prof_obj = RegisterNewDomain().save_nameserverprofile_details(client, req_dict)
        context['selected_domains'] = request.POST.getlist("selected_domains")
        context['status'] = True
        context['message'] = "NameServer Profile Successfully Created !"
        messages.success(request,"NameServer Profile Successfully Created !")
        response = render_to_string("fn/domain/new_domain_order2.html",context,RequestContext(request))
        return HttpResponse(json.dumps(context),mimetype="application/json")


@login_required
def get_registration_details(request):
    """
    """
    if request.method == "GET":
        pass
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        profile_id =  request.POST.get('profile_id', '')
        data = RegisterNewDomain().get_all_profile_details(int(profile_id))
    return HttpResponse(json.dumps(data),mimetype="application/json")


@login_required
def edit_profile_details(request ,profile_id):
    """
    """

    context = {}
    if request.method == "GET":
        reg_obj = RegisterNewDomain()
        data = reg_obj.get_all_profile_details(int(profile_id))
        countries = reg_obj.get_all_countries()
        context['countries'] = countries
        context['profile_details'] = data
        context['profile_id'] = profile_id
        context['edit'] = True
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        #Get current user
        try:
            user_id= request.user.id
        except:
            user_id = None
        #Get client info
        d_obj = FrontEndDomainManager()
        client_id = d_obj.get_client_id(user_id)
        client, brand_name, currency = d_obj.get_client(client_id)
        if client:
            client = client[0]
        prof_obj = RegisterNewDomain().modify_profile_details(client, req_dict)
        context['status'] = True
        messages.success(request,"NameServer Profile Successfully Updated !")
        return HttpResponse(json.dumps(context),mimetype="application/json")
    return render_to_response('fn/domain/create_registration_profile.html', context, RequestContext(request))


@login_required
def get_nameserver_details(request):
    """
    """
    context = {}
    if request.method == "GET":
        pass
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        nameserver_id =  request.POST.get('nameserver_id', '')
        reg_obj = RegisterNewDomain()
        nameserver_details = reg_obj.get_nameserver_details(int(nameserver_id))
        profilename = reg_obj.get_namserver_profile_name(nameserver_id)

        context['profilename'] = profilename
        context['nameserver_details'] = nameserver_details
    return render_to_response('fn/domain/nameserver.html', context, RequestContext(request))


@login_required
def edit_nameserver_details(request ,nameserver_id):
    """
    """
    context = {}
    if request.method == "GET":
        reg_obj = RegisterNewDomain()
        data = reg_obj.get_nameserver_details(int(nameserver_id))
        profilename = reg_obj.get_namserver_profile_name(nameserver_id)
        context['profilename'] = profilename
        context['profile_details'] = data
        context['nameserver_id'] = nameserver_id
        context['edit'] = True
    if request.method == "POST":
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        reg_obj = RegisterNewDomain()
        prof_obj = reg_obj.modify_nameserver_details(nameserver_id, req_dict)
#         #Get current user
#        try:
#            user_id= request.user.id
#        except:
#            user_id = None
#        #Get client info
#        d_obj = FrontEndDomainManager()
#        client_id = d_obj.get_client_id(user_id)
#        client, brand_name, currency = d_obj.get_client(client_id)
#        if client:
#            client = client[0]
#        name_severobj=reg_obj.modify_nameserver_details(client,req_dict)
        context['status'] = True
        messages.add_message(request, messages.SUCCESS, "Nameserver Details successfully updated !")
        return HttpResponse(json.dumps(context),mimetype="application/json")
    return render_to_response('fn/domain/create_nameserver_profile.html', context, RequestContext(request))


@login_required
def email_details(request):
    """
    """
    context = {}
    #Get current user
    try:
        user_id= request.user.id
    except:
        user_id = None
    #Get client info
    domain_obj = FrontEndDomainManager()
    client_id = domain_obj.get_client_id(user_id)
    client, brand_name, currency = domain_obj.get_client(client_id)
    if client:
        client = client[0]
    reg_obj = RegisterNewDomain()
    registration_profiles = reg_obj.get_all_registration_profiles(client)
    registration_profile_obj=reg_obj.get_all_registration_object(client)
    namerserver_profiles = reg_obj.get_all_nameserver_profiles(client)
    #permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
    #for i in request.user.user_permissions.all():
    #    if i.codename in permissions_list:
    #        permissions_list[i.codename] = True
    domain_list = request.POST.getlist("domain_name")
    req_dict = dict(zip(request.POST.keys(), request.POST.values()))
    req_dict['domain_name'] = domain_list
    mail_obj = SendMail()
    reg_obj = RegisterNewDomain()
    data_dict = reg_obj.process_data_for_email(req_dict)
    subject = "Domain Registration Details"
    #msg = "The domain and registration details are as follows : \n "
    domain_detail_list = str(','.join(data_dict['domain_list']))

    registartion_details = str(data_dict['registration_profile'])
    nameserver_details = str(data_dict['nameserver_profile'])
    auto_renew = request.POST.getlist('auto_renew')
    no_of_years_register = request.POST.getlist('period')
#    message = msg + "\n\t\t" + domain_detail_list + "\n\t\t" + registartion_details + "\n\t\t" + nameserver_details
    message1 = """<p>Hello %s,</p>
                <p>The domain and registration details are as follows : \n "</p>
                <p>Registration profile is : %s . \n\n</p>
                <p>Nameserver profile is : %s .  \n\n</p>"""%(str(request.user.first_name +" "+ request.user.last_name),registartion_details,nameserver_details)
#    len=len(data_dict['domain_list'])
    message_detail=""
    for i,j in enumerate(data_dict['domain_list']):
        message2="""
                <br>
                <br>
                <p>Selected Domain is  : %s .  \n\n   </p>
                <p>Autorenew option is : %s .  \n\n</p>
                <p>Number of years to register value is : %s .  \n\n</p>
                """ %(str(data_dict['domain_list'][i]),str(auto_renew[i]),str(no_of_years_register[i]))
        message_detail+=message2
    message3="""
                <br>
                <br>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """

    message= message1+message_detail+message3

    to_list = ['info@webip.com.au']
    to_list.append(request.user.email)
    from_id = EMAIL_HOST_USER
    cc_list = []
    bcc=['priteshm@leosys.in','gauravm@leosys.in']
    context["message"] = "The selected list of domains and the other registration details have been successfully emailed to your account manager and we will update you once the domains are registered successfully"
    context["data_dict"] = data_dict
    context['selected_domains'] = domain_list
    context['registration_profiles'] = registration_profiles
    context['namerserver_profiles'] = namerserver_profiles
    #context['permissions'] = permissions_list
    content_subtype = 'html'
#    filepath = settings.MESSAGE_TEMPLATE_PATH
#    mail_obj._send_mail(subject, message, from_id, to_list, cc_list, '',)
    status = mail_obj._send_mail(subject, message, from_id, to_list, cc_list,bcc, '' , content_subtype='html')
    msg='The selected list of domains and the other registration details have been successfully emailed to your account manager and we will update you once the domains are registered successfully'
    messages.add_message(request, messages.SUCCESS, msg)
    try:
        log('SENDMAIL',request.user,registration_profile_obj,data={'mail': msg})
    except:
        pass
    redirect_url = reverse("domain_home_page")
    return HttpResponseRedirect(redirect_url)
#    return HttpResponseRedirect(request.META["HTTP_REFERER"])
#    return render_to_response('fn/email_template.html', context, RequestContext(request))

@login_required
def check_registration_profile(request):
    """
        check dupliacte registration profile name.
    """
    profile_message = ""
    profile_name = request.POST.get('profile_name')
    try:
        profile_obj = DomainRegistration.objects.get(profile_name=profile_name)
        if profile_obj:
            profile_message = "Profile name is already exist."
    except:
        profile_message = ""
    return HttpResponse(json.dumps(profile_message),mimetype="application/json")

@login_required
def check_nameserver_profile(request):
    """
        check dupliacte registration profile name.
    """
    profile_message = ""
    profile_name = request.POST.get('profile_name')
    try:
        profile_obj = NameServerProfiles.objects.get(profile_name=profile_name)
        if profile_obj:
            profile_message = "Server profile name is already exist."
    except:
        profile_message = ""
    return HttpResponse(json.dumps(profile_message),mimetype="application/json")
