'''
Created on Jan 31, 2012

@author: shweta
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('domain.fn_views',
     url(r'^manage/$',                                  'manage_domains',               name="domain_home_page"),
     url(r'^add/$',                                     'add_domains',                  name="fn_addomain"),
     url(r'^instrainfo/$',                              'get_instra_domain_info',       name="fn_instrainfo"),
     url(r'^edit/(?P<domain_id>\d+)/$',                 'edit_domains',                 name="fn_editdomain"),
#     url(r'^view/(?P<domain_id>\d+)/$',                 'view_domains',                 name="viewdomain"),
     url(r'^export/$',                                  'export_domains',               name="fn_exportdomain"),
     url(r'^editssl/(?P<domain_id>\d+)/$',              'edit_ssl',                     name="fn_editssl"),
     url(r'^orderssl/(?P<domain_id>\d+)/$',             'order_ssl',{'template':"fn/domain/order_ssl.html"},name="fn_order_ssl"),
     url(r'^editnotes/(?P<domain_id>\d+)/$',            'edit_notes',                   name="fn_editdomainnotes"),
#     url(r'^check/$',                                   'check_domain',                 name="checkdomain"),
     url(r'^viewdns/(?P<domain_id>\d+)/$',              'view_dns',                     name="fn_editdns"),
     url(r'^dns/add/$',                                 'add_dns',                      name="fn_adddns"),
     url(r'^dns/delete/$',                              'delete_dns',                   name="fn_deletedns"),
     url(r'^dns/edit/$',                                'edit_dns',                     name="fn_editdns"),
#     url(r'^brandname/$',                               'get_brand_name',               name="getbrandname"),
#     url(r'^checknameserver/$',                         'check_nameserver',             name="checknameserver"),
#     url(r'^delete/(?P<domain_id>\d+)/$',               'delete_domain',                name="deletedomain"),
     url(r'^import/$',                                  'import_domains',               name="fn_importdomain"),
     url(r'^register/$',                                'register_new_domain',          name="fn_registerdomain"),
     url(r'^order/$',                                   'get_order_domain_page',        name="fn_order_domain"),
     url(r'^newprofile/$',                              'create_new_profile',           name="fn_new_profile"),
     url(r'^profiledetails/$',                          'get_registration_details',     name="fn_get_registration_details"),
     url(r'^editprofile/(?P<profile_id>\d+)/$',         'edit_profile_details',         name="fn_edit_profile"),
     url(r'^nameserverprofile/$',                       'create_nameserver_profile',    name="fn_nameserver_profile"),
     url(r'^editnameserver/(?P<nameserver_id>\d+)/$',   'edit_nameserver_details',      name="fn_edit_nameserver"),
     url(r'^serverprofile/$',                           'get_nameserver_details',       name="fn_server_details"),
     url(r'^emaildetails/$',                            'email_details',                name="fn_email_details"),
     url(r'^allssl/$',                                  'view_all_ssl',                 name="fn_viewallssl"),
     url(r'^getsslform/$',                              'get_ssl_info',                 name="fn_getsslform"),
     url(r'^download/(?P<format>\w+)/$',                'download_domain_spreadsheet',  name="fn_downloaddomainformat"),
     url(r'^check_registration_profile/$',              'check_registration_profile',  name="check_registration_profile"),
     url(r'^check_nameserver_profile/$',              'check_nameserver_profile',  name="check_nameserver_profile"),

     )

