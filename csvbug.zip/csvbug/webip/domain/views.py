'''
Created on Jan 31, 2012

@author: shweta
'''
# Create your views here.
import os
import time
import json
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from utils.paginator import paginate
from django.contrib.auth.models import User
from datetime import datetime
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
from domain.domain_manager import DomainManager , SSLManager
from domain.fn_manager import FrontEndDomainManager
from domain.forms import DomainForm, SSLForm
from django.forms.formsets  import formset_factory
from utils.paginator import paginate
from django.core.servers.basehttp import FileWrapper
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from utils.get_instra_domain import InstraDNSManager
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
from utils.send_mail import SendMail
from utils.filewrapper_info import FixedFileWrapper
from django.db.models import Q
from domain.models import *
from client.models import *
from admin_app.models import *
from utils.paginator import paginate
from datetime import datetime
from django.views.decorators.csrf import csrf_exempt
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action
@login_required
def manage_domains(request):
    """
        renders page to list clients
    """
  
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    req_dict = {}
    req_dict['country'] = request.GET.get('country')
    req_dict['client'] = request.GET.get('client')
    req_dict['expiry_in'], req_dict['expiry_out'], req_dict['per_page'] = request.GET.get('expiry_in'), request.GET.get('expiry_out'),request.GET.get('numOfResults',25)
    req_dict['keyword'] = request.GET.get("keyword")
    req_dict['cur_page']=request.GET.get('page', 1)
    obj = DomainManager()
    domain_list = obj.get_all_domains(data_dict=req_dict)
    
    order=request.GET.get('order')
    if request.GET.get('sort') =='client':
        if order=='asc':
            domain_list = domain_list.order_by("client__clientuser__user__first_name")
        else:
            domain_list = domain_list.order_by("-client__clientuser__user__first_name")
    
    
    if request.GET.get('sort') =='domain':
        if order=='asc':
            domain_list = domain_list.order_by("name")
        else:
            domain_list = domain_list.order_by("-name")
    
    if request.GET.get('sort') =='country':
        if order=='asc':
            domain_list = domain_list.order_by("country__country_name")
        else:
            domain_list = domain_list.order_by("-country__country_name")
    
    
    if request.GET.get('sort') =='costcenter':
        if order=='asc':
            domain_list = domain_list.order_by("costcentre")
        else:
            domain_list = domain_list.order_by("-costcentre")
    
    
    if request.GET.get('sort') =='brand':
        if order=='asc':
            domain_list = domain_list.order_by("brand_name")
        else:
            domain_list = domain_list.order_by("-brand_name")
    
    if request.GET.get('sort') =='expirydate':
        if order=='asc':
            domain_list = domain_list.order_by("expiry_date")
        else:
            domain_list = domain_list.order_by("-expiry_date")
            
    if request.GET.get('sort') =='register':
        if order=='asc':
            domain_list = domain_list.order_by("registrar")
        else:
            domain_list = domain_list.order_by("-registrar")
#    
    if request.GET.get('sort') =='autorenew':
        if order=='asc':
            domain_list = domain_list.order_by("auto_renew")
        else:
            domain_list = domain_list.order_by("-auto_renew")


 
    count=domain_list.count()
    if req_dict['per_page']=='ALL':
       req_dict['per_page']=count
    #Get paginated result
    paginated = paginate(domain_list,req_dict['cur_page'], req_dict['per_page'])
    domains = paginated.object_list
    ssl_details_list = []
    for domain in domains:
        ssl_details = domain.ssldetails_set.all()
        ssl_details_list.append({"ssl_details" : ssl_details})
    
  
    #Get all domain objects values
#    domains_info = domains.values("id", "name", "registrar","client__name","brand_name","country__country_name","expiry_date","auto_renew","costcentre","client__user__first_name","client__user__last_name","notes")
    domains_info = domains.values("id", "name", "registrar","client__name","brand_name","country__country_name","expiry_date","auto_renew","costcentre","client__user__first_name","client__user__last_name","notes")
    for index, domain in enumerate(domains_info):
        try:
            domain.update(ssl_details_list[index])
        except:
            pass
    if request.GET.get('country') or request.GET.get('client') or request.GET.get('expiry_in') or\
        request.GET.get('expiry_out') or request.GET.get("keyword"):
        if not domains_info:
            messages.warning(request,"No Records found!")

    paginated.object_list = domains_info#
    context["is_selected"] = "currnt"
    context['order']="asc" if order=="desc" else "desc"
    context["result_set"] = paginated
#        instra_domain=InstraManager()
#        domain_name='WEBIP.COM.AU'#webip.com.au',WEBIP.COM.AU
#        domain_info=instra_domain.get_domain_info(domain_name)
#        print "domain_info",domain_info
        
    return render(request, "domain/BE-DomainManagement.html", context)

@login_required
def add_domains(request, **kwargs):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        domain_form= DomainForm()
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet()
        context['sslformset'] = sslformset
        context['domainform'] = domain_form
        context["page_title"] = "Add Domain"
        return render_to_response("domain/add_domain.html",context,RequestContext(request))
    if request.method=='POST':
        data_dict={}
        registrar_val=None
        domain_form= DomainForm(request.POST)
        domain_info=request.POST
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
        
        if domain_form.is_valid():
            d_obj = DomainForm()
            if request.POST.get('other_registrar'):
                registrar_val=request.POST.get('other_registrar')
            status, domain_obj = d_obj.save_domain(domain_form,registrar_val)
            if status:
                if sslformset.is_valid():
                    for form in sslformset:
                        if form.is_valid():
                            ssl_obj = SSLForm().save_ssl(domain_obj,form)
                            if ssl_obj:
                                log('CREATE', request.user, ssl_obj)
                        else:
                            pass
                else:
                    context['sslformset'] = sslformset
                    context['domainform'] = domain_form
                    context['domain_info'] = domain_info
                    response = render_to_string("domain/add_domain.html",context,RequestContext(request))
                    data_dict['status']=False
                    data_dict['html']= response
                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
                context['message'] = "Domain Successfully Created !"
                context['status'] = True
                domain_form= DomainForm()
                log('CREATE', request.user, domain_obj)
                messages.add_message(request, messages.SUCCESS, "Domain Successfully Created !")
                return HttpResponse(json.dumps(context),mimetype="application/json")
            else:
                context['sslformset'] = sslformset
                context['domainform'] = domain_form
                context['domain_info'] = domain_info
                context["page_title"] = "Add Domain"
                if request.POST.has_key('show_ssl_form'):
                    if request.POST['show_ssl_form']:
                        context['show_ssl_form']=request.POST['show_ssl_form']
                response = render_to_string("domain/add_domain.html",context,RequestContext(request))
                data_dict['status']=False
                data_dict['html']= response
                return HttpResponse(json.dumps(data_dict),mimetype="application/json")
        else:
            
            context['sslformset'] = sslformset
            context['domainform'] = domain_form
            context['domain_info'] = domain_info
            context["page_title"] = "Add Domain"
            if request.POST.has_key('show_ssl_form'):
                if request.POST['show_ssl_form']:
                    context['show_ssl_form']=request.POST['show_ssl_form']
            response = render_to_string("domain/add_domain.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("domain/add_domain.html",context,RequestContext(request))


@login_required
def back_order_ssl(request,domain_id,**kwargs):
    
    """
    Order SSL function..
    """
    
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context['domain_name'] = FrontEndDomainManager().get_domain_name_by_id(int(domain_id))
    context['domain_id'] = int(domain_id)
    domain_obj = DomainManager().get_domain_by_id(domain_id)
    if request.method=='POST':
        context['domain_id'] = request.POST.get('domain_id','')
#        domain_obj = FrontEndDomainManager().get_domain_by_id(domain_id)
        data_dict={}
        bcc=['priteshm@leosys.in','gauravm@leosys.in']
        sender = str(request.user.email)
        to_list = ['support@webip.com.au',sender]
        f_obj=SendMail()
#        to_list.append(DEFAULT_FROM_EMAIL)
        common_name=''
        comment=''
        common_name = request.POST.get('common_name')
        comment = request.POST.get('comment')
        try:
            message = """<p>Hello %s,</p>
                    <p>Thank you for contacting us.Your request for New SSL order has been send Successfully to Web IP Support Team.</p>
                    <p>One of our agents will get back to you.</p>
                    <br>
                    <p>SSL Request Details:</p>
                    <p>Domain Name:%s</p>
                    <p>common:%s</p>
                    <p>comments:%s</p>
                    <br></br>
                    <br></br>
                    <p>Regards,</p>
                    <p>Web IP.</p>
                    """%(str(request.user.first_name + " "+ request.user.last_name),domain_obj.name,common_name,comment)
        except:
             pass   
        subject= 'Portal Request by %s'%(request.user.first_name)
        subject+=' '+ 'for New SSL order'
        try :
#            send_mail(subject, message, from_email, to_list, fail_silently=False)
             f_obj._send_mail(subject, message,settings.DEFAULT_FROM_EMAIL, to_list, [], bcc,'', content_subtype='html')
        except:
            pass
        messages.success(request, 'Your request for SSL order has been sent successfully.')
        msg = "SSL order request mail request successfully."
        log('SENDMAIL',request.user,domain_obj, data={'mail': msg})
        #return render_to_response(kwargs.get("template"),context,RequestContext(request))
        redirect_to = reverse("managedomains")
        return HttpResponseRedirect(redirect_to)
    return render_to_response(kwargs.get("template"),context,RequestContext(request))

@login_required
def edit_domains(request, domain_id):
    """
        Add or edit a Client information
    """
    
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        domain_info, ssl_info = DomainManager().get_domain_info(domain_id)
        domain_form= DomainForm(data = domain_info, edit=True)
        ssl_length = len(ssl_info)
        if ssl_length>0:
            context['show_ssl_form']='on'
        if ssl_length == 0:
            ssl_length = 1
        SSLFormSet = formset_factory(SSLForm, max_num=ssl_length)
        sslformset = SSLFormSet(initial=ssl_info)
        context['ssl_data_length'] = len(ssl_info)
        context['sslformset'] = sslformset
        context['domainform'] = domain_form
        context["page_title"] = "Edit Domain"
        context['domain_info']=domain_info
        context["edit"] = True
        context['domain_id'] = int(domain_id)
        return render_to_response("domain/add_domain.html",context,RequestContext(request))
    if request.method=='POST':
        data_dict={}
        registrar_val=None
        domain_form= DomainForm(request.POST,edit=True)
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
         # code for start edit history
        from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
        history = {}
        domain_obj = Domain.objects.get(id =domain_id)
        if domain_obj:
            history.update(
                           {
                            'registrar':domain_obj.registrar, 
                            'costcentre':domain_obj.costcentre,
                            'auto_renew':domain_obj.auto_renew,            
                            'notes':domain_obj.notes,
                            'cost_per_annum':domain_obj.cost_per_annum
                            })
                           
#        print "HISTORY",history
        result_array_new, result_array_old = Diff_match(history, request.POST)
        try:
            old_expiry_date=domain_obj.expiry_date.strftime("%d-%m-%Y")
            new_expiry_date=str(request.POST.get('expiry_date'))
            new_date_dict, ex_date_dict = Date_match(old_expiry_date,new_expiry_date)        
        except:
                old_expiry_date=''
        result_array_new.update(new_date_dict)
        result_array_old.update(ex_date_dict)
        
        if result_array_new or result_array_old:
            domain_data = {'old':result_array_old, 'new':result_array_new}
        else:
             domain_data = None
        # code for end edit 
        if domain_form.is_valid():
            d_obj = DomainForm()
            if request.POST.get('other_registrar'):
                registrar_val=request.POST.get('other_registrar')
          
            status, domain_obj = d_obj.modify(domain_form,registrar_val,domain_id)
            if status:
                if sslformset.is_valid():
                    for form in sslformset:
                        if form.is_valid():
                            ssl_obj,data = SSLForm().update_ssl(domain_obj,form)
                            if ssl_obj:
                                log('EDIT', request.user,ssl_obj, data=data)
                              
                        else:
                            pass
                else:
                    context['sslformset'] = sslformset
                    context['domainform'] = domain_form
                    response = render_to_string("domain/add_domain.html",context,RequestContext(request))
                    data_dict['status']=False
                    data_dict['html']= response
                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
                context['message'] = "Domain Successfully Updated !"
                context['status'] = True
                domain_form= DomainForm()
                log('EDIT', request.user,domain_obj, data=domain_data)
                messages.add_message(request, messages.SUCCESS, "Domain Successfully Updated !")
                return HttpResponse(json.dumps(context),mimetype="application/json")
            else:
                context['sslformset'] = sslformset
                context['domainform'] = domain_form
                context["page_title"] = "Edit Domain"
                response = render_to_string("domain/add_domain.html",context,RequestContext(request))
                data_dict['status']=False
                data_dict['html']= response
                return HttpResponse(json.dumps(data_dict),mimetype="application/json")
        else:
            context['domain_id'] = int(domain_id)
            context['sslformset'] = sslformset
            context['domainform'] = domain_form
            context["edit"] = True
            context["page_title"] = "Edit Domain"
            if request.POST.has_key('show_ssl_form'):
                if request.POST['show_ssl_form']:
                    context['show_ssl_form']=request.POST['show_ssl_form']
            response = render_to_string("domain/add_domain.html",context,RequestContext(request))
            data_dict['status']=False
            context["page_title"] = "Edit Domain"
            data_dict['html']= response
            return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("domain/add_domain.html",context,RequestContext(request))


@login_required
def view_domains(request, domain_id):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        domain_info, ssl_info = DomainManager().get_domain_info(domain_id)
        domain_form= DomainForm(domain_info, True)
        SSLFormSet = formset_factory(SSLForm, max_num=len(ssl_info))
        sslformset = SSLFormSet(initial=ssl_info)
        context['sslformset'] = sslformset
        context['domainform'] = domain_form
        context["page_title"] = "View Domain"
        context["view"] = True
        context["edit"] = False
        context['domain_id'] = int(domain_id)
        context['domain_info']=domain_info
        return render_to_response("domain/view_domain.html",context,RequestContext(request))


def export_domains(request):
    response= None
    if request.method =="GET":
        pass
    if request.method =="POST":
        #request dictionary
        req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
        data_dict = {}
        search = str(req_dict['search_data'])
        search_data = search.split('&')
        for item in search_data:
            item = item.split('=')
            data_dict[item[0]] = item[1]
        req_dict.update(data_dict)
        #get client information list
        domain_obj = DomainManager()
        domain_data = domain_obj.export_domain(req_dict)
        #Data required for creating spreadsheet
        sequence_list = SpreadsheetMapping.DOMAIN_SEQUENCE_LIST
        title_dict = SpreadsheetMapping.DOMAIN_TITLE_LIST
        #Create XLS
        if request.POST.get("format") == "xls":
            status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, domain_data, "domain_")
            msg = "Domain XLS Export Successful." if status else "Error in Domain XLS Export."
            log('EXPORT', request.user, request.user, data={'export':msg})
            if not status:
                pass
        #Create CSV
        elif request.POST.get("format") == "csv":
            file_location = os.path.join(settings.TEMP_DIR , "domain.csv")
            status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , domain_data , settings.TEMP_DIR  + os.sep + "domain.csv" )
            if status:
                wrapper = FixedFileWrapper(file(file_location))
                filename = 'attachment; filename=' + str(time.strftime("Domain_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
                response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
                response['Content-Disposition'] = filename
            msg = "Domain XLS Export Successful." if status else "Error in Domain XLS Export."
            log('EXPORT', request.user, request.user, data={'export':msg})
    return response


@login_required
def download_domain_spreadsheet(request, format):
    """
        Purpose: Export staff details on the basis of filtered results
    """
    response =None
    req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
    data_dict = {}
    #Create XLS
    if format == "xls":
        filename = "Domain_Import_Format.xls"
    elif format == "csv":
        filename = "Domain_Import_Format.csv"
        
    location = os.path.join(settings.SPREADSHEET_FORMAT_PATH , filename.replace(" ","_"))
    wrapper = FixedFileWrapper(file(location))
    filename = 'attachment; filename=' + str(filename)
    response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
    response['Content-Disposition'] = filename
    return response


#@login_required
#def edit_ssl(request, domain_id):
#    """
#        Add or edit a Client information
#    """
#    context = {}
#    if request.method =='GET':
#        ssl_info_list = SSLManager.get_ssl_info(domain_id)
#        SSLFormSet = formset_factory(SSLForm, max_num=len(ssl_info_list))
#        context['sslformset'] = SSLFormSet(initial = ssl_info_list)
#        context['edit'] = True
#        context["page_title"] = "Edit SSL"
#        return render_to_response("domain/edit_ssl.html",context,RequestContext(request))
    
@login_required
def edit_ssl(request, domain_id):
    """
        Add or edit a Client information
    """

    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        ssl_info = SSLManager().get_ssl_info(domain_id)
        ssl_length = len(ssl_info)
        if ssl_length == 0:
            ssl_length = 1
        SSLFormSet = formset_factory(SSLForm)
        sslformset = SSLFormSet(initial=ssl_info)
        context['ssl_data_length'] = len(ssl_info)
        context['sslformset'] = sslformset
        context["page_title"] = "Edit SSL"
        context["edit"] = True
        context['domain_id'] = int(domain_id)
        return render_to_response("domain/edit_ssl.html",context,RequestContext(request))
    if request.method=='POST':
        context['domain_id'] = request.POST.get('domain_id','')
        domain_obj = DomainManager().get_domain_by_id(domain_id)
        data_dict={}
        SSLFormSet = formset_factory(SSLForm, extra = 1)
        sslformset = SSLFormSet(request.POST)
        if sslformset.is_valid():
            for form in sslformset:
                if form.cleaned_data:
                    ssl_obj,data = SSLForm().update_ssl(domain_obj,form)
                    if ssl_obj:
                        log('EDIT', request.user,ssl_obj, data=data)
                    else:
                        pass
#                else:
#                    context['sslformset'] = sslformset
#                    context['domain_id'] = request.POST.get('domain_id','')
#                    response = render_to_string("domain/edit_ssl.html",context,RequestContext(request))
#                    data_dict['status']=False
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
            context['domain_id'] = request.POST.get('domain_id','')
            context['message'] = "SSL Successfully Updated !"
            context['status'] = True
            messages.add_message(request, messages.SUCCESS, "SSL Successfully Updated !")
            return HttpResponse(json.dumps(context),mimetype="application/json")
        else:
            
            context['sslformset'] = sslformset
            context['domain_id'] = request.POST.get('domain_id','')
            response = render_to_string("domain/edit_ssl.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("domain/edit_ssl.html",context,RequestContext(request))
    
@login_required
def edit_notes(request, domain_id):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    domain_obj = DomainManager()
    if request.method =='GET':
        domain = domain_obj.get_domain_by_id(int(domain_id))
        context['object'] = domain
        return render_to_response("domain/edit_notes.html",context,RequestContext(request))
    if request.method == "POST":
        status , domain,data = domain_obj.modify_notes(domain_id, request.POST)
        if status:
            context['message'] = "Notes is Updated Successfully!"
            context['status'] = True
            log('EDIT', request.user,domain, data=data)
            messages.add_message(request, messages.SUCCESS, "Notes is Updated Successfully!")
        else:
            context['message'] = "Error while updating notes!"
            context['status'] = False
            
        context['object'] = domain
        response=render_to_string('domain/edit_notes.html',context,RequestContext(request))
        dict={}
        dict['status']=context['status']
        dict['message']=context['message']
        dict['elements']= response       
        return HttpResponse(json.dumps(dict),mimetype="application/json")
    
@login_required    
def check_domain(request):
    """
        Purpose: To check availability of username
    """
    message = ''
    if request.method == 'GET' :
        pass
    if request.method == 'POST' :
        req_data = request.POST['domain_name']
        try:
            name = str(req_data).split('=')[-1].strip()
        except:
            name = ''
        message = DomainManager().check_domain_name_availability(name)
    return HttpResponse(str(message))

def view_dns(request, domain_id):
    """
            add dns view function 
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        domain_id = int(domain_id)
        context['domain_id'] = domain_id
        domain_obj = DomainManager().get_domain_by_id(domain_id)
        try:
            name = domain_obj.name
        except:
            name = ''
        try:
            response , dnsinfo = InstraDNSManager().get_domain_info(name)
        except:
            response = False
#           dnsinfo = "There is some issue with the Server. Please try again later!"
            dnsinfo ="DNS appears to be unavailable for this domain name. Please contact your Account Manager."
        if dnsinfo:
            context['dnsinfo'] = dnsinfo
        else:
            context['message'] = "Your request to add DNS is sent to administrator !"
        if response == False:
            context['message'] = dnsinfo
        return render_to_response("domain/dns.html",context,RequestContext(request))
    if request.method =='POST':
        pass
    return render_to_response("domain/dns.html",context,RequestContext(request))

def add_dns(request, *args, **kwargs):
    """
        Adds a DNS to instra
    """

    if request.is_ajax() and request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict['domain_id'])
        domain_obj = DomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        status , content = InstraDNSManager().add_dns(req_dict)
        msg = "DNS Successfully Added for  %s." %(domain_name) if status else content
        log('CREATE',request.user, domain_obj, data={'dns':msg})
        try:
            ajax_context = {}
            ajax_context['msg'] = content
            ajax_context['status'] = status
            ajax_context['domain_id'] = domain_id
#            ajax_context['edit_url'] = reverse("edit_industry_keyword", args=[cat_obj.id])
#            ajax_context['delete_url'] = reverse("delete_industry_category", args=[cat_obj.id])
            return HttpResponse(json.dumps(ajax_context), mimetype="application/json")
        except Exception, ex:
            raise Http404
    else:
        raise Http404
    
def edit_dns(request, *args, **kwargs):
    """
        Adds a DNS to instra
    """

    if request.is_ajax() and request.method == "POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict['domain_id'])
        domain_obj = DomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        status , content = InstraDNSManager().update_dns(req_dict)
        msg = "DNS Successfully Updated for  %s." %(domain_name) if status else content
        log('EDIT',request.user, domain_obj, data={'dns':msg})
        try:
            ajax_context = {}
            ajax_context['msg'] = content
            ajax_context['status'] = status
            ajax_context['domain_id'] = domain_id
            ajax_context['edit_url'] = reverse("editdns")
#            ajax_context['delete_url'] = reverse("delete_industry_category", args=[cat_obj.id])
            return HttpResponse(json.dumps(ajax_context), mimetype="application/json")
        except Exception, ex:
            raise Http404
    else:
        raise Http404
    
def delete_dns(request, *args, **kwargs):
    """
        Delete the Industry Keyword's sub_category by id aling with the keywords related to it
    """

    ajax_context ={}
    ajax_context['success'] = False
    ajax_context['message'] = "Some issues occurred while deletion. Please try again"
    if request.method=="POST":
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        domain_id = int(req_dict.get('domain_id'))
        domain_obj = DomainManager().get_domain_by_id(domain_id)
        try:
            domain_name = domain_obj.name
        except:
            domain_name = ''
        req_dict['domain_name'] = domain_name
        if domain_id:
            status , content = InstraDNSManager().delete_dns(req_dict)
            ajax_context['status'] = status
            ajax_context['message'] = "DNS Successfully Deleted"
            msg = "DNS Successfully Deleted  %s." %(domain_name) if status else content
            log('DELETE',request.user, domain_obj, data={'dns':msg})
        return HttpResponse(json.dumps( ajax_context),mimetype="application/json")
    return HttpResponse(json.dumps( ajax_context),mimetype="application/json")


def get_brand_name(request):
    """
        get brand name
    """
    context = {}
    req_data = request.POST['client_id']
    client_id = str(req_data).split('=')[-1]
    obj = DomainForm(request.POST)
    client , brand_name, currency = obj.get_client(client_id)
    context['brand_name'] = brand_name
    context['currency'] = currency
    return HttpResponse(json.dumps(context),mimetype="application/json")

@login_required    
def check_nameserver(request):
    """
        Purpose: To check availability of username
    """
    message = ''
    nameserver_dict = {}
    if request.method == 'GET' :
        pass
    if request.method == 'POST' :
        req_data = request.POST['nameserver']
        nameserver_dict["nameserver1"] = "ns1."+str(req_data)
        message = DomainManager().check_nameserver_availability(nameserver_dict)
    return HttpResponse(str(message))

@login_required
def delete_domain(request,domain_id):
    """
        Purpose to delete domain form the database and also from the instra
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context['obj']={"id":domain_id}
    domain_info = DomainManager().get_domain_by_id(domain_id)
    delete_url = reverse("deletedomain", args=[domain_id])
    context['post_url'] = delete_url
    context["message"] = "Are you sure you want to delete '"+str(domain_info.name)+"' domain?"
    context['visible']=True
    if request.method== 'POST':
        domainid = request.POST.get("record_id")
        try:
            data = DomainManager().delete_domain(domainid)
            context['status'] = "Domain is deleted"
            context['visible']=False
            messages.add_message(request, messages.SUCCESS, "Domain record is deleted!")
        except:
            raise
            context["message"] = "No record exists!"
        context["message"] = "Domain record is deleted!"
        context['visible']=False

        return HttpResponseRedirect(request.META["HTTP_REFERER"])

    return render_to_response('domain/delete_domain.html',context,RequestContext(request))

def get_instra_domain_info(request):
    """
        To get domain info 
    """
    context = {}
    if request.method == 'GET' :
        pass
    if request.method== 'POST':
        domainname = request.POST['name']
        try:
            data = DomainManager().get_domain_info_from_instra(domainname)
            context['status'] = "Domain Info"
        except:
            context["message"] = "No record exists!"
    return HttpResponse(json.dumps(data),mimetype="application/json")


def import_domains(request):
    """
        To import domain in xls or csv format
    """

    message = ''
    errors = []
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method == "GET":
        pass
    if request.method == "POST":
        if request.FILES.has_key('import_file'):
            file_obj = request.FILES['import_file']
            file_flag = True
        else:
            message = "Please upload file..."
            file_flag = False
    
        if file_flag:
            location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))
    
            Import_obj = DomainManager()
            status = Import_obj.save_uploaded_file(file_obj, location)
            if not status:
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
            
            format = Import_obj.checkForFormat(location)
            if format == "xls":
                obj = SpreadSheetDictonaryConversion()

#                spreadsheet_column_list = ['Domain Name','Country','Cost Centre','Registrar',
#                                           'Expiry Date','Notes','Cost Per Annum','Auto Renew',
#                                           "Company Name",'First Name','Last Name','Phone',
#                                           'Email','Currency Code','Subscription Plan','Activation Date','Expiry Date','SSL Details']
                spreadsheet_column_list = ['Client', 'Domain Name','Cost Centre','Country','Registrar',
                                           'Expiry Date','Notes','Cost Per Annum','Auto Renew',
                                           'SSL Details']              
                result_dict = obj.spreadsheet_converter(location , spreadsheet_column_list)
                status, message, errors = Import_obj.processXLSImportedDomain(result_dict)
                msg = "Domain XLS Import Successful for %s." %(file_obj.name) if status else errors
                log('IMPORT', request.user, request.user, data={'import':msg})
            if format == "csv":
                csvobj = CSVDictionaryConversion()
                result_dict = csvobj.csvConverter(location)
                status, message, errors = Import_obj.processCSVImportedDomain(result_dict)
                msg = "Domain CSV Import Successful for %s." %(file_obj.name) if status else errors
                log('IMPORT', request.user, request.user, data={'import':msg})
            Import_obj.delete_processed_file(location)

        context['message'] =  str(message)
        context['domain_errors']= errors
        print "errors" 
        pass
    return render_to_response('domain/import_domain.html', context, RequestContext(request))

def Oldimport_domains(request):
    """
        To import domain in xls or csv format
    """
    context = {}
    if request.method == "GET":
        pass
    if request.method == "POST":
        if request.FILES.has_key('import_file'):
            file_obj = request.FILES['import_file']
            file_flag = True
        else:
            message = "Please upload file..."
            file_flag = False
    
        if file_flag:
            location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))
    
            Import_obj = DomainManager()
            status = Import_obj.save_uploaded_file(file_obj, location)
            if not status:
                return HttpResponseRedirect(request.META['HTTP_REFERER'])
            
            format = Import_obj.checkForFormat(location)
            
            if format == "xls":
                obj = SpreadSheetDictonaryConversion()

                spreadsheet_column_list = ['Domain Name','Country','Cost Centre','Registrar',
                                           'Expiry Date','Notes','Cost Per Annum','Auto Renew',
                                           "Company Name",'First Name','Last Name','Phone',
                                           'Email','Currency','SSL Details']
                result_dict = obj.spreadsheet_converter(location , spreadsheet_column_list)
                status, message = Import_obj.processXLSImportedDomain(result_dict)
            if format == "csv":
                csvobj = CSVDictionaryConversion()
                result_dict = csvobj.csvConverter(location)
#                return HttpResponse(str(result_dict))
                status, message = Import_obj.processCSVImportedDomain(result_dict)
            Import_obj.delete_processed_file(location)
    
        context={'message': str(message)}
        pass
    return render_to_response('domain/import_domain.html', context, RequestContext(request))

@login_required
@csrf_exempt
def view_all_ssl(request):
    """
        Add or edit a Client information
    """
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        edit = True
        ssl_info = SSLManager().get_all_ssl_info()
        ssl_length = len(ssl_info)
        context["page_title"] = "Edit SSL"
        context['ssl_info'] = ssl_info
    if request.method=='POST':

        pass
    return render_to_response("domain/view_all_ssl.html",context,RequestContext(request))



@login_required
def get_ssl_info(request):
    """
    """

    context= {}
    if request.method =='GET':
        ssl_id = request.GET['ssl_id']
        domain_name =  request.GET['domain_name']
        ssl_info = SSLManager().get_ssl_info_by_id(ssl_id)
        ssl_form= SSLForm(initial = ssl_info)
        context['sslform'] = ssl_form
        context['domain_name'] = domain_name
        return render_to_response("domain/ssl.html",context,RequestContext(request))
    if request.method=='POST':
        domain_name = request.POST.get('domain_name','')
        context['domain_name'] = domain_name
        domain_obj = DomainManager().get_domain_by_name(domain_name)
        data_dict={}
        ssl_form= SSLForm(request.POST)
        if ssl_form.is_valid():
            ssl_obj,data = SSLForm().update_ssl(domain_obj,ssl_form)
            if ssl_obj:
                 log('EDIT', request.user,ssl_obj, data=data)
#            pass
#                else:
#                    context['sslformset'] = sslformset
#                    context['domain_id'] = request.POST.get('domain_id','')
#                    response = render_to_string("domain/edit_ssl.html",context,RequestContext(request))
#                    data_dict['status']=False
#                    data_dict['html']= response
#                    return HttpResponse(json.dumps(data_dict),mimetype="application/json")
            context['message'] = "SSL Successfully Updated !"
            context['status'] = True
            messages.add_message(request, messages.SUCCESS, "SSL Successfully Updated !")
            return HttpResponse(json.dumps(context),mimetype="application/json")
        else:
            context['sslform'] = ssl_form
            response = render_to_string("domain/ssl.html",context,RequestContext(request))
            data_dict['status']=False
            data_dict['html']= response
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")
    return render_to_response("domain/ssl.html",context,RequestContext(request))



