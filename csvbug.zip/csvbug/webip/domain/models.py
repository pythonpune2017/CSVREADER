from django.db import models
from client.models import ClientModel
from admin_app.models import CountryModel
from datetime import datetime, timedelta
from django.conf import settings

PERIOD = [("select","Select"),(1,'1 yr'),(2,'2 yrs'),(3,'3 yrs'),(4,'4 yrs'),(5,'5 yrs'),(6,'6 yrs'),(7,'7 yrs'),(8,'8 yrs'),(9,'9 yrs')]


domain_type = settings.DOMAIN_TYPES

class Domain(models.Model):
    """
        Maintains Domains
    """
    name = models.CharField(max_length=100, unique=True, db_index=True)
    client = models.ForeignKey(ClientModel)
    country = models.ForeignKey(CountryModel)
    brand_name = models.CharField(max_length=100, db_index=True)
    registrar = models.CharField(max_length=100, db_index=True)
    auto_renew = models.BooleanField(default=False)
    notes = models.TextField(max_length=500 ,blank=True,null=True)
    expiry_date = models.DateField(blank=True, null=True)
#    cost_per_annum = models.IntegerField(blank=True,null=True)
    cost_per_annum = models.DecimalField(max_digits=9, decimal_places=2)
    costcentre = models.CharField(max_length=100)
    period = models.IntegerField(choices = PERIOD,blank=True,null=True)
    instra_id= models.CharField(max_length=50,default="")
    dns_on_instra = models.BooleanField(default=False)
    nameserver1 = models.CharField(max_length=100)
    nameserver2 = models.CharField(max_length=100)
    nameserver3 = models.CharField(max_length=100)
    nameserver4 = models.CharField(max_length=100)
    nameserver5 = models.CharField(max_length=100)
    nameserver6 = models.CharField(max_length=100)
    #Meta fields
    is_active = models.BooleanField(default=False, help_text="is Domain active")
    is_deleted = models.BooleanField(default=False, help_text="True if Domain is deleted from the System")
    
    created = models.DateTimeField(auto_now_add = True)
    updated = models.DateTimeField(auto_now = True)
    
    def __unicode__(self):
        return self.name

    class Meta:
        permissions = (("view_domain", "Can view domain"),)
        
    
class SSLDetails(models.Model):
    """
        Maintains SSL Details
    """
    domain = models.ForeignKey(Domain)
    ssl_common_name = models.CharField(max_length=100, db_index=True)
    provider = models.CharField(max_length=100)
    date_of_issue = models.DateField()
    expiry_date = models.DateField()
    type = models.CharField(max_length=50)
    #Meta fields
    created = models.DateTimeField(auto_now_add = True)
    updated = models.DateTimeField(auto_now = True)
    def __unicode__(self):
        return self.ssl_common_name
    
class GlobalDomains(models.Model):
    """
        Maintains Domains
    """
    name = models.CharField(max_length=100, unique=True, db_index=True)
    domain_type = models.IntegerField(choices = domain_type,db_index=True,blank=True,null=True)
    
    def __unicode__(self):
        return self.name