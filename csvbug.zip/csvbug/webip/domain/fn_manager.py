'''
Created on Mar 1, 2012

@author: shweta
'''
from django.db.models import Q
from domain.models import *
from client.models import *
from admin_app.models import *
from utils.paginator import paginate
from datetime import datetime
import datetime, os, re
from utils.get_instra_domain import InstraDomainManager
from utils.random_generator import RandomGenerator
from django.contrib.auth.models import User
from utils import getDateObject


class FrontEndDomainManager(object):
    """
        Domain related objects
    """
    def get_all_domains(self,data_dict={}):
        """
            Purpose: To get all domain objects list
        """
        domains_having_ssl=[]
        user_id = data_dict['user_id']
        try:
            user_obj= User.objects.get(id = user_id)
        except:
            user_obj=None
        client_id = self.get_client_id(user_id)

        if not data_dict.has_key('main'):
            domains = Domain.objects.filter(client__id =client_id ,  is_active = True)
        else:
            #Check for domains that are not deleted
            domains = Domain.objects.select_related().filter(client__id =client_id ,  is_active = True)
            domains_having_ssl = SSLDetails.objects.filter(domain__in = domains).values_list('domain')
            domains_having_ssl = [i[0] for i in domains_having_ssl]

        #logic for default show filter with costcentersr
        try:
            client_user_obj= ClientUser.objects.get(user = user_id)
        except:
            client_user_obj=None
        if client_user_obj and client_user_obj.user_type=='subuser':
            temp=[]
            tstr = ''
            temp = user_obj.clientuser.clientdomaincategory_set.values('category',)
            if temp:
                try:
                    cat_list = eval(str(temp[0]['category']))
                    cat_list = list(set(cat_list))
                except:
                       cat_list = []
                if not cat_list:
#                    context[self.context_name] = []
                   domains=domains.filter(costcentre='')
                for i  in cat_list:
                    tstr += " | Q(costcentre= '%s')" %(str(i))
                    tstr = tstr.lstrip(' | ')
            if tstr:
                domains=domains.filter(eval(tstr))
            else:
                pass
        #Check for Keywords
        if data_dict['keyword']:
            keyword = data_dict['keyword']
            fields_4_keyword_search = ["name"]
            q_str = ""
            for element in fields_4_keyword_search:
                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
                domains = domains.filter(eval(q_str))
        #Check for country
        domains = domains.filter(country__id = data_dict['country']) if data_dict['country'] else domains
        #Check for costcenters
        domains = domains.filter(costcentre = data_dict['costcenter']) if data_dict['costcenter'] else domains

        expiry_in_date = getDateObject(data_dict.get('expiry_in'))   
        expiry_out_date = getDateObject(data_dict.get('expiry_out'))

        if expiry_in_date and expiry_out_date:
            domains = domains.filter(expiry_date__range = (datetime.datetime.combine(expiry_in_date, datetime.time.min),
                       datetime.datetime.combine(expiry_out_date, datetime.time.max)))
        elif expiry_out_date:
            domains=domains.filter(expiry_date__lte=expiry_out_date)

        elif expiry_in_date:
            domains=domains.filter(expiry_date__gte = expiry_in_date)
        else:
            domains=domains
        #Order by Name
        domains = domains.order_by("name")

        for i in domains:
            if i.id in domains_having_ssl:
                i.has_ssl =True
            else:
                i.has_ssl =False

        return domains


    def get_client_id(self, userid):
        """
            Get client id from user id
        """

        client_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
            client_id = user.clientuser.client_id
        return client_id


    def get_clientuser_id(self, userid):
        """
            Get clientuser id from user id
        """

        clientuser_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
            clientuser_id = user.clientuser.id
        return clientuser_id

    def get_client(self, client_id):
        """
            Get Client on the basis of id
        """
        brand_name = ''
        currency=''
        try:
            client = ClientModel.objects.filter(id=client_id)
        except:
            client = None
        if client:
            client_obj = client[0]
            brand_name = client_obj.name
            currency = client_obj.currency.currency_code
        return client, brand_name, currency

    def get_client_obj(self, client_id):
        """
            Get Client on the basis of id
        """
        brand_name = ''
        try:
            client = ClientModel.objects.get(id=client_id)
        except:
            client = None

        return client

    def get_domain_info_from_instra(self, domain_name):
        """
        """
        obj = InstraDomainManager()
        try:
            response , data = obj.get_domain_info(domain_name)
        except:
            response , data = {}, {}
        return data

    def get_domain_name_by_id(self, domain_id):
        """
            Purpose: To get domain object on the basis of id
            Input: domain_id
            Output: domain-obj
        """
        domain_name = ''
        try:
            domain_obj = Domain.objects.get(id = domain_id)
        except:
            domain_obj = None
        if domain_obj:
            domain_name = domain_obj.name
        return domain_name

    def get_domain_by_id(self, domain_id):
        """
            Purpose: To get domain object on the basis of id
            Input: domain_id
            Output: domain-obj
        """
        try:
            domain_obj = Domain.objects.get(id = domain_id)
        except:
            domain_obj = None
        return domain_obj


    def get_domain_by_name(self, domain_name):
        """
            Purpose: To get domain object on the basis of id
            Input: domain_id
            Output: domain-obj
        """
        try:
            domain_obj = Domain.objects.get(name = domain_name)
        except:
            domain_obj = None
        return domain_obj

    def get_domain_info(self, domain_id):
        """
            Purpose: To get all the domain_related information
        """
        data_dict = {}
        ssl_info_list = []
        domain = Domain.objects.filter(id = domain_id)
        ssl_info = domain[0].ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date")
        for ssls in ssl_info:
            if ssls.has_key("date_of_issue"):
                ssls["date_of_issue"] = datetime.datetime.strftime(ssls["date_of_issue"] ,'%d-%m-%Y' )
            if ssls.has_key("expiry_date"):
                ssls["expiry_date_ssl"] = datetime.datetime.strftime(ssls["expiry_date"] ,'%d-%m-%Y' )
            if ssls.has_key("id"):
                ssls["ssl_id"] = ssls["id"]
            ssl_info_list.append(ssls)
            
        domain_info = domain.values("id", "name", "registrar","client__id","client__name","brand_name","expiry_date","auto_renew","country__id",
                                      "costcentre","client__clientuser__user__first_name","client__clientuser__user__last_name",
                                      "client__country__country_name","client__currency__currency_code","cost_per_annum","expiry_date","notes", 'period',"dns_on_instra","nameserver1","nameserver2","nameserver3","nameserver4","nameserver5","nameserver6")
        if domain_info:
            other_registrar=''
            domain_info = domain_info[0]

            try:
                data_dict['id'] = domain_info['id']
                data_dict['name'] = domain_info['name']
                data_dict['registrar'] = 0 if domain_info['registrar'] == "Web IP" else 1
                if domain_info['registrar']!="Web IP":
                    other_registrar=domain_info['registrar']
                data_dict['other_registrar']=other_registrar
                data_dict['brand_name'] = domain_info['brand_name']
                data_dict['country']=domain_info['country__id']
                data_dict['client'] = domain_info['client__id']
                data_dict['costcentre'] = domain_info['costcentre']
                data_dict['notes'] = domain_info['notes']
                data_dict['auto_renew'] = 'yes' if domain_info['auto_renew'] else 'no'
                data_dict['dns_on_instra'] = domain_info['dns_on_instra']
                data_dict['expiry_date'] = datetime.datetime.strftime(domain_info['expiry_date'] , "%d-%m-%Y")
                data_dict['cost_per_annum'] = domain_info['cost_per_annum']
                data_dict['currency'] = domain_info['client__currency__currency_code']
#                data_dict['name_server_1'] = domain_info['nameserver1']
#                data_dict['name_server_2'] = domain_info['nameserver2']
#                data_dict['name_server_3'] = domain_info['nameserver3']
#                data_dict['name_server_4'] = domain_info['nameserver4']
#                data_dict['name_server_5'] = domain_info['nameserver5']
#                data_dict['name_server_6'] = domain_info['nameserver6']
            except:
                pass
            data = self.get_domain_info_from_instra(domain_info['name'])
            if data.has_key('code') and data['code'] == '541':
                data_dict['instra'] = False
                data_dict['dns_on_instra'] = False
            else:
                data_dict['instra'] = True
                data_dict['dns_on_instra'] = True
            try:
                expiry_date = datetime.datetime.strptime(str(data['expirydate'].split(' ')[0]), "%Y-%m-%d")
                data_dict['expiry_date'] = datetime.datetime.strftime(expiry_date , "%d-%m-%Y")
                #data_dict['auto_renew'] = "yes" if data['renewalmode']=="AUTO-RENEW" or "auto-renew" else "no"
                if data['renewalmode'] == "AUTO-RENEW"  or data['renewalmode']== "auto-renew":
                  data_dict['auto_renew'] = "yes"
                else:
                    data_dict['auto_renew'] = "no"
                data_dict['name_server_1'] = data['nameserver1']
                data_dict['name_server_2'] = data['nameserver2']
                data_dict['name_server_3'] = data['nameserver3']
                data_dict['name_server_4'] = data['nameserver4']
                data_dict['name_server_5'] = data['nameserver5']
                data_dict['name_server_6'] = data['nameserver6']
            except Exception , e:
                pass
        return data_dict , ssl_info_list


    def modify_notes(self, domain_id, data_dict):
        """
            Purpose : To modify notes about domain
            Input: notes
        """
        domain_obj = self.get_domain_by_id(domain_id)
        if domain_obj:
             # code for start edit history
            from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
            history = {}
            if domain_obj:
                history.update(
                               {
                                'notes':domain_obj.notes
                                })
            new_dict={}
            new_dict.update({'notes':data_dict['notes']})
            data = {'old':history, 'new':new_dict}
            # code for end edit
            try:
                domain_obj.notes = data_dict['notes']
                domain_obj.save()
            except:
                return False,''
        return True , domain_obj,data

    def export_domain(self, data_dict={}):
        """
            Purpose: 1. Export all the domains present in the database
                     2. Export all the domains on the basis of serach and filter results
            Input: data_dict (having search and filtered results if any)
        """
        domains = self.get_all_domains(data_dict = data_dict)
        ssl_details_list = []
        for item in domains.iterator():
            ssl_details = item.ssldetails_set.all().values("id","ssl_common_name","provider","type","date_of_issue","expiry_date")
            new_ssl = []
            if ssl_details:
                for ssl in ssl_details:
                    ssl_dict = {}
                    for k , v in ssl.iteritems():
                        if k == "date_of_issue":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        elif k == "expiry_date":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        else:
                            ssl_dict[k] = v
                    new_ssl.append(ssl_dict)
            else:
                new_ssl = ''

            ssl_details_list.append({"ssl_details": str(new_ssl)})

#        domains_info = domains.values("id", "name", "registrar","client__name","brand_name","expiry_date","auto_renew",
#                                      "costcentre","client__clientuser__user__first_name","client__clientuser__user__last_name",
#                                      "client__country__country_name","cost_per_annum","expiry_date","notes")
        domains_info = domains.values("id", "name", "registrar","client__name","brand_name","country__country_name","expiry_date","auto_renew",
                                      "costcentre","client__user__first_name","client__user__last_name",
                                      "client__country__country_name","cost_per_annum","expiry_date","notes")

        for index, domain in enumerate(domains_info):
            try:
                domain.update(ssl_details_list[index])
            except:
                pass
        return domains_info

    def save_uploaded_file(self,file_obj, location):
        """
            Save Uploaded File at temporary location.
        """
        try:
            destination = open(str(location), 'wb+')
            for chunk in file_obj.chunks():
                destination.write(chunk)
            destination.close()
            return True
        except:
            return False

#    def processXLSImportedDomain(self, req_dict, client):
#        """
#            Process dictionary for imported staff.
#        """
#        try:
#            for sheet, value_list in req_dict.iteritems():
#                for val_dct in value_list:
#                    if client:
#                        domain = self.addDomain(client,val_dct)
#                        ssl = self.addSSL(domain,val_dct)
#                    else:
#                        pass
#            return True, "Spreadsheet Uploaded"
#        except Exception, e:
#            print str(e)
#            return False, "Error while processing spreadsheet"


    def processXLSImportedDomain(self, req_dict, client):
        """
            Process dictionary for imported staff.
        """
        error_list = []
        for sheet, value_list in req_dict.iteritems():
            for val_dct in value_list:
                if client:
                    try:
                        status , domain , error = self.addDomain(client,val_dct)
                        if not status:
                            error_list.append((val_dct['Domain Name'], error))
                            try:
                                domain.delete()
                            except:
                                pass
                        ssl , error = self.addSSL(domain,val_dct)
                        if not ssl:
                            error_list.append((val_dct['Domain Name'], error))
                            try:
                                domain.delete()
                            except:
                                pass
                    except Exception , e:
                        error_list.append((val_dct['Domain Name'], str(e)))
                        try:
                            domain.delete()
                        except:
                            pass
                        pass
                else:
                    error_list.append((val_dct['Domain Name'], "Client does not exist"))
                    try:
                        domain.delete()
                    except:
                        pass
                    pass
        return True, "Spreadsheet Uploaded", error_list


    def processCSVImportedDomain(self, req_dict, client):
        """
            Process dictionary for imported staff.
        """
        error_list = []
        for val_dct in req_dict:
            if client:
                try:
                    status , domain , error = self.addDomain(client,val_dct)
                    if not status:
                        error_list.append((val_dct['Domain Name'], error))
                        try:
                            domain.delete()
                        except:
                            pass
                    ssl , error = self.addSSL(domain,val_dct)
                    if not ssl:
                        error_list.append((val_dct['Domain Name'], error))
                        try:
                            domain.delete()
                        except:
                            pass
                except Exception , e:
                    error_list.append((val_dct['Domain Name'], str(e)))
                    try:
                        domain.delete()
                    except:
                        pass
                    pass
            else:
                error_list.append((val_dct['Domain Name'], "Client does not exist"))
                try:
                    domain.delete()
                except:
                    pass
                pass
        return True, "Spreadsheet Uploaded", error_list


    def addDomain(self, client=None, req_dict={}):
        """
            Add Domain
        """
        try:
            domain_obj = Domain.objects.get(name = req_dict['Domain Name'])
        except:
            domain_obj = None
        if not domain_obj:
            try:
                domain_obj  = Domain(name = req_dict['Domain Name'], client = client, brand_name=client.name)
                domain_obj.registrar = 'WebIp' if str(req_dict['Registrar']).lower() == "webip" else req_dict['Registrar']
                domain_obj.costcentre = req_dict['Cost Centre']
                country=self.getCountryObj(req_dict)
                domain_obj.country = country
                domain_obj.expiry_date = getDateObject(req_dict['Expiry Date'])
                domain_obj.auto_renew = True if str(req_dict['Auto Renew']).title() in ['True','Yes'] else False
                domain_obj.notes = str(req_dict['Notes'])
                domain_obj.cost_per_annum = int(str(req_dict['Cost Per Annum']).split('.')[0])
                domain_obj.is_active = True
                domain_obj.save()
                return True , domain_obj,''
            except Exception , e:
                    print "error=============================", str(e)
                    return False , domain_obj, str(e)
        else:
            domain_obj = None
            return False , domain_obj, "Domain already exists."
    
    
    def getCountryObj(self, req_dict={}):
        """
            Save country
        """
        try:
            country = CountryModel.objects.get(country_name__icontains = str(req_dict['Country'].title()))
        except:
            country = None
        return country

#    def addDomain(self, client=None, req_dict={}):
#        """
#            Add Domain
#        """
#        try:
#            domain_obj = Domain.objects.get(name = req_dict['Domain Name'])
#        except:
#            domain_obj = None
#        if not domain_obj:
#            try:
#                domain_obj  = Domain(name = req_dict['Domain Name'], client = client, brand_name=client.name)
#                domain_obj.registrar = 'WebIp' if str(req_dict['Registrar']).lower() == "webip" else req_dict['Registrar']
#                domain_obj.costcentre = req_dict['Cost Centre']
#                try:
#	                domain_obj.expiry_date = datetime.datetime.strptime(str(req_dict['Expiry Date']), "%d-%m-%y")
#                except:
#					try:
#						t_date = req_dict['Expiry Date'].split('-')
#						d, m, y = t_date[0], t_date[1], t_date[2][2:]
#						expiry_date = "-".join([d,m,y])
#						domain_obj.expiry_date = datetime.datetime.strptime(str(expiry_date), "%d-%m-%y")
#					except:
#						pass
#                domain_obj.auto_renew = True if str(req_dict['Auto Renew']).title() in ['True','Yes'] else False
#                domain_obj.notes = str(req_dict['Notes'])
#                domain_obj.cost_per_annum = int(str(req_dict['Cost Per Annum']).split('.')[0])
#                domain_obj.is_active = True
#                domain_obj.save()
#                return True , domain_obj,''
#            except Exception , e:
#                return False , domain_obj, str(e)
#        else:
#            domain_obj = None
#            return False , domain_obj, "Domain already exists."

    def addSSL(self,domain=None, req_dict={}):
        """
            Save SSL details
        """
        e = ''
        ssl_obj = True
        if req_dict.has_key('SSL Details') and req_dict['SSL Details']:
            try:
                data = eval(str(req_dict['SSL Details']))
            except Exception , e:
                data = []
                ssl_obj = None
                return ssl_obj , "ssl error : " + str(e)

            if len(data) != 0:
                for ssl_data in data:
                    try:
                        date_of_issue = getDateObject(ssl_data['date_of_issue']) if ssl_data.has_key('date_of_issue') else None
                        expiry_date = getDateObject(ssl_data['expiry_date'])  if ssl_data.has_key('expiry_date') else None   
                        
                        ssl_obj,is_created = SSLDetails.objects.get_or_create(domain = domain,
                                                                              ssl_common_name = ssl_data['ssl_common_name'],
                                                                              date_of_issue = date_of_issue,
                                                                              expiry_date= expiry_date,
                                                                              provider = ssl_data['provider'],
                                                                              type = ssl_data['type']
                                                                              )
                        ssl_obj.save()
                    except Exception , e:
                        ssl_obj = None
                        return ssl_obj , "ssl error : " +str(e)
        return ssl_obj , str(e)

    def delete_processed_file(self, location):
        """
        """
        try:
            os.remove(location)
        except:
            pass

    def checkForFormat(self, filename):
        """
            Check whether imported file is csv or xls
        """
        try:
            file_format = filename.split(os.extsep)[-1]
        except:
            file_format = ''
        return file_format


class FrontEndSSLManager(object):
    """
    """
    def get_ssl_info(self, domain_id):
        """
        """
        ssl_info_list = []
        domain = Domain.objects.filter(id = domain_id)
        if domain:
            ssl_info = domain[0].ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date")
        for ssls in ssl_info:
            ssl_dict = {}
            for k , v in ssls.iteritems():
                if k == "date_of_issue":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "expiry_date":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict.update({'expiry_date_ssl':nv})
                    ssl_dict[k] = nv
                elif k == "id":
                    ssl_dict["ssl_id"] = v
                else:
                    ssl_dict[k] = v
            ssl_info_list.append(ssl_dict)
        return ssl_info_list

    def get_all_ssl_info(self, client):
        """
        """

        ssl_info_list = []
        domain_list = Domain.objects.filter(client= client)
        if domain_list:
            for domain in domain_list:
                ssl_info = domain.ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date", "domain__name")
                for ssls in ssl_info:
                    ssl_dict = {}
                    for k , v in ssls.iteritems():
                        if k == "date_of_issue":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        elif k == "expiry_date":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict.update({'expiry_date_ssl':nv})
                            ssl_dict[k] = nv
                        elif k == "id":
                            ssl_dict["ssl_id"] = v
                        else:
                            ssl_dict[k] = v
                    ssl_info_list.append(ssl_dict)
        return ssl_info_list
    def get_ssl_info_by_id(self, ssl_id):
        """
        """
        ssl_info_list= []
        ssl_info = SSLDetails.objects.filter(id = ssl_id).values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date", "domain__name")
        for ssls in ssl_info:
            ssl_dict = {}
            for k , v in ssls.iteritems():
                if k == "date_of_issue":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "expiry_date":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict.update({'expiry_date_ssl':nv})
                    ssl_dict[k] = nv
                elif k == "id":
                    ssl_dict["ssl_id"] = v
                else:
                    ssl_dict[k] = v
            ssl_info_list.append(ssl_dict)
        return ssl_info_list[0]

class RegisterNewDomain(object):
    """
    """


    def get_domain_list(self, req_dict):
        """
            Make a list of domains from the domain data returned from request
        """

        all_values = []
        domain_data = req_dict.get('domain',[])
        values = domain_data.split("\r\n") if domain_data else []
        values = [elem for elem in values if elem]
#        values = domain_data.split("\r\n") if domain_data else []
#        values = [elem.replace(' ','') for elem in values if elem]
        all_values.extend(values)
        return all_values

    def check_for_domain_existance(self, domain_list ):
        """
        """
        response , info_dict = InstraDomainManager().check_domain_available(domain_list)
        return info_dict

    def get_all_nameserver_profiles(self, client):
        """
        """
        server_profiles = NameServerProfiles.objects.filter(client= client)
        return server_profiles

    def get_all_nameservers(self, profile_id):
        """
        """
        nameservers = NameServerProfileDetails.objects.filter(profile__id = profile_id)
        return nameservers

    def get_all_registration_profiles(self, client):
        """ Doamin Registration Profile Model """
        reg_prof = DomainRegistration.objects.filter(client = client)
        return  reg_prof
    def get_all_registration_object(self, client):
        """ Doamin Registration Profile Model """
        #reg_prof = DomainRegistration.objects.get(client = client)
        reg_prof = DomainRegistration.objects.filter(client = client)
        return  reg_prof

    def get_all_profile_details(self, profile_id):
        """
        """
        profiles = RegistrationDetails.objects.filter(profile__id = profile_id).values("id","profile__id","name","email","phone","fax","address1","address2","city","state","country__id","country__country_name","postalcode","profile_type","profile__profile_name", "profile__company_name","profile__abn_number")
        profile_dict = {}
        for profile in profiles:
            if profile['profile_type'] == "admin":
                profile_dict['name'] = profile['name']
                profile_dict['email'] = profile['email']
                profile_dict['phone'] = profile['phone']
                profile_dict['fax'] = profile['fax']
                profile_dict['address1'] = profile['address1']
                profile_dict['address2'] = profile['address2']
                profile_dict['city'] = profile['city']
                profile_dict['state'] = profile['state']
                profile_dict['country_id'] = profile['country__id']
                profile_dict['country_name'] = profile['country__country_name']
                profile_dict['profile_name'] = profile['profile__profile_name']
                profile_dict['company_name'] = profile['profile__company_name']
                profile_dict['abn_number'] = profile['profile__abn_number']
                profile_dict['postalcode'] = profile['postalcode']
                profile_dict['admin_id'] = profile['id']
                profile_dict['reg_id'] = profile['profile__id']
            if profile['profile_type'] == "tech":
                profile_dict['tech_name'] = profile['name']
                profile_dict['tech_email'] = profile['email']
                profile_dict['tech_phone'] = profile['phone']
                profile_dict['tech_fax'] = profile['fax']
                profile_dict['tech_address1'] = profile['address1']
                profile_dict['tech_address2'] = profile['address2']
                profile_dict['tech_city'] = profile['city']
                profile_dict['tech_state'] = profile['state']
                profile_dict['tech_country_id'] = profile['country__id']
                profile_dict['tech_country_name'] = profile['country__country_name']
                profile_dict['tech_postalcode'] = profile['postalcode']
                profile_dict['profile_name'] = profile['profile__profile_name']
                profile_dict['company_name'] = profile['profile__company_name']
                profile_dict['abn_number'] = profile['profile__abn_number']
                profile_dict['tech_id'] = profile['id']
                profile_dict['reg_id'] = profile['profile__id']
        return profile_dict

    def get_all_countries(self):
        """
        """
        countries = CountryModel.objects.all().values("id", "country_name").order_by('country_name')
        return countries

    def get_country_by_id(self, country_id):
        """
        """
        country = CountryModel.objects.get(id = country_id)
        return country

    def save_registration_profile(self, client, req_dict):
        """
        """

        reg_prof = None
        try:
            reg_prof = DomainRegistration(client = client,client_user = client.user.clientuser)
            reg_prof.profile_name = req_dict['profile_name']
            reg_prof.company_name = req_dict['company_name']
            reg_prof.abn_number = req_dict['abn_number']
            reg_prof.save()
        except Exception,e:
            print "EERROR",str(e)
            pass
        return reg_prof



    def save_profile_details(self, client, req_dict):
        """
        """
        reg_prof = self.save_registration_profile(client, req_dict)
        country = self.get_country_by_id(int(req_dict['country']))
        country1 = self.get_country_by_id(int(req_dict['tech_country']))

        try:
            profl_obj = RegistrationDetails(profile = reg_prof, country = country)
            profl_obj.name = req_dict['name']
            profl_obj.email = req_dict['email']
            profl_obj.phone = req_dict['phone']
            profl_obj.fax = req_dict['fax']
            profl_obj.address1 = req_dict['address1']
            profl_obj.address2 = req_dict['address2']
            profl_obj.city = req_dict['city']
            profl_obj.state = req_dict['state']
            profl_obj.postalcode = req_dict['postalcode']
            profl_obj.profile_type = "admin"
            profl_obj.save()
        except:
            pass

        try:
            profl_obj1 = RegistrationDetails(profile = reg_prof, country = country1)
            profl_obj1.name = req_dict['tech_name']
            profl_obj1.email = req_dict['tech_email']
            profl_obj1.phone = req_dict['tech_phone']
            profl_obj1.fax = req_dict['tech_fax']
            profl_obj1.address1 = req_dict['tech_address1']
            profl_obj1.address2 = req_dict['tech_address2']
            profl_obj1.city = req_dict['tech_city']
            profl_obj1.state = req_dict['tech_state']
            profl_obj1.postalcode = req_dict['tech_postalcode']
            profl_obj1.profile_type = "tech"
            profl_obj1.save()
        except:
            pass

        return profl_obj

    def save_nameserver_profile(self, client, req_dict):
        """
        """
        reg_prof = None
        try:
            reg_prof = NameServerProfiles(client = client,client_user = client.user.clientuser)
            reg_prof.profile_name = req_dict['profile_name']
            reg_prof.save()
        except:
            pass
        return reg_prof

    def save_nameserverprofile_details(self, client, req_dict):
        """
        """
        reg_prof = self.save_nameserver_profile(client, req_dict)
        for k , v in req_dict.iteritems():
            try:
                if k == "profile_name":
                    reg_prof.profile_name = v
                if k.startswith("nameserver"):
                    nameserver , order =  k.split("_")
                    if v:
                        server_obj = NameServerProfileDetails(profile_id = reg_prof.id)
                        server_obj.nameserver = v
                        server_obj.order = order
                        server_obj.save()
                    else:pass
                else:pass
            except Exception , e:
                print "Exception in nameserver profile details", str(e)
        return True

    def get_registration_profile_object(self, reg_id):
        """
        """
        try:
            reg_prof = DomainRegistration.objects.get(id = reg_id)
        except:
            reg_prof = None
        return  reg_prof

    def modify_profile_details(self, client, req_dict):
        """
        """

        country = self.get_country_by_id(int(req_dict['country']))
        country1 = self.get_country_by_id(int(req_dict['tech_country']))
        try:

            reg_prof = self.get_registration_profile_object(int(req_dict['reg_id']))
            #reg_prof.profile_name = req_dict['profile_name']
            reg_prof.company_name = req_dict['company_name']
            reg_prof.abn_number = req_dict['abn_number']
            reg_prof.save()
        except:
            pass

        try:
            profl_obj = RegistrationDetails.objects.get(id = req_dict['admin_id'])
        except:
            profl_obj = RegistrationDetails(profile = reg_prof, country__id = int(req_dict['country']))
        try:
            profl_obj.name = req_dict['name']
            profl_obj.email = req_dict['email']
            profl_obj.phone = req_dict['phone']
            profl_obj.fax = req_dict['fax']
            profl_obj.address1 = req_dict['address1']
            profl_obj.address2 = req_dict['address2']
            profl_obj.city = req_dict['city']
            profl_obj.state = req_dict['state']
            profl_obj.postalcode = req_dict['postalcode']
            profl_obj.profile_type = "admin"
            profl_obj.country = country
            profl_obj.save()
        except:
            pass

        try:
            profl_obj1 = RegistrationDetails.objects.get(id = req_dict['tech_id'])
        except:
            profl_obj1 = RegistrationDetails(profile = reg_prof, country__id = req_dict['country'])
        try:
            profl_obj1.name = req_dict['tech_name']
            profl_obj1.email = req_dict['tech_email']
            profl_obj1.phone = req_dict['tech_phone']
            profl_obj1.fax = req_dict['tech_fax']
            profl_obj1.address1 = req_dict['tech_address1']
            profl_obj1.address2 = req_dict['tech_address2']
            profl_obj1.city = req_dict['tech_city']
            profl_obj1.state = req_dict['tech_state']
            profl_obj1.postalcode = req_dict['tech_postalcode']
            profl_obj1.profile_type = "tech"
            profl_obj1.country = country1
            profl_obj1.save()
        except:
            pass

        return profl_obj

    def get_nameserver_details(self, nameserver_id):
        """
        """
        nameservers = NameServerProfileDetails.objects.filter(profile__id = nameserver_id).values("id","nameserver","profile__profile_name","order")
        nameservers = nameservers.order_by("order")
        return nameservers


    def modify_nameserver_details(self, nameserver_id, req_dict):
        """
        """
        try:
            nameserver_obj = NameServerProfiles.objects.get(id = nameserver_id)
            #nameserver_obj.profile_name=req_dict['profile_name']
            nameserver_obj.save()
        except:
            nameserver_obj = None
        nameserver_detail_obj = NameServerProfileDetails.objects.filter(profile__id = nameserver_id)
        try:
            nameserver_detail_obj.delete()
        except:
            pass

        for k , v in req_dict.iteritems():
            #if k == "profile_name":
            #    nameserver_obj.profile_name = v
            if k.startswith("nameserver"):
                nameserver , order =  k.split("_")
                if v:
                    server_obj = NameServerProfileDetails(profile = nameserver_obj)
                    server_obj.nameserver = v
                    server_obj.order = order
                    server_obj.save()
                else:pass
            else:pass
        return True

    def get_namserver_profile_name(self, nameserver_id):
        """
        """
        try:
            prof = NameServerProfiles.objects.get(id = nameserver_id)
            prof_name  = prof.profile_name
        except:
            prof_name = ''
        return prof_name

    def get_regsitration_profile_name(self, profile_id):
        """
        """
        try:
            prof = DomainRegistration.objects.get(id = profile_id)
            prof_name  = prof.profile_name
        except:
            prof_name = ''
        return prof_name


    def process_data_for_email(self, req_dict):
        """
        """
        data_dict = {}
        if req_dict.has_key("domain_name"):
            data_dict['domain_list'] = req_dict["domain_name"]
        if req_dict.has_key("nameserver_profile"):
            data_dict['nameserver_profile'] = self.get_namserver_profile_name(req_dict["nameserver_profile"])
        if req_dict.has_key("registration_profile_name"):
            data_dict['registration_profile'] = self.get_regsitration_profile_name(req_dict["registration_profile_name"])
        if req_dict.has_key("auto_renew"):
            data_dict['auto_renew'] = req_dict["auto_renew"]
        if req_dict.has_key("period"):
            data_dict['period'] = req_dict["period"]
        return data_dict

    def checkForClientsRegistrationProfile(self , client):
        """
            Check whether the clients registration profile already exists
        """
        status = DomainRegistration.objects.filter(client = client)
        return status

    def checkForClientsNameServerProfile(self , client):
        """
            Check whether the clients registration profile already exists
        """
        status = NameServerProfiles.objects.filter(client = client)
        return status

