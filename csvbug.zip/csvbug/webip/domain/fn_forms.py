# import re
from django import forms
# from django.http import HttpResponseRedirect
# from django.shortcuts import render_to_response
from datetime import *
from django import forms
from django.utils.safestring import mark_safe
from client.models import ClientModel , InstraCorpUser,ClientUser,ClientDomainCategory
from domain.models import *
from admin_app.models import CountryModel
# from django.core import validators
# from django.forms.util import ErrorList
import re
import os
import json
from datetime import datetime
from utils.get_instra_domain import InstraDomainManager
from domain_manager import DomainManager
from django.core import validators
# from django.forms.widgets import RadioSelect
from django.contrib.auth.models import User

REGISTRAR=[("select"," Please Select"),(0,'Web IP'),(1,'Other')]
PERIOD = [("select","Select"),(1,'1 yr'),(2,'2 yrs'),(3,'3 yrs'),(4,'4 yrs'),(5,'5 yrs'),(6,'6 yrs'),(7,'7 yrs'),(8,'8 yrs'),(9,'9 yrs')]

class CustomRadioRenderer(forms.RadioSelect.renderer):
    """ this overrides widget method to put radio buttons horizontally
        instead of vertically.
    """
    def render(self):
            """Outputs radios"""
            return mark_safe(u'\n'.join([u'%s\n' % w for w in self]))



class DomainForm(forms.Form): # Inherit SSL Form
    """ Form used to add event """

    def __init__(self, *args, **kwargs) :
        """ Constructor for AddForm """
        if kwargs.has_key("edit"):
            edit = kwargs.pop("edit")
        else:
            edit = False
        self.data = kwargs.get("data", {})
        self.edit = edit
        
        super(DomainForm, self).__init__( *args, **kwargs)
        self.fields['country'].empty_label = 'Please Select'
#        if self.edit:
#            self.fields['name'].widget.attrs['readonly'] = True


    name = forms.CharField(label="Domain Name:", max_length=50, required = True,
            widget=forms.TextInput(attrs={'class':'login_input'}),
            validators=[validators.RegexValidator(regex=re.compile('^(http[s]?://|ftp://)?(www\.)?[a-zA-Z0-9-\.]+(\.[a-zA-Z0-9-\.]+)+([/?].+)?$'), code='invalid')],
                                error_messages = {'invalid': 'Enter the Domain Name in proper format'})
    registrar = forms.ChoiceField(label="Registrar:", required = True,choices = REGISTRAR,
                                widget=forms.Select(attrs={'class':'add_use_drop_SSL webip_select_pop','id':'speedD'}),
                                error_messages = {'required': 'Registrar is required'})
    costcentre = forms.CharField(label="Cost Centre:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Cost Centre is required'})

    auto_renew = forms.ChoiceField(label="Auto Renew",required = True,choices=(('yes','YES'),('no','NO')),
                                widget=forms.RadioSelect(renderer=CustomRadioRenderer),
                                error_messages = {'required': 'Auto Renew is required'})

#    auto_renew = forms.CharField(label="Auto Renew",required = True,
#                                widget=forms.RadioSelect(renderer=HorizRadioRenderer,choices=(('yes','YES'),('no','NO')), attrs = {"class":"div20CC fltL marR_10 pad_4" }),
#                                error_messages = {'required': 'Auto Renew is required'})
    brand_name = forms.CharField(label="Brand Name:",required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Brand Name is required'})
#    client = forms.ChoiceField(label="Clients:",required = True,choices = clients,
#                                widget=forms.Select(attrs={'class':'add_user_drop4','id':'speedD'}),
#                                error_messages = {'required': 'Clients is required'})
#    period = forms.ChoiceField(label="Period:",required = True,choices = PERIOD,
#                                widget=forms.Select(attrs={'class':'popinput-domain'}),
#                                error_messages = {'required': 'Period is required'})
    notes = forms.CharField(label="Notes:", required = False,
                                widget=forms.Textarea(attrs={'class':'textarea'}))
#    cost_per_annum = forms.CharField(max_length=9,label="Annual Cost", validators=[validators.RegexValidator(regex=re.compile('[0-9]'),code='invalid')],required = True,
#                                widget=forms.TextInput(attrs={'class':'domain_file_inputsmall'}))

    cost_per_annum = forms.DecimalField(label="Annual Cost:",max_digits=9, decimal_places=2,required = True,
                                widget=forms.TextInput(attrs={'class':'domain_file_inputsmall'}))
    
    country = forms.ModelChoiceField(queryset = CountryModel.objects.all().order_by('country_name'),label=("Country"),widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop2 webip_select_pop'}),error_messages = {'required': 'Conutry Field is required'},required = True)
    currency = forms.CharField(max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'adddomain_file_inputsmall','readonly':'readonly'}))
    expiry_date = forms.DateField(label="Expiry Date:", required = True,
                                widget=forms.DateInput(attrs={'class':"text_date datepicker"}),input_formats=["%d-%m-%Y"],
                                error_messages = {'required': 'Expiry Date is required'})
    
    instra_id = forms.CharField(label="Instra handler id",widget=forms.HiddenInput(),required = False)
    
    name_server_1 = forms.CharField(label="Name Server 1:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Nameserver is required'})
    name_server_2 = forms.CharField(label="Name Server 2:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Nameserver is required'})
    name_server_3 = forms.CharField(label="Name Server 3:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))
    name_server_4 = forms.CharField(label="Name Server 4:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))
    name_server_5 = forms.CharField(label="Name Server 5:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))
    name_server_6 = forms.CharField(label="Name Server 6:",required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))

    dns_on_instra = forms.CharField(label="DNS On Instra",widget=forms.HiddenInput(),required = False)


    def save_domain(self ,user_id = None,  form=None,registrar_val=None):
        """
            Save Domain Details
        """
        data = form.cleaned_data
        client_id = self.get_client_id(user_id)
        client_user_id = self.get_client_user_id(user_id)
        client, brand_name, currency = self.get_client(client_id)
        if data.has_key('expiry_date'):
            expiry_date = self.string_to_date(data['expiry_date'])
        try:
            domain_obj ,is_created = Domain.objects.get_or_create(name = data['name'], client = client[0], brand_name=data['brand_name'])
            domain_obj.registrar = 'Web IP' if int(data['registrar']) == 0 else registrar_val
            domain_obj.costcentre = data['costcentre']
            if client_user_id:
                try:
                    client_user_obj=ClientUser.objects.get(id=client_user_id)
                except:
                    client_user_obj=None
                if client_user_obj.user_type=='subuser':
                    try:
                        client_domain_category=ClientDomainCategory.objects.get(client=client_user_obj)
                        current_category = []
                        current_category=json.loads(client_domain_category.category)
                        current_category.append(data['costcentre'])
                        client_domain_category.category = json.dumps(current_category)
                    except:
                        cat_list = []
                        cat_list.append(data['costcentre'])
                        client_domain_category=ClientDomainCategory(client=client_user_obj)
                        client_domain_category.category = json.dumps(cat_list)
                    
                    client_domain_category.save()
            domain_obj.notes = str(data['notes'])
            domain_obj.cost_per_annum = str(data['cost_per_annum'])
            domain_obj.is_active = True
            country_obj=CountryModel.objects.get(id=data['country'].id)
            domain_obj.country=country_obj
            if str(data['dns_on_instra']) == 'True':
                domain_obj.dns_on_instra =True
                response_dict = self.update_instra_domain(data,data['instra_id'])
                autorenew_status="1" if str(data['auto_renew']) == 'yes' else "0"
                obj = InstraDomainManager()
                autorenew_response = obj.set_domain_autorenew(str(data['name']), autorenew_status)
                domain_obj.instra_id = data['instra_id']
                domain_obj.expiry_date = data['expiry_date']
                domain_obj.auto_renew = True if str(data['auto_renew']) == 'yes' else False
            else:
                domain_obj.dns_on_instra =False
                domain_obj.expiry_date = data['expiry_date']
                domain_obj.auto_renew = True if str(data['auto_renew']) == 'yes' else False               
                
            domain_obj.save()
            return True , domain_obj
        except Exception , e:
            print "Exception while saving domain", str(e)
            try:
                domain_obj.delete()
            except:
                pass
            return False,str(e)


    def create_instra_domain(self, data, handlercontactid):
        """
        """
        instra_dict = {}
        nameserver_dict = {}
        instra_dict['domain'] = data['name']
        instra_dict['registrantcontact'] = handlercontactid
        instra_dict['admincontact'] = handlercontactid
        instra_dict['techcontact'] = handlercontactid
        instra_dict['billingcontact'] = handlercontactid
        instra_dict['period'] = data['period']
        if data.has_key('name_server_1') and data['name_server_1'] != '':
            nameserver_dict['nameserver1'] = "ns1."+str(data['name_server_1'])
        if data.has_key('name_server_2') and data['name_server_2'] != '':
            nameserver_dict['nameserver2'] = "ns2."+str(data['name_server_2'])
        if data.has_key('name_server_3') and data['name_server_3'] != '':
            nameserver_dict['nameserver3'] = "ns3."+str(data['name_server_3'])
        if data.has_key('name_server_4') and data['name_server_4'] != '':
            nameserver_dict['nameserver4'] = "ns4."+str(data['name_server_4'])
        if data.has_key('name_server_5') and data['name_server_5'] != '':
            nameserver_dict['nameserver5'] = "ns5."+str(data['name_server_5'])
        if data.has_key('name_server_6') and data['name_server_6'] != '':
            nameserver_dict['nameserver6'] = "ns6."+str(data['name_server_6'])
        obj = InstraDomainManager()
        response , data = obj.create_domain(instra_dict, nameserver_dict)
        return data

    def modify(self, form=None,registrar_val=None,domain_id=None,client_user_id=None):
        """
        """
        
        data = form.cleaned_data
        if data.has_key('client'):
            client, brand_name, currency = self.get_client(int(data['client']))
        try:
            domain_obj= Domain.objects.get(id=domain_id)
            domain_obj.name = data['name']
            domain_obj.registrar = 'Web IP' if int(data['registrar']) == 0 else registrar_val
            old_costcenter=domain_obj.costcentre
            domain_obj.costcentre = data['costcentre']
            domain_obj.brand_name=data['brand_name']
            domain_obj.notes = str(data['notes'])
            domain_obj.cost_per_annum = str(data['cost_per_annum'])
            country_obj=CountryModel.objects.get(id=data['country'].id)
            domain_obj.country=country_obj
            domain_obj.is_active = True    
            if str(data['dns_on_instra']) == 'False':
                domain_obj.expiry_date = data['expiry_date']
                domain_obj.auto_renew = True if str(data['auto_renew']) == 'yes' else False
                domain_obj.dns_on_instra = False    
#                if data.has_key('name_server_1') and data['name_server_1'] != '':
#                    domain_obj.nameserver1= str(data['name_server_1'])
#                if data.has_key('name_server_2') and data['name_server_2'] != '':
#                    domain_obj.nameserver2 = str(data['name_server_2'])
#                if data.has_key('name_server_3') and data['name_server_3'] != '':
#                    domain_obj.nameserver3 = str(data['name_server_3'])
#                if data.has_key('name_server_4') and data['name_server_4'] != '':
#                    domain_obj.nameserver4 = str(data['name_server_4'])
#                if data.has_key('name_server_5') and data['name_server_5'] != '':
#                    domain_obj.nameserver5 = str(data['name_server_5'])
#                if data.has_key('name_server_6') and data['name_server_6'] != '':
#                    domain_obj.nameserver6 = str(data['name_server_6'])
                    
            else:
                domain_obj.dns_on_instra =True
                # changes in the instra directly
                response_dict = self.update_instra_domain(data,data['instra_id'])
                autorenew_status="1" if str(data['auto_renew']) == 'yes' else "0"
                obj = InstraDomainManager()
                autorenew_response = obj.set_domain_autorenew(str(data['name']), autorenew_status)
                # chanes in database
                domain_obj.auto_renew = True if str(data['auto_renew']) =='yes' else False
#                if data.has_key('name_server_1') and data['name_server_1'] != '':
#                    domain_obj.nameserver1= str(data['name_server_1'])
#                if data.has_key('name_server_2') and data['name_server_2'] != '':
#                    domain_obj.nameserver2 = str(data['name_server_2'])
#                if data.has_key('name_server_3') and data['name_server_3'] != '':
#                    domain_obj.nameserver3 = str(data['name_server_3'])
#                if data.has_key('name_server_4') and data['name_server_4'] != '':
#                    domain_obj.nameserver4 = str(data['name_server_4'])
#                if data.has_key('name_server_5') and data['name_server_5'] != '':
#                    domain_obj.nameserver5 = str(data['name_server_5'])
#                if data.has_key('name_server_6') and data['name_server_6'] != '':
#                    domain_obj.nameserver6 = str(data['name_server_6'])
                    
            #domain category code start
            if client_user_id:
                try:
                    client_user_obj=ClientUser.objects.get(id=client_user_id)
                except:
                    client_user_obj=None
                if client_user_obj.user_type=='subuser':
                    try:
                        
                        client_domain_category=ClientDomainCategory.objects.get(client=client_user_obj)
                        current_category = []
                        current_category=json.loads(client_domain_category.category)
                        for i in current_category:
                            if i == old_costcenter:
                                current_category.remove(i)
                        current_category.append(data['costcentre'])
                        client_domain_category.category = json.dumps(current_category)
                    except:
                        cat_list = []
                        cat_list.append(data['costcentre'])
                        client_domain_category=ClientDomainCategory(client=client_user_obj)
                        client_domain_category.category = json.dumps(cat_list)
                    
                    client_domain_category.save()
            
            #domain categoru code end        
        
            domain_obj.save()
        except Exception , e:
            print "Exception while saving domain", str(e)
            domain_obj= None
            return False , domain_obj
        return True , domain_obj
#        else:
#            return False , None

    def update_instra_domain(self, data, handlercontactid):
        """
        """
        instra_dict = {}
        nameserver_dict = {}
        instra_dict['domain'] = data['name']
        instra_dict['registrantcontact'] = handlercontactid
        instra_dict['admincontact'] = handlercontactid
        instra_dict['techcontact'] = handlercontactid
        instra_dict['billingcontact'] = handlercontactid
        if data.has_key('name_server_1') and data['name_server_1'] != '':
            nameserver_dict['nameserver1'] = str(data['name_server_1'])
        if data.has_key('name_server_2') and data['name_server_2'] != '':
            nameserver_dict['nameserver2'] = str(data['name_server_2'])
        if data.has_key('name_server_3') and data['name_server_3'] != '':
            nameserver_dict['nameserver3'] = str(data['name_server_3'])
        if data.has_key('name_server_4') and data['name_server_4'] != '':
            nameserver_dict['nameserver4'] = str(data['name_server_4'])
        if data.has_key('name_server_5') and data['name_server_5'] != '':
            nameserver_dict['nameserver5'] = str(data['name_server_5'])
        if data.has_key('name_server_6') and data['name_server_6'] != '':
            nameserver_dict['nameserver6'] = str(data['name_server_6'])
        obj = InstraDomainManager()
        response , data = obj.update_domain(instra_dict, nameserver_dict)
        return data

    def get_client_id(self, userid):
        """
            Get client id from user id
        """
        client_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
            client_id = user.clientuser.client_id
        return client_id
    
    def get_client_user_id(self, userid):
        """
            Get client id from user id
        """
        client_user_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
            client_user_id = user.clientuser.id
        return client_user_id
    
    

    def get_client(self, client_id):
        """
            Get Client on the basis of id
        """
        brand_name = ''
        try:
            client = ClientModel.objects.filter(id=client_id)
        except:
            client = None
        if client:
            client_obj = client[0]
            brand_name = client_obj.name
            currency = client_obj.currency.currency_code
        return client, brand_name, currency

    def create_instra_contact(self, client):
        """
            Get Client details and create contact in Instra
        """
        client_dict = {}
        client = client.values("clientuser__user__first_name" , "clientuser__user__last_name",
                      "clientuser__user__email", "country__country_code",
                       "clientuser__user__userprofilemodel__phone",'clientuser__user__id')
        for item in client:
                for k , v in item.iteritems():
                    client_dict[k] = v
        try:
            corp_obj= InstraCorpUser.objects.get(user_id = int(client_dict['clientuser__user__id']))
        except:
            corp_obj = None
        if not corp_obj:
            obj = InstraDomainManager()
            response , data = obj.create_contact(client_dict)
            if data:
                corp_obj,is_created = InstraCorpUser.objects.get_or_create(user_id = int(client_dict['clientuser__user__id']))
                corp_obj.instra_id = data
                corp_obj.save()
                return True, corp_obj
            else:
                return False, None
        else:
            return True , corp_obj

    def string_to_date(self, datestring, format='%d-%m-%Y'):
        """
            Convert string into datetime object
        """
        try:
            date_object = datetime.strptime(str(datestring), format)
        except:
            date_object = None
        return date_object


    def clean(self):
        """ Method to validation form"""
        if not self.edit:
            # Null checking
            name = self.cleaned_data.get('name')
            if not name :
                pass
#                error_message = {"Domain Name is required":''}
#                self._errors['name'] = error_message

            else :
                # Check if domain name already exist
                try :
                    status = DomainManager().check_domain_name_availability(name)
                    if not status:
                        error_message = ["Domain Name already exists"]
                        self._errors['name'] = error_message
                except :
                    pass

        registrar = self.cleaned_data.get('registrar')
        if registrar.lower() == 'select' or not registrar :
            error_message = ["Registrar is required"]
            self._errors['registrar'] = error_message

        brand_name = self.cleaned_data.get('brand_name')
        if not brand_name:
            error_message = ["Brand Name is required"]
            self._errors['brand_name'] = error_message

        #if self._errors.has_key('cost_per_annum'):
         #   self._errors.pop('cost_per_annum') #for cleanup predefine validation
        
        
        costcentre = self.cleaned_data.get('costcentre')
        if not costcentre:
            error_message = ["Cost Centre is required"]
            self._errors['costcentre'] = error_message
        

        cost_per_annum = self.data.get('cost_per_annum')
        if cost_per_annum=='' and cost_per_annum==None:
            error_message = ["Cost per annum is required"]
            self._errors['cost_per_annum'] = error_message

        if cost_per_annum:
            if '.' in cost_per_annum:
                cost_per_annum=str(cost_per_annum).split(".")[0]+'.'+str(cost_per_annum).split(".")[1][:2]
                self.cleaned_data['cost_per_annum'] = cost_per_annum
            if not '.' in cost_per_annum: cost_per_annum = cost_per_annum+'.00'
            res = re.match('^[\d]{1,7}?\.[\d]{0,2}?$',str(cost_per_annum))
            if not res:
                error_message = ["cost per annum should be 7 digits and two digit precision."]
                self._errors['cost_per_annum'] = error_message


#        period = self.cleaned_data.get('period')
#        if period.lower() == 'select' or not period :
#            error_message = "Period is required"
#            self._errors['period'] = error_message

        expiry_date = self.cleaned_data.get('expiry_date')
        if not expiry_date:
            error_message = ["Expiry Date is required"]
            self._errors['expiry_date'] = error_message
        instra_status=self.cleaned_data.get('dns_on_instra')
        if instra_status == 'False':
            if expiry_date:
                today_date=datetime.today().date()
                if expiry_date < today_date:
                    error_message = ["Expiry date should not be less than Current date"]
                    self._errors['expiry_date'] = error_message

#        if not self.edit:
#            # Null checking
##            name_server_1 = self.cleaned_data.get('name_server_1')
#            if not name_server_1 :
#                error_message = {"Name Server is required":''}
#                self._errors['name_server_1'] = error_message
#            else :
#                # Check if domain name already exist
#                try :
#                    status = DomainManager().check_nameserver_availability(name_server_1)
#                    if not status:
#                        error_message = {"Name server already exists":''}
#                        self._errors['name_server_1'] = error_message
#                except :
#                    pass
#
#        if not self.edit:
#            # Null checking
#            name_server_2 = self.cleaned_data.get('name_server_2')
#            if not name_server_2 :
#                error_message = {"Name Server is required":''}
#                self._errors['name_server_2'] = error_message
#            else :
#                # Check if domain name already exist
#                try :
#                    status = DomainManager().check_nameserver_availability(name_server_2)
#                    if not status:
#                        error_message = {"Name server already exists":""}
#                        self._errors['name_server_2'] = error_message
#                except :
#                    pass
#        # Null checking
#        name_server_3 = self.cleaned_data.get('name_server_3')
#        if  name_server_3 :
#            # Check if domain name already exist
#            try :
#                status = DomainManager().check_nameserver_availability(name_server_3)
#                if not status:
#                    error_message = {"Name server already exists":""}
#                    self._errors['name_server_3'] = error_message
#            except :
#                pass
#        # Null checking
#        name_server_4 = self.cleaned_data.get('name_server_4')
#        if  name_server_4 :
#            # Check if domain name already exist
#            try :
#                status = DomainManager().check_nameserver_availability(name_server_4)
#                if not status:
#                    error_message = {"Name server already exists":''}
#                    self._errors['name_server_4'] = error_message
#            except :
#                pass
#        # Null checking
#        name_server_5 = self.cleaned_data.get('name_server_5')
#        if name_server_5 :
#            # Check if domain name already exist
#            try :
#                status = DomainManager().check_nameserver_availability(name_server_5)
#                if not status:
#                    error_message = {"Name server already exists":''}
#                    self._errors['name_server_5'] = error_message
#            except :
#                pass
#
#        # Null checking
#        name_server_6 = self.cleaned_data.get('name_server_6')
#        if name_server_6 :
#            # Check if domain name already exist
#            try :
#                status = DomainManager().check_nameserver_availability(name_server_6)
#                if not status:
#                    error_message = {"Name server already exists":''}
#                    self._errors['name_server_6'] = error_message
#            except :
#                pass
       
        return self.cleaned_data


#===============================================================================
# SSL FORM
#===============================================================================


class SSLForm(forms.Form):
    """ Repeatative SSl form """

    def __init__(self, *args, **kwargs ) :
        """ Constructor for AddForm """
        self.data = kwargs.get("data", {})
        self.edit = kwargs.get("edit", "")
        super(SSLForm, self).__init__( *args, **kwargs)

    ssl_id = forms.CharField(label="ssl_id",widget=forms.HiddenInput(),required = False)
    ssl_common_name = forms.CharField(label="SSL Common Name:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'SSL Common Name is required'})
    provider = forms.CharField(label="Provider:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Provider is required'})
    type = forms.CharField(label="SSL Type:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Type is required'})
    date_of_issue = forms.DateField(label="Date of Issue:", required = True,
                                widget=forms.DateInput(attrs={'class':"text_date datepicker"}),input_formats=["%d-%m-%Y"],
                                error_messages = {'required': 'Date of Issue is required'})
    expiry_date_ssl = forms.DateField(label="Expiry Date:", required = True,
                                widget=forms.DateInput(attrs={'class':"text_date datepicker"}),input_formats=["%d-%m-%Y"],
                                error_messages = {'required': 'Expiry Date is required'})

    def save_ssl(self, domain, form=None):
        """
            Save SSL details
        """
        data = form.cleaned_data
        if data.has_key('date_of_issue'):
            date_of_issue = DomainForm().string_to_date(data['date_of_issue'])
        if data.has_key('expiry_date'):
            expiry_date = DomainForm().string_to_date(data['expiry_date'])
        try:
            ssl_obj,is_created = SSLDetails.objects.get_or_create(domain = domain,
                                                                  ssl_common_name = data['ssl_common_name'],
                                                                  date_of_issue = data['date_of_issue'],
                                                                  expiry_date= data['expiry_date_ssl'],
                                                                  provider = data['provider'],
                                                                  type = data['type']
                                                                  )
            ssl_obj.save()
        except:
            ssl_obj = None
        return ssl_obj

    def update_ssl(self, domain, form=None):
        """
            Save SSL details
        """

        final_data={}
        data = form.cleaned_data
        if not data:
            return None,final_data
        try:
            id = data.pop("ssl_id")
        except:
            id = ''
        if not id:
            ssl_obj=SSLDetails(domain = domain,date_of_issue = data['date_of_issue'],ssl_common_name=data['ssl_common_name'],
                                                                  expiry_date= data['expiry_date_ssl'],
                                                                  provider = data['provider'],
                                                                  type = data['type']
                                                                  )
            ssl_obj.save()
            return ssl_obj,final_data
        try:
            ssl_obj = SSLDetails.objects.get(id = id)
              # code for start edit history
            if ssl_obj:
                from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
                history = {}
                result_array_new={}
                result_array_old={}
                final_data={}
                old_expiry_date=''
                old_issue_date=''
                old_expiry_date=''
                new_date_dict=''
                ex_date_dict=''
                new_date_dict1=''
                ex_date_dict1=''
                if ssl_obj:
                    history.update(
                                   {
                                    'ssl_common_name':ssl_obj.ssl_common_name,
                                    'provider':ssl_obj.provider,
                                    'type':ssl_obj.type
                                    })

                result_array_new, result_array_old = Diff_match(history, data)
                try:
                    old_issue_date=ssl_obj.date_of_issue.strftime("%d-%m-%Y")
                    new_issue_date=data['date_of_issue'].strftime("%d-%m-%Y")
                    old_expiry_date=ssl_obj.expiry_date.strftime("%d-%m-%Y")
                    new_expiry_date=data['expiry_date_ssl'].strftime("%d-%m-%Y")
                    new_date_dict, ex_date_dict = Date_match(old_issue_date,new_issue_date)
                    new_date_dict1, ex_date_dict1 = Date_match(old_expiry_date,new_expiry_date)
                except:
                        old_expiry_date=''
                        old_issue_date=''
                result_array_new.update(new_date_dict)
                result_array_old.update(ex_date_dict)
                result_array_new.update(new_date_dict1)
                result_array_old.update(ex_date_dict1)

                if result_array_new or result_array_old:
                    final_data = {'old':result_array_old, 'new':result_array_new}
                else:
                     final_data = None
                # code for end edit

        except Exception , e:
            ssl_obj= SSLDetails(domain = domain)
        ssl_obj.ssl_common_name =data['ssl_common_name']
        ssl_obj.date_of_issue = data['date_of_issue']
        ssl_obj.expiry_date= data['expiry_date_ssl']
        ssl_obj.provider = data['provider']
        ssl_obj.type = data['type']
        ssl_obj.save()
        return ssl_obj,final_data
##
#    def clean(self):
#        """ Method to validation form"""
#        error_message = ''
#        ssl_common_name = self.cleaned_data.get('ssl_common_name')
#        if not ssl_common_name :
#            error_message = "SSL Common Name is required"
#            self._errors['clients'] = error_message
#        provider = self.cleaned_data.get('provider')
#        if not provider :
#            error_message = "Provider is required"
#            self._errors['provider'] = error_message
#        type = self.cleaned_data.get('type')
#        if not type :
#            error_message = "SSL Type is required"
#            self._errors['type'] = error_message
#        date_of_issue = self.cleaned_data.get('date_of_issue')
#        if not date_of_issue :
#            error_message = "SSL Issue Date is required"
#            self._errors['clients'] = error_message
#        expiry_date = self.cleaned_data.get('expiry_date')
#        if not expiry_date :
#            error_message = "SSL Expiry Date is required"
#            self._errors['expiry_date'] = error_message
#        return self.cleaned_data
#


