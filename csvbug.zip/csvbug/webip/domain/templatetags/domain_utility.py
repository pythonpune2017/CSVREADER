from django.template import Library
from django.conf import settings
register = Library()

@register.simple_tag(takes_context=True)
def checkDomainName(context, site_name):
	"""
		Returns True For SiteName with Domain specified in DOMAIN_NAME_LIST. 
		True = 2 years To Register
		False = Any
	"""
	status = False
	for domain_name in settings.DOMAIN_NAME_LIST:
		if site_name.endswith(domain_name):
			status = True
			break
	context["domain_status"] = status
	return ''


from cases.models import CasedetailModel
#def getCaseDetail(domain_name,client):
def getCaseDetail(domain_name,client):
	"""
	"""
#	import ipdb
#	ipdb.set_trace()
 	try:
		casedetailmodel = CasedetailModel.objects.get(domain_name=domain_name,client=client)
#		casedetailmodel = CasedetailModel.objects.get(domain_name=domain_name)
 	except:
 		casedetailmodel = None
	return casedetailmodel
register.filter('getCaseDetail',getCaseDetail)


def check_url_exists(url):
	"""
	"""
	from django.core.validators import URLValidator
	from django.core.exceptions import ValidationError

	validate = URLValidator(verify_exists=True)
	try:
		validate(settings.UPLOAD_MEDIA_URL +  url)
		status = True
	except ValidationError, e:
		status = False
	return status
register.filter('check_url_exists',check_url_exists)


@register.simple_tag(takes_context=True)
def getPermissionStatus(context, permission_name): 
	"""
	"""
	if context['permissions'].has_key(permission_name):
		status = context['permissions'][permission_name]
	else:
		status = False

	context[permission_name + "_user_status"] = status
	return ''
	

	