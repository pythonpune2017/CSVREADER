'''
Created on Jan 30, 2012

@author: arun
'''
from django.contrib import admin 
from domain.models import *

class GlobalDomainsAdmin(admin.ModelAdmin):
    list_display = [f.name for f in GlobalDomains._meta.fields]
    search_fields = ['name','domain_type']
    save_on_top = True
admin.site.register(GlobalDomains, GlobalDomainsAdmin)


admin.site.register(Domain)
admin.site.register(SSLDetails)
#admin.site.register(GlobalDomains)