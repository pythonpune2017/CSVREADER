'''
Created on Jan 31, 2012

@author: shweta
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('domain.views',
     url(r'^manage/$',                                  'manage_domains',           name="managedomains"),  
     url(r'^add/$',                                     'add_domains',              name="addomain"),
     url(r'^instrainfo/$',                              'get_instra_domain_info',   name="instrainfo"),
     url(r'^edit/(?P<domain_id>\d+)/$',                 'edit_domains',             name="editdomain"),
     url(r'^view/(?P<domain_id>\d+)/$',                 'view_domains',             name="viewdomain"),
     url(r'^export/$',                                  'export_domains',           name="exportdomain"),
     url(r'^editssl/(?P<domain_id>\d+)/$',              'edit_ssl',                 name="editssl"),
     url(r'^bkorderssl/(?P<domain_id>\d+)/$',           'back_order_ssl',{'template':"domain/back_order_ssl.html"},name="bk_order_ssl"),   
     url(r'^editnotes/(?P<domain_id>\d+)/$',            'edit_notes',               name="editnotes"),
     url(r'^check/$',                                   'check_domain',             name="checkdomain"),
     url(r'^viewdns/(?P<domain_id>\d+)/$',              'view_dns',                 name="editdns"),
     url(r'^dns/add/$',                                 'add_dns',                  name="adddns"),
     url(r'^dns/delete/$',                              'delete_dns',               name="deletedns"),
     url(r'^dns/edit/$',                                'edit_dns',                 name="editdns"),
     url(r'^brandname/$',                               'get_brand_name',           name="getbrandname"),
     url(r'^checknameserver/$',                         'check_nameserver',         name="checknameserver"),
     url(r'^delete/(?P<domain_id>\d+)/$',               'delete_domain',            name="deletedomain"),
     url(r'^import/$',                                  'import_domains',           name="importdomain"),
     url(r'^download/(?P<format>\w+)/$',                'download_domain_spreadsheet',name="downloaddomainformat"),
     url(r'^allssl/$',                                  'view_all_ssl',             name="viewallssl"),
     url(r'^getsslform/$',                              'get_ssl_info',             name="getsslform"),
     )

