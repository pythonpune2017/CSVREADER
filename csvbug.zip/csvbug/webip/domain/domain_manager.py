'''
Created on Jan 31, 2012

@author: shweta
'''
from django.db.models import Q
from domain.models import *
from client.models import *
from admin_app.models import *
from utils.paginator import paginate
from datetime import datetime
import datetime
import os, re
from utils.get_instra_domain import InstraDomainManager
from utils.random_generator import RandomGenerator
from django.contrib.auth.models import User
from utils import getDateObject

class DomainManager(object):
    """
        Domain related objects
    """
    def get_all_domains(self,data_dict={}):
        """
            Purpose: To get all domain objects list
        """

        #Check for domains that are not deleted
        domains = Domain.objects.filter(is_active = True )
        #Check for Keywords
        if data_dict['keyword']:
            keyword = data_dict['keyword']
            fields_4_keyword_search = ["name"]
            q_str = ""
            for element in fields_4_keyword_search:
                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
                domains = domains.filter(eval(q_str))
        #Check for country
        domains = domains.filter(country__id = data_dict['country']) if data_dict['country'] else domains
        #Check for clients
        domains = domains.filter(client__id = data_dict['client']) if data_dict['client'] else domains
       
        if data_dict['expiry_in'] and data_dict['expiry_out']:
            expiry_in_date = datetime.datetime.strptime(str(data_dict['expiry_in']), '%d-%m-%Y')
            expiry_out_date = datetime.datetime.strptime(str(data_dict['expiry_out']), '%d-%m-%Y')
            domains = domains.filter(expiry_date__range = (datetime.datetime.combine(expiry_in_date, datetime.time.min),
                       datetime.datetime.combine(expiry_out_date, datetime.time.max)))
        elif data_dict['expiry_out']:
            expiry_out_date = datetime.datetime.strptime(str(data_dict['expiry_out']), '%d-%m-%Y')
            domains=domains.filter(expiry_date__lte=expiry_out_date)
            
        elif data_dict['expiry_in']:  
            expiry_in_date = datetime.datetime.strptime(str(data_dict['expiry_in']), '%d-%m-%Y')     
            domains=domains.filter(expiry_date__gte = expiry_in_date)
        else:
            domains=domains
        #Order by Name
#        domains = domains.filter(client__clientuser__user_type = 'superuser')
        domains = domains.order_by("-created")
        return domains
    
    def export_domain(self, data_dict={}):
        """
            Purpose: 1. Export all the domains present in the database
                     2. Export all the domains on the basis of serach and filter results
            Input: data_dict (having search and filtered results if any)
        """
        domains = self.get_all_domains(data_dict = data_dict)
        ssl_details_list = []
        for item in domains.iterator():
            ssl_details = item.ssldetails_set.all().values("id","ssl_common_name","provider","type","date_of_issue","expiry_date")
            new_ssl = []
            if ssl_details:
                for ssl in ssl_details:
                    ssl_dict = {}
                    for k , v in ssl.iteritems():
                        if k == "date_of_issue":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        elif k == "expiry_date":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        else:
                            ssl_dict[k] = v
                    new_ssl.append(ssl_dict)
            else:
                new_ssl = ''
                
            ssl_details_list.append({"ssl_details": str(new_ssl)})
            
        domains_info = domains.values("id", "name", "registrar","client__name","brand_name","expiry_date","auto_renew","country__country_name",
                                      "costcentre","client__user__first_name","client__user__last_name"
                                      ,"cost_per_annum","expiry_date","notes","dns_on_instra")
        
        for index, domain in enumerate(domains_info):
            try:
                domain.update(ssl_details_list[index])
            except:
                pass
        return domains_info

    def get_domain_by_id(self, domain_id):
        """
            Purpose: To get domain object on the basis of id
            Input: domain_id
            Output: domain-obj
        """
        try:
            domain_obj = Domain.objects.get(id = domain_id)
        except:
            domain_obj = None
        return domain_obj
    
    
    def get_domain_info(self, domain_id):
        """
            Purpose: To get all the domain_related information
        """
        data_dict = {}
        ssl_info_list = []
        domain = Domain.objects.filter(id = domain_id)
        ssl_info = domain[0].ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date")
        for ssls in ssl_info:
            ssl_dict = {}
            for k , v in ssls.iteritems():
                if k == "date_of_issue":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "expiry_date":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "id":
                    ssl_dict["ssl_id"] = v
                else:
                    ssl_dict[k] = v
            ssl_info_list.append(ssl_dict)
        domain_info = domain.values("id", "name", "registrar","client__id","client__name","brand_name","expiry_date","auto_renew","country__id",
                                      "costcentre","client__clientuser__user__first_name","client__clientuser__user__last_name"
                                      ,"client__currency__name","cost_per_annum","expiry_date","instra_id","notes", 'period',"dns_on_instra","nameserver1","nameserver2","nameserver3","nameserver4","nameserver5","nameserver6")
        if domain_info:
            other_registrar=''
            domain_info = domain_info[0]
            try:
                data_dict['id'] = domain_info['id']
                data_dict['name'] = domain_info['name']
                data_dict['registrar'] = 0 if domain_info['registrar'] == "Web IP" else 1
                if domain_info['registrar']!="Web IP":
                    other_registrar=domain_info['registrar']
                data_dict['other_registrar']=other_registrar
                data_dict['brand_name'] = domain_info['brand_name']
                data_dict['client'] = domain_info['client__id']
                data_dict['country'] = domain_info['country__id']
                data_dict['costcentre'] = domain_info['costcentre']
                data_dict['notes'] = domain_info['notes']
                data_dict['auto_renew'] = 'yes' if domain_info['auto_renew'] else 'no'
                data_dict['dns_on_instra'] = domain_info['dns_on_instra']
                data_dict['expiry_date'] = datetime.datetime.strftime(domain_info['expiry_date'] , "%d-%m-%Y")
                data_dict['cost_per_annum'] = domain_info['cost_per_annum']
                data_dict['currency'] = domain_info['client__currency__name']
#                data_dict['name_server_1'] = domain_info['nameserver1']
#                data_dict['name_server_2'] = domain_info['nameserver2']
#                data_dict['name_server_3'] = domain_info['nameserver3']
#                data_dict['name_server_4'] = domain_info['nameserver4']
#                data_dict['name_server_5'] = domain_info['nameserver5']
#                data_dict['name_server_6'] = domain_info['nameserver6']
            except:
                pass
            try:
                data = self.get_domain_info_from_instra(domain_info['name'])
            except:
                data = {}
                data_dict['instra'] = False
            if data.has_key('code') and data['code'] == '541':
                data_dict['instra'] = False
                data_dict['dns_on_instra'] = False
            else:
                data_dict['instra'] = True
                data_dict['dns_on_instra'] = True
            try:
                expiry_date = datetime.datetime.strptime(str(data['expirydate'].split(' ')[0]), "%Y-%m-%d")
                data_dict['expiry_date'] = datetime.datetime.strftime(expiry_date , "%d-%m-%Y")
                if data['renewalmode'] == "AUTO-RENEW"  or data['renewalmode']== "auto-renew":
                  data_dict['auto_renew'] = "yes"
                else:
                    data_dict['auto_renew'] = "no"
                data_dict['name_server_1'] = data['nameserver1']
                data_dict['name_server_2'] = data['nameserver2']
                data_dict['name_server_3'] = data['nameserver3']
                data_dict['name_server_4'] = data['nameserver4']
                data_dict['name_server_5'] = data['nameserver5']
                data_dict['name_server_6'] = data['nameserver6']
            except Exception , e:
                pass
        return data_dict , ssl_info_list
    
    def get_domain_info_from_instra(self, domain_name):
        """
        """
        obj = InstraDomainManager()
        try:
            response , data = obj.get_domain_info(domain_name)
        except:
            response , data = {},{}
        return data
    
    def modify_notes(self, domain_id, data_dict):
        """
            Purpose : To modify notes about domain
            Input: notes
        """
        domain_obj = self.get_domain_by_id(domain_id)
        if domain_obj:
              # code for start edit history
            from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
            history = {}
            if domain_obj:
                history.update(
                               {
                                'notes':domain_obj.notes
                                })
            new_dict={}
            new_dict.update({'notes':data_dict['notes']})                  
            data = {'old':history, 'new':new_dict}
            # code for end edit
            
            try:
                domain_obj.notes = data_dict['notes']
                domain_obj.save()
            except:
                return False,''
        return True ,domain_obj,data
 #Checking of domain name from instra   
#    def check_domain_name_availability(self, name):
#        """
#            Purpose: To check availability of username and accordingly send status
#        """
#        obj = InstraDomainManager()
#        response , data_list = obj.check_domain_available(name)
#        for data in data_list:
#            if not data == []:
#                data_list = data
#                break
#        instra_status = [v for i in data_list for k , v in i.iteritems() if k.startswith("status")]
#        i_status = self.instra_status(instra_status[0])
#        if i_status:
#            status = True
#        else:
#            status = False
#        return status
#    
#    def instra_status(self,instra_status):
#        """
#        """
#        status = False
#        if instra_status == "available":
#            status = True
#        return status


    def check_domain_name_availability(self, name):
        """
        check domain name in the existing system
        """
        domain = Domain.objects.filter(name = name)
        if domain:
            status = False
        else:
            status = True
        return status
        
    
    def check_nameserver_availability(self, nameserver):
        """
        """
        obj = InstraDomainManager()
        response , data_list = obj.check_nameserver_availability(nameserver)
        instra_status = [i for i in data_list if i.__contains__("status")]
        i_status = instra_status[0]
        if i_status == 0:
            status = True
        else:
            status = False
        return status
    
#    def get_domain_by_id(self, domain_id):
#        """
#        """
#        try:
#            domain = Domain.objects.get(id= domain_id)
#        except:
#            domain = None
#        return domain
    
    def delete_domain(self, domain_id):
        """
        """
        domain = self.get_domain_by_id(int(domain_id))
#        try:
#            domain_name = domain.name
#        except:
#            domain_name = ''
#        obj = InstraDomainManager()
#        response , data_list = obj.delete_domain(domain_name)
        if domain:
            try:
#                domain.is_delete = True
#                domain.save()
                domain.delete()
                
            except:
                raise
        return True
    
    def save_uploaded_file(self,file_obj, location):
        """
            Save Uploaded File at temporary location.
        """
   
        try:
            destination = open(location, 'wb+')
            for chunk in file_obj.chunks():
                destination.write(chunk)
            destination.close()
            return True
        except:
            return False
        
#    def processXLSImportedDomain(self, req_dict):
#        """
#            Process dictionary for imported staff. 
#        """
#        error_list = []
#        try:
#            for sheet, value_list in req_dict.iteritems():
#                for val_dct in value_list:
#                    user = self.addUser(val_dct)
#                    if user:
#                        self.createUserProfile(val_dct, user)
#                        country = self.getCountryObj(val_dct)
#                        currency = self.getCurrencyObj(val_dct)
#                        client = self.addClient(country,currency,user,val_dct)
#                        clientuser = self.addClientUser(user, client)
#                        domain = self.addDomain(client,val_dct)
#                        ssl = self.addSSL(domain,val_dct)
#                    else:
#                        pass
#            return True, "Spreadsheet Uploaded",[]
#        except Exception, e:
#            error_list.append(str(e))
#            print "Exception in Domain Import(XLS Format", str(e)
#            return False, "Error while processing spreadsheet", error_list
##            return False, error_list


    def processXLSImportedDomain(self, req_dict):
        """
            Process dictionary for imported staff. 
        """
   
        error_list = []
        for sheet, value_list in req_dict.iteritems():
            for val_dct in value_list:
                try:
                    client  = self.getClient(val_dct)
                    if client:
                        status , domain, error = self.addDomain(client,val_dct)
                        if not status:
                            error_list.append((val_dct['Domain Name'], error))
                            try:
                                domain.delete()
                            except:
                                pass
                        ssl , error = self.addSSL(domain,val_dct)
                        if error:
                            error_list.append((val_dct['Domain Name'], error))
                            try:
                                domain.delete()
                            except:
                                pass
                    else:
                        error_list.append((val_dct['Domain Name'], "Client does not exist."))
                        try:
                            domain.delete()
                        except:
                            pass
                        pass
                except Exception, e:
                    error_list.append((val_dct['Domain Name'], str(e)))
                    try:
                        domain.delete()
                    except:
                        pass
                    pass
        return True, "Spreadsheet Uploaded",error_list
        
        
#    def processCSVImportedDomain(self, req_dict):
#        """
#            Process dictionary for imported staff. 
#        """
#        try:
#            for val_dct in req_dict:
#                user = self.addUser(val_dct)
#                if user:
#                    self.createUserProfile(val_dct, user)
#                    country = self.getCountryObj(val_dct)
#                    currency = self.getCurrencyObj(val_dct)
#                    client = self.addClient(country,currency,user,val_dct)
#                    domain = self.addDomain(client,val_dct)
#                    ssl = self.addSSL(domain,val_dct)
#                else:
#                    pass
#            return True, "Spreadsheet Uploaded"
#        except Exception, e:
#            print "Exception in Domain Import(CSV Format", str(e)
#            return False, "Error while processing spreadsheet. Csv not in proper format"


    def processCSVImportedDomain(self, req_dict):
        """
            Process dictionary for imported staff. 
        """
        error_list = []
        for val_dct in req_dict:
            try:
                client = self.getClient(val_dct)
                if client:
                    status , domain, error = self.addDomain(client,val_dct)
                    if not status:
                        error_list.append((val_dct['Domain Name'], error))
                        try:
                            domain.delete()
                        except:
                            pass
                    ssl , error = self.addSSL(domain,val_dct)
                    if error:
                        error_list.append((val_dct['Domain Name'],str(error)))
                        try:
                            domain.delete()
                        except:
                            pass
                else:
                    error_list.append((val_dct['Domain Name'], "Client does not exist."))
                    try:
                        domain.delete()
                    except:
                        pass
                    pass
            except Exception , e:
                error_list.append((val_dct['Domain Name'], str(e)))
                try:
                    domain.delete()
                except:
                    pass
                pass
                
        return True, "Spreadsheet Uploaded", error_list
        
    def addUser(self, val_dct):
        """
            Purpose : To add user
            Input : request_dict
        """
        username = RandomGenerator().username_generator()
        password = RandomGenerator().password_generator()
        try:
            user = User.objects.create_user(username = username, password = password, email= val_dct['Email'])
            user.first_name = val_dct['First Name']
            user.last_name = val_dct['Last Name']
            user.is_active = True 
            user.save()
        except:
            user = None
        return user
        
    def createUserProfile(self, val_dct, user):
        """
            Create User Profile.
        """
        try:
            user_prof = UserProfileModel.objects.get(user=user)
        except:
            user_prof = UserProfileModel(user=user)
            user_prof.phone = val_dct['Phone']
            user_prof.save()
        return user_prof
    
    def getCountryObj(self, req_dict={}):
        """
            Save country
        """
        try:
            country = CountryModel.objects.get(country_name = str(req_dict['Country'].title()))
        except:
            country = None
        return country
    
    def getCurrencyObj(self, req_dict={}):
        """
            Save country
        """
        try:
            currency = CurrencyModel.objects.get(currency_code = str(req_dict['Currency Code'].title()))
        except:
            currency = None
        return currency
    
#    def addClient(self, country=None,currency=None,user=None,req_dict={}):
#        """
#            Save clients
#        """
#        try:
#            client = ClientModel.objects.get(name = str(req_dict.get('Company Name')), country = country, currency = currency,user=user)
#        except Exception , e:
#            client = ClientModel(name = str(req_dict.get('Company Name')), country = country, currency = currency,user=user)
#            client.is_active = True 
#            client.is_delete = False
#            client.save()
#        return client
    
    def getClient(self,req_dict={}):
        """
            Save clients
        """
        try:
            client = ClientModel.objects.get(name = str(req_dict['Client']))
        except Exception , e:
            print "Exception in getting client" , str(e)
            client= None
#            client = ClientModel(name = str(req_dict.get('Company Name')), country = country, currency = currency,user=user)
#            client.is_active = True 
#            client.is_delete = False
#            client.save()
        return client 
    
    def getSubscriptionPlanObj(self, req_dict={}):
        """
            To get subscription plan object
        """
        try:
            plan = SubcriptionPlan.objects.get(name__icontains = req_dict['Subscription Plan'].title())
        except:
            plan = None
        return plan
        
    def addClientSubscription(self, client, plan ,req_dict={}):
        """
            To add subscription plan for client
        """
        try:
            client_plan = ClientSubscription.objects.get(client=client, plan=plan,activation_date=req_dict['Activation Date'],expiry_date=req_dict['Expiry Date'])
        except:
            client_plan = ClientSubscription(client=client, plan=plan)
            activation_date = self.getDateObject(str(req_dict['Activation Date']))
            client_plan.activation_date=activation_date
            expiry_date = self.getDateObject(str(req_dict['Expiry Date']))
            client_plan.expiry_date=expiry_date
            client_plan.is_active = True
            client_plan.save()
        return client_plan
    
    def getDateObject(self,datestring):
        """
        """
        return getDateObject(datestring)
    
    
    def addClientUser(self, user,client):
        """
            Save clients
        """
        try:
            clientuser = ClientUser.objects.get(user =user , client = client )
        except Exception , e:
            clientuser = ClientUser(user =user ,client = client, user_type = 'superadmin')
            clientuser.save()
        return clientuser
    
        
    def addDomain(self, client=None, req_dict={}):
        """
            Add Domain
        """
        try:
            domain_obj = Domain.objects.get(name = req_dict['Domain Name'])
        except:
            domain_obj = None
        if not domain_obj:
            try:
                domain_obj = Domain(name = req_dict['Domain Name'], client = client, brand_name=client.name)
                domain_obj.registrar = 'WebIp' if str(req_dict['Registrar']).lower() == "webip" else req_dict['Registrar']
                domain_obj.costcentre = req_dict['Cost Centre']
                #domain_obj.expiry_date = datetime.datetime.strptime(str(req_dict['Expiry Date']), "%d-%m-%y")
                domain_obj.expiry_date = getDateObject(req_dict['Expiry Date'])
                country=self.getCountryObj(req_dict)
                domain_obj.country = country
                domain_obj.auto_renew = True if str(req_dict['Auto Renew']).title() == 'True' else False
                domain_obj.notes = str(req_dict['Notes'])
                domain_obj.cost_per_annum = int(str(req_dict['Cost Per Annum']).split('.')[0])
                domain_obj.is_active = True
                domain_obj.save()
                return True , domain_obj, ''
            except Exception , e:
                return False , domain_obj, str(e)
        else:
            domain_obj = None
            return False , domain_obj, "Domain already exists."
        

        
    def addSSL(self,domain=None, req_dict={}):
        """
            Save SSL details
        """
        e = ''
        ssl_obj = None
        if req_dict.has_key('SSL Details') and req_dict['SSL Details']:
            try:
                data = eval(str(req_dict['SSL Details']))
            except Exception ,e:
                data = []
                ssl_obj = None
                return ssl_obj , "ssl error : " + str(e)
            if len(data) != 0:
                for ssl_data in data:
                    try:
                        date_of_issue = getDateObject(ssl_data['date_of_issue']) if ssl_data.has_key('date_of_issue') else None
                        expiry_date = getDateObject(ssl_data['expiry_date']) if ssl_data.has_key('expiry_date') else None
                             
                        ssl_obj = SSLDetails( domain = domain, 
                                              ssl_common_name = ssl_data['ssl_common_name'],
                                              date_of_issue = date_of_issue,
                                              expiry_date= expiry_date,
                                              provider = ssl_data['provider'],
                                              type = str(ssl_data['type'])
                                              )
                        ssl_obj.save()
                    except Exception , e:
                        print "Error while saving SSL ----------- " , str(e)
                        ssl_obj = None
                        return ssl_obj , "ssl error : " +str(e)
        return ssl_obj , str(e)
    
    def delete_processed_file(self, location):
        """
        """
        try:
            os.remove(location)
        except:
            pass
        
    def checkForFormat(self, filename):
        """
            Check whether imported file is csv or xls
        """
        try:
            formats = filename.split(os.extsep)[-1]
        except:
            formats = ''
        return formats
    
    def get_domain_by_name(self, domain_name):
        """
            Purpose: To get domain object on the basis of id
            Input: domain_id
            Output: domain-obj
        """
        try:
            domain_obj = Domain.objects.get(name = domain_name)
        except:
            domain_obj = None
        return domain_obj
    
        
class SSLManager(object):
    """
    """
    
    def get_ssl_info(self, domain_id):
        """
        """
        ssl_info_list = []
        domain = Domain.objects.filter(id = domain_id)
        if domain:
            ssl_info = domain[0].ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date")
        for ssls in ssl_info:
            ssl_dict = {}
            for k , v in ssls.iteritems():
                if k == "date_of_issue":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "expiry_date":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "id":
                    ssl_dict["ssl_id"] = v
                else:
                    ssl_dict[k] = v
            ssl_info_list.append(ssl_dict)
        return ssl_info_list
    
    def get_all_ssl_info(self):
        """
        """
        ssl_info_list = []
        domain_list = Domain.objects.all()
        if domain_list:
            for domain in domain_list:
                ssl_info = domain.ssldetails_set.all().values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date", "domain__name")
                for ssls in ssl_info:
                    ssl_dict = {}
                    for k , v in ssls.iteritems():
                        if k == "date_of_issue":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        elif k == "expiry_date":
                            nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                            ssl_dict[k] = nv
                        elif k == "id":
                            ssl_dict["ssl_id"] = v
                        else:
                            ssl_dict[k] = v
                    ssl_info_list.append(ssl_dict)
        return ssl_info_list
    
    def get_ssl_info_by_id(self, ssl_id):
        """
        """
        ssl_info_list= []
        ssl_info = SSLDetails.objects.filter(id = ssl_id).values("id", "ssl_common_name", "provider", "type","date_of_issue", "expiry_date", "domain__name")
        for ssls in ssl_info:
            ssl_dict = {}
            for k , v in ssls.iteritems():
                if k == "date_of_issue":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "expiry_date":
                    nv = datetime.datetime.strftime(v ,'%d-%m-%Y' )
                    ssl_dict[k] = nv
                elif k == "id":
                    ssl_dict["ssl_id"] = v
                else:
                    ssl_dict[k] = v
            ssl_info_list.append(ssl_dict)
        return ssl_info_list[0]