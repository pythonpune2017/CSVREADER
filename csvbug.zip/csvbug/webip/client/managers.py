'''
Created on Jan 31, 2012

@author: arun
'''
from client.models import Alert, FREQUENCY_TYPE, ClientUser
from utils.permissions_manager import USER_PERMISSION_MAP


class AlertManager():

    def __ini__(self, alert=None):
        self.alert = alert

    def get_user_alerts(self, user):
        """
            Returns Alert Objects for the given user
        """
        alert_types = [elem[0] for elem in FREQUENCY_TYPE]
        alerts = Alert.objects.filter(name__in = alert_types, user = user)
        return alerts



class ClientPermManager(object):

    def __init__(self,client=None):
        self.client =client

    def get_client_permissions(self):
        """
            Returns permission detail for the given client
        """
        data = {}
        user_permissions = self.client.user.user_permissions.all()
        for elem in USER_PERMISSION_MAP:
            if elem["permission"] in user_permissions:
                data[elem["name"]] = True

        return data

class ClientUserManager(object):
    """ Class to manupilate with ClientUser model """

    def get_by_client(self,data={}):
        """ Method to get ClientUser model object with Client
        args : values dict
        return : ClientUser object
        """
        status = True
        try :
            client_user_list = ClientUser.objects.filter(client=data['client'])
        except Exception, e :
            print e # replace with LOGGING
            status = False
            client_user_list = []

        return status, client_user_list

    def get_by_id(self,data={}):
        """ Method to get Client User object by Id
        args : values dict
        returns : Client User object
        """
        status = True
        try :
            client_user = ClientUser.objects.get(id=data['client_user_id'])
        except Exception,e :
            print e # replace with LOGGING
            status = False
            client_user = None

        return status, client_user
