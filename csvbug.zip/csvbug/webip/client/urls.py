'''
Created on Jan 12, 2012

@author: arun
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('client.views',

     url(r'^client/$','manage_clients',name="manageclients"),
     url(r'^client/(?P<staff_id>\d+)/$','staff_clients',name="viewclients"),  
     url(r'^client/download/(?P<format>\w+)/$','download_client_spreadsheet',name="downloadclientformat"),   
     url(r'^client/add/$','add_clients',name='addclient'),
     url(r'^client/edit/(?P<id>\d+)/$','edit_clients',name='editclient'),
     url(r'^client/delete/(?P<cl_id>\d+)/$','delete_client',name="deleteclient"),
     url(r'^client/exportclient/$','export_client_details',name="exportclient"),
     url(r'^client/importclient/$','import_client',name="importclient"),
#     url(r'^staff/importclient/save/$','import_client_save',name="save_importclient"),


     )





