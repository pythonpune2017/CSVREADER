from django.db import models
from django.contrib.auth.models import User
from admin_app.models import CountryModel, StaffModel

# Create your models here.
from datetime import datetime, timedelta
from email.utils import parsedate_tz
from django.conf import settings
from django.core.files.storage import FileSystemStorage
userimage_storage = FileSystemStorage()
import os
from utils.processing_image import resize_image

ALERT_TYPE = (
    ("", "Select"),
    (u'daily', u'Daily'),
    (u'Weekly', u'Weekly'),
    (u'monthly', u'Monthly'),
    (u'yearly', u'Yearly'),

    )

FREQUENCY_TYPE = (
    ("", "Select"),
    (u'domain_renewals','Domain Renewals'),
    (u'dms_changes','DNS Changes'),
    (u'ssl_renewals','SSL Renewals'),
    (u'trademark_renewals','Trademark Renewals'),
    (u'contract_changes','Contract Changes')
    )

PROFILE_TYPE = (
              ('admin', "Admin"),
              ('tech', "Tech"),
              )



class CurrencyModel(models.Model):
    """ Master model for currency """
    name = models.CharField("Currency", max_length=20)
    currency_code= models.CharField("Country code",max_length=15)
    symbol= models.CharField("Symbol",max_length=5, blank=True,null=True)

    def __unicode__(self):
        """docstring for __unicode__"""
        return str(self.name)

class ClientUser(models.Model):

    """client User table """

    USER_TYPE = (
    (u'superuser', u'Superuser'),
    (u'subuser', u'Subuser')
    )

    user = models.OneToOneField(User, unique=True)
    user_type = models.CharField(max_length=10,choices=USER_TYPE,default='superuser')
    client = models.ForeignKey("ClientModel")
    is_deleted = models.BooleanField('is_deleted', default=False)

    def __unicode__(self):
        return u'%s' % (self.user)

class ClientUserProfile(models.Model):
    """ client user profile model """

    def get_upload_path(self, filename):
        """
        """
        return os.path.join("user",
        "%d" % self.client.id,str(self.client.user.id), filename)

    client = models.OneToOneField(ClientUser, unique=True)
    role = models.CharField(max_length=50, blank=True, null=True)
    department = models.CharField(max_length=50, blank=True, null=True)
    image = models.FileField(storage=userimage_storage, upload_to=get_upload_path, null=True, blank = True)
    def __unicode__(self):
        return u'%s' % (self.client_id)

    def save(self,*args, **kwargs):
        super(ClientUserProfile, self).save(*args, **kwargs)
        if self.image:
            #resize_image(self.image.path, out_path=None, height=100, width=100)
            m_out_path = os.path.dirname(self.image.path)
            resize_image(self.image.path, m_out_path, height=100, width=100)
            super(ClientUserProfile, self).save()

class ClientDomainCategory(models.Model):
    """ client user domain category model """
    client = models.ForeignKey(ClientUser)
    category = models.TextField(blank=True, null=True)



class ClientModel(models.Model):

    """ Client Master table """

    name = models.CharField("Brand Name", max_length=100,unique=True)
    country = models.ForeignKey(CountryModel)
    currency = models.ForeignKey('CurrencyModel')
    accountmangers=models.ManyToManyField(StaffModel,blank=True,null=True)
    user = models.OneToOneField(User, unique=True)
    searchlimit=models.IntegerField(blank=True,null=True, default=15)
    searchlimitcount=models.IntegerField(blank=True,null=True,default=0)
    searchlimitdate=models.DateTimeField(default=None,blank=True,null=True,auto_now_add = True)
    created = models.DateTimeField('Created Date' ,auto_now_add = True)
    updated = models.DateTimeField('Updated' ,auto_now = True)

    is_active = models.BooleanField(default=False, help_text="is client plan active")
    is_deleted = models.BooleanField(default=False, help_text="True if Client is deleted from the System")


    def __unicode__(self):
        return u'%s' % (self.name)
    def to_datetime(self,datestring):
        time_tuple = parsedate_tz(datestring.strip())
        dt = datetime(*time_tuple[:6])
        return dt - timedelta(seconds=time_tuple[-1])


class ClientSubscription(models.Model):
    """
        Maintains listing of client subscriptions
    """
    client = models.ForeignKey(ClientModel)
    plan = models.ForeignKey('SubcriptionPlan')
    activation_date = models.DateTimeField(auto_now_add = True)
    expiry_date = models.DateTimeField(default=None)
    is_active = models.BooleanField(default=False, help_text="is subscription plan active")

    def __unicode__(self):
        return str(self.client.name + self.plan.name)




# alert_permission
#class AccountManager(models.Model):
#
#    """Client to Account manager mapping table"""
#


class SubcriptionPlan(models.Model):
    """Subriction plan details"""

    PLAN_TYPE = (
    (u'trial', u'Trial'),
    (u'free', u'Free'),
    (u'monthly', u'Monthly'),
    (u'yearly', u'Yearly'),
    (u'weekly', u'Weekly')
    )


    name = models.CharField("Plan Name", max_length=100)
    description=models.CharField("Description", max_length=500)
    plan_type= models.CharField(max_length=10, choices=PLAN_TYPE,default='yearly')

    def __unicode__(self):
        return '%s' % (self.name)


class Alert(models.Model):
    """each client Plan Alert information """
    name = models.CharField("Alert", max_length=100,choices=FREQUENCY_TYPE)
    frequency= models.CharField(max_length=10, choices=ALERT_TYPE, default="")
    user = models.ForeignKey(User)
    client = models.ForeignKey(ClientModel, blank=True, null = True)
    def __unicode__(self):
        return '%s' % (self.name)


class InstraCorpUser(models.Model):
    """each client Plan Alert information """
    user = models.ForeignKey(User)
    instra_id= models.CharField(max_length=50,default="")
    def __unicode__(self):
        return '%s' % (self.user)

class DomainRegistration(models.Model):
    """domain registering"""
#    client = models.OneToOneField(ClientModel)
    client = models.ForeignKey(ClientModel)
    client_user = models.ForeignKey(ClientUser)
    profile_name = models.CharField(max_length=100,db_index=True,unique=True)
    company_name = models.CharField(max_length=100,db_index=True)
    abn_number = models.CharField(max_length=100,db_index=True)
    def __unicode__(self):
        return '%s' % (self.profile_name)

class RegistrationDetails(models.Model):
    """each client Plan Alert information """
    profile = models.ForeignKey(DomainRegistration)
    name = models.CharField(max_length=100,db_index=True)
    email = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    fax = models.CharField(max_length=100)
    address1 = models.CharField(max_length=100)
    address2 = models.CharField(max_length=100,blank=True, null = True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postalcode = models.CharField(max_length=100)
    country = models.ForeignKey(CountryModel)
    profile_type= models.CharField(max_length=10, choices=PROFILE_TYPE)
    def __unicode__(self):
        return '%s' % (self.name)

class NameServerProfiles(models.Model):
    """domain registering"""
#    client = models.OneToOneField(ClientModel)
    client = models.ForeignKey(ClientModel)
    client_user = models.ForeignKey(ClientUser)
    profile_name = models.CharField(max_length=100,db_index=True, unique=True)
    def __unicode__(self):
        return '%s' % (self.profile_name)

class NameServerProfileDetails(models.Model):
    """each client Plan Alert information """
    profile = models.ForeignKey(NameServerProfiles)
    nameserver = models.CharField(max_length=100,db_index=True)
    order = models.PositiveIntegerField(blank=True,null=True)
    def __unicode__(self):
        return '%s' % (self.profile)

