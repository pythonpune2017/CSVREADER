import os, datetime
from django.db.models import get_model
from client.models import *
from django.contrib.auth.models import User
from django.http import HttpResponse
from utils.random_generator import RandomGenerator
from admin_app.models import *
from django.db.models import Q
from models import Alert as alert_permission
from models import FREQUENCY_TYPE
from django.contrib.auth.models import User, Group
from client.models import Alert,ClientModel,FREQUENCY_TYPE,ALERT_TYPE
from utils import getDateObject

class QueryManager():
    """
        Class Responsible For Querying, Filtering, Fetching QuerySet/Values From Models.
    """
    def __init__(self, app_label, model_name):
        """
        """
        self.app_label = app_label
        self.model_name = model_name
        self.model_instance = self.get_model_instance()

    def get_model_instance(self):
        """
            Get ModelBase instance of Model Class.
        """
        self.model_instance = get_model(self.app_label, self.model_name)
        if not self.model_instance:
            return False, "Check Application Label or Model Name."
        self.model_instance = self.model_instance.objects
        return True, ''

    def get_query(self, param_dict):
        """
            Get QueryObject based upon input parameter dictionary.
            Input: param_dict [Type: dict]
            Format: {'field_name_1':'field_value_1', 'field_name_2':'field_value_2'}

            Output: QuerySet Object.
        """
        try:
            return self.model_instance.select_related().get(**param_dict)
        except:
            return None

    def filter_query(self, params):
        """
            Filters QuerySet based upon input parameter.
            Input: params [Type: dict/string]

            e.q: 1. {'field_name_1':'field_value_1', 'field_name_2':'field_value_2'}
                 2. "Q(field_name_1__contains='field_value_1') | Q(field_name_2__startswith=field_value_2)"
        """
        if not isinstance(params, dict):
            self.model_instance = self.model_instance.filter(eval(params)).select_related()
        else:
            self.model_instance = self.model_instance.filter(**params).select_related()

    def all_query(self):
        """
            Fetches All QuerySet Objects.
        """
        self.model_instance = self.model_instance.all().select_related()

    def fetch_values(self, value_tup, value_flag=False):
        """
            Returns QuerySet/QuerySet Values based upon value_flag value.

            Input: 1. value_tup
                   2. value_falg
            Format: value_tup = ('field_name_1','field_name_2','field_name_3')

            Output: QuerySet/QuerySet Values.
            Format: values = [{'field_name_1':'field_value_1','field_name_2':'field_value_2'},{},..]
        """
        if not value_flag:
            return self.model_instance

        try:
            if not value_tup:
                return self.model_instance.values()
            else:
                return self.model_instance.values(*value_tup)
        except:
            return []

    def fetch_value_list(self, value_tup, value_flag=False):
        """
            Returns QuerySet/QuerySet Values based upon value_flag value.

            Input: 1. value_tup
                   2. value_flag
            Format: value_tup = ('field_name_1','field_name_2',..)

            Output: QuerySet/QuerySet Values.
            Format: values = [('field_value_1','field_value_2',..),(),..]
        """
        if not value_flag:
            return self.model_instance

        try:
            if not value_tup:
                return self.model_instance.values_list()
            else:
                return self.model_instance.values_list(*value_tup)
        except:
            return []
        
        
        
class ClientManager(object):
    """
        To get ClientModel related objects
    """
    def exportClientMember(self, req_dict):
        """
            Purpose : To get CliendModel objects
            Input: req_dict
            Output: client_info (list of dictionaries)
        """
        client_data = ClientModel.objects.filter(is_active = True).select_related() #clientuser__user_type = 'superuser'
        if req_dict.get('subscription'):
            client_data = client_data.filter(clientsubscription__id = req_dict['subscription'])

        #-- Build Query String.                
        fields_4_keyword_search = ["name", "clientuser__user__username", "clientuser__user__email"]
        if req_dict.get('keyword'):
            q_str = ""
            for element in fields_4_keyword_search:
                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element, req_dict['keyword'])
    
            if q_str:    
                client_data = client_data.filter(eval(q_str))

        #-- Filter by User Status.
        
        if req_dict.get('status') == "1":
            client_data = client_data.filter(is_active = True)
        elif req_dict.get('status') == "0":
            client_data = client_data.filter(is_active = False)
            
        if req_dict.get('expiry_in') and req_dict.get('expiry_out'):
            expiry_in_date = datetime.datetime.strptime(req_dict.get('expiry_in'), '%d-%m-%Y')
            expiry_out_date = datetime.datetime.strptime(req_dict.get('expiry_out'), '%d-%m-%Y')
            client_data = client_data.filter(clientsubscription__expiry_date__range = (datetime.datetime.combine(expiry_in_date, datetime.time.min),
                       datetime.datetime.combine(expiry_out_date, datetime.time.max)))
        elif req_dict.get('expiry_out'):
            expiry_out_date = datetime.datetime.strptime(req_dict.get('expiry_out'), '%d-%m-%Y')
            client_data=client_data.filter(clientsubscription__expiry_date__lt=expiry_out_date)
            
        elif req_dict.get('expiry_in'):       
            expiry_in_date = datetime.datetime.strptime(req_dict.get('expiry_in'), '%d-%m-%Y')
            client_data=client_data.filter(clientsubscription__expiry_date__gt = expiry_in_date)
        else:
            client_data=client_data
            
        #-- Get Total Client For Staff Member.
        client_info_list = []
        alert_info_list=[]
        for elem in client_data.iterator():
            try:
                subscription = elem.clientsubscription_set.filter(is_active =True)[0].plan.name
            except:
                subscription  =''
            client_info_list.append({"subscription": subscription})
            alerts_list = [str(i[1]) for i in FREQUENCY_TYPE]
            alert_types = elem.alert_set.all().values('name','frequency')
            existing_alerts = [alert['name'] for alert in alert_types]
            remaining_alerts = [{item:""} for item in alerts_list if item not in existing_alerts]
            for alert in alert_types:
                    alert_info_list.append({alert['name']:alert['frequency']})
            alert_info_list.extend(remaining_alerts)
        
        
        client_info = client_data.values("name", "clientuser__user__username", "clientuser__user__email",'clientuser__user__first_name',
                          'clientuser__user__userprofilemodel__phone',"country__country_name", "is_active",)
        
        for index, client in enumerate(client_info):
            try:
                client.update(client_info_list[index])
                for i in alert_info_list:
                    client.update(i)
            except Exception , e :
                import traceback
                e = traceback.print_exc()
                print "Excepiton in client csv import" , str(e)
                pass
        return client_info
    
    def save_uploaded_file(self,file_obj, location):
        """
            Save Uploaded File at temporary location.
        """
        try:
            destination = open(location, 'wb+')
            for chunk in file_obj.chunks():
                destination.write(chunk)
            destination.close()
            return True
        except:
            return False

    def delete_processed_file(self, location):
        """
        """
        try:
            os.remove(location)
        except:
            pass
    
#    def processImportedClient(self, req_dict):
#        """
#            Process dictionary for imported staff. 
#        """
#        import pdb
#        pdb.set_trace()
#        try:
#            for sheet, value_list in req_dict.iteritems():
#                for val_dct in value_list:
#                    user = self.addUser(val_dct)
#                    if user:
#                        self.createUserProfile(val_dct, user)
#                        country = self.getCountryObj(val_dct)
#                        currency = self.getCurrencyObj(val_dct)
#                        accountmanager = self.getAccountmanagerObjByName(val_dct)
#                        client = self.addClient(country, accountmanager,currency,user,val_dct)
#                        plan = self.getSubscriptionPlanObj(val_dct)
#                        self.addClientSubscription(client, plan, val_dct)
#                        client_user = self.addClientUser(user,client)
#                        self.addAlertPermission(user, client, val_dct)
#            return True, "Spreadsheet Uploaded"
#        except Exception, e:
#            print "Exception in Client Import(XLS Format", str(e)
#            return False, "Error while processing spreadsheet"

    def processImportedClient(self, req_dict):
        """
            Process dictionary for imported staff. 
        """

        error_list = []
        for sheet, value_list in req_dict.iteritems():
            for val_dct in value_list:
                try:
                    user = self.addUser(val_dct)
                    if user:
                        user_obj , error = self.createUserProfile(val_dct, user)
                        if error:
                            error_list.append((val_dct['Company Name'],error))
                            try:
                                user.delete()
                            except:
                                pass
                        country = self.getCountryObj(val_dct)
                        currency = self.getCurrencyObj(val_dct)
                        accountmanager = self.getAccountmanagerObjByName(val_dct)
                        status, client, error = self.addClient(country, accountmanager,currency,user,val_dct)
                        if not status:
                            error_list.append((val_dct['Company Name'], error))
                            try:
                                user.delete()
                            except:
                                pass
                        
                        if client:
                            plan = self.getSubscriptionPlanObj(val_dct)
                            status , client_plan , error = self.addClientSubscription(client, plan, val_dct)
                            if not status:
                                error_list.append((val_dct['Company Name'], error))
                                try:
                                    user.delete()
                                except:
                                    pass 
                            status , client_user, error = self.addClientUser(user,client)
                            if not status:
                                error_list.append((val_dct['Company Name'], error))
                                try:
                                    user.delete()
                                except:
                                    pass   
                            
                            error = self.addAlertPermission(user, client, val_dct)
                            if error:
                                error_list.append((val_dct['Company Name'], error))
                                try:
                                    user.delete()
                                except:
                                    pass   
                    else: 
                        error_list.append((val_dct['Company Name'], "User Already Exists!"))
                        pass
                except Exception , e:
#                    raise
                    error_list.append((val_dct['Company Name'], str(e)))
                    pass
        return True, "Spreadsheet Uploaded" , error_list
        
#    def processCSVImportedClient(self, req_dict):
#        """
#            Process dictionary for imported staff. 
#        """
#        try:
#            for val_dct in req_dict:
#                user = self.addUser(val_dct)
#                if user:
#                    self.createUserProfile(val_dct, user)
#                    country = self.getCountryObj(val_dct)
#                    currency = self.getCurrencyObj(val_dct)
#                    accountmanager = self.getAccountmanagerObjByName(val_dct)
#                    client = self.addClient(country, accountmanager,currency,user,val_dct)
#                    plan = self.getSubscriptionPlanObj(val_dct)
#                    self.addClientSubscription(client, plan, val_dct)
#                    client_user = self.addClientUser(user,client)
#                    self.addAlertPermission(user, client, val_dct)
#            return True, "Spreadsheet Uploaded"
#        except Exception, e:
#            print "Exception in Client Import(CSV Format", str(e)
#            return False, "Error while processing spreadsheet"


    def processCSVImportedClient(self, req_dict):
        """
            Process dictionary for imported staff. 
        """
        error_list = []
        for val_dct in req_dict:
            try:
                user = self.addUser(val_dct)
                if user:
                    user_obj , error = self.createUserProfile(val_dct, user)
                    if error:
                        error_list.append((val_dct['Company Name'],error))
                        try:
                            user.delete()
                        except:
                            pass
                    country = self.getCountryObj(val_dct)
                    currency = self.getCurrencyObj(val_dct)
                    accountmanager = self.getAccountmanagerObjByName(val_dct)
                    status, client, error = self.addClient(country, accountmanager,currency,user,val_dct)
                    if not status:
                        error_list.append((val_dct['Company Name'], error))
                        try:
                            user.delete()
                        except:
                            pass
                    plan = self.getSubscriptionPlanObj(val_dct)
                    status , client_plan , error = self.addClientSubscription(client, plan, val_dct)
                    if not status:
                        error_list.append((val_dct['Company Name'], error))
                        try:
                            user.delete()
                        except:
                            pass                    
                    status , client_user, error = self.addClientUser(user,client)
                    if not status:
                        error_list.append((val_dct['Company Name'], error))
                        try:
                            user.delete()
                        except:
                            pass   
                    error = self.addAlertPermission(user, client, val_dct)
                    if error:
                        error_list.append((val_dct['Company Name'], error))
                else:
                    error_list.append((val_dct['Company Name'], "User Already Exists!"))
                    pass
            except Exception , e:
                error_list.append((val_dct['Company Name'], str(e)))
                pass
        return True, "Spreadsheet Uploaded", error_list
        
        
    def addUser(self, val_dct):
        """
            Purpose : To add user
            Input : request_dict
        """
         
        username = RandomGenerator().username_generator()
        password = RandomGenerator().password_generator()
        try:
            user = User.objects.create_user(username = username, password = password, email= val_dct['Email'])
            user.first_name = val_dct['First Name']
            user.last_name = val_dct['Last Name']
            user.is_active = True if val_dct['Status'].lower()=='active' else False
            group =Group.objects.get(name="all_clients")
            user.groups.add(group) 
            user.save()
            
        except:
            user = None
        return user
    
    def createUserProfile(self, val_dct, user):
        """
            Create User Profile.
        """
        user_prof = None
        try:
            user_prof = UserProfileModel(user=user)
            user_prof.phone = val_dct['Phone']
            user_prof.save()
            return user_prof , ''
        except Exception , e:
            return user_prof , str(e)
    
    def getAccountmanagerObjByName(self, req_dict={}):
        """
            Get Accountmanager object
        """
        try:
            obj = StaffModel.objects.get(user__username = req_dict['Account Managers'].lower())
        except:
            obj = None
        return obj
        
    def getCountryObj(self, req_dict={}):
        """
            Save country
        """
        try:
            country = CountryModel.objects.get(country_name__icontains = str(req_dict['Country'].title()))
        except:
            country = None
        return country
    
    def getCurrencyObj(self, req_dict={}):
        """
            Save country
        """
        try:
            currency = CurrencyModel.objects.get(currency_code = str(req_dict['Currency Code'].upper()))
        except:
            currency = None
        return currency
        
    def addClientUser(self, user, client):
        """
            Save client users
        """
        clientuser = None
        try:
            clientuser , is_created = ClientUser.objects.get_or_create(user = user, client = client, user_type="superuser")
            clientuser.save()
            clientprofile_obj=ClientUserProfile(client=clientuser)
            clientprofile_obj.save()
            if is_created:
                return True , clientuser,''
            else:
                return False , clientuser,'Client user already exists.'
        except Exception , e:
            return False , clientuser, str(e)
        
    def addClient(self, country=None, accountmanager=None,currency =None,user=None,req_dict={}):
        """
            Save clients
        """
        client= None
        try:
            client,is_created = ClientModel.objects.get_or_create(name = req_dict['Company Name'], country = country,currency=currency,user=user)
            client.is_active = True if req_dict['Status'].lower()=='active' else False
            client.is_delete = False
            client.save()
            if accountmanager:
                client.accountmangers.add(accountmanager)
            if is_created:
                return True , client,''
            else:
                return False , client,'Client already exists.'
        except Exception , e:
            return False , client, str(e)
        
    def getSubscriptionPlanObj(self, req_dict={}):
        """
            To get subscription plan object
        """
        try:
            plan = SubcriptionPlan.objects.get(name__icontains = req_dict['Subscription Plan'].title())
        except:
            plan = None
        return plan
        
    def addClientSubscription(self, client, plan ,req_dict={}):
        """
            To add subscription plan for client
        """

        client_plan = None
        try:
            activation_date = self.getDateObject(str(req_dict['Activation Date']))
            expiry_date = self.getDateObject(str(req_dict['Expiry Date']))
            client_plan , is_created = ClientSubscription.objects.get_or_create(client=client, plan=plan,activation_date=activation_date,expiry_date=expiry_date)
            client_plan.is_active = True
            client_plan.save()
            if is_created:
                return True , client_plan,''
            else:
                return False , client_plan,'This subscription plan for the respective client already exists.'
        except Exception , e:
            return False , client_plan, str(e)
    
    def addAlertPermission(self, user=None,client=None,req_dict={}):
        """
            To add alert permissions for the client
        """
        FREQUENCY_TYPE1 = ['Domain Renewals','DNS Changes','SSL Renewals','Trademark Renewals','Contract Changes']
        alerts = {"Domain Renewals": FREQUENCY_TYPE[1][0], "DNS Changes": FREQUENCY_TYPE[2][0], "SSL Renewals":FREQUENCY_TYPE[3][0], "Trademark Renewals":FREQUENCY_TYPE[4][0], "Contract Changes":FREQUENCY_TYPE[5][0]}
        alert_types={'Daily':ALERT_TYPE[1][0],'Weekly':ALERT_TYPE[2][0],'Monthly':ALERT_TYPE[3][0],'Yearly':ALERT_TYPE[4][0]}

    
        e = ''
        
        for name in FREQUENCY_TYPE1:
            try:
                if name in alerts.keys():
                    alert, is_created = Alert.objects.get_or_create(name = alerts[name], user = user,client=client)
                    if req_dict[name] in alert_types:
                            alert.frequency=alert_types[req_dict[name]]
                    alert.save()
            except Exception , e:
                pass
        return e
    
    def getDateObject(self,datestring):
        """
        """
        return getDateObject(datestring)
    
    def checkForFormat(self, filename):
        """
            Check whether imported file is csv or xls
        """
        try:
            format = filename.split(os.extsep)[-1]
        except:
            format = ''
        return format
        
