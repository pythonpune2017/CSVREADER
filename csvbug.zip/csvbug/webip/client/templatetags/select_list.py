'''
Created on Jan 12, 2012

@author: arun

Purpose: Template Tags for Various list needed for present select html widget in Forms
'''
from django.template import Library, Node, TemplateSyntaxError
from django.utils.translation import ugettext as _
from operator import itemgetter
register = Library()

from admin_app.models import CountryModel
from client.models import ClientModel, SubcriptionPlan,ClientUser
from domain.models import *
from django.db.models import Q
def get_countries( parser, token ):
	"""
		 get list of countries
	"""
	# take steps to ensure template var was formatted properly
	try:
		bits = token.split_contents()
	except ValueError:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )
	if bits[1] != 'as':
		raise TemplateSyntaxError( 
			_( "second argument to tag must be 'as'" ) )
	if len( bits ) != 3:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )

	return CountryNode( bits[2] )

class CountryNode( Node ):
	"""
		get list of countries
	"""
	def __init__( self,  context_name ):
		self.context_name = context_name
	def render( self, context ):
		countries = CountryModel.objects.all().order_by( 'country_name' ).values("id", "country_name")
		context[self.context_name] = countries
		return ''

register.tag( "countries", get_countries )


def get_clients( parser, token ):
	"""
		 get list of Clients
	"""
	# take steps to ensure template var was formatted properly
	try:
		bits = token.split_contents()
	except ValueError:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )
	if bits[1] != 'as':
		raise TemplateSyntaxError( 
			_( "second argument to tag must be 'as'" ) )
	if len( bits ) != 3:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )

	return ClientsNode( bits[2] )

class ClientsNode( Node ):
	"""
		get list of countries
	"""
	def __init__( self, context_name ):
		self.context_name = context_name
	def render( self, context ):
		clients = ClientModel.objects.all().distinct().order_by( 'name' ).values("id", "name")
		context[self.context_name] = clients
		return ''

register.tag("clients", get_clients )


def get_costcenters( parser, token ):
	"""
		 get list of domains cost centers
	"""
	# take steps to ensure template var was formatted properly
   
	try:
		bits = token.split_contents()
	except ValueError:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )
	if bits[1] != 'as':
		raise TemplateSyntaxError( 
			_( "second argument to tag must be 'as'" ) )
	if len( bits ) != 3:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )

	return CostcenterNode( bits[2] )

class CostcenterNode( Node ):
	"""
		get list of domains costcenters
	"""
	def __init__( self, context_name ):
		self.context_name = context_name
		
	def render( self,context ):
		cost_centerlist=[]
		user_obj=context.get('user')
#		print "check for users",user_obj.clientuser.clientdomaincategory_set.values_list('category')
		
		try:
			client_user_obj= ClientUser.objects.get(user = user_obj.id)
		except:
			client_user_obj=None
		if client_user_obj and client_user_obj.user_type=='superuser':
			#cpst_centers = Domain.objects.filter(client=client_user_obj.client).distinct('costcentre').order_by( 'costcentre' ).values_list("id", "costcentre")
			cpst_centers = Domain.objects.filter(client=client_user_obj.client).distinct('costcentre').order_by( 'costcentre' ).values_list("id", "costcentre")
			finallist = unifyList(list(cpst_centers))
			context[self.context_name] = finallist
			return ''
			
		else:
			temp=[]
			tstr = ''
			temp = user_obj.clientuser.clientdomaincategory_set.values('category',)
			if temp:
				try:
					cat_list = eval(str(temp[0]['category']))
					cat_list = list(set(cat_list))
				except:
		   			cat_list = []
				
				if not cat_list:
					context[self.context_name] = []
					return ''

				for i  in cat_list:
					tstr += " | Q(costcentre= '%s')" %(str(i))
					tstr = tstr.lstrip(' | ')
			if tstr:
				cpst_centers = Domain.objects.filter(eval(tstr)).distinct('costcentre').order_by( 'costcentre' ).values_list("id", "costcentre")
				finallist = unifyList(list(cpst_centers))
				context[self.context_name] = finallist
				return ''
			else:
				context[self.context_name] = []
				return ''

register.tag("costcenters", get_costcenters )

def unifyList(cpst_centers):
	"""
		Remove Duplicates From the List Of Dictionary.
	"""
 	try:
		temp_lst = []
		result_lst = []
		for tup in cpst_centers:
			if tup[1] and tup[1] not in temp_lst:
				result_lst.append(tup)
				temp_lst.append(tup[1])
			result_lst.sort(key=lambda t : tuple(t[1].lower()))
		return result_lst
 	except Exception,e:
 	 	return cpst_centers




def get_subscription_plans( parser, token ):
	"""
		 get all subscription plans
	"""
	# take steps to ensure template var was formatted properly
	try:
		bits = token.split_contents()
	except ValueError:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )
	if bits[1] != 'as':
		raise TemplateSyntaxError( 
			_( "second argument to tag must be 'as'" ) )
	if len( bits ) != 3:
		raise TemplateSyntaxError( 
			_( 'tag requires exactly 2 arguments' ) )

	return SubscriptionPlansNode(  bits[2] )

class SubscriptionPlansNode( Node ):
	"""
		get all subscription plans
	"""
	def __init__( self, context_name ):
		self.context_name = context_name
	def render( self, context ):
		
		clients = SubcriptionPlan.objects.all().order_by( 'name' ).values("id", "name")
		context[self.context_name] = clients
		
		return ''

register.tag( "subscription_plans", get_subscription_plans )