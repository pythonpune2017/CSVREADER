# Create your views here.
import os
import time
from datetime import datetime
from utils.random_generator import RandomGenerator
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from client.models import ClientModel,ClientUser,ClientSubscription
from admin_app.form import PremissionsForm
from utils.paginator import paginate
from client.form import ClientForm
from django.contrib.auth.models import User, Group
from admin_app.models import CountryModel,UserProfileModel,StaffModel
from client.models import SubcriptionPlan,ClientSubscription,ClientModel,CurrencyModel,ClientUserProfile
from datetime import datetime
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from query_manager import ClientManager
from managers import ClientPermManager
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from utils.send_mail import SendMail
from django.core.servers.basehttp import FileWrapper
from models import Alert as alert_permission
from admin_app.form import AlertForm, get_values_for_alert_form
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
import json
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action
from query_manager import ClientManager
from utils.filewrapper_info import FixedFileWrapper

class WebIPException:
    def __init__(self):
        pass

@login_required
def manage_clients(request):
    """
        renders page to list clients
    """
    context ={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    country, plan, status  = request.GET.get('country'), request.GET.get('subscription'), request.GET.get('status')
    expiry_in, expiry_out, per_page = request.GET.get('expiry_in'), request.GET.get('expiry_out'),request.GET.get('numOfResults',25)
    keyword = request.GET.get("keyword")
    expiry_in, expiry_out = request.GET.get("expiry_in"), request.GET.get("expiry_out")
    cur_page=request.GET.get('page', 1)
    order=request.GET.get('order')
    clients = ClientModel.objects.all()
    if keyword:
#        fields_4_keyword_search = ["user__username", "user__first_name", "user__email"]
        #fields_4_keyword_search = ["name", "clientuser__user__username", "clientuser__user__email"]
        fields_4_keyword_search = ["name","user__email","user__first_name"]
        q_str = ""
        for element in fields_4_keyword_search:
            q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
        
        clients = clients.filter(eval(q_str))


    if status=="1" :
        clients = clients.filter(is_active = True)
    elif status=="0":
        clients = clients.filter(is_active = False)

    clients = clients.filter(country__id = country) if country else clients
# logic for filter a plan and expiry date start


    if plan:
        clients=clients.filter(clientsubscription__plan = plan)



    if expiry_in and expiry_out:
        expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
        expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__gt = expiry_in_date,clientsubscription__expiry_date__lt=expiry_out_date)

    elif expiry_out:
        expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__lt=expiry_out_date)

    elif expiry_in:
        expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__gt = expiry_in_date)

    else:
        clients=clients

    clients=clients.order_by("name")
# logic for filter a plan and expiry date end


#logic for the sorting and desending coloumns view
    if request.GET.get('sort') =='cmpname':

        if order=='asc':
            clients = clients.order_by("name")
        else:
             clients = clients.order_by("-name")

    if request.GET.get('sort')=='cname':
        if order=='asc':
            clients = clients.order_by("clientuser__user__first_name")
        else:
            clients = clients.order_by("-clientuser__user__first_name")


    if request.GET.get('sort')=='email':
        if order=='asc':
            clients = clients.order_by("clientuser__user__email")
        else:
            clients = clients.order_by("-clientuser__user__email")


    if request.GET.get('sort') =='country':
        if order=='asc':
            clients = clients.order_by("country")
        else:
            clients = clients.order_by("country")

    if request.GET.get('sort')=='reg_date':
        if order=='asc':
            clients = clients.order_by("clientsubscription__activation_date")
        else:
            clients = clients.order_by("-clientsubscription__activation_date")

    if request.GET.get('sort')=='exp_date':
        if order=='asc':
            clients = clients.order_by("clientsubscription__expiry_date")
        else:
            clients = clients.order_by("-clientsubscription__expiry_date")

    if request.GET.get('sort')=='subsp':
        if order=='asc':
            clients = clients.order_by("clientsubscription__plan")
        else:
            clients = clients.order_by("-clientsubscription__plan")

    if request.GET.get('sort')=='status':
        if order=='asc':
            clients = clients.order_by("is_active")
        else:
            clients = clients.order_by("-is_active")


    count=clients.count()
    if per_page=='ALL':
       per_page=count
    paginated = paginate(clients,cur_page, per_page)

    if keyword or country or expiry_in or expiry_out or plan or status:
        if not clients:
            messages.warning(request,"No Records found!")

    clients = paginated.object_list
    client_super_users_info = []
    for client in clients:
        try:
#            client_super_user = ClientUser.objects.get(client=client, user_type="superadmin")
            client_super_users_info.append({'client_name' : client.user.get_full_name(), "client_email":client.user.email})
        except Exception, e:
            client_super_users_info.append({'client_name' : "Unavailable", "client_email":"Unavailable"})

    client_subscription_info = []

    for client in clients:

        try:
            current_sub = ClientSubscription.objects.get(client=client, is_active=True)
            client_subscription_info.append({"plan":current_sub.plan.name, 'start_date':current_sub.activation_date.date, "last_date":current_sub.expiry_date.date })
        except Exception,e:
            client_subscription_info.append({'plan' : "Unavailable", "start_date":"Unavailable", "last_date":"Unavailable"})

    clients_info = clients.values("id", "name", "country__country_name", "is_active")

    for index, client in enumerate(clients_info):
        client.update(client_super_users_info[index])
        client.update(client_subscription_info[index])

    paginated.object_list = clients_info#
#    id = kwargs.get("id", None)
#    if request.method =="GET":
#        pass# this is a edit request
##        if id:
##       else add request
#
#    if request.method = "POST":
#
#        pass
#    if id: edir else add new
#    #send blank form
#
#
    context["is_selected"] = "currnt"
    context["result_set"] = paginated
    context['order']="asc" if order=="desc" else "desc"
    return render(request, "admin_app/be-manageclients.html", context)

@login_required
def staff_clients(request,staff_id):
    """
        renders page to list clients
    """
    context ={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    country, plan, status  = request.GET.get('country'), request.GET.get('subscription'), request.GET.get('status')
    expiry_in, expiry_out, per_page = request.GET.get('expiry_in'), request.GET.get('expiry_out'),request.GET.get('numOfResults',25)
    keyword = request.GET.get("keyword")
    expiry_in, expiry_out = request.GET.get("expiry_in"), request.GET.get("expiry_out")
    cur_page=request.GET.get('page', 1)
    order=request.GET.get('order')
    clients = ClientModel.objects.filter(accountmangers=staff_id)
    if not clients:
            messages.warning(request,"No Clients Assign for this Account Manager")
    if keyword:
#        fields_4_keyword_search = ["user__username", "user__first_name", "user__email"]
        #fields_4_keyword_search = ["name", "clientuser__user__username", "clientuser__user__email"]
        fields_4_keyword_search = ["user__first_name"]
        q_str = ""
        for element in fields_4_keyword_search:
            q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
        
        clients = clients.filter(eval(q_str))


    if status=="1" :
        clients = clients.filter(is_active = True)
    elif status=="0":
        clients = clients.filter(is_active = False)

    clients = clients.filter(country__id = country) if country else clients
# logic for filter a plan and expiry date start


    if plan:
        clients=clients.filter(clientsubscription__plan = plan)



    if expiry_in and expiry_out:
        expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
        expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__gt = expiry_in_date,clientsubscription__expiry_date__lt=expiry_out_date)

    elif expiry_out:
        expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__lt=expiry_out_date)

    elif expiry_in:
        expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
        clients=clients.filter(clientsubscription__expiry_date__gt = expiry_in_date)

    else:
        clients=clients

    clients=clients.order_by("name")
# logic for filter a plan and expiry date end


#logic for the sorting and desending coloumns view
    if request.GET.get('sort') =='cmpname':

        if order=='asc':
            clients = clients.order_by("name")
        else:
             clients = clients.order_by("-name")

    if request.GET.get('sort')=='cname':
        if order=='asc':
            clients = clients.order_by("clientuser__user__first_name")
        else:
            clients = clients.order_by("-clientuser__user__first_name")


    if request.GET.get('sort')=='email':
        if order=='asc':
            clients = clients.order_by("clientuser__user__email")
        else:
            clients = clients.order_by("-clientuser__user__email")


    if request.GET.get('sort') =='country':
        if order=='asc':
            clients = clients.order_by("country")
        else:
            clients = clients.order_by("country")

    if request.GET.get('sort')=='reg_date':
        if order=='asc':
            clients = clients.order_by("clientsubscription__activation_date")
        else:
            clients = clients.order_by("-clientsubscription__activation_date")

    if request.GET.get('sort')=='exp_date':
        if order=='asc':
            clients = clients.order_by("clientsubscription__expiry_date")
        else:
            clients = clients.order_by("-clientsubscription__expiry_date")

    if request.GET.get('sort')=='subsp':
        if order=='asc':
            clients = clients.order_by("clientsubscription__plan")
        else:
            clients = clients.order_by("-clientsubscription__plan")

    if request.GET.get('sort')=='status':
        if order=='asc':
            clients = clients.order_by("is_active")
        else:
            clients = clients.order_by("-is_active")


    count=clients.count()
    if per_page=='ALL':
       per_page=count
    paginated = paginate(clients,cur_page, per_page)

    if keyword or country or expiry_in or expiry_out or plan or status:
        if not clients:
            messages.warning(request,"No Records found!")

    clients = paginated.object_list
    client_super_users_info = []
    for client in clients:
        try:
#            client_super_user = ClientUser.objects.get(client=client, user_type="superadmin")
            client_super_users_info.append({'client_name' : client.user.get_full_name(), "client_email":client.user.email})
        except Exception, e:
            client_super_users_info.append({'client_name' : "Unavailable", "client_email":"Unavailable"})

    client_subscription_info = []

    for client in clients:

        try:
            current_sub = ClientSubscription.objects.get(client=client, is_active=True)
            client_subscription_info.append({"plan":current_sub.plan.name, 'start_date':current_sub.activation_date.date, "last_date":current_sub.expiry_date.date })
        except Exception,e:
            client_subscription_info.append({'plan' : "Unavailable", "start_date":"Unavailable", "last_date":"Unavailable"})

    clients_info = clients.values("id", "name", "country__country_name", "is_active")

    for index, client in enumerate(clients_info):
        client.update(client_super_users_info[index])
        client.update(client_subscription_info[index])

    paginated.object_list = clients_info#

#
#
    context["is_selected"] = "currnt"
    context["result_set"] = paginated
    context['order']="asc" if order=="desc" else "desc"
    return render(request, "admin_app/be-manageclients.html", context)


@login_required
def add_clients(request, **kwargs):
    """
        Add or edit a Client information
    """

    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method =='GET':
        searchlimit={'searchlimit':15}
        client_form= ClientForm(initial=searchlimit)
        context['clientform'] = client_form
        context["page_title"] = "Add Client"
        return render(request,"admin_app/BE_AddClient.html", context)

    if request.method=='POST':
        try:
            client_form = ClientForm(request.POST)
            if client_form.is_valid():
                #create a record for clientmodel
                try:
                    country_obj=CountryModel.objects.get(id=client_form.cleaned_data['country'].id)
                    currency_obj=CurrencyModel.objects.get(id=client_form.cleaned_data['currency'].id)
                except:
                    pass

                try:
                    password = client_form.cleaned_data['password']
                    username = RandomGenerator().username_generator()
                    user_obj = User.objects.create_user(username = username,email = client_form.cleaned_data['email'] ,password =password)
                    user_obj.first_name = client_form.cleaned_data['first_name']
                    user_obj.last_name = client_form.cleaned_data['last_name']
                    user_obj.is_active=eval(client_form.cleaned_data['status'])
                    group =Group.objects.get(name="all_clients")
                    user_obj.groups.add(group)
                    user_obj.save()
                
                    client_record=ClientModel(name=client_form.cleaned_data['company_name'],country=country_obj,currency=client_form.cleaned_data['currency'],user=user_obj,is_active=eval(client_form.cleaned_data['status']))
                    if client_form.cleaned_data['searchlimit']:
                        client_record.searchlimit=client_form.cleaned_data['searchlimit']
                    client_record.save()

                    user_profile_obj = UserProfileModel(user=user_obj,mobile=client_form.cleaned_data['phone'],phone=client_form.cleaned_data['phone'])
                    user_profile_obj.save()
                    log('CREATE', request.user, user_profile_obj)
                    clientuser_record=ClientUser(user=user_obj,client=client_record)
                    clientuser_record.save()
                    log('CREATE', request.user, clientuser_record)
                    clientprofile_obj=ClientUserProfile(client=clientuser_record)
                    clientprofile_obj.save()
                except:
                    pass
#                    clientuser_record = None
#                    print "Exception : %s" % str(e)


                #create a  record for the SubcriptionPlan and client subscriotion
                if client_form.cleaned_data['subscription']:
                    client_obj=ClientManager()
    #                plan = client_obj.getSubscriptionPlanObj(client_form.cleaned_data['subscription'])
                    plan=SubcriptionPlan.objects.get(id=client_form.cleaned_data['subscription'].id)
                    expriy_date=client_form.cleaned_data['expiry_date'].strftime('%d-%m-%y')
                    try:
                         client_plan = ClientSubscription.objects.get(client=client_record, plan=plan,expiry_date=client_form.cleaned_data['expiry_date'])
                    except:
                         try:
                             #datetimeobj = datetime.strptime(str(client_form.cleaned_data['expiry_date']), '%d-%m-%y')
                             datetimeobj = datetime.strptime(expriy_date, '%d-%m-%y')
                         except:
                            datetimeobj =None
                         client_plan = ClientSubscription(client=client_record, plan=plan)
                         client_plan.expiry_date=datetimeobj
                         client_plan.is_active = True
                         client_plan.save()


                #create a alert permission record


                #alert list checkbox listfrom admin_app.form import PremissionsForm
                alert_list = ["c1","c2","c3","c4","c5"]
                alert_list_values={}
                alertForm = AlertForm(request.POST)
                if alertForm.is_valid():
                    alertForm.saveAlerts(clientuser_record.user)
                    
                #to get frequency values
                perm_form=PremissionsForm(request.POST)
                if perm_form.is_valid():
                    perm_form.setPermissions(user_obj)

                
                
                context['message'] = "Client Record Successfully Created !"
                context['status'] = True
                log('CREATE', request.user, client_record)
                client_form= ClientForm()
                to_list = [user_obj.email,'priteshm@leosys.in']
                f_obj=SendMail()
                #to_list.append(DEFAULT_FROM_EMAIL)
                from_email = settings.EMAIL_HOST_USER
                # subject = request.POST.get('subject')
                message = """<p>Hello %s,</p>
                <p>Your Account has been created successfully.</p>
                <p>Your Username is %s</p>
                <p>Your password is %s</p>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """%(str(user_obj.first_name +" "+ user_obj.last_name), str(user_obj.email), str(password))
                try :
                     f_obj._send_mail('Client is created', message, from_email, to_list, [], '', content_subtype='html')
                except:
                    pass
                messages.add_message(request, messages.SUCCESS, "Client Record Successfully Created !")
            else:
                context['message'] = "Errors while creating Client Record!"
                context['status'] = False

        except:
            #print "Exception : %s" % str(e)
            pass


        context["page_title"] = "Add Client"
        context['clientform'] = client_form
#        return render(request, "admin_app/BE_AddClient.html", context)
        response=render_to_string("admin_app/BE_AddClient.html",context,RequestContext(request))
        tdict={}
        tdict['status']=context['status']
        tdict['message']=context['message']
        tdict['elements']= response

        return HttpResponse(json.dumps(tdict),mimetype="application/json")
#
#    id = kwargs.get("id", None)
#    if request.method =="GET":
#        pass# this is a edit request
##        if id:
##       else add request
#
#    if request.method = "POST":
#
#        pass
#    if id: edir else add new
#    #send blank form
#
#
#
#

@login_required
def edit_clients(request, id):
    """  edit a Client information"""
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method == 'GET':
        context["page_title"] = "Edit Client"
        first_name=''
        user_phone=''
        password=''
        last_name=''
        email=''
        status=''
        country=''
        currency=''
        searchlimit=''
        searchlimitdate=''
        client_obj=ClientModel.objects.get(pk = id)

        #tempoaray solution for clientobj usign username
        try:
            if client_obj.user:
                first_name=client_obj.user.first_name
                user_phone = client_obj.user.userprofilemodel.phone
#                password=client_user_obj.user.password
                last_name=client_obj.user.last_name
                email=client_obj.user.email
                status=client_obj.user.is_active
                country=client_obj.country.id
                currency=client_obj.currency.id
                searchlimit=client_obj.searchlimit

        except:
            pass

        try:
            client_subscription_obj=ClientSubscription.objects.get(client=client_obj)
            if client_subscription_obj:
                plan_id=client_subscription_obj.plan_id
                ex_date=client_subscription_obj.expiry_date.strftime("%d-%m-%Y")

        except:
              plan_id=''
              ex_date=''
              client_subscription_obj=None
              pass


        form_data={
                       'id':client_obj.id,
                       'company_name':client_obj.name,
                       'first_name':first_name,
                       'last_name':last_name,
                       'password':password ,
                       'phone':user_phone,
                       'email': email,
                       'status':status,
                       'country':country,
                       'subscription':plan_id,
                       'expiry_date':ex_date,
                       'currency':currency,
                       'searchlimit':searchlimit,
                      
                       }

        alertformdata = get_values_for_alert_form(client_obj.user)
        form_data.update(alertformdata)
        # logic for get a permiision data start
        cm = ClientPermManager(client_obj)
        client_permmission_info = cm.get_client_permissions()
        form_data.update(client_permmission_info)

        # logic for get a permiision data end

        clientform = ClientForm(form_data)
#        clientform.country = client_obj.country.id
#        clientform.subscription_plan=plan_id
#        clientform.expiry_date =ex_date

        context['clientform']=clientform
        return render(request, "admin_app/BE_EditClient.html", context)

    if request.method=='POST':
        """  Client log information """
        email_send=False
        from webip.utils.context_processor import Diff_match, Permission_match, Date_match, Alert_match
        history = {}
        client_object = ClientModel.objects.get(pk = request.POST.get('id'))
        #alertformdata = get_values_for_alert_form(client_object.user)
        history.update({'company_name':client_object.name,
                       'first_name':client_object.user.first_name,
                       'last_name':client_object.user.last_name,
                       'phone':client_object.user.userprofilemodel.phone,
                       'email': client_object.user.email,
                       'status':str(client_object.user.is_active),
                       'country':str(client_object.country.id),
                       'currency':str(client_object.currency.id),
                       'seachlimit':client_object.searchlimit
                       })
        result_array_new, result_array_old = Diff_match(history, request.POST)
        # date matching for log
        try:
            client_subscription_object=ClientSubscription.objects.get(client=client_object)
            if client_subscription_object:
                ex_date=client_subscription_object.expiry_date.strftime("%d-%m-%Y")
                new_date=request.POST.get('expiry_date')
                new_date_dict, ex_date_dict = Date_match(ex_date,new_date)
                result_array_new.update(new_date_dict)
                result_array_old.update(ex_date_dict)
        except:
              ex_date=''
              client_subscription_obj=None
              pass
#              print "Exception : %s" % str(e)
        if result_array_new or result_array_old:
            data = {'old':result_array_old, 'new':result_array_new}
        else:
            data = None
        # permission matching for log
        cm = ClientPermManager(client_object)
        client_permmission_info = cm.get_client_permissions()
        perms_new, perms_old = Permission_match(client_permmission_info, request.POST)
        result_array_new.update(perms_new)
        result_array_old.update(perms_old)
        """ Alert matching information """
        alertformdata = get_values_for_alert_form(client_object.user)
        alerts_new, alerts_old = Alert_match(alertformdata, request.POST)
        result_array_new.update(alerts_new)
        result_array_old.update(alerts_old)
        if result_array_new or result_array_old:
            data = {'old':result_array_old, 'new':result_array_new}
        else:
            data = None

        clientform = ClientForm(request.POST)
        try:
            if clientform.is_valid():
                client_obj=ClientModel.objects.get(pk = id)

                if len(clientform.cleaned_data['password']):
                    client_obj.user.set_password(clientform.cleaned_data['password'])
                    email_send=True

                client_obj.user.first_name=clientform.cleaned_data['first_name']
                client_obj.user.last_name=clientform.cleaned_data['last_name']
                client_obj.user.email=clientform.cleaned_data['email']
                client_obj.user.is_active=eval(clientform.cleaned_data['status'])
                client_obj.is_active=eval(clientform.cleaned_data['status'])
                client_obj.user.save()


                client_obj.user.userprofilemodel.phone=clientform.cleaned_data['phone']
                client_obj.user.userprofilemodel.save()

                country_obj=CountryModel.objects.get(id=clientform.cleaned_data['country'].id)
                client_obj.name=clientform.cleaned_data['company_name']
                client_obj.country=country_obj
                client_obj.currency=clientform.cleaned_data['currency']
                try:
                    client_obj.searchlimit=int(clientform.cleaned_data['searchlimit'])
                except:
                    client_obj.searchlimit=0
                client_obj.save()

#                clientform.country=country_obj.country.id

                if clientform.cleaned_data['subscription'] and clientform.cleaned_data['expiry_date']:
                    subs_plan=SubcriptionPlan.objects.get(id=clientform.cleaned_data['subscription'].id)
                    expriy_date=clientform.cleaned_data['expiry_date'].strftime('%d-%m-%y')
                    try:
                            datetimeobj = datetime.strptime(expriy_date, '%d-%m-%y')
                    except:
                            datetimeobj =None
                    try:
                         client_plan = ClientSubscription.objects.get(client=client_obj)
                         client_plan.plan=subs_plan
                         client_plan.expiry_date=datetimeobj
                         client_plan.save()
                    except:
                        client_plan = ClientSubscription(client=client_obj, plan=subs_plan)
                        client_plan.expiry_date=datetimeobj
                        client_plan.is_active = True
                        client_plan.save()



                alertForm = AlertForm(request.POST)
                if alertForm.is_valid():
                    alertForm.saveAlerts(client_obj.user)

                Perm_Form=PremissionsForm(request.POST)

                if Perm_Form.is_valid():
                    Perm_Form.setPermissions(client_obj.user)
#
                log('EDIT', request.user, client_obj, data=data)
                context['message'] = "Client Record is Updated Successfully!"
                context['status'] = True
                messages.add_message(request, messages.SUCCESS, "Client Record is Updated Successfully!")
#                code for send email if password is change start
                if email_send:
                    to_list = [clientform.cleaned_data['email']]
                    bcc_list=['priteshm@leosys.in']
                    f_obj=SendMail()
                    #to_list.append(DEFAULT_FROM_EMAIL)
                    from_email = settings.EMAIL_HOST_USER
                    # subject = request.POST.get('subject')
                    message = """<p>Hello %s,</p>
                    <p>Your Password has been Updated successfully.</p>
                    <p>Your Username is %s</p>
                    <p>Your password is %s</p>
                    <p>Thanks,</p>
                    <p>Web Ip Support.</p>
                    """%(str(client_obj.user.first_name +" "+ client_obj.user.last_name), clientform.cleaned_data['email'], clientform.cleaned_data['password'])
                    try :
                         f_obj._send_mail('Password Changed.', message, from_email, to_list, [],bcc_list,'', content_subtype='html')
                    except:
                        pass
                    
            else:
                context['message'] = "Error while updating Client"
                context['status'] = False
        except Exception,e:
            country_obj=None
            client_obj=None
            context['message'] = "Error while updating Client"
            context['status'] = False
            print "exception",str(e)


        context['clientform']=clientform
#        return render(request, "admin_app/BE_EditClient.html", context)
        response=render_to_string("admin_app/BE_EditClient.html", context,RequestContext(request))
        tdict={}
        tdict['status']=context['status']
        tdict['message']=context['message']
        tdict['elements']= response
        import json
        return HttpResponse(json.dumps(tdict),mimetype="application/json")


@login_required
def delete_client(request,cl_id):
    """
        Marks a Client as Deleted
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context['obj']={"id":cl_id}
    delete_url = reverse("deleteclient", args=[cl_id])
    client = ClientModel.objects.get(id = cl_id)
    context["message"] = "Are you sure you want to delete '"+ str(client.name)+"' client?"
    context['post_url'] = delete_url
    context['visible']=True
    if request.method== 'POST':
        clientid = request.POST.get("record_id")
        try:
            client_user_objects_list=ClientUser.objects.filter(client=cl_id)
            if client_user_objects_list:
                for i in client_user_objects_list:
                    if i:
                        if i.user_type =='subuser':
                            i.user.delete()
                            i.delete()
                    else:   
                        pass
            
            client.user.delete()
            client.delete()        
            context['visible']=False
        except:
            context["message"] = "No record exists!"
        context["message"] = "Client record is  deleted!"
        context['visible']=False
        messages.add_message(request, messages.SUCCESS, "Client record is deleted Successfully!")

        return HttpResponseRedirect(request.META["HTTP_REFERER"])

    return render_to_response('admin_app/delete_staff.html',context,RequestContext(request))

@login_required
def import_client(request):
    """
        Purpose: Import client details both from csv and spreadsheet
    """
    message = ''
    errors = []
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method == "GET":
        return render_to_response('admin_app/Import_Client.html', context, RequestContext(request))
    if request.method == "POST":
        if request.FILES.has_key('import_file'):
            file_obj = request.FILES['import_file']
            file_flag = True
        else:
            message = "Please upload file..."
            file_flag = False

        if file_flag:
            location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))

            Import_obj = ClientManager()
            status = Import_obj.save_uploaded_file(file_obj, location)
            if not status:
                return HttpResponseRedirect(request.META['HTTP_REFERER'])

            format = Import_obj.checkForFormat(location)

            if format == "xls" or "xlsx":

                obj = SpreadSheetDictonaryConversion()
                spreadsheet_column_list = ['Company Name','First Name','Last Name',
                                           'Phone','Email','Country','Currency Code','Subscription Plan',
                                           'Domain Renewals','DNS Changes','SSL Renewals',
                                           'Trademark Renewals','Contract Changes','Activation Date',
                                           'Expiry Date','Status']

                result_dict = obj.spreadsheet_converter(location , spreadsheet_column_list)
                status, message, errors = Import_obj.processImportedClient(result_dict)
            if format == "csv":
                csvobj = CSVDictionaryConversion()
                result_dict = csvobj.csvConverter(location)
                status, message, errors = Import_obj.processCSVImportedClient(result_dict)
            Import_obj.delete_processed_file(location)
        context['message'] =  str(message)
        context['client_errors'] =  errors
    return render_to_response('admin_app/Import_Client.html', context, RequestContext(request))

@login_required
def export_client_details(request):
    """
        Export Clients Details on the basis of filtered results
    """
    context={}
    data_dict={}
    response = None
    #request dictionary
    req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
#    data_dict = {}
#    search = str(req_dict['search_data'])
#    search_data = search.split('&')
#    for item in search_data:
#        item = item.split('=')
#        data_dict[item[0]] = item[1]
#    req_dict.update(data_dict)
    #get client information list
    client_obj = ClientManager()
    client_data = client_obj.exportClientMember(req_dict)
    #client_data = ClientModel.objects.filter(is_active = True , clientuser__user_type = 'superuser').select_related()
    #Data required for creating spreadsheet
    sequence_list = SpreadsheetMapping.CLIENT_SEQUENCE_LIST
    title_dict = SpreadsheetMapping.CLIENT_TITLE_LIST
    #Create XLS
    if request.POST.get("format") == "xls":
        status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, client_data, "client_")
        file_location = os.path.join(settings.TEMP_DIR , "client.csv")
        #status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , client_data , file_location)
        if not status:
            pass
    #Create CSV
    elif request.POST.get("format") == "csv":
        file_location = os.path.join(settings.TEMP_DIR , "client.csv")
        status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , client_data , file_location)
        if status:
            wrapper = FixedFileWrapper(file(file_location))
            filename = 'attachment; filename=' + str(time.strftime("Client_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
            response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
            response['Content-Disposition'] = filename
        msg = "Client CSV Export Successful." if status else "Error in Client CSV Export."
        log('EXPORT', request.user, request.user, data={'export':msg})
    return response


@login_required
def download_client_spreadsheet(request, format):
    """
        Purpose: Export staff details on the basis of filtered results
    """
    response =None
    req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
    data_dict = {}
    #Create XLS
    if format == "xls":
        filename = "Client_Import_Format.xls"
    elif format == "csv":
        filename = "Client_Import_Format.csv"
    location = os.path.join(settings.SPREADSHEET_FORMAT_PATH , filename.replace(" ","_"))
    wrapper = FixedFileWrapper(file(location))
    filename = 'attachment; filename=' + str(filename)
    response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
    response['Content-Disposition'] = filename
    return response

def Clientlog(client_object):
    """
        client log information
    """

