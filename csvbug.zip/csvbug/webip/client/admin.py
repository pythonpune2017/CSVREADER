'''
Created on 06-Jan-2012

@author: pritesh
'''

from models import *

from models import Alert as alert_permission

from django.contrib import admin as django_admin


class AlertAdmin(django_admin.ModelAdmin ):
    list_display = ( 'user','name', 'frequency' )
    search_fields = ( 'user','name' )

django_admin.site.register(CurrencyModel)
django_admin.site.register(ClientUser)
django_admin.site.register(ClientModel)
django_admin.site.register(SubcriptionPlan)
django_admin.site.register(ClientSubscription)
django_admin.site.register(Alert, AlertAdmin)
django_admin.site.register(InstraCorpUser)
django_admin.site.register(ClientDomainCategory)
django_admin.site.register(ClientUserProfile)
django_admin.site.register(DomainRegistration)
django_admin.site.register(RegistrationDetails)
django_admin.site.register(NameServerProfiles)
django_admin.site.register(NameServerProfileDetails)
