from django import forms
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from client.models import *
from admin_app.models import *
from django import forms
from django.core import validators

from admin_app.form import AlertForm
from admin_app.form import PremissionsForm

import re
import os
attrs_dict = {'class': 'required'}


class ClientForm(AlertForm,PremissionsForm):


    STATUS = (

    (True, "Active"),
    (False,"Inactive")
     )

    STAFF_CHOICE = (
    ('admin', 'Admin.'),
    ('accountmanager', 'Account Manager'),
)

    frequency_list = (
    ('none','please select'),
    ('daily', 'Once in Day'),
    ('weekly', 'Once in Week'),
    ('monthly', 'Once in Month'),
    ('yearly', 'Once in Year'),
)

    id = forms.CharField(label="id",widget=forms.HiddenInput(),required = False)
    company_name = forms.CharField(label="Comapny Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z]'), code='invalid')],
                                error_messages = {'invalid': 'CompanyName must be alphabetic'} 
                                )

    first_name = forms.CharField(label="First Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Client First Name must be alphanumeric'} ,
                                

                                )

    last_name = forms.CharField(label="Last Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Client Last Name must be alphanumeric'},
                                
                                )
                                


    email = forms.EmailField(widget=forms.TextInput(attrs={'class':'popinput'}), max_length=75,label=_("E-mail"),
                             error_messages={'required':"Email is required"})

    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'popinput'}, render_value=False),
                                label=_("Password"),error_messages={'required':"Password is required"},required = False)


    phone = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'popinput'}),required=True,
                                label=_("Phone"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Phone must be numeric'}                                
                                )

    
    searchlimit = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'popinput'}),required=False,
                                label=_("Search Limit"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Search Limit must be numeric'}                                
                                )

    
    currency = forms.ModelChoiceField(queryset = CurrencyModel.objects.all().order_by('name'),label=_("Currency"),widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop2 webip_select_pop'}),error_messages = {'required': 'Currency Field is required'},required = True)
    
    country = forms.ModelChoiceField(queryset = CountryModel.objects.all().order_by('country_name'),label=_("Country"),widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop2 webip_select_pop'}),error_messages = {'required': 'Conutry Field is required'},required = True)
    
    subscription=forms.ModelChoiceField(queryset = SubcriptionPlan.objects.all(),label=_("Subscription Plan"),required = True,widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop2 webip_select_pop'}),error_messages = {'required': 'Subscription Field is required'})
    
    expiry_date = forms.DateField(label="Expiry date", required = True,
                                widget=forms.DateInput(attrs={'class':'datepicker'}),input_formats=["%d-%m-%Y"],
                                error_messages = {'required': 'Expiry Date is required'})

    status=forms.ChoiceField(choices=STATUS,
                             widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop webip_select_pop'}),
                                label=_("Status"),required = False)
    


    def __init__(self, *args, **kwargs):
        super(ClientForm, self).__init__(*args, **kwargs)
        self.fields['currency'].empty_label = 'Please Select'
        self.fields['subscription'].empty_label = 'Please Select'
        self.fields['country'].empty_label = 'Please Select'
    
    
    def clean_password(self):
        password=self.cleaned_data['password']
        try:
            if not len(self.cleaned_data['id']):
                if not password:
                    raise forms.ValidationError("please enter the password")                
        except:
            raise
                
        return password  

   
#        error_message = ''
#        try:
#            company = self.cleaned_data["company_name"]
#            client_id = self.cleaned_data["id"]
#            clientmodel = ClientModel.objects.get(name=company)
#        except :
#            clientmodel = None
#        if clientmodel:
#            if client_id:
#                error_message = "Company name is already exist"
#                self._errors['company_name'] = error_message
#                
#        return self.cleaned_data

    def clean_email(self):
        """  Validates that an active client exists with the given email address."""
        email = self.cleaned_data["email"]
        try:
            if not len(self.cleaned_data['id']):
                self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
                if len(self.client_cache):
                    for user_id in self.client_cache:
                        client=ClientModel.objects.filter(user=user_id)
                        if client:
                            raise forms.ValidationError("The e-mail address already associated with other Client Account.")
                        staff=StaffModel.objects.filter(user=user_id)
                        if staff:
                            raise forms.ValidationError("The e-mail address already associated with other Staff Account.")    
                if self.cleaned_data['id']:
                    client=ClientModel.objects.filter(user__email=self.cleaned_data["email"])
                    if not client:
                        self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
                    if len(self.client_cache):
                        for user_id in self.client_cache:
                            client=ClientModel.objects.filter(user=user_id)
                            if client:
                                raise forms.ValidationError("The e-mail address already associated with other Client Account.")
                            staff=StaffModel.objects.filter(user=user_id)
                            if staff:
                                raise forms.ValidationError("The e-mail address already associated with other Staff Account.")
        except:
            raise    
        
        return email

    def clean_company_name(self):
          """  Validates that an active company name already exists with given name"""
          company_name = self.cleaned_data["company_name"]
          
          client_obj=None
          try:  
              if not len(self.cleaned_data['id']):
                  client_obj = ClientModel.objects.get(name=company_name)
                  if client_obj:
                      self._errors['company_name'] = "The company is already exist"
                      #raise forms.ValidationError("The Company name already associated with other Client Account.")
                  else:
                      pass
              
              if len(self.cleaned_data['id']):
                  if company_name: 
                      client_obj=ClientModel.objects.get(id=eval(self.cleaned_data['id']))
                      if not client_obj.name==company_name:
                          client_obj=ClientModel.objects.get(name=company_name)
                          if client_obj:
                              self._errors['company_name'] = "The company is already exist"
                          else:
                              pass
                      else:
                           pass
                   
                         
          except:
                client_obj=None
            
          return company_name
            
#
#if record is on edit
#
#then  first check that if the company name is change and that change data is check with existing company name
#
#if that change match with existing client name then show a error
#'or other wise dont do any thing '
