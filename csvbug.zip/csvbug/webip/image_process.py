import os
import utils.set_django_env
from utils.processing_image import resize_image
from client.models import ClientUserProfile
from trademark.models import Trademark

class Image_Process(object):
    """
        processing image for trademark and user.
    """
    def user_image_process(self):
        client_data =  ClientUserProfile.objects.all()
        for client in client_data:
            if client.image:
                m_out_path = os.path.dirname(client.image.path)
                resize_image(client.image.path, m_out_path, height=100, width=100)

    def trademark_image_process(self):
        client_data =  Trademark.objects.all()
        for client in client_data:
            if client.image:
                m_out_path = os.path.dirname(client.image.path)
                resize_image(client.image.path, m_out_path, height=100, width=100)

if __name__ == '__main__':
    image_process_obj = Image_Process()
    image_process_obj.user_image_process()
    image_process_obj.trademark_image_process()
