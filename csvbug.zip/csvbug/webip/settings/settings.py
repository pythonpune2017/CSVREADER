# Django settings for webip project.

import socket
import os
DJANGO_PRJ_PATH = os.path.abspath(os.path.dirname(__file__))
CODE_DIR = os.path.abspath(os.path.dirname(DJANGO_PRJ_PATH))
PROJECT_DIR = os.path.abspath(os.path.dirname(CODE_DIR))

host=['web168.webfaction.com', 'leosys.net', 'pythondev.net', 'python-desktop']


# check machine by its host name and decide which values to take
#if socket.gethostname() == 'server_host_name' :
if socket.gethostname() in ['leosys.net']:
    import settings_production as  sp
elif socket.gethostname() in ['dedicated.webip.com.au']:
    import settings_client as  sp
elif socket.gethostname() in ['web168.webfaction.com']:
    import settings_webfraction as  sp
elif socket.gethostname() in ['staging.webip.com.au']:
    import settings_staging as sp
elif socket.gethostname()  in  ['pythondev.net', 'python-desktop'] :
    import settings_dev_server as sp
else:
    import settings_development as sp

os.environ['DJANGO_SETTINGS_MODULE'] = 'webip.settings'
DEBUG = sp.DEBUG
TEMPLATE_DEBUG = sp.TEMPLATE_DEBUG

ADMINS = (
     ('Pritesh Modi', "priteshm@leosys.in")
)

MANAGERS = ADMINS



DATABASES = {
    'default': {
        'ENGINE': sp.db_engine, # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.,
        'NAME': sp.db_name,                      # Or path to database file if using sqlite3.
        'USER': sp.db_user,                      # Not used with sqlite3.
        'PASSWORD':sp.db_pass,                  # Not used with sqlite3.
        'HOST':sp.db_host,                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT':sp.db_port,                      # Set to empty string for default. Not used with sqlite3.
    },
#    'innodb': {
#        'ENGINE': sp.db_engine,
#        'OPTIONS': { 'init_command' : 'SET storage_engine=INNODB;' }
#        }
}
#
# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# On Unix systems, a value of None will cause Django to use the same
# timezone as the operating system.
# If running in a Windows environment this must be set to the same as your
# system time zone.
TIME_ZONE = 'America/Chicago'

# Language code for this installation. All choices can be found here:
# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1

# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True

# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = sp.MEDIA_ROOT


# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash.
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"

MEDIA_URL = sp.MEDIA_URL

UPLOAD_MEDIA_URL = sp.UPLOAD_MEDIA_URL
#MEDIA_URL='http://localhost/media/'
# Absolute path to the directory static files should be collected to.
# Don't put anything in this directory yourself; store your static files
# in apps' "static/" subdirectories and in STATICFILES_DIRS.
# Example: "/home/media/media.lawrence.com/static/"
STATIC_ROOT = sp.STATIC_ROOT

# URL prefix for static files.
# Example: "http://media.lawrence.com/static/"
STATIC_URL = sp.STATIC_URL

# URL prefix for admin static files -- CSS, JavaScript and images.
# Make sure to use a trailing slash.
# Examples: "http://foo.com/static/admin/", "/static/admin/".
#ADMIN_MEDIA_PREFIX = 'http://webip.com/admin-media/'
ADMIN_MEDIA_PREFIX = sp.admin_media_prefix
# Additional locations of static files
STATICFILES_DIRS = (
    # Put strings here, like "/home/html/static" or "C:/www/django/static".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
)

# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
)

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'gn6nd@f!#p8(d_vhq)6ll(wk%z@@2v7x17z)t7ppusnse%sj2l'

# List of callables that know how to import templates from various sources.
#TEMPLATE_LOADERS = (
#    'django.template.loaders.filesystem.Loader',
#    'django.template.loaders.app_directories.Loader',
##     'django.template.loaders.eggs.Loader',
#)
#TEMPLATE_CONTEXT_PROCESSORS=(
#                         'django.contrib.auth.context_processors.auth',
#
#                         )
MIDDLEWARE_CLASSES = (

    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
)

ROOT_URLCONF = 'webip.urls'
#
#
TEMPLATE_DIRS = (
#                 '/home/pritesh/workspace/webip-Trunk/code/templates'
                 os.path.join(CODE_DIR,"templates"),
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
)



INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
##    # Uncomment the next line to enable the admin:
     'django.contrib.admin',
##    # Uncomment the next line to enable admin documentation:
     'django.contrib.admindocs',
     'webip_auth',
     'admin_app',
     'client',
     'domain',
     "utils",
     "trademark",
     "contract",
     "monitoring",
     "object_log",
     "south",
     "webip_mail",
     "captcha",
     "users",
     "vendor",
     "cases"


)
#
## A sample logging configuration. The only tangible logging
## performed by this configuration is to send an email to
## the site admins on every HTTP 500 error.
## See http://docs.djangoproject.com/en/dev/topics/logging for
## more details on how to customize your logging configuration.
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }

}


TEMPLATE_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.core.context_processors.debug',
    'django.core.context_processors.i18n',
    "django.core.context_processors.media",
    'django.contrib.messages.context_processors.messages',
    'django.core.context_processors.request',
    'django.core.context_processors.static',
    'utils.context_processor.active_url',

 )



TEMPLATE_CONTEXT_PROCESSORS = TEMPLATE_CONTEXT_PROCESSORS + (
    'utils.context_processor.latest_tweet',
)

TWITTER_USER = "WebIPAustralia"
TWITTER_TIMEOUT = 30
#
#
#

#
#TWITTER_USER = "webip_leosys"
#TWITTER_TIMEOUT = 60


TEMP_DIR = sp.TEMP_DIR
LOGIN_URL = sp.LOGIN_URL


EMAIL_HOST = 'smtp.webhost4life.com' #'smtpout.asia.secureserver.net'
EMAIL_HOST_USER = "opensource@leosys.in" #al@yogasync.tv
EMAIL_HOST_PASSWORD = "opensource"
EMAIL_PORT = 25

#EMAIL_HOST = 'BL2PRD0610.mailbox.outlook.com' #'smtpout.asia.secureserver.net'
#EMAIL_HOST_USER = "alerts@webip.com.au" #al@yogasync.tv
#EMAIL_HOST_PASSWORD = 'Woodfish501'
#EMAIL_PORT = 25
EMAIL_USE_TLS = False

SERVER_EMAIL = EMAIL_HOST_USER
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
AUTHENTICATION_BACKENDS = ('webip.webip_auth.views.EmailAuthBackend',)

#root dir for saving Application data
APPLICATION_DATA_DIR = sp.application_data_dir
APPLICATION_DOMAIN_DIR=sp.application_domain_dir

# location where the data is uploaded using FTP or other sources
UPLOAD_DIR = sp.UPLOAD_DIR
LOGIN_URL = "/login/"
ACCOUNT_ACTIVATION_DAYS=30
SPREADSHEET_FORMAT_PATH=sp.SPREADSHEET_FORMAT_PATH
FILE_STORAGE_LOCATION=sp.FILE_STORAGE_LOCATION

 # For Following Domain Names Years to Register Will To 2.
DOMAIN_NAME_LIST = ['.com.au','.co.uk']
DOMAIN_TYPES = [(1,'com'), (2,'net'), (3,'edu'), (4,'biz'), (5,'info'), (6,'org'), (7,'comau'), (8,'netau')]
