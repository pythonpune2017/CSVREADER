# All the setting variables required by settings.py for production will be taken from here
# NOTE : copy these varaibles in a file called settings_development.py and set your local settings.
import os

DEBUG = False
db_engine = 'django.db.backends.mysql'
db_name = 'leosatyen_webip'
db_user = 'leosatyen_webip'
db_pass = 'leo_123'
db_host = ''
db_port = ''
DOMAIN = ''
IPADD = ''
IPDB = False
INTERNAL_IP = ''
APACHE_MEDIA_URL = '/media/'
UPLOAD_MEDIA_URL = '/image/'
APACHE_ADMIN_MEDIA_URL = '/admin-media/'
TEMPLATE_DEBUG=False
STATIC_URL=APACHE_MEDIA_URL
STATIC_ROOT=''
admin_media_prefix=APACHE_ADMIN_MEDIA_URL
TEMP_DIR='/tmp'
LOGIN_URL = '/'

SPREADSHEET_FORMAT_PATH='/home/webip/spreadsheet/'

application_data_dir = r"/home/leosatyen/webapps/webip/data/application_data"
application_domain_dir= r"/home/leosatyen/webapps/webip/data/application_data"

MEDIA_URL = "/data/"
MEDIA_ROOT = r"/home/leosatyen/webapps/webip/data/application_data"
UPLOAD_DIR = "/home/leosatyen/webapps/webip/data/upload"
FILE_STORAGE_LOCATION='/home/leosatyen/webapps/webip/Trunk/spreadsheet'

