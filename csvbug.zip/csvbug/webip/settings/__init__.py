import socket
import os

host=['web168.webfaction.com', 'leosys.net', 'pythondev.net', 'python-desktop']
# check machine by its host name and decide which values to take
hostname = socket.gethostname()
if hostname  in  ['pritesh-desktop'] :
    from settings_pritesh import *
elif hostname == "arun-desktop":
    from settings_arun import *
else:
    from settings_client_production import *
    
del(hostname)
    
