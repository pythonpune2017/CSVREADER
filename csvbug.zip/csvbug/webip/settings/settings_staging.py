# Django settings for webip project.

import os
SETTINGS_PACK_PATH = os.path.abspath(os.path.dirname(__file__))
DJANGO_PRJ_PATH = os.path.abspath(os.path.dirname(SETTINGS_PACK_PATH))
CODE_DIR = os.path.abspath(os.path.dirname(DJANGO_PRJ_PATH))
PROJECT_DIR = os.path.abspath(os.path.dirname(CODE_DIR))

DEBUG = True
TEMPLATE_DEBUG = DEBUG

ADMINS = (
     ('Arun Mittal', "arunm@leosys.in")
)

MANAGERS = ADMINS

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql', # Add 'postgresql_psycopg2', 'postgresql', 'mysql', 'sqlite3' or 'oracle'.,
        'NAME': "stagingw_webip",                      # Or path to database file if using sqlite3.
        'USER': "stagingw_webip",                      # Not used with sqlite3.
        'PASSWORD':"!A@S#D$F%G",                  # Not used with sqlite3.
        'HOST':"",                      # Set to empty string for localhost. Not used with sqlite3.
        'PORT': "",                      # Set to empty string for default. Not used with sqlite3.
    },
}
#
TIME_ZONE = 'America/Chicago'

# http://www.i18nguy.com/unicode/language-identifiers.html
LANGUAGE_CODE = 'en-us'

SITE_ID = 1
# If you set this to False, Django will make some optimizations so as not
# to load the internationalization machinery.
USE_I18N = True
# If you set this to False, Django will not format dates, numbers and
# calendars according to the current locale
USE_L10N = True

# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
MEDIA_ROOT = "/home/stagingw/data/"
MEDIA_URL = "/data/"

STATIC_ROOT = ''
STATIC_URL = '/static/'

UPLOAD_MEDIA_URL = '/image/'
#ADMIN_MEDIA_PREFIX = 'http://webip.com/admin-media/'
ADMIN_MEDIA_PREFIX = '/admin-media/'
ADMIN_MEDIA_ROOT = os.path.join(CODE_DIR, "media/admin")
# Additional locations of static files
STATICFILES_DIRS = (
    os.path.join(CODE_DIR, "media/"),
)

# List of finder classes that know how to find static files in
# various locations.
STATICFILES_FINDERS = (
    'django.contrib.staticfiles.finders.FileSystemFinder',
    'django.contrib.staticfiles.finders.AppDirectoriesFinder',
#    'django.contrib.staticfiles.finders.DefaultStorageFinder',
)

# Make this unique, and don't share it with anybody.
SECRET_KEY = 'gn6nd@f!#p8(d_vhq)6ll(wk%z@@2v7x17z)t7ppusnse%sj2l'

MIDDLEWARE_CLASSES = (

    'django.middleware.common.CommonMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'debug_toolbar.middleware.DebugToolbarMiddleware',
    'pagination.middleware.PaginationMiddleware',
#    'utils.middlewares.sessionexpiredmiddleware.SessionExpiredMiddleware',
    'utils.middlewares.saas.SaasMiddleware'
)

ROOT_URLCONF = 'webip.urls'

TEMPLATE_DIRS = (
                 os.path.join(CODE_DIR,"templates"),
)

INSTALLED_APPS = (
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.sites',
    'django.contrib.messages',
    'django.contrib.staticfiles',
     'django.contrib.admin',
     'django.contrib.admindocs',
     'webip_auth',
     'admin_app',
     'client',
     'domain',
     "utils",
     "trademark",
     "contract",
     "monitoring",
     "object_log",
     "south",
     "webip_mail",
     "captcha",
     "users",
     "vendor",
     "cases",
     'debug_toolbar',
      "pagination"
     
)
#
## A sample logging configuration. The only tangible logging
## performed by this configuration is to send an email to
## the site admins on every HTTP 500 error.
## See http://docs.djangoproject.com/en/dev/topics/logging for
## more details on how to customize your logging configuration.
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'class': 'django.utils.log.AdminEmailHandler'
        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['mail_admins'],
            'level': 'ERROR',
            'propagate': True,
        },
    }

}


TEMPLATE_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.core.context_processors.debug',
    'django.core.context_processors.i18n',
    "django.core.context_processors.media",
    'django.contrib.messages.context_processors.messages',
    'django.core.context_processors.request',
    'django.core.context_processors.static',
    'utils.context_processor.active_url',

 )

TEMPLATE_CONTEXT_PROCESSORS = TEMPLATE_CONTEXT_PROCESSORS + (
    'utils.context_processor.latest_tweet',
)

SESSION_IDLE_TIMEOUT = 900
TWITTER_USER = "WebIPAustralia"
TWITTER_TIMEOUT = 30


TEMP_DIR = '/home/stagingw/tmp/webip/'
LOGIN_URL =  '/'

EMAIL_HOST = 'smtp.webhost4life.com' #'smtpout.asia.secureserver.net'
EMAIL_HOST_USER = "opensource@leosys.in" #al@yogasync.tv
EMAIL_HOST_PASSWORD = "opensource"
EMAIL_PORT = 25
#EMAIL_HOST = 'BL2PRD0610.mailbox.outlook.com' #'smtpout.asia.secureserver.net'
#EMAIL_HOST_USER = "alerts@webip.com.au" #al@yogasync.tv
#EMAIL_HOST_PASSWORD = 'Woodfish501'
#EMAIL_PORT = 25
EMAIL_USE_TLS = False
SERVER_EMAIL = EMAIL_HOST_USER
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER

AUTHENTICATION_BACKENDS = ('webip.webip_auth.views.EmailAuthBackend',)

#root dir for saving Application data
APPLICATION_DATA_DIR = os.path.join(MEDIA_ROOT, "webip") #'/home/stagingw/data/webip/application_data/'
APPLICATION_DOMAIN_DIR= os.path.join(MEDIA_ROOT, "webip/domain") #'/home/stagingw/data/webip/application_data/'

# location where the data is uploaded using FTP or other sources
UPLOAD_DIR = "/home/stagingw/data/webip/upload"

ACCOUNT_ACTIVATION_DAYS=30
SPREADSHEET_FORMAT_PATH='/home/stagingw/public_html/webip/Trunk/spreadsheet'
FILE_STORAGE_LOCATION='/home/stagingw/public_html/webip/Trunk/spreadsheet'

 # For Following Domain Names Years to Register Will To 2.
DOMAIN_NAME_LIST = ['.com.au','.co.uk']
DOMAIN_TYPES = [(1,'com'), (2,'net'), (3,'edu'), (4,'biz'), (5,'info'), (6,'org'), (7,'comau'), (8,'netau')]

TRADEMARK_IMAGE_PATH= os.path.join(MEDIA_ROOT, "trademark") #'/home/stagingw/data/'


#INTERNAL_IPS =('127.0.0.1','14.140.226.234')
INTERNAL_IPS =()
DEBUG_TOOLBAR_PANELS = (
    'debug_toolbar.panels.version.VersionDebugPanel',
    'debug_toolbar.panels.timer.TimerDebugPanel',
    'debug_toolbar.panels.settings_vars.SettingsVarsDebugPanel',
    'debug_toolbar.panels.headers.HeaderDebugPanel',
    'debug_toolbar.panels.request_vars.RequestVarsDebugPanel',
    'debug_toolbar.panels.template.TemplateDebugPanel',
    'debug_toolbar.panels.sql.SQLDebugPanel',
    'debug_toolbar.panels.signals.SignalDebugPanel',
    'debug_toolbar.panels.logger.LoggingPanel',
)
def custom_show_toolbar(request):
    if request.META["REMOTE_ADDR"] in INTERNAL_IPS:
        return True
    else: return False
    return True # Always show toolbar, for example purposes only.

DEBUG_TOOLBAR_CONFIG = {
    'INTERCEPT_REDIRECTS': False,
    'SHOW_TOOLBAR_CALLBACK': custom_show_toolbar,
    'EXTRA_SIGNALS': [],
    'HIDE_DJANGO_SQL': False,
    'TAG': 'div',
    'ENABLE_STACKTRACES' : True,
}

TRADEMARK_API=True
GOOGLE_API_KEY='AIzaSyDWieEw7CMTzL30fIIIOFhPAxtxDBksnNY'