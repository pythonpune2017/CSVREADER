# All the setting variables required by settings.py for development will be taken from here
import os



DEBUG = True
db_engine = 'django.db.backends.mysql'
db_name = 'webip1'
db_user = 'root'
db_pass = 'root'
db_host = 'localhost'
db_port = '3306'
DOMAIN = ''
IPADD = ''
IPDB = True
#INTERNAL_IP = '115.248.229.50'
APACHE_MEDIA_URL = 'http://localhost/media/'
UPLOAD_MEDIA_URL = 'http://localhost/image/'
#APACHE_ADMIN_MEDIA_URL = 'http://arch.com/admin-media/'
TEMPLATE_DEBUG=True
STATIC_ROOT=''
STATIC_URL=APACHE_MEDIA_URL
TEMP_DIR='/tmp'
admin_media_prefix='http://localhost/admin-media/'
LOGIN_URL = '/'
#application_data_dir = r"E:\workarea\workspace\webip\application_data"
application_data_dir = "/home/nilesh/workspace/webip/Trunk/code/webip/application_data"
application_domain_dir="/home/nilesh/workspace/webip/Trunk/code/webip/application_data"
MEDIA_URL = "http://localhost/data/"
MEDIA_ROOT = "/home/nilesh/workspace/webip_application_data/application_data"
UPLOAD_DIR = "/home/nilesh/workspace/webip_application_data/upload"

SPREADSHEET_FORMAT_PATH='/home/nilesh/workspace/webip/Trunk/spreadsheet'
FILE_STORAGE_LOCATION='/home/nilesh/workspace/webip/Trunk/spreadsheet'
