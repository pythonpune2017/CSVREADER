import os
from django.db.models import Q
from django.contrib.auth.models import User, Group
from django.http import HttpResponse
from client.managers import AlertManager
from utils.permissions_manager import WebipPermissionManager, USER_PERMISSION_MAP
from admin_app.models import UserProfileModel,StaffModel
from client.models import FREQUENCY_TYPE
from admin_app.form import get_values_for_alert_form
from admin_app.models import UserProfileModel
from client.models import ClientUser, ClientModel, SubcriptionPlan, ClientSubscription, ClientUserProfile
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action
from admin_app.form import AlertForm, get_values_for_alert_form,PremissionsForm, DomainCategoryForm
from constants import PERMISSION_DATA
from client.models import Alert,FREQUENCY_TYPE, ClientDomainCategory
from django.contrib.auth.models import Permission
import json

class ClientUsers(object):
	"""
	"""
	def __init__(self, data={}, user={}):
		self.data = data
		self.user = user

	def save(self, data={}, user={}, filename =None):
		"""
			Save client user.

		"""
		try:
		   clientuser_object = self.user["user"]
		   client = self.user["user"].clientmodel
		   # create new user for clientmodel
		   user = User.objects.create_user(username=self.data['username'], password=self.data['password'],email=self.data['email'])
		   user.is_active=eval(self.data['status'])
		   group =Group.objects.get(name="all_clients")
		   user.groups.add(group)
		   user.save()
		   # create userprofile for new user
		   userprofile = UserProfileModel(user=user,mobile=self.data['mobile'],phone=self.data['phone'])
		   userprofile.save()
		   # save user as a clientuser
		   clientuser = ClientUser(user=user,user_type=self.data['user_type'],client=client)
		   clientuser.save()
		   try:
		   		clientuserprofile = ClientUserProfile(client=clientuser, role=self.data['role'],department=self.data['department'], image=self.user['image'])
		   		clientuserprofile.save()
		   except:
				pass
		   #store domain caterogory
		   try:
		       client_domain=ClientDomainCategory(client=clientuser,category=json.dumps(self.data.getlist('domain_category')))
		       client_domain.save()
		   except:
		   	   pass
		   #alert list checkbox listfrom admin_app.form import PremissionsForm
		   alert_list = ["c1","c2","c3","c4","c5"]
		   alert_list_values={}
		   alertForm = AlertForm(self.data)
		   if alertForm.is_valid():
		       alertForm.saveAlerts(clientuser.user)
#                       log('CREATE', request.user, alertForm)

		   # set permissions for superadmin, planuser, employee
		   if self.data['user_type'] == 'superuser':
               # set all permission for superadmin
			   perm_form=PremissionsForm(PERMISSION_DATA)
		   else:
               #set selected permission for planuser and employee
			   perm_form=PremissionsForm(self.data)
		   if perm_form.is_valid():
		       perm_form.setPermissions(user)
           # set domain category
		   return True, clientuser
		except Exception:
			return False, None

	def display(self, data={}, user={}):
		"""
			display all user information
		"""
		clientuser_object = ClientUser.objects.get(user__username=self.user['username'])
		clientmodel = ClientModel.objects.get(id=clientuser_object.client.id)
		user_object = ClientUser.objects.filter(client=clientmodel,is_deleted=False).exclude(user__username=clientuser_object.user.username)
		user_object = user_object.values("id","user__email","user__username","user__first_name","user__userprofilemodel__phone","user__userprofilemodel__mobile","user__email","user__is_active","user_type","clientuserprofile__role","clientuserprofile__department", "clientuserprofile__image")
		return user_object

	def search(self, data={}, user={}):
		"""
			search the client user.
		"""
		
		user_list = []
		keyword = self.data['keyword']
		status = str(self.data['status'])
		user_t = str(self.data['user_t'])
		user_status = {'Active':True, 'Inactive':False}
		clientuser_object = ClientUser.objects.get(user__username=self.user['username'])
		clientmodel = ClientModel.objects.get(id=clientuser_object.client.id)
		user_object = ClientUser.objects.filter(client=clientmodel,is_deleted=False).exclude(user__username=clientuser_object.user.username)
		user_object = user_object.values("id","user__email","user__username","user__first_name","user__userprofilemodel__phone","user__userprofilemodel__mobile","user__email","user__is_active","user_type","clientuserprofile__role","clientuserprofile__department")
		if keyword :
			for u_list in user_object:
				if u_list['user__username'].count(keyword) > 0:
					user_list.append(u_list)
			user_object = user_list
		if status :
			user_list = []
			for st in user_object:
				if st['user__is_active'] == user_status[status]:
					user_list.append(st)
			user_object = user_list
		if user_t:
			user_list = []
			for usertype in user_object:
				if usertype['user_type'] == user_t:
					user_list.append(usertype)
		return user_list

	def getdetails(self, data={}, user={}):
		""" getting clientuser info """
		clientuser_object = ClientUser.objects.get(id=self.data['user_id'])
		return clientuser_object

	def delete(self, data={}, user={}):
		""" delete clientuser """
  		try:
			clientuser_object = ClientUser.objects.get(id=self.data['id'])
			clientuser_object.is_deleted = True
			clientuser_object.save()
			user_obj = User.objects.get(id=clientuser_object.user_id)
			user_obj.is_active = False
			user_obj.email, user_obj.username = set_delete_flag(user_obj)
			user_obj.save()

			return True, clientuser_object
  		except:
  	  		return False, None

	def update(self, data={}, user={}, filename=None):
		"""
			Update client user.
		"""
		mail_send=False
		try:
			category_list = {'category1':False, 'category2':False, 'category3':False,'category4':False}
			permission_list = {'view_domain': False,'edit_domain': False,'order_domain': False,'view_trademark': False,'edit_trademark': False,'view_contract' : False,'edit_contract' : False, 'view_cases' : False,'edit_cases':False,'monitoring_brand':False,'monitoring_domain':False,'monitoring_trademark':False }
			permission_map = {'view_domain': Permission.objects.get(codename="view_domain"),
                                      'edit_domain': Permission.objects.get(codename="change_domain"),
                                      'order_domain': Permission.objects.get(codename="add_domain") ,
                                      'view_trademark': Permission.objects.get(codename="view_trademark"),
                                      'edit_trademark': Permission.objects.get(codename="change_trademark"),
                                      'view_contract' : Permission.objects.get(codename="view_contract"),
                                      'edit_contract' : Permission.objects.get(codename="change_contract"),
                                      'view_cases' : Permission.objects.get(codename="add_casedetailmodel"),
                                      'edit_cases':Permission.objects.get(codename="change_casedetailmodel"),
									  "monitoring_brand" : Permission.objects.get(codename="monitoring_brand"),
									  "monitoring_domain" : Permission.objects.get(codename="monitoring_domain"),
									  "monitoring_trademark" : Permission.objects.get(codename="monitoring_trademark")
                                      
							  }
			clientuser_object = ClientUser.objects.get(id=self.user['user_id'])
			if self.data.has_key('user_type') and self.data['user_type']:
				if not clientuser_object.user_type =='superuser':
					clientuser_object.user_type = self.data['user_type']
			clientuser_object.save()
			user_obj = User.objects.get(id=clientuser_object.user_id)
			if self.data.has_key('firstname') and self.data['firstname']:
				user_obj.first_name=self.data['firstname']
			if self.data.has_key('lastname'):
				user_obj.last_name=self.data['lastname']
			if self.data.has_key('status') and self.data['status']:
				user_obj.is_active = eval(self.data['status'])
			if self.data.has_key('password') and self.data['password']:
				try:
					user_obj.set_password(self.data['password'])
					mail_send=True
				except Exception,e:
					pass
				
			user_obj.save()

			userprofile_object = UserProfileModel.objects.get(user=clientuser_object.user)
			userprofile_object.phone = self.data['phone']
			userprofile_object.mobile = self.data['mobile']
			userprofile_object.save()

			clientuserprofile_obj, st = ClientUserProfile.objects.get_or_create(client=clientuser_object)
			clientuserprofile_obj.role = self.data['role']
			clientuserprofile_obj.department = self.data['department']
			
			if self.user['image']:
			    clientuserprofile_obj.image = self.user['image']
			clientuserprofile_obj.save()
			if not clientuser_object.user_type =='superuser':
				try :
				    category = ClientDomainCategory.objects.get(client=clientuser_object)
				    category.category = json.dumps(self.data.getlist('domain_category'))
				    category.save()
				except:
					pass
	
				for key in permission_list.keys():
				    if key in self.data:
				        permission_list.update({key:True})
	
				for elem in permission_map.keys():
				    if self.data['user_type'] == 'subuser':
				        # if elem in changed_data: in case of subuser
				        if permission_list[elem]:
				            user_obj.user_permissions.add(permission_map[elem])
				        else:
				            user_obj.user_permissions.remove(permission_map[elem])
				    else:
				        #in case of superuser
				        user_obj.user_permissions.add(permission_map[elem])
				try:
				    Alert.objects.filter(user=user_obj).delete()
				except:
				    pass
	
				#alert list checkbox listfrom admin_app.form import PremissionsForm
				alert_list = ["c1","c2","c3","c4","c5"]
				alert_list_values={}
				alertForm = AlertForm(self.data)
				if alertForm.is_valid():
				    alertForm.saveAlerts(user_obj)

			return True, clientuser_object, mail_send
		except Exception as ex:
			return False, None, mail_send

def set_delete_flag(user_obj) :
    ''' sets a delete flag for user email
    '''
    email = user_obj.email
    name = user_obj.username
    user_count = 0
    USER = True

    while USER :
        email = email + '+' + str(user_count)
        name = name + '+' + str(user_count)
        user_count = user_count + 1
        try :
            user_obj = User.objects.get(email=email)
            tmp_email = email.split("+")
            email = tmp_email[0]
        except :
            USER = False
        try :
            user_obj = User.objects.get(username=name)
        except :
            USER = False
            #tmp_name = email.split("+")

    return email, name
