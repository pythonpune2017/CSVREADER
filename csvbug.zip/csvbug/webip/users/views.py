# Create your views here.
import os
import time
import json
import ast
import urllib2
from datetime import datetime

from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from django.contrib.auth.models import User
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
from django.core.servers.basehttp import FileWrapper

from client.models import ClientModel,ClientUser,ClientSubscription
from admin_app.form import PremissionsForm
from utils.paginator import paginate
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
#from models import Alert as alert_permission
from admin_app.form import AlertForm, get_values_for_alert_form
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from webip_auth.form import AddUserForm
from webip.users.users import ClientUsers
from constants import CLIENT_USER_TYPE, STATUS
from webip_auth.form import ChangePasswordForm
from webip_auth.form import EditProfilerForm
from domain.models import *
from utils.filewrapper_info import FixedFileWrapper
from utils.send_mail import SendMail
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action# Create your views here.
from client.models import ClientUser


def manage_users(request, *args, **kwargs):
    context = {}
    per_page, cur_page = request.GET.get('numOfResults',25), request.GET.get('page', 1)
    clientuser_object = ClientUser.objects.get(user = request.user)
    client = clientuser_object.client
    
    client_users = ClientUser.objects.filter(client=client,is_deleted=False).select_related("clientuserprofile", "user", "user__userprofilemodel")
    keyword, status, user_t = request.GET.get('keyword'), request.GET.get('status'), request.GET.get('user_type')
    
    usernamefilter = Q(user__username__icontains=keyword)
    emailfilter = Q(user__email__icontains=keyword)
    
    client_users = client_users.filter(emailfilter | usernamefilter) if keyword else client_users
    if status == "Active":
        client_users = client_users.filter(user__is_active=True)
    elif status == "Inactive": 
        client_users = client_users.filter(user__is_active=False)
    
    client_users = client_users.filter(user_type = user_t) if user_t else client_users
    user_object = client_users
    
    sort_by = request.GET.get('sort')
    order=request.GET.get('order')
    if sort_by:
        field_model_map = {"username": "user__username", "role": "clientuserprofile__role", 
                       "department": "clientuserprofile__department", 
                       "email": "user__email", "phone": "user__userprofilemodel__phone",
                        "mobile": "user__userprofilemodel__mobile", 
                        "usertype": "user_type", "status": "user__is_active"}
    
        sort_by_field = field_model_map.get(sort_by) 
        if sort_by_field:
            sort_by_field = sort_by_field if order == 'asc' else "-" + sort_by_field
            user_object = user_object.order_by(sort_by_field)
    
    
    
#    if request.GET.get('sort') =='username':
#        if order=='asc':
#            user_object = user_object.order_by("user__username")
#        else:
#            user_object = user_object.order_by("-user__username")
#
#    elif request.GET.get('sort') =='role':
#        if order=='asc':
#            user_object = user_object.order_by("clientuserprofile__role")
#        else:
#            user_object = user_object.order_by("-clientuserprofile__role")
#    elif request.GET.get('sort') =='department':
#        if order=='asc':
#            user_object = user_object.order_by("clientuserprofile__department")
#        else:
#            user_object = user_object.order_by("-clientuserprofile__department")
#    elif request.GET.get('sort') =='email':
#        if order=='asc':
#            user_object = user_object.order_by("user__email")
#        else:
#            user_object = user_object.order_by("-user__email")
#    elif request.GET.get('sort') =='phone':
#        if order=='asc':
#            user_object = user_object.order_by("user__userprofilemodel__phone")
#        else:
#            user_object = user_object.order_by("-user__userprofilemodel__phone")
#    elif request.GET.get('sort') =='mobile':
#        if order=='asc':
#            user_object = user_object.order_by("user__userprofilemodel__mobile")
#        else:
#            user_object = user_object.order_by("-user__userprofilemodel__mobile")
#
#    elif request.GET.get('sort') =='usertype':
#        if order=='asc':
#            user_object = user_object.order_by("user_type")
#        else:
#            user_object = user_object.order_by("-user_type")
#
#    elif request.GET.get('sort') =='status':
#        if order=='asc':
#            user_object = user_object.order_by("user__is_active")
#        else:
#            user_object = user_object.order_by("-user__is_active")

    context['user_type'] =  CLIENT_USER_TYPE
    context['status'] = STATUS 
    
    paginated = paginate(user_object, cur_page, int(per_page))
    
    images_dict = {}
    for record in paginated.object_list:
        images_dict[record.id] =  record.clientuserprofile.image.url if record.clientuserprofile.image else ""  
    
    user_object = paginated.object_list.values("id","user__email","user__username","user__first_name","user__userprofilemodel__phone","user__userprofilemodel__mobile","clientuserprofile__image",  "user__email","user__is_active","user_type","clientuserprofile__role","clientuserprofile__department")
    
    
    for record in user_object:
        record["user_image"] = images_dict[record["id"]]
    
    paginated.object_list = user_object
    context['keyword'] = keyword if keyword else ''
    context['t'] = user_t if user_t else ''
    context['st'] = status if status else ''
    context['users_object'] = paginated
    context['order']="asc" if order=="desc" else "desc"
    return render(request, kwargs.get("template"), context)

@login_required
def manage_users1(request, *args, **kwargs):
    """
        renders page to list of users
    """
    context ={}
    
    if request.method == "GET":
        per_page, cur_page = request.GET.get('numOfResults',25), request.GET.get('page', 1)
        keyword, status, user_t = request.GET.get('keyword'), request.GET.get('status'), request.GET.get('user_type')
        try:
            if keyword or status or user_t:
                clientuser = ClientUsers(data={'keyword':keyword,'status':status,'user_t':user_t}, user={'username':request.user.username, 'user':request.user})
                user_object = clientuser.search()
            else:
                clientuser = ClientUsers(data={}, user={'username':request.user.username, 'user':request.user})
                user_object = clientuser.display()
        except:
            redirect_to = reverse("fn_login")
            return HttpResponseRedirect(redirect_to)
        order=request.GET.get('order')

        if request.GET.get('sort') =='username':
            if order=='asc':
                user_object = user_object.order_by("user__username")
            else:
                user_object = user_object.order_by("-user__username")

        if request.GET.get('sort') =='role':
            if order=='asc':
                user_object = user_object.order_by("clientuserprofile__role")
            else:
                user_object = user_object.order_by("-clientuserprofile__role")
        if request.GET.get('sort') =='department':
            if order=='asc':
                user_object = user_object.order_by("clientuserprofile__department")
            else:
                user_object = user_object.order_by("-clientuserprofile__department")
        if request.GET.get('sort') =='email':
            if order=='asc':
                user_object = user_object.order_by("user__email")
            else:
                user_object = user_object.order_by("-user__email")
        if request.GET.get('sort') =='phone':
            if order=='asc':
                user_object = user_object.order_by("user__userprofilemodel__phone")
            else:
                user_object = user_object.order_by("-user__userprofilemodel__phone")
        if request.GET.get('sort') =='mobile':
            if order=='asc':
                user_object = user_object.order_by("user__userprofilemodel__mobile")
            else:
                user_object = user_object.order_by("-user__userprofilemodel__mobile")

        if request.GET.get('sort') =='usertype':
            if order=='asc':
                user_object = user_object.order_by("user_type")
            else:
                user_object = user_object.order_by("-user_type")

        if request.GET.get('sort') =='status':
            if order=='asc':
                user_object = user_object.order_by("user__is_active")
            else:
                user_object = user_object.order_by("-user__is_active")

        context['user_type'] =  CLIENT_USER_TYPE
        context['status'] = STATUS

        #paginate = Pagination(objects_list=user_object,set=int(per_page),page=cur_page)
        if keyword or status or user_t:
            if not user_object:
                messages.warning(request, 'No Records found !')
        try:
            count=user_object.count()
        except:
            count=len(user_object)
        if per_page=='ALL':
            per_page=count
        paginated = paginate(user_object, cur_page, int(per_page))
        context['keyword'] = keyword if keyword else ''
        context['t'] = user_t if user_t else ''
        context['st'] = status if status else ''
        context['users_object'] = paginated
        context['order']="asc" if order=="desc" else "desc"
        #context['users_object'] = user_object
    return render(request, kwargs.get("template"), context)

@login_required
def manage_myaccount(request):
    """
        renders page to change frontend User change Profile
    """
    context ={}
    client_user_id=ClientUser.objects.get(user=request.user.id)
    users_object = ClientUsers(data={'user_id':client_user_id.id}, user={'username':request.user.username, 'user':request.user})
    users_info = users_object.getdetails()
    context['user_info'] = users_info
    

    if request.method=="GET":
        print "in the get"
        edit_userprofile_form=EditProfilerForm()
        context['editprofileform']=edit_userprofile_form

    if request.method=="POST":
        request_dict = dict (zip(request.POST.keys(),request.POST.values()))
        # temp fix , added user to reqeust dict
        request_dict['user'] = request.user
        edit_userprofile_form= EditProfilerForm(request_dict, edit=True)
        if edit_userprofile_form.is_valid():
            users_object = ClientUsers(data=request.POST, user={'username':request.user.username, 'user_id':client_user_id.id, 'user':request.user, 'image':request.FILES.get('profile_image','')})
            users_info = users_object.update()
            messages.success(request, 'Profile has been updated successfully !')
            edit_userprofile_form=EditProfilerForm()
            context['status']=True
            context['message'] = "Profile is updated successfully!"

        else:
            context['message'] = "Errors while Updating Profile!"
            context['status']=False

        context['editprofileform']=edit_userprofile_form
        response = render_to_string("fn/users/my_account.html",context,RequestContext(request))
        data_dict={}
        data_dict['status']=context['message']
        data_dict['message']=context['status']
        data_dict['elements']= response
        redirect_to = reverse('client_home_page')
        return HttpResponseRedirect(redirect_to)


    return render_to_response('fn/users/my_account.html',context,RequestContext(request))

@login_required
def manage_password(request):
    """ renders page to  frontend User change password form """
    context={}
    data_dict = {}

    if request.method == "GET":
        change_password_form = ChangePasswordForm()
        context['changepasswordform'] = change_password_form

    if request.method =="POST":
        request_dict = dict (zip(request.POST.keys(),request.POST.values()))
        # temp fix , added user to reqeust dict
        request_dict['user'] = request.user
        change_password_form= ChangePasswordForm(request_dict)
        if change_password_form.is_valid():

            #currentpassword = ast.literal_eval(change_password_form.cleaned_data.get('currentpassword'))[0]
            #newpassword = ast.literal_eval(change_password_form.cleaned_data.get('newpassword'))[0]
            #confirmpassword = ast.literal_eval(change_password_form.cleaned_data.get('confirmpassword'))[0]

            currentpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('currentpassword')))
            newpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('newpassword')))
            confirmpassword = ast.literal_eval(json.dumps(change_password_form.cleaned_data.get('confirmpassword')))

            if request.user:
                #verify current password
                if request.user.check_password(currentpassword):
                    request.user.set_password(newpassword.strip())
                    request.user.save()
                    messages.success(request, 'Password resets successfully !')
                    context['status']=True
                    change_password_form = ChangePasswordForm()
                    context['message'] = "Password resets successfully !"
        else:
            context['message'] = "Errors while Reset Password!"
            context['status'] = False

        context['changepasswordform'] = change_password_form
        response = render_to_string("fn/users/change_password.html",context,RequestContext(request))
        data_dict={}
        data_dict['status']=context['status']
        data_dict['message']=context['message']
        data_dict['elements']= response
        return HttpResponse(json.dumps(data_dict),mimetype="application/json")

    return render_to_response('fn/users/change_password.html',context,RequestContext(request))

@login_required
def user_add(request, *args, **kwargs):
    """
        renders page to list of users
    """
    data_dict = {}
    context ={}
    domain_obj = Domain.objects.filter(client=request.user.clientmodel)
    cost_center=domain_obj.exclude(costcentre="").values_list('costcentre').distinct()
    cost_center = [i[0] for i in cost_center]

    if request.method == "GET":
	    userform = AddUserForm()
	    context['costcenters']=cost_center

    if request.method == "POST":
        data = {}
        user={}
        userform = AddUserForm(request.POST,edit=False)
        if userform.is_valid() :
            if request.user:
                #save all user client data
                clientuser = ClientUsers(data=request.POST, user={'username':request.user.username, 'user':request.user, 'image':request.FILES.get("image" , '')})
                status, clientuser = clientuser.save()
                if status:
                    log('CREATE', request.user, clientuser)
                    to_list = [clientuser.user.email,'priteshm@leosys.in']
                    f_obj=SendMail()
                    #to_list.append(DEFAULT_FROM_EMAIL)
                    from_email = settings.EMAIL_HOST_USER
                    # subject = request.POST.get('subject')
                    message = """<p>Hello %s,</p>
                    <p>Your Account has been created successfully.</p>
                    <p>Your Username is  %s</p>
                    <p>Your password is %s</p>
                    <p>Thanks,</p>
                    <p>Web Ip Support.</p>
                    """%(str(clientuser.user.first_name + " "+ clientuser.user.last_name), str(clientuser.user.email), str(request.POST['password']))
                    try:
                        f_obj._send_mail('Staff is created', message, from_email, to_list, [], '', content_subtype='html')
                    except:
                        pass
                    messages.success(request,"New user has been added successfully.")
                else:
					messages.error(request,"Internal error while adding New User.")

                redirect_url = reverse("manageusers")
                return HttpResponseRedirect(redirect_url)

    context['userform'] = userform
    return render(request, kwargs.get("template"), context)


@login_required
def edit_user(request, user_id, *args, **kwargs):
    """
        renders page to list of users
    """

    context ={}
    cost_center=None
    permission_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'add_casedetailmodel':False,'change_casedetailmodel':False,'monitoring_brand':False,'monitoring_domain':False,'monitoring_trademark':False}
    alert_list = {'domain_renewals':False,'dms_changes':False,'ssl_renewals':False,'trademark_renewals':False,'contract_changes':False}
    if user_id:
        users_object = ClientUsers(data={'user_id':user_id}, user={'username':request.user.username, 'user':request.user})
        users_info = users_object.getdetails()
        for perm in users_info.user.user_permissions.values():
            if perm['codename'] in permission_list:
                permission_list[perm['codename']] = True
        for alert in users_info.user.alert_set.values():
            if alert['name'] in alert_list:
                alert_list[alert['name']] = True
                alert_list.update({alert['name']:alert['frequency']})
    for key,value in alert_list.items():
        context[key] = value

    for k,v in permission_list.items():
        context[k] = v
        user_costcenter_list=None
    #logic to get a domain category
    try:
        domain_obj = Domain.objects.filter(client=request.user.clientmodel)
        cost_center=domain_obj.exclude(costcentre="").values_list('costcentre').distinct()
        cost_center = [i[0] for i in cost_center]
#        cost_center= unifyConstCenter(cost_center)
        if users_info.clientdomaincategory_set:
            user_costcenter_list=eval(users_info.clientdomaincategory_set.values()[0]['category'])

    except:
        domain_obj=None

    context['user_costcenter_list']=user_costcenter_list
    context['costcenters']=cost_center
    context['user_info'] = users_info
    context['user_id'] = user_id


    if request.method == 'GET':
        userform = AddUserForm()
        context['userform'] = userform
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        userform = AddUserForm(request.POST, edit=True)
        data_dict = {}
        user_password=''
        if request.POST['password']:
            user_password=request.POST['password']
        if userform.is_valid():
            users_object = ClientUsers(data=request.POST, user={'username':request.user.username,'password':user_password,'user_id':user_id, 'user':request.user, 'image':request.FILES.get("image", "")})
            status, clientuser_object,mail_send = users_object.update()
            if status:
            	log('EDIT', request.user, clientuser_object, data={})
            	messages.success(request, "User Details has been updated successfully.")
                if mail_send:
                    to_list = [str(clientuser_object.user.email)]
                    bcc_list=['priteshm@leosys.in']
                    f_obj=SendMail()
                    from_email = settings.EMAIL_HOST_USER
                    subject="Password Updated"
                    message = """<p>Hello %s,</p>
                    <p>Your Password has been Updated successfully.</p>
                    <p>Your Username is %s</p>
                    <p>Your password is %s</p>
                    <p>Thanks,</p>
                    <p>Web Ip Support.</p>
                    """%(str(clientuser_object.user.first_name + " "+ clientuser_object.user.last_name), str(clientuser_object.user.email), request.POST['password'])
                    try :
                         f_obj._send_mail(subject, message, from_email,to_list,[],bcc_list, '', content_subtype='html')
                    except Exception,e:
                        print "error",str(e)
                        pass
            else:
            	messages.error(request, "Internal error while updating user details.")
            redirect_url = reverse("manageusers")
            return HttpResponseRedirect(redirect_url)

    return render(request, kwargs.get("template"), context)

@login_required
def delete_user(request, user_id, *args, **kwargs):
    """
        renders page to list of users
    """
    context={}
    if request.method == 'GET':
        context['obj']={"id":user_id}
        delete_url = reverse("deleteuser", args=[user_id])
        users_object = ClientUser.objects.get(id=user_id)
        context['post_url'] = delete_url
        context["message"] = "Are you sure you want to delete '"+str(users_object.user.username)+"' user?"
        context['visible']=True
    if request.method == 'POST':
        clientuser_id = request.POST.get('record_id')
        users_object = ClientUsers(data={'id':clientuser_id}, user={'user':request.user})
        status, clientuser_object = users_object.delete()
        if status:
        	log('DELETE', request.user, clientuser_object, data = "User has been deleted successfully.")
        	messages.success(request, 'User has been deleted successfully')
        else:
        	messages.success(request, 'Internal error while deleting user.')

        return HttpResponseRedirect(request.META['HTTP_REFERER'])
    return render(request, kwargs.get("template"), context)

@login_required
def check_username(request):
    """
        Purpose: To check availability of username
    """
    message = ''
    if request.method == 'GET' :
        pass
    if request.method == 'POST' :
        req_data = request.POST['username']
        try:
            name = str(req_data).split('=')[-1].strip()
        except:
            name = ''
        message = User.objects.filter(username = name).exists()
    return HttpResponse(str(message))

@login_required
def check_email(request):
    """
        Purpose: To check availability of username
    """
    message = ''
    if request.method == 'GET' :
        pass
    if request.method == 'POST' :
        req_data = request.POST['email']
        try:
            email = str(req_data).split('=')[-1].strip()
            email = urllib2.unquote(email)
        except:
            email = ''
        status = validateEmail(email)
        if status:
            message = User.objects.filter(email = email).exists()
        else:
            message = "Invalid"
    return HttpResponse(str(message))


def validateEmail( email ):
    from django.core.validators import validate_email
    from django.core.exceptions import ValidationError
    try:
        validate_email( email )
        return True
    except ValidationError:
        return False
