from django.conf.urls.defaults import patterns, include, url


urlpatterns = patterns('users.views',
   url(r'^ManageUsers$','manage_users',{'template':'fn/users/user_management.html'},name="manageusers"),
   url(r'^AddUser/$','user_add',{'template':'fn/users/add_new_users.html'},name="adduser"),
   url(r'^EditUser/(?P<user_id>\d+)/$','edit_user',{'template':'fn/users/edit_users.html'},name="edituser"), 
   url(r'^DeleteUser/(?P<user_id>\d+)/$','delete_user',{'template':'fn/users/delete_users.html'},name="deleteuser"),
   url(r'^checkuser/$','check_username',name="checkuser"),
   url(r'^checkemail/$','check_email',name="checkemail"), 
   )
