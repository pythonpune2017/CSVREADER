import os, posixpath
from django.conf import settings


TRADEMARK_UPLOAD_DIR = os.path.abspath(os.path.join(settings.UPLOAD_DIR))
TRADEMARK_DATA_DIR = os.path.abspath(os.path.join(settings.MEDIA_ROOT, "trademark"))
TRADEMARK_IMAGE_URL = posixpath.join(settings.MEDIA_URL, "trademark/")


def create_dirs():
    """
        Creates the DIRS on first initialization
    """
    dirs_to_process = [TRADEMARK_UPLOAD_DIR,  TRADEMARK_DATA_DIR]
    
    for path in dirs_to_process:
        if not os.path.exists(path):
            os.makedirs(path)
            
create_dirs();
