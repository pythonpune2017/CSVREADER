'''
Created on Feb 13, 2012

@author: arun
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('trademark.views',
     url(r'^trademark/$','trademark_page',name="trademark_page"),    
     url(r'^trademark/import_xml/$','import_xml',name="import_xml"),   
     url(r'^trademark/import_xml/processing/$',        'show_processing',           name="show_processing"),   
     
     )
