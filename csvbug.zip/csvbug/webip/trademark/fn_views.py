# Create your views here.
import os
import tempfile
import time
import json

from datetime import datetime
from django.http import HttpResponse,HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from django.conf import settings
from django.db.models import Q
from django.shortcuts import render_to_response, render
from django.template import RequestContext
from django.template.loader import render_to_string
from django.core.servers.basehttp import FileWrapper
from django.contrib.auth.decorators import login_required

from trademark import import_export
from trademark.import_export import TrademarkImportManager
from webip_mail.manager import WebipSendMail
from trademark.models import Trademark
from utils.paginator import paginate
from forms import TrademarkForm
from domain.fn_manager import FrontEndDomainManager, FrontEndSSLManager, RegisterNewDomain
from trademark_manager import TrademarkManager
from client.models import ClientModel
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from settings import TRADEMARK_IMAGE_PATH
from object_log.models import LogItem
log = LogItem.objects.log_action
from utils.filewrapper_info import FixedFileWrapper
from utils.trademark_api import TrademarkAPIManager
from utils import getDateObject
from utils.processing_image import resize_image
@login_required
def manage_trademark(request):
	"""renders the Trademark page to manage the trademark """
	
	context={}

	expiry_in, expiry_out = request.GET.get('expiry_in'), request.GET.get('expiry_out'),
	per_page, cur_page = request.GET.get('numOfResults',25), request.GET.get('page', 1)
	keyword = request.GET.get("keyword")
	status = request.GET.get("status")
	order=request.GET.get('order')

	trademark_data=Trademark.objects.filter(client=request.client)

	 #trademark_data=trademark_data.filter(
	if keyword:
		fields_4_keyword_search = ["number", "name"]
		q_str = ""
		for element in fields_4_keyword_search:
			q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
		trademark_data = trademark_data.filter(eval(q_str))



	if expiry_in and expiry_out:
		expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
		expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
		trademark_data=trademark_data.filter(renewal_date__gt = expiry_in_date,renewal_date__lt=expiry_out_date)

	elif expiry_out:
		expiry_out_date = datetime.strptime(expiry_out, '%d-%m-%Y')
		trademark_data=trademark_data.filter(renewal_date__lt=expiry_out_date)

	elif expiry_in:
		expiry_in_date = datetime.strptime(expiry_in, '%d-%m-%Y')
		trademark_data=trademark_data.filter(renewal_date__gt = expiry_in_date)

	else:
		trademark_data=trademark_data


	if status=="0" :
		trademark_data = trademark_data.filter(status ="Registered")
	elif status=="1":
		trademark_data = trademark_data.filter(status ="Pending")
	elif status=="2":
		trademark_data = trademark_data.filter(status = "Expired")
	else:
		trademark_data = trademark_data


#logic for sorting start here
	if request.GET.get('sort') =='tmnumber':
		if order=='asc':
			trademark_data = trademark_data.order_by("number")
		else:
			trademark_data = trademark_data.order_by("-number")

	if request.GET.get('sort') =='tmname':
		if order=='asc':
			trademark_data = trademark_data.order_by("name")
		else:
			trademark_data = trademark_data.order_by("-name")

	if request.GET.get('sort') =='class':
		if order=='asc':
			trademark_data = trademark_data.order_by("t_class")
		else:
			trademark_data = trademark_data.order_by("-t_class")

	if request.GET.get('sort') =='status':
		if order=='asc':
			trademark_data = trademark_data.order_by("status")
		else:
			trademark_data = trademark_data.order_by("-status")

	if request.GET.get('sort') =='type':
		if order=='asc':
			trademark_data = trademark_data.order_by("t_type")
		else:
			trademark_data = trademark_data.order_by("-t_type")

	if request.GET.get('sort') =='renewaldate':
		if order=='asc':
			trademark_data = trademark_data.order_by("renewal_date")
		else:
			trademark_data = trademark_data.order_by("-renewal_date")

	if request.GET.get('sort') =='vendor':
		if order=='asc':
			trademark_data = trademark_data.order_by("vendor")
		else:
			trademark_data = trademark_data.order_by("-vendor")

	if request.GET.get('sort') =='renewalcost':
		if order=='asc':
			trademark_data = trademark_data.order_by("renewal_cost")
		else:
			trademark_data = trademark_data.order_by("-renewal_cost")


	count=trademark_data.count()
	if per_page=='ALL':
		per_page=count
	paginated = paginate(trademark_data, cur_page, per_page)

	trademarks_info = paginated.object_list

	trademark_data=trademarks_info.values("id","number","name","t_class","status","t_type","renewal_date","renewal_cost","business_unit","vendor","image")
#	sys_path=TRADEMARK_IMAGE_PATH
#	for i in trademark_data:
#		i['image_exists'] = os.path.exists(sys_path+i['image'])

#	for i in trademarks_info:
#		i.image_url = i.image.url if i.image else ""

	paginated.object_list = trademarks_info

	if keyword or expiry_in or expiry_out or status:
		if not trademark_data:
			messages.warning(request,"No Records found!")


	context['order']="asc" if order=="desc" else "desc"
	context["objects"] = paginated

	return render_to_response("fn/trademark/trademark_management.html",context,RequestContext(request))

@login_required
def add_trademarks(request):
	"""
	"""
	context={}
	if request.method=='GET':
		trademark_form=TrademarkForm()
		context['trademarkform'] = trademark_form
		return render_to_response("fn/trademark/add_new_trademark.html",context,RequestContext(request))

	if request.method=='POST':
		trademark_form=TrademarkForm(request.POST)
		if trademark_form.is_valid():
			client_obj=request.client
			
			try:
				tm_obj = Trademark.objects.filter(name = trademark_form.cleaned_data['name'],number = trademark_form.cleaned_data['number'],client=client_obj)
			except:
				tm_obj = None
			
			if tm_obj:
				messages.error(request, "Trademark record with same number and name already exists.")
			else:
				tm_obj = Trademark(
								name = trademark_form.cleaned_data['name'],
								number = trademark_form.cleaned_data['number'],
								t_class = trademark_form.cleaned_data['t_class'],
								status = trademark_form.cleaned_data['status'],
								image = request.FILES.get('upload_image', ''),
								t_type = trademark_form.cleaned_data['t_type'],
								renewal_date = trademark_form.cleaned_data['renewal_date'],
								renewal_cost = trademark_form.cleaned_data['renewal_cost'] if trademark_form.cleaned_data['renewal_cost'] else 0,
								business_unit = trademark_form.cleaned_data['businees_unit'],
								vendor = trademark_form.cleaned_data['vendor'],
								client = client_obj
							)
				
				tm_obj.save()
				if request.FILES.get('upload_image', ''):
					m_out_path = os.path.dirname(tm_obj.image.path)
					resize_image(tm_obj.image.path, m_out_path, height=100, width=100)
				
				messages.success(request, "Trademark Record is Created Successfully.")
				log('CREATE', request.user, tm_obj)
		else:
			messages.error(request, "Internal error while creating Trademark record.")

		redirect_url = reverse("manage_trademark")
		return HttpResponseRedirect(redirect_url)

@login_required
def edit_trademarks(request,id):
	""" edit trademark functionality """
	context={}
	context['id'] = id
	trademark_form=TrademarkForm()
	if id:
		trademark_object = TrademarkManager(data={'trademark_id':id}, clientuser={'user_id':request.user.id})
		trademark_info=trademark_object.get_trademark_details()
		context['trademarkinfo'] = trademark_info
		context['trademarkform'] = trademark_form

	if request.method=='GET':
		return render_to_response("fn/trademark/edit_trademark.html",context,RequestContext(request))

	if request.method=="POST":
		from webip.utils.context_processor import Diff_match,Date_match,Diff_filename
		trademark_form=TrademarkForm(request.POST)
		trademark_object = Trademark.objects.get(id=id)
		history = {}
		if trademark_object:
			#history.update(trademark_object.__dict__)
			history.update({'name':trademark_object.name,
						   'number':trademark_object.number,
						   't_class':trademark_object.t_class,
						   'status':trademark_object.status,
						   't_type': trademark_object.t_type,
						   'business_unit':trademark_object.business_unit,
						   'vendor':trademark_object.vendor,
						   'renewal_cost':str(trademark_object.renewal_cost),


						   })
			result_array_new, result_array_old = Diff_match(history, request.POST)
			try:
				existing_date=trademark_object.renewal_date.strftime("%d-%m-%Y")
				new_date=request.POST.get('renewal_date')
				new_date_dict, ex_date_dict = Date_match(existing_date,new_date)
			except:
				ex_date, new_date_dict ='', ''


			result_array_new.update(new_date_dict)
			result_array_old.update(ex_date_dict)
			
			try:
				oldimage=trademark_object.image.name
				newimage=request.FILES.get('trademark_image').name
				newimagedict,oldimagedict=Diff_filename(oldimage,newimage)
			except:
				oldimage,newimage,newimagedict,oldimagedict='','','',''



			result_array_new.update(newimagedict)
			result_array_old.update(oldimagedict)
			if result_array_new or result_array_old:
				data = {'old':result_array_old, 'new':result_array_new}
			else:
				data = None

		if trademark_form.is_valid():
			trademark_object.name = trademark_form.cleaned_data['name']
			trademark_object.number = trademark_form.cleaned_data['number']
			trademark_object.t_class = trademark_form.cleaned_data['t_class']
			trademark_object.status = trademark_form.cleaned_data['status']
			trademark_object.t_type = trademark_form.cleaned_data['t_type']
			trademark_object.renewal_date = trademark_form.cleaned_data['renewal_date']
			trademark_object.renewal_cost = trademark_form.cleaned_data['renewal_cost'] if trademark_form.cleaned_data['renewal_cost'] else 0
			trademark_object.business_unit = trademark_form.cleaned_data['businees_unit']
			trademark_object.vendor = trademark_form.cleaned_data['vendor']
			if request.FILES.get('trademark_image', ''):
				m_out_path = os.path.dirname(trademark_object.image.path)
				resize_image(trademark_object.image.path, m_out_path, height=100, width=100)
			trademark_object.save()
			messages.success(request, "Trademark Record is Updated Successfully!")
			log('EDIT', request.user, trademark_object, data=data)
		else:
			log('ERROR', request.user, trademark_object, data="Internal error while updating Trademark record.")
			messages.success(request, "Internal error while updating Trademark record.")
		redirect_url = reverse("manage_trademark")
		return HttpResponseRedirect(redirect_url)

#@login_required
#def search_trademark_ip(request):
#	""" search trademark ip functionality """
#
#	#trade_info = Trademark.objects.select_related('name','number','t_type','t_class','id','status','image').all()
#	trade_info =''
#	context={}
#	if request.method =='GET':
#		print "HH"
##		trade_info = trade_info.filter(name=t_name[0]).values('name','number','t_type','t_class','id','status','image')
##		response=render_to_string("fn/trademark/search_trademark_ip.html",context,RequestContext(request))
##		tdict={}
##		tdict['status'] = True
##		tdict['message'] = ""
##		tdict['elements'] = response
##		return HttpResponse(json.dumps(tdict),mimetype="application/json")
#	else:
#		temp_tname=''
#		temp_list=''
#		temp_list=request.POST.getlist('formdata')[0].split('&')
#		temp_tname = [i for i in temp_list if 'ip_keyword' in i][0]
#		temp_tname=temp_tname.split('=')[1]
#		temp_tname = str(temp_tname).replace('+',' ')
#		trade_info = Trademark.objects.select_related('name','number','t_type','t_class','id','status','image').all()
#		trade_info = trade_info.filter(name__icontains=temp_tname,client=None).values('name','number','t_type','t_class','id','status','image')[:100]
#
#		#sys path to read the image location
#		sys_path=TRADEMARK_IMAGE_PATH
#		for i in trade_info:
#			 i['image_exists'] = os.path.exists(sys_path+i['image'])
#		context['trademarkinfo'] = trade_info
#		if temp_list and not trade_info:
#			messages.warning(request,"No Records found!")
#
#		response=render_to_string("fn/trademark/search_trademark_ip.html",context,RequestContext(request))
#		tdict={}
#		tdict['status'] = True
#		tdict['message'] = ""
#		tdict['elements'] = response
#		return HttpResponse(json.dumps(tdict),mimetype="application/json")
#
#
#
#	context['trademarkinfo'] = trade_info
#	return render_to_response("fn/trademark/search_trademark_ip.html",context,RequestContext(request))

@login_required
def search_trademark_ip(request):
	""" search trademark ip functionality """

	#trade_info = Trademark.objects.select_related('name','number','t_type','t_class','id','status','image').all()
	trade_info =''
	context={}
	if request.method =='GET':
		print "HH"
#		trade_info = trade_info.filter(name=t_name[0]).values('name','number','t_type','t_class','id','status','image')
#		response=render_to_string("fn/trademark/search_trademark_ip.html",context,RequestContext(request))
#		tdict={}
#		tdict['status'] = True
#		tdict['message'] = ""
#		tdict['elements'] = response
#		return HttpResponse(json.dumps(tdict),mimetype="application/json")
	else:
		temp_tname=''
		temp_list=''
		country_val=''
		country_code=''
		temp_list=request.POST.getlist('formdata')[0].split('&')
		temp_tname = [i for i in temp_list if 'ip_keyword' in i][0]
		temp_tname=temp_tname.split('=')[1]
		temp_tname = str(temp_tname).replace('+',' ')
		country_val=[i for i in temp_list if 'tm_country' in i][0]
		country_val=country_val.split('=')[1]
		if country_val:
			if str(country_val)== '2':
				country_code='AU'
#				country_code='Australia'
			if str(country_val)== '3':
				country_code='US'
#				country_code='USA'
		else:
			country_code=None
#		trade_info = Trademark.objects.select_related('name','number','t_type','t_class','id','status','image').all()
#		trade_info = trade_info.filter(name__icontains=temp_tname,client=None).values('name','number','t_type','t_class','id','status','image')[:100]
		t_api_obj=TrademarkAPIManager()

		if country_code:
			trade_info=t_api_obj.search_tradmarkInfo(temp_tname,country_code)
		else:
			trade_info=t_api_obj.search_tradmarkInfo(temp_tname)
		
		#sys path to read the image location
#		sys_path=TRADEMARK_IMAGE_PATH
#		for i in trade_info:
#			 i['image_exists'] = os.path.exists(sys_path+i['image'])
		context['trademarkinfo'] = trade_info
		context['seach_keyword'] = temp_tname
		context['seach_country'] = country_val
		if temp_list and not trade_info:
			messages.warning(request,"No Records found!")
		response=render_to_string("fn/trademark/search_trademark_ip.html",context,RequestContext(request))
		tdict={}
		tdict['status'] = True
		tdict['message'] = ""
		tdict['elements'] = response
		return HttpResponse(json.dumps(tdict),mimetype="application/json")


	context['trademarkinfo'] = trade_info
	return render_to_response("fn/trademark/search_trademark_ip.html",context,RequestContext(request))


@login_required
def add_trademark_ip(request,number,*args):
	""" search trademark ip functionality """
	context={}
	if request.method=='GET':
		client_obj=request.client
        try:
            if Trademark.objects.filter(client=client_obj,number=number).exists():
            	messages.warning(request, "Trademark IP is already added.")
            	redirect_to = reverse('manage_trademark')
            	return HttpResponseRedirect(redirect_to)
        except Exception,e:
	    	pass
        try:
         	trademark_info = request.GET.get('trademark_object','')
         	trademark_dict=eval(trademark_info) if isinstance(trademark_info,str) or isinstance(trademark_info,unicode) else trademark_info
        	if trademark_dict['renewal_date']:
        		renewal_date_obj= datetime.strptime(trademark_dict['renewal_date'], '%Y-%m-%d')
        		trademark_object=Trademark(number=trademark_dict['number'],name=trademark_dict['name'],t_class=trademark_dict['t_class'],renewal_date=renewal_date_obj)
        	else:
        		trademark_object=Trademark(number=trademark_dict['number'],name=trademark_dict['name'],t_class=trademark_dict['t_class'])
        	trademark_object.client = client_obj
        	trademark_object.importedimage = trademark_dict["image"]
        	trademark_object.save()
        	messages.success(request, "New Trademark IP added.")
        	log('CREATE', request.user, trademark_object)
        except:
        	trademark_object=None
        	pass            
    	redirect_to = reverse('manage_trademark')
        return HttpResponseRedirect(redirect_to)

@login_required
def delete_trademark(request,tid, *args, **kwargs):
    """
        delete the trademark details
    """
    context={}
    if request.method == 'GET':
        context['obj']={"id":tid}
        delete_url = reverse("deletetrademark", args=[tid])
        trademark_object = Trademark.objects.get(id=tid)
        context['post_url'] = delete_url
        context["message"] = "Are you sure you want to delete '"+str(trademark_object.name)+"' trademark?"
        context['visible']=True
    if request.method == 'POST':
        trademark_id = request.POST.get('record_id')
        trademark_object = TrademarkManager(data={'id':tid}, clientuser={'user_id':request.user.id})
        data=trademark_object.delete()
        messages.success(request, 'Trademark has been deleted successfully.')
        msg="Trademark has been deleted successfully."
        data={'delete':msg}
        log('DELETE', request.user,request.user, data=data)
        return HttpResponseRedirect(request.META['HTTP_REFERER'])
    return render(request, kwargs.get("template"), context)


@login_required
def export_trademarks(request):
	response= None

	if request.method =="GET":
		pass
	if request.method =="POST":
		#request dictionary
		req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
		try:
			req_dict['user_id']=request.user.id
		except:
			req_dict['user_id'] = ''

		client_id = FrontEndDomainManager().get_client_id(req_dict['user_id'])
		client, brand_name, currency = FrontEndDomainManager().get_client(client_id)
		if client:
			client = client[0]

		data_dict = {}
		search = str(req_dict['search_data'])
		search_data = search.split('&')
		for item in search_data:
			item = item.split('=')
			data_dict[item[0]] = item[1]
		req_dict.update(data_dict)
		#get client information list
		trademark_obj = TrademarkManager()
		trademark_data = trademark_obj.export_trademarks(req_dict,client)
		#Data required for creating spreadsheet
		sequence_list = SpreadsheetMapping.TRADEMARK_SEQUENCE_LIST
		title_dict = SpreadsheetMapping.TRADEMARK_TITLE_LIST
		#Create XLS
		if request.POST.get("format") == "xls":
			status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, trademark_data, "trademark_")
			msg = "Trademark XLS Export Successful." if status else "Error in Trademark XLS Export."
			log('EXPORT', request.user, request.user, data={'vender_export':msg})
			if not status:
				pass
		#Create CSV
		elif request.POST.get("format") == "csv":
			location = os.path.join(settings.TEMP_DIR , "trademark.csv" )
			status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , trademark_data , location  )
			if status:
				wrapper = FixedFileWrapper(file(location))
				filename = 'attachment; filename=' + str(time.strftime("trademark_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
				response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
				response['Content-Disposition'] = filename
				msg = "Trademark CSV Export Successful." if status else "Error in Trademark CSV Export."
				log('EXPORT', request.user, request.user, data={'vender_export': msg})

	return response

@login_required
def import_trademarks(request):
	"""
		To import trademark in xls or csv format
	"""
	message = ''
	errors = []
	context = {}
	permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
	for i in request.user.user_permissions.all():
		if i.codename in permissions_list:
			permissions_list[i.codename] = True
	context['permissions'] = permissions_list
#	context['TOOLTIP_DICT'] = TOOLTIP_DICT
	if request.method == "GET":
		pass
	if request.method == "POST":
		if request.FILES.has_key('import_file'):
			file_obj = request.FILES['import_file']
			file_flag = True
		else:
			message = "Please upload file..."
			file_flag = False
		if file_flag:
			location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))
			Import_obj = TrademarkManager()
			try:
				status = Import_obj.save_uploaded_file(file_obj,str(location))
			except Exception,e:
				print "ERRROS WHILE UPLOADING A XLS/CSV FILE",str(e)
				pass

			try:
				user_id= request.user.id
			except:
				user_id = None

			client_id = FrontEndDomainManager().get_client_id(user_id)
			client, brand_name, currency = FrontEndDomainManager().get_client(client_id)
			if client:
				client = client[0]

			if not status:
				return HttpResponseRedirect(request.META['HTTP_REFERER'])

			format = Import_obj.checkForFormat(location)
			if format == "xls":
				obj = SpreadSheetDictonaryConversion()

				spreadsheet_column_list = ["TM Number","TM Name","T Type","TM Class","Status","Renewal Date","Renewal Cost(inc)","Business Unit","Vendor"]

#				spreadsheet_column_list = ['TM Number','TM Name','TM Class','T Type','Status','Renewal Date','Renewal Cost(inc)','Business Unit','Vendor']
				result_dict = obj.spreadsheet_converter(location , spreadsheet_column_list)
				status, message, errors = Import_obj.processXLSImportedTrdemark(result_dict , client)
				try:
					msg = "Trdemark XLS Import Successful for %s." %(file_obj.name) if status else errors
					log('IMPORT', request.user, request.user, data={'vender_export':msg})
				except Exception,e:
					print "ERRORS WHILE IMPORT TRADEMARK XLS LOG",str(e)
					pass

			if format == "csv":
				csvobj = CSVDictionaryConversion()
				result_dict = csvobj.csvConverter(location)
				status, message, errors = Import_obj.processCSVImportedTrademark(result_dict, client)
				try:
					msg = "Trdemark CSV Import Successful for %s." %(file_obj.name) if status else errors
					log('IMPORT', request.user, request.user, data={'import':msg})
				except Exception,e:
					print "ERRORS WHILE IMPORT TRADEMARK CSV LOG",str(e)
					pass

			Import_obj.delete_processed_file(location)
		context['message'] =  str(message)
		context['trademark_errors'] = errors
		pass
	return render_to_response('fn/trademark/import_trademark.html', context, RequestContext(request))

@login_required
def download_trademark_spreadsheet(request, format):
	"""
		Purpose: Export trademark details on the basis of filtered results
	"""
	response =None
	req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
	data_dict = {}
	#Create XLS
	if format == "xls":
		filename = "Trademark_Import_Format.xls"
	elif format == "csv":
		filename = "Trademark_Import_Format.csv"
	location = os.path.join(settings.SPREADSHEET_FORMAT_PATH , filename)
	wrapper = FixedFileWrapper(file(location))
	filename = 'attachment; filename=' + str(filename)
	response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
	response['Content-Disposition'] = filename
	return response
