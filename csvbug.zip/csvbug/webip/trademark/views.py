# Create your views here.
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
from django.core.urlresolvers import reverse
from django.contrib import messages
from django.conf import settings
import os, tempfile
from trademark import import_export
from trademark.import_export import TrademarkImportManager
from webip_mail.manager import WebipSendMail
from django.db.models import Q
                                            
#def handle_uploaded_file(f):
#    """
#        saves the uploaded file
#    """
##    destination = open('some/file/name.txt', 'wb+')
#    destination = tempfile.TemporaryFile('w+b', prefix="trademark", dir=TRADEMARK_FILE_UPLOAD_DIR)
#    for chunk in f.chunks():
#        destination.write(chunk)
#    destination.close()
#    return destination

def trademark_page(request):
    """
        renders the Trademark page to upload files
    """
    context={}
    context["active_sub_menu"] = "current"
    return render(request, "trademark.html", context)

def import_xml(request):
    """
        Imports the XML file and processes the data
    """
    redirect_to = reverse("trademark_page")
    if request.FILES.has_key("trademark_xml"):
        fileHandle = request.FILES["trademark_xml"]

        import os
        file_ext = (os.path.splitext(fileHandle.name))[1]

        if not file_ext == ".zip":
            msg = "Only zip files are permitted."
            messages.error(request, msg)
            redirect_to = reverse("trademark_page")
            return HttpResponseRedirect(redirect_to)
        else:
            fileHandle = import_export.save_uploaded_file(fileHandle)
            im_manager = TrademarkImportManager()
            im_manager.start_processing_trademarks()
            mail_context = {}
            #WebipSendMail("TIPM").mailadmins(mail_context)
            msg = "Trademarks file is uploaded Successfully."
            messages.success(request, msg)
    else:
            msg = "Please Upload File.."
            messages.error(request, msg)
            redirect_to = reverse("trademark_page")
            return HttpResponseRedirect(redirect_to)
    return HttpResponseRedirect(redirect_to)

def show_processing(request):
    return HttpResponse("Import In Process...")