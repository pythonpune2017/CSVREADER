from django.db.models import Q
from trademark.models import *
from client.models import *
from utils.paginator import paginate
from datetime import datetime
import datetime
import os
import re
from django.contrib.auth.models import User
from domain.fn_manager import FrontEndDomainManager
from utils import getDateObject

class TrademarkManager(object):
    
    def __init__(self, data={},clientuser={}):
        self.data = data
        self.clientuser=clientuser
    
    
    def get_trademark_details(self):
         """ getting trademark info """
         client_id = FrontEndDomainManager().get_client_id(self.clientuser['user_id'])
#         client_obj=FrontEndDomainManager().get_client(client_id)
         trademark_object = Trademark.objects.get(id=self.data['trademark_id'],client=client_id)
         return trademark_object
        
    def delete(self, data={}, user={}):
            """ delete trademark """
            client_id = FrontEndDomainManager().get_client_id(self.clientuser['user_id'])
            trademark_object = Trademark.objects.get(id=self.data['id'],client=client_id)
#            trademark_object.is_deleted = True
#            trademark_object.client = None
#            trademark_object.save()
            trademark_object.delete()
            return True
    
    
    def get_all_trademarks(self,data_dict={},client=None):
        """
            Purpose: To get all trademaks list
        """
        #Check for domains that are not deleted
        #trademarks = Trademark.objects.filter(is_deleted = False )
        trademarks = Trademark.objects.filter(client=client)
        #Check for Keywords
        if data_dict['keyword']:
            keyword = data_dict['keyword']
            fields_4_keyword_search = ["name","number"]
            q_str = ""
            for element in fields_4_keyword_search:
                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
                trademarks = trademarks.filter(eval(q_str))

        expiry_in_date = getDateObject(str(data_dict['expiry_in']))
        expiry_out_date = getDateObject(str(data_dict['expiry_out']))

        if expiry_in_date and expiry_out_date:
            trademarks=trademarks.filter(renewal_date__gt = expiry_in_date,renewal_date__lt=expiry_out_date)
        elif expiry_out_date:
            trademarks=trademarks.filter(renewal_date__lt=expiry_out_date)
        elif expiry_in_date:
            trademarks=trademarks.filter(renewal_date__gt = expiry_in_date)

        else:
            trademarks=trademarks
        #Order by Name
        
        if data_dict['status']=="0" :
            trademarks = trademarks.filter(status = 'Registered')
        elif data_dict['status']=="1":
            trademarks = trademarks.filter(status = 'Pending')
        elif data_dict['status']=="2":
            trademarks = trademarks.filter(status = 'Expired')
        else:
            trademarks = trademarks
       
        return trademarks
    
    
    
    def export_trademarks(self, data_dict={},client=None):
        """
            Purpose: 1. Export all the trademarks present in the database
                     2. Export all the trademarks on the basis of serach and filter results
            Input: data_dict (having search and filtered results if any)
        """
        trademark_data = self.get_all_trademarks(data_dict = data_dict,client=client)
        trademark_info = trademark_data.values("number","name", "t_class","status","t_type","renewal_date","renewal_cost","business_unit","vendor")
        trademark_list = []
        for trade in trademark_info:
            trade_dict = {}
            for k , v in trade.iteritems():
                trade_dict[k] = v
#                if k == 'renewal_date':
#                    trade_dict['renewal_date'] = datetime.datetime.strftime(v , "%d-%m-%Y")
#                else: 
                    
            trademark_list.append(trade_dict)
        return trademark_list
    
    
    def save_uploaded_file(self,file_obj, location):
        """
            Save Uploaded File at temporary location.
        """
        try:
            destination = open(location, 'wb+')
            for chunk in file_obj.chunks():
                destination.write(chunk)
            destination.close()
            return True
        except:
            return False
    def checkForFormat(self, filename):
        """
            Check whether imported file is csv or xls
        """
        try:
            file_format = filename.split(os.extsep)[-1]
        except:
            file_format = ''
        return file_format
    
    
    def processXLSImportedTrdemark(self, req_dict, client):
        """
            Process dictionary for import trademark. 
        """
        error_list = []
        for sheet, value_list in req_dict.iteritems():
            for val_dct in value_list:
                if client:
                    status, trademark, error = self.addTrademark(client,val_dct)
                    if not status:
                        error_list.append((val_dct['TM Name'], error))
                else:
                    error_list.append((val_dct['TM Name'], "Session Expired."))
                    pass
        return True, "Spreadsheet Uploaded" , error_list

        
    def processCSVImportedTrademark(self, req_dict, client):
        """
            Process dictionary forimport trademark.  
        """
        error_list = []
        for val_dct in req_dict:
            if client:
                status, trademark, error = self.addTrademark(client,val_dct)
                if not status:
                    error_list.append((val_dct['TM Name'], error))
            else:
                error_list.append((val_dct['TM Name'], "Session Expired."))
                pass
        return True, "Spreadsheet Uploaded", error_list
        
    def delete_processed_file(self, location):
        """
        """
        try:
            os.remove(location)
        except:
            pass  
    
    def addTrademark(self ,client, data):
        """
            Save Trademark Details
        """
        try:  
            renewal_date = getDateObject(data['Renewal Date'])
            renewal_date = datetime.datetime.now() if not renewal_date else renewal_date
            tm_obj ,is_created = Trademark.objects.get_or_create(name = data['TM Name'],number = data['TM Number'],client = client, defaults = {"renewal_date" :renewal_date,})
            tm_obj.t_class = data['TM Class']
            tm_obj.status = data['Status']
            tm_obj.t_type = data['T Type']
            tm_obj.business_unit = data['Business Unit']
            tm_obj.renewal_cost=data['Renewal Cost(inc)']
            tm_obj.vendor = data['Vendor']
            tm_obj.save()
            if is_created:
                return True , tm_obj,''
            else:
                return False , tm_obj , "Trademark already exists."
        except Exception , e:
            print "Exception while saving vendor", str(e)
            tm_obj= None
            return False , tm_obj , str(e)