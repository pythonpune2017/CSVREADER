'''
Created on Feb 13, 2012

@author: arun

Purpose: Script to Import Trademarks from IP Aus weekly update.
    This will be run as a scheduler or can be manully trigger as a script. python import_export
    
    Function: It assumes that the zip file is placed in dir TRADEMARK_UPLOAD_DIR.
    it will pick the latest zip file fronm this dir and start processing it. Only the latest file 
    is processed no matter how many files are present.
'''
import os, shutil, zipfile
from datetime import datetime
from lxml import etree
from trademark import TRADEMARK_UPLOAD_DIR
from trademark import TRADEMARK_DATA_DIR
from exceptions import BaseException
from trademark.models import Trademark
from django.conf import settings
import datetime
import time
    

class TrademarkImportManager:
    """
        For Managing activities related to Importing the Trademark from IP-AUS
    """
    
    def get_latest_file(self):
        """Reads the latest file from upload dir and moves it to sandbox for processing"""
        filelist = os.listdir(TRADEMARK_UPLOAD_DIR)
        filelist = [os.path.join(TRADEMARK_UPLOAD_DIR, elem)for elem in filelist]
        filelist = filter(lambda x: os.path.isfile(x), filelist)
        newest = max(filelist, key=lambda x: os.stat(x).st_ctime)
        return newest

    def unzipfile(self, filepath, unzip_dir=None):
        """
            extract contents of given zip file.
            @filepath: valid zip file
            @unzip_dir: directory in which contents should be unzipped
        """
        filename = os.path.splitext(os.path.basename(filepath))[0]
        unzip_dir = unzip_dir or settings.TEMP_DIR
        if not os.path.exists(unzip_dir):
            raise Exception("No directory named '%s'" % unzip_dir)
        unzip_dir = os.path.join(unzip_dir, filename)

        zippiedfile = zipfile.ZipFile(filepath)
        zippiedfile.extractall(unzip_dir)
        return unzip_dir
    
    def unzipxmldir(self, dir_name):
        """
            find zip file containing xml files, unzip it , return dir path
            it is assumed that dir have only one xml file
        """
        filelist = os.listdir(dir_name)
        filelist = [os.path.join(dir_name, elem)for elem in filelist]
        filelist = filter(lambda x: zipfile.is_zipfile(x), filelist)
        zippedfile = filelist[0]
        unzip_dir = os.path.dirname(zippedfile)
        unzip_dir = self.unzipfile(zippedfile, unzip_dir)
        return unzip_dir
    
    def start_processing_trademarks(self):
       
        filepath = self.get_latest_file()
        print "start processing file : %s" % filepath
        unzip_dir = self.unzipfile(filepath)
        print "Extracted file to : %s" % unzip_dir
        xml_dir = self.unzipxmldir(unzip_dir)
        print "Extracted xml zip folder to : %s" % xml_dir
        image_dir = unzip_dir
        self.process_dir(xml_dir, image_dir)
        shutil.rmtree(unzip_dir, ignore_errors=True)
        
    def _remove_namespace_(self,doc, namespace):
        """Remove namespace in the passed document in place."""
        ns = u'{%s}' % namespace
        nsl = len(ns)
        for elem in doc.getiterator():
            if elem.tag.startswith(ns):
                elem.tag = elem.tag[nsl:]
        return doc

    def process_dir(self, xml_dir=None, image_dir=None):
        """
            Start Processsing xml files 
        """
        files_2_process = os.listdir(xml_dir)
        
        files_2_process = map(lambda x: os.path.join(xml_dir, x), files_2_process)
        
        total_files = len(files_2_process)
        for index, elem in enumerate(files_2_process):
            self.process_file(elem, image_dir) 
            #just to print the percent of task completed.
            percent = index*100*1.0/total_files
            if not round(percent, 1)%1:
                print "\n%d percent completed!" % percent
        
#        map(self.process_file, files_2_process, ([image_dir] * len(files_2_process)) )
            
    def process_file(self, xml_file, image_dir):
        if not os.path.isfile(xml_file):
            raise BaseException("File not Found!")
        
        data = self.get_data_fro_xml(xml_file)
        if data.has_key("renewal_date"):
#            datetime_obj = datetime.datetime.strptime(datatime.now(), "%Y%m%d")
            datetime_obj = datetime.datetime.strptime(data["renewal_date"], "%Y%m%d")
            data["renewal_date"] = datetime_obj.date()
        
        if not data.has_key("renewal_date"):
            datetime_obj = datetime.datetime.now()
            data["renewal_date"] = datetime_obj.date()
        self.update_or_create_trademark(data, image_dir)
            
#        os.remove(xml_file)           
    
    def _process_number_2_path(self,number):
        """
        """
        number = int(number)
        path = "%d" +  os.sep + "%d" + os.sep + "%d.1.high.jpg" 
        numb = number/1000
        pre = numb/100
        suf = numb%100
        path = path % (pre, suf, number)
        return path
        
    def move_image_file(self, number, image_dir):
        file_suffix = self._process_number_2_path(number)
        raw_file = os.path.join(image_dir, file_suffix)
        new_file_location = os.path.join(TRADEMARK_DATA_DIR, file_suffix)
        if os.path.isfile(raw_file):
            file_dir = os.path.dirname(new_file_location)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            shutil.move(raw_file, new_file_location)
            
    def update_or_create_trademark(self, data, image_dir):
        """
            Creates or update a Trademark in DB
        """
        trademark, is_created = Trademark.objects.get_or_create(**data)
        file_suffix = self._process_number_2_path(trademark.number)
        self.move_image_file(data['number'], image_dir)
        trademark.image.name = file_suffix
        trademark.save()

    def get_data_fro_xml(self, filepath):
        """
        """
        tags_2_read_map = {"BASAPPN":"number", "MARDESC":"name", "IMAGEFILE":"image", 
                           "NICCLAI": "t_class","BASSTA":"status", "TYPMARI": "t_type", "BASREND": "renewal_date"}
        xml_tree = etree.parse(filepath)
        root = xml_tree.getroot()
        root = self._remove_namespace_(root , root.nsmap[root.prefix])
        data_map = {}
        for elem in root.iter():
            if elem.tag in tags_2_read_map.keys():
                data_map[tags_2_read_map[elem.tag]] = elem.text
            
        return data_map


def save_uploaded_file(f):
    """
        Saves the XMl file uploaded from UI to predefined DIR
    """
    file_path = os.path.join(TRADEMARK_UPLOAD_DIR, f.name)
    
    destination = open(file_path, "w+b")
#    destination = tempfile.TemporaryFile('w+b', prefix="trademark", dir=TRADEMARK_UPLOAD_DIR)
    for chunk in f.chunks():
        destination.write(chunk)
    destination.close()
    return destination


if __name__=="__main__":
    """
        Script to process the TradeMarks 
    """
    im_manager = TrademarkImportManager()
    im_manager.start_processing_trademarks()