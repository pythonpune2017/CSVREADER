from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('trademark.fn_views',
     url(r'^managetrademark/$','manage_trademark',name="manage_trademark"),  
     url(r'^addtrademark/$','add_trademarks', name="addtrademark"),
     url(r'^searchtrademark/$','search_trademark_ip', name="search_trademark_ip"),
     url(r'^edittrademark/(?P<id>\d+)/$','edit_trademarks',name="edittrademark"),
     url(r'^addtrademarkip/(?P<number>\d+)/$','add_trademark_ip',name="add_trademark_ip"),
     url(r'^Deletetrademark/(?P<tid>\d+)/$','delete_trademark',{'template':'fn/trademark/delete_trademark.html'},name="deletetrademark"),
     url(r'^Export/$','export_trademarks',name="fn_exporttrademark"),
     url(r'^import/$','import_trademarks',name="fn_importtrademark"),
     url(r'^download/(?P<format>\w+)/$','download_trademark_spreadsheet',name="fn_downloadtrademarkformat"),
     )

