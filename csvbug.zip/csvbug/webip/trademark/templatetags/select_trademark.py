from django.template import Library, Node, TemplateSyntaxError
from django.utils.translation import ugettext as _
register = Library()

from admin_app.models import StaffModel

def trademark_status( parser, token ):
    """
         get list of trademark status
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError(
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )

    return TrademarkStatusNode( bits[2] )

class TrademarkStatusNode( Node ):
    """
        get list of AccountManagers
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        trademark_status = [(0, "Registered"),(1, "Pending"),(2, "Expired")]
        context[self.context_name] = trademark_status
        return ''

register.tag( "trademark_status", trademark_status )


