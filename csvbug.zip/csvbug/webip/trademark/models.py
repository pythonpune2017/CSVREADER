from django.db import models
from client.models import ClientModel
from django.conf import settings
from trademark import TRADEMARK_DATA_DIR
from trademark import TRADEMARK_IMAGE_URL

from django.core.files.storage import FileSystemStorage

trademark_image_storage = FileSystemStorage(location=TRADEMARK_DATA_DIR, base_url=TRADEMARK_IMAGE_URL)
import os
from utils.processing_image import resize_image

def trademark_upload(instance, filename):
    """
        get the suffix path for file
    """
    path = ""
    number = instance.number
    if(number):
        number = int(number)
        path = "%d/%d/%d.1.high.jpg"
        numb = number/1000
        pre = numb/100
        suf = numb%100
        path = path % (pre, suf, number)
    return path



class Trademark(models.Model):
    """
        Maintains trademarks
    """
    number = models.CharField(max_length=10, db_index=True)
    name = models.TextField(max_length=2000)
    image = models.ImageField(upload_to=trademark_upload, storage=trademark_image_storage,null=True, blank=True, help_text="image file if uploaded")
    importedimage = models.URLField(max_length=1000, null=True, blank=True, help_text="Image url if image coming from global trademarks")
    #t_class = models.CharField(max_length=100,null=True, blank=True)
    t_class = models.TextField(max_length=2000)
    status = models.CharField(max_length=50,null=True, blank=True)
    t_type= models.CharField(max_length=13,null=True, blank=True)
    renewal_date = models.DateField()
    renewal_cost = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank = True)
    business_unit = models.CharField(max_length=50, null=True, blank=True)
    vendor = models.CharField(max_length=50, null=True, blank=True)
    client = models.ForeignKey(ClientModel,null=True, blank=True)


    is_active = models.BooleanField(default=False, help_text="is Trademark active")
    is_deleted = models.BooleanField(default=False, help_text="True if Trademark is deleted from the System")

    #META Fields
    created_data = models.DateTimeField(auto_now_add = True)
    modified_data = models.DateTimeField(auto_now= True)

#    def _get_image_url(self):
#        """
#            extract the image url for trademark based on the value im image or importedimage field
#            for trademarks added in the system image file is uploaded which is saved in image field,
#            and for trademark imported from global system image url is saved in importedimage.
#            
#            logo_url provides the single interface to access the image url
#        """
#        url = ""
#        try:
#            url = self.image.url
#        except:
#            url = self.importedimage
#        return url
#
#    logo_url = property(_get_image_url)
    
    def __unicode__(self):
        return str(self.id)

#    def save(self, *args, **kwargs):
#        super(Trademark, self).save( *args, **kwargs)
#        is_new = self.id is None
#        if is_new:
#            Trademark.objects.create(thing=self)
#        if self.image:
#            #resize_image(self.image.path, out_path=None, height=100, width=100)
#            m_out_path = os.path.dirname(self.image.path)
#            resize_image(self.image.path, m_out_path, height=100, width=100)
#            super(Trademark, self).save()

    class Meta:
        permissions = (("view_trademark", "Can view trademark"),)
