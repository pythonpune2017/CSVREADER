import re
from django import forms
from django.http import HttpResponse ,HttpResponseRedirect
from django.shortcuts import render_to_response
from datetime import *
from django import forms
from django.utils.safestring import mark_safe
from trademark.models import *
from django.core import validators
from django.forms.util import ErrorList
from datetime import datetime
from django.forms.fields import ChoiceField
from django.forms.fields import MultipleChoiceField
from django.forms.widgets import RadioSelect
from django.forms.widgets import CheckboxSelectMultiple
from django.forms.extras.widgets import SelectDateWidget
from django.forms.fields import SelectMultiple

class TrademarkForm(forms.Form):
    """ Form used to add trademark """

    def __init__(self, *args, **kwargs) :
        """ Constructor for TrademarkForm """
        super(TrademarkForm, self).__init__( *args, **kwargs)
#        if kwargs.has_key("edit"):
#            edit = kwargs.pop("edit")
#        else:
#            edit = False
#        self.data = kwargs.get("data", {})
#        self.edit = edit
#
#        #Get all clients present in the database
#        clients_list = ClientModel.objects.all().values("id","name","clientuser__user__id","clientuser__user__first_name","clientuser__user__last_name")
#        clients = [(int(i['id']),str(i['clientuser__user__first_name']).title()+" "+str(i['clientuser__user__last_name']).title()) for i in clients_list ]
#        clients.insert(0, ('select','Select'))
#        self.base_fields['client'].choices = clients
#
#        if self.edit:
#            self.base_fields['name'].widget.attrs['readonly'] = True
#        super(DomainForm, self).__init__( *args, **kwargs)


    TM_STATUS = (
    ('none','please select'),
    ('Registered', 'Registered'),
    ('Pending', 'Pending'),
    ('Expired', 'Expired'),
    
    
    
    )
    TM_TYPE = (
            ('none','please select'),
            ('Australia', 'Australia'),
            ('United States', 'United States'),

    )

    name = forms.CharField(label="TM name:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'Trademark Name is required'})
    number = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'login_input'}),required=True,
                                label="TM Number",validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'trademark number must be numeric'}
                                )

    upload_image = forms.CharField(label="TM Image", required = False,
                                widget=forms.FileInput(attrs={'class':'file_inputsmall2'}))

    t_class = forms.CharField(label="Class:", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'required': 'TM Class is required'})
    status = forms.ChoiceField(choices=TM_STATUS,
                             widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL webip_select_pop'}),
                                label="STATUS",required = False)

    
    t_type = forms.ChoiceField(choices=TM_TYPE,required = False,widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL webip_select_pop'}),error_messages = {'required': 'TM Type is required'})

#    t_type = forms.ChoiceField(choices=TM_TYPE,required = False,widget=forms.SelectMultiple(attrs={'id':'speedD', 'class':'add_use_drop_SSL webip_select_pop'}),
#                                error_messages = {'required': 'Country is required'})
    
#    t_type = forms.ModelMultipleChoiceField(queryset=MyModel.objects.all(), widget=FilteredSelectMultiple("verbose name", is_stacked=False))

#    t_type = forms.MultipleChoiceField(choices=TM_TYPE,required = False,widget=CheckboxSelectMultiple(),
#                                error_messages = {'required': 'Country is required'})

    renewal_date = forms.DateField(label="Renewal date", required = False,
                                widget=forms.DateInput(attrs={'class':"text_date webipdatepicker"}),input_formats=["%d-%m-%Y"],
                                error_messages = {'required': 'Renewal Date is required'})
#
#    renewal_cost = forms.CharField(label="Annual Cost", max_length=50, required = False,
#                                widget=forms.TextInput(attrs={'class':'file_inputsmall'}))

    renewal_cost = forms.DecimalField(label="Annual Cost:",required = False,max_digits=9, decimal_places=2,
                                widget=forms.TextInput(attrs={'class':'file_inputsmall'}))

    businees_unit = forms.CharField(max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))

    vendor = forms.CharField(max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))


    def clean(self):
        """ clean form """
        t_class = str(self.cleaned_data.get('t_class'))
        #if len(t_class) > 2:
        #    self._errors['t_class'] = "Length should be 2 digit."
        return self.cleaned_data
