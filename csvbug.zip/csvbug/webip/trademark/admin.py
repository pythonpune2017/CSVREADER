'''
Created on Feb 13, 2012

@author: arun
'''
from django.contrib import admin 
from trademark.models import Trademark

class TrademarkAdmin(admin.ModelAdmin):
    list_display = ( 'name','number','status')
    search_fields = ( "number" ,)
    
    
admin.site.register(Trademark, TrademarkAdmin)

