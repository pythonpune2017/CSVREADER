# All the setting variables required by settings.py for production will be taken from here
# NOTE : copy these varaibles in a file called settings_development.py and set your local settings.
import os


DEBUG = True
db_engine = 'django.db.backends.mysql'
db_name = 'webip'
db_user = 'webip'
db_pass = 'webip123'
db_host = ''
db_port = ''
DOMAIN = ''
IPADD = ''
IPDB = False
INTERNAL_IP = ''
APACHE_MEDIA_URL = '/media/'
UPLOAD_MEDIA_URL = '/image/'
APACHE_ADMIN_MEDIA_URL = '/admin-media/'
TEMPLATE_DEBUG=False
STATIC_URL=APACHE_MEDIA_URL
STATIC_ROOT=''
admin_media_prefix=APACHE_ADMIN_MEDIA_URL
TEMP_DIR='/tmp'
LOGIN_URL = '/'


application_data_dir = r"/home/arun/data/webip/application_data"
application_domain_dir= r"/home/arun/data/webip/application_data"

MEDIA_URL = "/data/"
MEDIA_ROOT = r"/home/arun/data/webip/application_data"
UPLOAD_DIR = "/home/arun/data/webip/upload"
