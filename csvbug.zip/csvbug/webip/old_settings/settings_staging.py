# All the setting variables required by settings.py for production will be taken from here
# NOTE : copy these varaibles in a file called settings_development.py and set your local settings.
import os

DEBUG = False
db_engine = 'django.db.backends.mysql'
db_name = 'stagingw_webip'
db_user = 'stagingw_webip'
db_pass = '!A@S#D$F%G'
db_host = ''
db_port = ''
DOMAIN = ''
IPADD = ''
IPDB = False
INTERNAL_IP = ''
APACHE_MEDIA_URL = '/media/'
UPLOAD_MEDIA_URL = '/image/'
APACHE_ADMIN_MEDIA_URL = '/admin-media/'
TEMPLATE_DEBUG=False
STATIC_URL=APACHE_MEDIA_URL
STATIC_ROOT=''
admin_media_prefix=APACHE_ADMIN_MEDIA_URL
TEMP_DIR='/home/stagingw/tmp/webip/'
LOGIN_URL = '/'

SPREADSHEET_FORMAT_PATH='/home/stagingw/public_html/webip/Trunk/spreadsheet'

application_data_dir = '/home/stagingw/data/webip/application_data/'
application_domain_dir= '/home/stagingw/data/webip/application_data/'

MEDIA_URL = "/data/"
MEDIA_ROOT = "/home/stagingw/data/"
UPLOAD_DIR = "/home/stagingw/data/webip/upload"
FILE_STORAGE_LOCATION='/home/stagingw/public_html/webip/Trunk/spreadsheet'



