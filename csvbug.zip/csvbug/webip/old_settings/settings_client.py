# All the setting variables required by settings.py for production will be taken from here
# NOTE : copy these varaibles in a file called settings_development.py and set your local settings.
import os

DEBUG = True
db_engine = 'django.db.backends.mysql'
db_name = 'clientip_webip'
db_user = 'clientip_webip'
db_pass = 'leo_123'
db_host = ''
db_port = ''
DOMAIN = ''
IPADD = ''
IPDB = False
INTERNAL_IP = ''
APACHE_MEDIA_URL = '/media/'
UPLOAD_MEDIA_URL = '/image/'
APACHE_ADMIN_MEDIA_URL = '/admin-media/'
TEMPLATE_DEBUG=False
STATIC_URL=APACHE_MEDIA_URL
STATIC_ROOT=''
admin_media_prefix=APACHE_ADMIN_MEDIA_URL
TEMP_DIR='/home/clientip/tmp/webip/'
LOGIN_URL = '/'

SPREADSHEET_FORMAT_PATH='/home/clientip/public_html/Trunk/spreadsheet'

application_data_dir = '/home/clientip/tmp/webip/'
application_domain_dir= '/home/clientip/tmp/webip/'

MEDIA_URL = "/data/"
MEDIA_ROOT = "/home/clientip/data/"
UPLOAD_DIR = "/home/clientip/tmp/webip/upload"
FILE_STORAGE_LOCATION='/home/clientip/public_html/Trunk/spreadsheet'



