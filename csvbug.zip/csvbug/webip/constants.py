STATUS = ['Active','Inactive']
USER_TYPE = ['superuser','subuser']
CLIENT_USER_TYPE=['subuser']

PERMISSION_DATA = { 'edit_domain': True, 'view_contract': True, 'edit_contract': True,'edit_cases': True,
'edit_trademark': True, 'view_cases': True, 'view_domain': True,'order_domain': True, 'view_trademark': True}

PERMISSION_LIST = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_cases':False,'edit_cases':False}

DOMAIN_FOR_COUNTRY = {'.au':'Australia', '.in':'India', '.com':'Global', '.org':'Global', '.net':'Global', '.mobi':'Global', '.edu':'Global', '.info':'Global', '.biz':'Global'}

