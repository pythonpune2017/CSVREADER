from django.conf.urls.defaults import patterns, include, url
from django.conf.urls.defaults import *
from django.contrib import admin
admin.autodiscover()
#from employee.view import*

urlpatterns = patterns('admin_app.views',
     
     url(r'^staff/importstaff/$','import_staff',name="importstaff"),
     url(r'^staff/importstaff/save/$','import_staff_save',name="save_importstaff"),
 
     url(r'^staff/exportstaff/$','export_staff_details',name="exportstaff"),
     
     url(r'^staff/$','manage_staff',name="managestaff"),
     url(r'^staff/download/(?P<format>\w+)/$','download_staff_spreadsheet',name="downloadformat"),
     url(r'^staff/export_xls/$','export_xls',name="exportxls"),
     url(r'^staff/export_csv/$','export_xls',name="exportcsv"),     
     url(r'^staff/add/$','addstaff',name='addstaff'),
     url(r'^staff/edit/(?P<emp_id>\d+)/$','editstaff',name="editstaff"),
     url(r'^staff/delete/(?P<emp_id>\d+)/$','deletestaff',name="deletestaff"),
     
     url(r'^assignclient/$','assign_client',name='assignclient'),
     url(r'^assignclient/addaccountmanager/$','add_account_manager',name='addaccountmanager'),
     url(r'^assignclient/editacc_manager/(?P<emp_id>\d+)/$','add_account_manager',{'change':True},name='editaccountmanager'),
     url(r'^assignclient/deleterecord/(?P<emp_id>\d+)/(?P<client_id>\d+)/$','del_client_manager_record',name='del_manager_record'),
#     url(r"clients/manage", "manage_clients", name="render_manage_clients"),
#     url(r"clients/assign-manager", "client_account_manager", name="render_client_account_manager"),
    
     
     
     #url(r'^gen_password/$','generate_radompassword',name='gen_passwd'),
     url(r'^generate_password/$','generate_password',name='generate_passwd'),
     
     url(r'^get/manager/data/(?P<emp_id>\d+)/$','get_managers_clients',name='get_managers_clients'),

     )





