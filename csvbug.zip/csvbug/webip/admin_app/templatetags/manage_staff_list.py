'''
Created on Jan 14, 2012

@author: pritesh

Purpose: Template Tags for Various list needed for present select html widget in Forms
'''
from django.template import Library, Node, TemplateSyntaxError
from django.utils.translation import ugettext as _
register = Library()

from admin_app.models import StaffModel
from constants import DOMAIN_FOR_COUNTRY
import os

def get_staff_type( parser, token ):
    """
         get list of Staff Type
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError( 
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )

    return StaffTypeNode( bits[2] )

class StaffTypeNode( Node ):
    """
        get list of StaffType
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        staff_type = [(0,"Admin"),(1,"AccountManager")]
        context[self.context_name] = staff_type 
        return ''

register.tag( "staff_type", get_staff_type )


def get_user_type( parser, token ):
    """
         get list of user Type in backend app
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError( 
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )

    return UserTypeNode( bits[2] )

class UserTypeNode( Node ):
    """
        get list of User Type
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        user_type = [(0,"Admin"),(1,"AccountManager"),(2,"client"),(3,"Superuser")]
        context[self.context_name] = user_type 
        return ''

register.tag( "user_type", get_user_type )



def get_Activity_list( parser, token ):
    """
         get list of Activity of each database record
             """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError( 
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )

    return ActivityNode( bits[2] )

class ActivityNode( Node ):
    """
        get list of Records Activity
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        activity_type = [(0,"Create"),(1,"Edit"),(2,"Delete")]
        context[self.context_name] = activity_type 
        return ''

register.tag( "activity_type", get_Activity_list )




def staff_status( parser, token ):
    """
         get list of staff status
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError( 
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )

    return StaffStatusNode( bits[2] )

class StaffStatusNode( Node ):
    """
        get list of AccountManagers
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        staff_status = [(1, "Active"), (0, "Inactive")]
        context[self.context_name] = staff_status
        return ''

register.tag( "staff_status", staff_status )



def staff_Accountmanagers( parser, token ):
    """
         get list of staff who is account managers
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError( 
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError( 
            _( 'tag requires exactly 2 arguments' ) )

    return StaffAccountManagerNode( bits[2] )

class StaffAccountManagerNode( Node ):
    """
        get list of staff who is AccountManagers
    """
  
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self,context):
        staff_accountmanager=StaffModel.objects.filter(emp_type='Account Manager').order_by('user__first_name').values('id','user__first_name')
        context[self.context_name] = staff_accountmanager
        return ''

register.tag("staff_accountmanager", staff_Accountmanagers )


@register.filter(name="truncchar")
def truncchar(value, arg):
    if len(value) < arg:
        return value
    else:               
        return value[:arg] + '..'

@register.filter(name="splitext")
def splitext(value):
    v = os.path.splitext(value)
    return v[1]

@register.filter(name="country_list")
def country_list(value):
    v = os.path.splitext(value)
    key = v[1].lower()
    try:
        key = DOMAIN_FOR_COUNTRY[key]
    except:
        key = ''
    return key

@register.filter(name='image_process')
def image_process(value):
#    value_name = value.split('/')
    file_name = "m_" + os.path.basename(value)
    return os.path.join(os.path.dirname(value), file_name)


@register.filter(name='image_process_filter')
def image_process_filter(value):
    value_name = value.split('/')
    return os.sep.join([value_name[0],value_name[1],'m_' + str(value_name[2])])


@register.filter(name='sized_image')
def sized_image(value, arg="m"):
    """
        add a prefix to image url name 
        arg: l/m/s (large/medium/small)
        ex: {{ image_url|sized_image:"m" }}
    """
    prefixs = {"l": "l", "m": "m", "s": "s"}
    file_name = "%s_%s" %(prefixs.get(arg, "") , os.path.basename(value))
    url = os.path.join(os.path.dirname(value), file_name)
    return url
    