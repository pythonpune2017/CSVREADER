'''
Created on Jan 12, 2012

@author: arun

Purpose: Template Tags for Various list needed for present select html widget in Forms
'''
from django.template import Library, Node, TemplateSyntaxError
from django.utils.translation import ugettext as _
register = Library()

from admin_app.models import StaffModel

def get_account_managers( parser, token ):
    """
         get list of Account Managers
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError(
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )

    return AccountManagersNode( bits[2] )

class AccountManagersNode( Node ):
    """
        get list of AccountManagers
    """

    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        account_mangers = StaffModel.objects.filter(emp_type ='Account Manager', user__is_active=True).order_by( "user__first_name").values("id", "user__first_name")
        context[self.context_name] = account_mangers
        return ''

register.tag( "account_managers", get_account_managers )




def client_status( parser, token ):
    """
         get list of countries
    """
    # take steps to ensure template var was formatted properly
    try:
        bits = token.split_contents()
    except ValueError:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )
    if bits[1] != 'as':
        raise TemplateSyntaxError(
            _( "second argument to tag must be 'as'" ) )
    if len( bits ) != 3:
        raise TemplateSyntaxError(
            _( 'tag requires exactly 2 arguments' ) )

    return ClientStatusNode( bits[2] )

class ClientStatusNode( Node ):
    """
        get list of AccountManagers
    """
    def __init__( self,  context_name ):
        self.context_name = context_name
    def render( self, context ):
        client_status = [(1, "Active"), (0, "Inactive")]
        context[self.context_name] = client_status
        return ''

register.tag( "client_status", client_status )


