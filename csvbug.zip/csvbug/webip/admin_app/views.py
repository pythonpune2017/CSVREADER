from django.views.decorators.csrf import  csrf_exempt
import os
import time
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import User
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from admin_app.form import StaffForm
from admin_app.models import UserProfileModel,StaffModel
from utils.paginator import paginate
from django.conf import settings
from admin_manager import StaffManager
from django.core.urlresolvers import reverse
from client.models import ClientModel
from django.template.loader import render_to_string
from django.contrib import messages
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from client.query_manager import ClientManager
from django.core.servers.basehttp import FileWrapper
from admin_app.form import AssignClientForm
from utils import create_spreadsheet as CreateSpreadsheet
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from object_log.models import LogItem
from utils.send_mail import SendMail
log = LogItem.objects.log_action
from django.db.models import Q
from utils.filewrapper_info import FixedFileWrapper
from django.utils import simplejson
from client.managers import AlertManager
@login_required
def manage_staff(request):
    #import pdb
    #pdb.set_trace()
    per_page = request.GET.get('numOfResults',25)
    client, stafftype, status,  = request.GET.get('client'), request.GET.get('staff_type'),request.GET.get('status')
    cur_page = int(request.GET.get('page', 1))

    keyword = request.GET.get("keyword")

    order=request.GET.get('order')
    staff_data=StaffModel.objects.all()
   
    if keyword:
        fields_4_keyword_search = ["user__username", "user__first_name", "user__email"]
        q_str = ""
        for element in fields_4_keyword_search:
            q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)

        staff_data = staff_data.filter(eval(q_str))

    staff_data = staff_data.exclude(user__id=request.user.id)
    if status=="1":
        staff_data = staff_data.filter(is_status = True)
    elif status=="0":
        staff_data = staff_data.filter(is_status = False)

    if stafftype=='0':
        staff_data=staff_data.filter(emp_type='Admin')
    elif stafftype=='1':
        staff_data=staff_data.filter(emp_type='Account Manager')

    if client:
        staff_data = staff_data.filter(clientmodel__id = client)
    else:
        staff_data

    if request.GET.get('sort') =='username':
        if order=='asc':
            staff_data = staff_data.order_by("user__username")
        else:
            staff_data = staff_data.order_by("-user__username")

    if request.GET.get('sort')=='name':
        if order=='asc':
            staff_data = staff_data.order_by("user__first_name")
        else:
            staff_data = staff_data.order_by("-user__first_name")

    if request.GET.get('sort')=='phone':
        if order=='asc':
            staff_data = staff_data.order_by("user__userprofilemodel__phone")
        else:
            staff_data = staff_data.order_by("-user__userprofilemodel__phone")

    if request.GET.get('sort')=='email':
        if order=='asc':
            staff_data = staff_data.order_by("user__email")
        else:
            staff_data = staff_data.order_by("-user__email")

    if request.GET.get('sort')=='stafftype':
        if order=='asc':
            staff_data = staff_data.order_by("emp_type")
        else:
            staff_data = staff_data.order_by("-emp_type")

    if request.GET.get('sort')=='status':
        if order=='asc':
            staff_data = staff_data.order_by("user__is_active")
        else:
            staff_data = staff_data.order_by("-user__is_active")


    count=staff_data.count()
    if per_page=='ALL':
       per_page=count
    paginated = paginate(staff_data,cur_page,int(per_page))

    staffs = paginated.object_list

   
    staff_client_info = []
    for elem in staffs.iterator():
        staff_client_info.append({"total_clients": elem.clientmodel_set.all().count()})


    staffs_info = staffs.values("id","user__username","user__first_name","user__userprofilemodel__phone","user__email","emp_type","user__is_active")

    for index, staff in enumerate(staffs_info):
        staff.update(staff_client_info[index])

    paginated.object_list = staffs_info

    if keyword or client or stafftype or status:
        if not staff_data:
            messages.warning(request,"No Records found!")
    
    context ={}
    context['countall']=count
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context["objects"] = paginated
    context["client"] = client
    context["stafftype"] = stafftype
    context["status"] = status
    context["keyword"] = keyword
    context["is_selected"] = "curent"
    context['order']="asc" if order=="desc" else "desc"
    return render_to_response('admin_app/manage_staff.html',context,RequestContext(request))


@login_required
def addstaff(request):
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    # status=False
    if request.method =='POST':
        try:
            staff_form = StaffForm(request.POST)
            if staff_form.is_valid():

                '''create a user first for assign to  staff '''
                password = staff_form.cleaned_data['password']

                try:
                    user_obj = User.objects.filter(username = staff_form.cleaned_data['username'])[0]
                except:
                    user_obj = None
                if not user_obj:
                    user_obj = User.objects.create_user(username = staff_form.cleaned_data['username'],email = staff_form.cleaned_data['email'] ,password = password)
                    user_obj.first_name = staff_form.cleaned_data['name']
                    user_obj.is_active=eval(staff_form.cleaned_data['status'])
                    user_obj.save()
                    log('CREATE', request.user, user_obj,data={'name':user_obj.first_name})

                '''create a user profile based on the user'''

                try:
                    user_profile_obj = UserProfileModel.objects.filter(user = user_obj)
                except:
                        user_profile_obj = None

                if not user_profile_obj:
                    user_profile_obj = UserProfileModel(user=user_obj,mobile=staff_form.cleaned_data['mobile'],role=staff_form.cleaned_data['role'],department=staff_form.cleaned_data['department'],phone=staff_form.cleaned_data['phone'])
                    user_profile_obj.save()
                    log('CREATE', request.user, user_profile_obj,data={'name':user_profile_obj.user.first_name})

                '''create a Staff  assign to  staff'''

                try:

                    staff_obj= StaffModel.objects.filter(user=user_obj)

                except:

                    staff_obj =None

                if not staff_obj:

                    staff_obj=StaffModel(user=user_obj,emp_type=staff_form.cleaned_data['staff_type'],is_status=eval(staff_form.cleaned_data['status']))
                    staff_obj.save()
                    log('CREATE', request.user, staff_obj)

                # status = True
                staff_form= StaffForm()
                context['message'] = "Staff is Created!"
                # message="Staff is Created Successfully!"
                context['status'] = True
                to_list = [user_obj.email]
                bcc_list=['priteshm@leosys.in']
                f_obj=SendMail()
                #to_list.append(DEFAULT_FROM_EMAIL)
                from_email = settings.EMAIL_HOST_USER
                # subject = request.POST.get('subject')

                message = """<p>Hello %s,</p>
                <p>Your Account has been created successfully.</p>
                <p>Your Username is %s</p>
                <p>Your password is %s</p>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """%(str(user_obj.first_name + " "+ user_obj.last_name), str(user_obj.email), str(password))
                try:
                    f_obj._send_mail('Staff is created', message,from_email,to_list,[],bcc_list,'',content_subtype='html')
                    
                except Exception, e:
                    #print "ERROR WHILE send email for staff ",str(e)
                    pass
                messages.add_message(request, messages.SUCCESS, "Staff Member Successfully Added")


            else:
                    context['message'] = "Errors while creating Staff!"
                    context['status'] = False

        except:
                raise
        context['StaffForm'] = staff_form
#       return render(request,'admin_app/add_staff.html',context)
        response=render_to_string('admin_app/add_staff.html',context,RequestContext(request))
        dict={}
        dict['status']=context['status']
        dict['message']=context['message']
        dict['elements']= response
        return HttpResponse(simplejson.dumps(dict),mimetype="application/json")


    if request.method =='GET':
        staff_form= StaffForm()
        context['StaffForm'] = staff_form
        return render_to_response('admin_app/add_staff.html',context,RequestContext(request))


@login_required
def export_csv(request):
        if request.method=='GET':
            return HttpResponse("GET REQUEST")

        elif request.method=='POST':
            return HttpResponse("post request")

def export_xls(request):
    return HttpResponse("")

@login_required
def deletestaff(request,emp_id):
    """
        deletes a staff record
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context['obj']={"id":emp_id}
    delete_url = reverse("deletestaff", args=[emp_id])
    staff_obj = StaffModel.objects.get(id = emp_id)
    context['post_url'] = delete_url
    context["message"] = "Are you sure you want to delete '"+str(staff_obj.user.username)+"' staff?"
    context['visible']=True
    if request.method== 'POST':
        # clientid = request.POST.get("record_id")
#        staff_delete_form=StaffForm(request.POST)
        try:
#            user_profile_obj=UserProfileModel.objects.get(user=staff_obj.user.id)
#            user_profile_obj.delete()
#            staff_obj.delete()
            staff_obj.delete()
            log('DELETE', request.user, staff_obj)
            context['status'] = "Staff is deleted"
            context['visible']=False
            messages.add_message(request, messages.SUCCESS, "Staff record is deleted!")
        except:
            raise
            context["message"] = "No record exists!"

        context["message"] = "Staff record is deleted!"
        context['visible']=False

        return HttpResponseRedirect(request.META["HTTP_REFERER"])

    return render_to_response('admin_app/delete_staff.html',context,RequestContext(request))


@login_required
def editstaff(request,emp_id):
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    if request.method == 'GET':
        staff_obj=StaffModel.objects.get(pk = emp_id)
        try :
            user_phone = staff_obj.user.userprofilemodel.phone
            user_mobile = staff_obj.user.userprofilemodel.mobile
            user_role = staff_obj.user.userprofilemodel.role
            user_department = staff_obj.user.userprofilemodel.department
        except :
            user_phone = ''
            user_mobile = ''
            user_role = ''
            user_department = ''

        form_data={'id':staff_obj.id,'username':staff_obj.user.username,'name':staff_obj.user.first_name,'phone':user_phone,'mobile':user_mobile,'role':user_role,'department':user_department,'email':staff_obj.user.email,'staff_type':staff_obj.emp_type,'status':staff_obj.user.is_active}

        client_count=staff_obj.clientmodel_set.all().count()
        form_data.update({'total_clients':client_count})

        form = StaffForm(form_data)
        form.total_clients=client_count
        context['obj']=form
        return render_to_response('admin_app/BE_Editstaff.html',context,RequestContext(request))

    if request.method == 'POST':
        email_send=False
        from webip.utils.context_processor import Diff_match
        staff_obj1 = StaffModel.objects.get(pk=request.POST.get('id'))
        history = {}
        history.update({'name':staff_obj1.user.first_name,'username':staff_obj1.user.username, 'email':staff_obj1.user.email,'phone':staff_obj1.user.userprofilemodel.phone, 'staff_type':staff_obj1.emp_type, 'status':str(staff_obj1.user.is_active)})
        result_array_new, result_array_old = Diff_match(history, request.POST)
        if result_array_new or result_array_old:
            data = {'old':result_array_old, 'new':result_array_new}
        else:
            data = None


        # aa=request.POST.getlist("")
        staff_edit_form=StaffForm(request.POST)
        if staff_edit_form.is_valid():

            '''update username '''

            staff_obj=StaffModel.objects.get(id = emp_id)
            if staff_obj:
                staff_obj.emp_type=staff_edit_form.cleaned_data['staff_type']
                staff_obj.is_status = eval(staff_edit_form.cleaned_data['status'])
                staff_obj.save()
                log('EDIT', request.user, staff_obj, data=data)
            try:
                user = User.objects.get(id=staff_obj.user.id)
                user.username=staff_edit_form.cleaned_data['username']
                user.first_name=staff_edit_form.cleaned_data['name']
                if len(request.POST['password']):
                    user.set_password(request.POST['password'])
                    email_send=True
                user.is_active = eval(staff_edit_form.cleaned_data['status'])
                user.email=staff_edit_form.cleaned_data['email']
                user.save()

            except:
                raise

            user_profile_obj=UserProfileModel.objects.get(user=staff_obj.user.id)
            if user_profile_obj:
                    user_profile_obj.phone=staff_edit_form.cleaned_data['phone']
                    user_profile_obj.mobile=staff_edit_form.cleaned_data['mobile']
                    user_profile_obj.role=staff_edit_form.cleaned_data['role']
                    user_profile_obj.department=staff_edit_form.cleaned_data['department']
                    user_profile_obj.save()
                    log('EDIT', request.user, user_profile_obj, data=data)

#
            context['message'] = "Staff is Updated!"
            context['status'] = True
            messages.add_message(request, messages.SUCCESS, "Staff is Updated Successfully!")
            #code for send email if password is change start
            if email_send:
                to_list = [staff_edit_form.cleaned_data['email']]
                bcc_list=['priteshm@leosys.in']
                f_obj=SendMail()
                #to_list.append(DEFAULT_FROM_EMAIL)
                from_email = settings.EMAIL_HOST_USER
                # subject = request.POST.get('subject')
                message = """<p>Hello %s,</p>
                <p>Your Password has been Updated successfully.</p>
                <p>Your Username is %s</p>
                <p>Your password is %s</p>
                <p>Thanks,</p>
                <p>Web Ip Support.</p>
                """%(str(user.first_name +" "+ user.last_name), staff_edit_form.cleaned_data['email'], staff_edit_form.cleaned_data['password'])
                try :
                     f_obj._send_mail('Password Changed.', message, from_email, to_list, [],bcc_list,'', content_subtype='html')
                except Exception, e:
                    print "ERROR WHILE send email for edit staff ",str(e)
                    pass
        else:
            context['message'] = "Error while updating staff!"
            context['status'] = False


        context['obj']=staff_edit_form
#        return render_to_response('admin_app/BE_Editstaff.html',context,RequestContext(request))
        response=render_to_string('admin_app/BE_Editstaff.html',context,RequestContext(request))
        dict={}
        dict['status']=context['status']
        dict['message']=context['message']
        dict['elements']= response
        return HttpResponse(simplejson.dumps(dict),mimetype="application/json")

@login_required
def generate_radompassword(request):
    if request.method=='POST':
        passd=User.objects.make_random_password(10)
    return render_to_response('admin_app/addemp.html',{},RequestContext(request))



def client_account_manager(request):
    """
        Renders a Page for Assigning a Client to Account Manager
    """
    return render (request, "admin_app/BE_AssignToClient.html", {})

def generate_password(request):
    """ generate random password"""
    passd=User.objects.make_random_password(10)

    return HttpResponse(passd)

def import_staff(request):
    """
    """
    context={}
    return render_to_response('admin_app/Import_Staff.html', context, RequestContext(request))


@login_required
def import_staff_save(request):
    """
        Purpose: Import staff details both from csv and spreadsheet
    """
    message = ''
    errors = []
    context = {}
    if request.FILES.has_key('import_file'):
        file_obj = request.FILES['import_file']
        file_flag = True
    else:
        message = "Please upload file..."
        file_flag = False

    if file_flag:
        location = os.path.join(settings.TEMP_DIR , file_obj.name.replace(" ","_"))
        Import_obj = StaffManager()
        status = Import_obj.save_uploaded_file(file_obj, location)
        if not status:
            return HttpResponseRedirect(request.META['HTTP_REFERER'])

        f_obj = ClientManager()
        format = f_obj.checkForFormat(location)
        if format == "xls":
            obj = SpreadSheetDictonaryConversion()
            spreadsheet_cloumn_list = ['Staff Name', 'Username', 'Password', 'Email Address', 'Phone', 'Staff Type', 'Status']
            result_dict = obj.spreadsheet_converter(location , spreadsheet_cloumn_list)
            status, message, errors = Import_obj.processImportedStaff(result_dict)
        if format == "csv":
            csvobj = CSVDictionaryConversion()
            result_dict = csvobj.csvConverter(location)
            status, message, errors = Import_obj.processCSVImportedStaff(result_dict)
        Import_obj.delete_processed_file(location)
    context['message'] =  str(message)
    context['staff_errors'] = errors
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    return render_to_response('admin_app/Import_Staff.html', context, RequestContext(request))


@login_required
def export_staff_details(request):
    """
        Purpose: Export staff details on the basis of filtered results
    """
    response =None
    req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))

    data_dict = {}
    search = str(req_dict['search_data'])
    search_data = search.split('&')
    for item in search_data:
        item = item.split('=')
        data_dict[item[0]] = item[1]
    req_dict.update(data_dict)
    staff_obj = StaffManager()
    staff_data = staff_obj.exportStaffMember(req_dict)
    #Data required for creating spreadsheet
    sequence_list = SpreadsheetMapping.STAFF_SEQUENCE_LIST
    title_dict = SpreadsheetMapping.STAFF_TITLE_LIST
    #Create XLS
    if request.POST.get("format") == "xls":
        status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, staff_data, "staff_")
        msg = "Staff XLS Export Successful." if status else "Error in Staff XLS Export."
        log('EXPORT', request.user, request.user, data={'export':msg})
        if not status:
            pass
    elif request.POST.get("format") == "csv":
        file_location = os.path.join(settings.TEMP_DIR , "staff.csv")
        status , response = CreateSpreadsheet.create_csv_file(sequence_list,title_dict , staff_data , file_location )
        if status:
            wrapper = FixedFileWrapper(file(file_location))
            filename = 'attachment; filename=' + str(time.strftime("Staff_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
            response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
            response['Content-Disposition'] = filename
        msg = "Staff CSV Export Successful." if status else "Error in Staff CSV Export."
        log('EXPORT', request.user, request.user, data={'export':msg})
    return response


@login_required
def download_staff_spreadsheet(request, format):
    """
        Purpose: Export staff details on the basis of filtered results
    """
    response =None
    # req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
    # data_dict = {}
    #Create XLS
    if format == "xls":
        filename = "Staff_Import_Format.xls"
    elif format == "csv":
        filename = "Staff_Import_Format.csv"
    file_location = os.path.join(settings.SPREADSHEET_FORMAT_PATH , filename)
    wrapper = FixedFileWrapper(file(file_location))
    filename = 'attachment; filename=' + str(filename)
    response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
    response['Content-Disposition'] = filename
    return response


def assign_client(request):

    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    client, manager_id = request.GET.get('client') or None, request.GET.get('staff') or None
    per_page, cur_page = request.GET.get('numOfResults',25), request.GET.get('page', 1)
    keyword = request.GET.get("keyword")
    context["is_selected"] = "current"

    clients = ClientModel.objects.filter(is_active=True).exclude(accountmangers=None).select_related("accountmangers")
    
    clients = clients.values("id", "accountmangers__id", "accountmangers__user__first_name","accountmangers__user__last_name", "name")
    
    if keyword:
        clients = clients.filter(name__icontains= keyword)
    if client:
        clients = clients.filter(id = client)
    if manager_id:
        def filter_by_manager(record):
            if str(record["accountmangers__id"]) == manager_id:
                return True
        
        clients = filter(filter_by_manager, clients)

    paginated = paginate(clients, cur_page, per_page)
    for record in paginated.object_list:
        record["accountmangers__full_name"] = record["accountmangers__user__first_name"] + " " + record["accountmangers__user__last_name"]

    
    data_set = []
    
#    for elem in paginated.object_list:
#        record = [ {"client":client, "manager": elem}  for client in elem.clientmodel_set.all() ]
#        data_set.extend(record)
#    clients  = ClientModel.objects.filter(is_active=True)
#    if keyword:
#        clients = clients.filter(name__icontains= keyword)
#    if client:
#        clients = clients.filter(id = client)
#    if manager_id:
#        clients = clients.filter(accountmangers__id = manager_id)
#
#    paginated = paginate(clients, cur_page, per_page)
#    clients = paginated.object_list 
#    result = []
#    for client in paginated.object_list:
#        if manager_id:
#            temp_set = [{"client":client, "manager":manager}  for manager in client.accountmangers.filter(emp_type="accountmanager") if int(manager_id)==manager.id]
#        else:
#            temp_set = [{"client":client, "manager":manager}  for manager in client.accountmangers.filter(emp_type="accountmanager") ]
#        if temp_set:
#            for elem in temp_set:
#                elem['manager'].full_name = elem['manager'].user.get_full_name()
#                result.append(elem)
#    if keyword or client or manager_id:
#        if not clients:
#            messages.warning(request,"No Records found!")

#    paginated.object_list = data_set
    context["result_set"] = paginated
#    context['countall']=count
    return render_to_response('admin_app/BE_AssignToClient.html',context,RequestContext(request))

def add_account_manager(request, *args, **kwargs):
    """
        Assign Account Managers to Clients
    """
    context={}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    context["is_selected"] = "current"
    change = kwargs.get('change', False)
    if request.method=="GET":
        if change:
            #this is a edit request
            context["page_title"] = "Edit Account Manager to Clients"
            empid = kwargs.get("emp_id")
            manager = StaffModel.objects.get(id = empid)
            data = {}

            sm = StaffManager(manager)
            info = sm.getAccountManagerInfo()
            data.update(info)
            form = AssignClientForm(data = data)
        else:
            context["page_title"] = "Add New Account Manager to Clients"
            form = AssignClientForm()
        context["form"] = form
    elif request.method=="POST":
        form = AssignClientForm(request.POST)
        ajax_context = {}
        if form.is_valid():
            try:
                form.save(form)
                ajax_context['status'] =True
                messages.success(request,"Record Added Successfully!")
            except:
                #log the event
                raise
        else:
            context['form'] = form
            response = render_to_string('admin_app/BE_AddNewAccountManagerToClients.html',context,RequestContext(request))
            ajax_context['status']=False
            ajax_context['html']= response

        return HttpResponse(simplejson.dumps( ajax_context),mimetype="application/json")

    return render_to_response('admin_app/BE_AddNewAccountManagerToClients.html',context,RequestContext(request))

@csrf_exempt
def del_client_manager_record(request, *args, **kwargs):
    """
    """
    context = {};
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    emdid= kwargs.get("emp_id")
    client_id = kwargs.get("client_id")
    manager = StaffModel.objects.get(id = emdid)
    client = ClientModel.objects.get(id = client_id)
    manager.clientmodel_set.remove(client)
    messages.success(request, "Record deleted.")
    return HttpResponse(simplejson.dumps({'status':True}),mimetype="application/json")


def get_managers_clients(request, *args, **kwargs):
    """
        returns the list of clients, to which the given account manager is assigned
    """

    emp_id = kwargs["emp_id"]
    userclients = ClientModel.objects.filter(is_active=True, accountmangers=emp_id).values_list("id", "name").order_by("name")
    otherclients = ClientModel.objects.filter(is_active=True).exclude(accountmangers=emp_id).values_list("id", "name").order_by("name")
    
    manager = StaffModel.objects.get(id = emp_id)
    alerts = AlertManager().get_user_alerts(manager.user)
    al_dict = {}
    
    for i in alerts:
        al_dict[i.name] = i.frequency
    
#    data = {}
#
#    sm = StaffManager(manager)
#    info = sm.getAccountManagerInfo()
#    data.update(info)
#    form = AssignClientForm(data = data)
    
    context = {"all": list(otherclients), "managers": list(userclients), "alerts" : al_dict}
    
#    userclients = simplejson.dumps(list(userclients))
#    otherclients = simplejson.dumps(list(otherclients))
    
    context = simplejson.dumps(context)
    
    return HttpResponse(context,mimetype="application/json")
    
    
    