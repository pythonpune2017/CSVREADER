'''
Created on 06-Jan-2012

@author: pritesh
'''
from models import *
from django.contrib import admin

admin.site.register(CountryModel)
admin.site.register(UserProfileModel)
admin.site.register(StaffModel)

