from django.db import models
from django.contrib.auth.models import User
from object_log.models import LogAction

# Create your models here.

class CountryModel(models.Model):
    country_name= models.CharField("Country name",max_length=50,unique=True)
    country_code= models.CharField("Country code",max_length=50, blank=True,null=True)
    
    
    def __unicode__(self):
        return self.country_name
    

class UserProfileModel(models.Model) :
    """ Model to hold User profile """
    
    user = models.OneToOneField(User, unique=True)
    mobile = models.CharField("Mobile", max_length=20, blank=True,null=True)
    phone = models.CharField("Phone", max_length=20, blank=True,null=True)
    age = models.PositiveSmallIntegerField('Age', max_length=20, blank=True,null=True)
    role = models.CharField(max_length=50, blank=True, null=True)
    department = models.CharField(max_length=50, blank=True, null=True)
    #Meta
    updated = models.DateTimeField('Updated' , auto_now = True)
    
    def __unicode__(self):
        return u'%s' % (self.user)
    
    
class StaffModel(models.Model):
    """ Employee master """  
    
    EMP_TYPE = (
    (u'admin', u'Admin'),
    (u'Account Manager', u'Account Manager'))
    
    user = models.OneToOneField(User, unique=True)
    emp_type = models.CharField(max_length=20, choices=EMP_TYPE,default='admin')
    is_status = models.BooleanField(default=False)
    

    #Meta
    created = models.DateTimeField('Created Date' , auto_now_add = True)
    updated = models.DateTimeField('Updated' , auto_now = True)
    
    def __unicode__(self):
        return u'%s' % (self.user)

    def delete(self):
        """
            Marks a Staff as Deleted.
            This deletes a Entry in User, UserProfile and StaffModel
        """
        try:
            User.objects.filter(id=self.user.id).delete()
#            staff_obj.delete()
        except:
            raise

