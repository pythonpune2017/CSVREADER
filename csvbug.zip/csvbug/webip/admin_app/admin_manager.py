import os
from django.db.models import Q
from django.contrib.auth.models import User
from django.http import HttpResponse
from client.managers import AlertManager
from utils.permissions_manager import WebipPermissionManager, USER_PERMISSION_MAP
from admin_app.models import UserProfileModel,StaffModel
from client.models import FREQUENCY_TYPE
from admin_app.form import get_values_for_alert_form


class StaffManager(object):
	"""
	"""
	def __init__(self, staff=None):
		self.staff = staff
	
	
	def save_uploaded_file(self,file_obj, location):
		"""
			Save Uploaded File at temporary location.
		"""
		try:
			destination = open(location, 'wb+')
			for chunk in file_obj.chunks():
				destination.write(chunk)
			destination.close()
			return True
		except:
			return False


	def delete_processed_file(self, location):
		"""
		"""
		try:
			os.remove(location)
		except:
			pass

	
#	def processImportedStaff(self, req_dict):
#		"""
#			Process dictionary for imported staff. 
#		"""
#		try:
#			for sheet, value_list in req_dict.iteritems():
#				for val_dct in value_list:
#					usr_obj = self.addUser(val_dct)
#					if usr_obj:
#						self.createUserProfile(val_dct, usr_obj)
#						self.addStaff(val_dct, usr_obj)
#			return True, "Spreadsheet Uploaded"
#		except Exception, e:
#			print "Exception in Staff Import(XLS Format", str(e)
#			return False, "Error while processing spreadsheet"
		
	def processImportedStaff(self, req_dict):
		"""
			Process dictionary for imported staff. 
		"""
		error_list = []
		for sheet, value_list in req_dict.iteritems():
			for val_dct in value_list:
				try:
					usr_obj = self.addUser(val_dct)
					if usr_obj:
						try:
							self.createUserProfile(val_dct, usr_obj)
							self.addStaff(val_dct, usr_obj)
						except Exception , e:
							error_list.append((val_dct['Staff Name'], "User Already Exists!"))
							pass
					else:
						error_list.append((val_dct['Staff Name'], "User Already Exists!"))
						pass
				except Exception , e:
					error_list.append((val_dct['Staff Name'], str(e)))
					usr_obj.delete()
    				pass
		return True, "Spreadsheet Uploaded", error_list
		
#	def processCSVImportedStaff(self, req_dict):
#		"""
#			Process dictionary for imported staff. 
#		"""
#		try:
#			for val_dct in req_dict:
#				usr_obj = self.addUser(val_dct)
#				if usr_obj :
#					self.createUserProfile(val_dct, usr_obj)
#					self.addStaff(val_dct, usr_obj)
#			return True, "Spreadsheet Uploaded"
#		except Exception, e:
#			print "Exception in Client Import(CSV Format", str(e)
#			return False, "Error while processing spreadsheet"

	def processCSVImportedStaff(self, req_dict):
		"""
			Process dictionary for imported staff. 
		"""
		error_list = []
		for val_dct in req_dict:
  			try:
  				usr_obj = self.addUser(val_dct)
				if usr_obj :
					self.createUserProfile(val_dct, usr_obj)
					self.addStaff(val_dct, usr_obj)
				else:
					error_list.append((val_dct['Staff Name'], "User Already Exists!"))
					pass
  			except Exception , e:
  				error_list.append((val_dct['Staff Name'], str(e)))
  				usr_obj.delete()
   	  			pass
		return True, "Spreadsheet Uploaded", error_list

		
	def addUser(self, val_dct):
		"""
			Add User.
		"""
		try:
			usr_obj = User.objects.create_user(username = val_dct['Username'],email=val_dct['Email Address'], password = val_dct['Password'])
			usr_obj.first_name = val_dct['Staff Name']
			usr_obj.is_active = True if val_dct['Status'].lower()=='active' else False
			usr_obj.save()
		except:
			usr_obj = None
			
		return usr_obj
	
	
	def createUserProfile(self, val_dct, usr_obj):
		"""
			Create User Profile.
		"""
		usr_prf_obj = UserProfileModel(user=usr_obj)
		usr_prf_obj.phone = val_dct['Phone'].split('.')[0]
		usr_prf_obj.save()
		
		
	def addStaff(self, val_dct, usr_obj):
		"""
			Add Staff.
		"""
		staff_obj = StaffModel(user=usr_obj)
		staff_obj.emp_type = val_dct['Staff Type'].lower()
		staff_obj.is_status=True
		staff_obj.save()
		
		
	def exportStaffMember(self, req_dict):
		"""
		"""
		staff_data = StaffModel.objects.all().select_related()

		if req_dict.get('client'):
			staff_data = staff_data.filter(clientmodel__id = req_dict['client'])

		#-- Build Query String.				
		fields_4_keyword_search = ["user__username", "user__first_name", "user__email"]
		if req_dict.get('keyword'):
			q_str = ""
			for element in fields_4_keyword_search:
				q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element, req_dict['keyword'])
	
			if q_str:	
				staff_data = staff_data.filter(eval(q_str))

		#-- Filter by User Status.
		if req_dict.get('status') == "1":
			staff_data = staff_data.filter(user__is_active = True)
		elif req_dict.get('status') == "0":
			staff_data = staff_data.filter(user__is_active = False)
		
		#-- Filter by User Employee Type.
		if req_dict.get('staff_type') == '0':
			staff_data=staff_data.filter(emp_type = 'Admin')
		elif req_dict.get('staff_type') == '1':
			staff_data=staff_data.filter(emp_type = 'AccountManager')

		staff_data = staff_data.order_by("user__first_name")
		
		#-- Get Total Client For Staff Member.
		staff_client_info = []
		for elem in staff_data.iterator():
			staff_client_info.append({"total_clients": elem.clientmodel_set.all().count()})
		
		staff_info = staff_data.values('user__first_name','user__username','user__email',
						  'user__userprofilemodel__phone','emp_type','user__is_active',)

		for index, staff in enumerate(staff_info):
			staff.update(staff_client_info[index])
		
		return staff_info
		
	def getAccountManagerInfo(self):
		"""
			Get all the Information related to Account Manager
		"""
		
		if not self.staff.emp_type == "Account Manager":
			raise "Staff should be a Account Manager"
		data = {}
		data['manager'] = self.staff.id
		manager_clients = self.staff.clientmodel_set.all().values_list("id", "name")
#		import pdb
#		pdb.set_trace()
		data["selectedclients"]=manager_clients

		data.update(get_values_for_alert_form(self.staff.user))
#		for elem in USER_PERMISSION_MAP:
#			if elem["permission"] in self.staff.user.user_permissions.all():
#				data[elem["name"]] = True

		return data