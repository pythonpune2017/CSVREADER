from django import forms
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
import os
from client.models import ALERT_TYPE
from admin_app.models import StaffModel
from django.conf import settings
from django.contrib.admin.widgets import FilteredSelectMultiple
from django.utils.safestring import mark_safe
from django.template.loader import render_to_string

from client.models import Alert,ClientModel,FREQUENCY_TYPE, ClientDomainCategory
from django.contrib.auth.models import Permission
from django.core.exceptions import ValidationError

from client.managers import AlertManager
from django import forms
from django.core import validators
from webip.client.models import *
from utils.permissions_manager import USER_PERMISSION_MAP

import re


attrs_dict = {'class': 'required'}
class StaffForm(forms.Form):


    STATUS = (

    (True, "Active"),
    (False,"Inactive")
     )

    STAFF_CHOICE = (
    ('admin', 'Admin'),
    ('Account Manager', 'Account Manager'),
)


    id = forms.CharField(label="id",widget=forms.HiddenInput(),required = False)
    name = forms.CharField(label="Staff Name", max_length=30, required = True,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Staff  Name must be alphanumeric'})

    username = forms.RegexField(regex=r'^[\w.@+-]+$',
                                max_length=30,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                label=_("UserName"),
                                error_messages={'invalid': _("This value must contain only letters, numbers and underscores.")})

    email = forms.EmailField(widget=forms.TextInput(attrs={'class':'popinput'}), max_length=75,label=_("E-mail"))

    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'popinput'},render_value=False),
                                label=_("Password"),required = False)


    phone = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'popinput'}),required=True,
                                label=_("Phone"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Phone must be numeric'})


    role = forms.CharField(label="Role", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('^\d*[a-zA-Z_.-@\s][a-zA-Z0-9_.-@\s]*$'), code='invalid')],
                                error_messages = {'invalid': 'Role must be in valid format'})
    department = forms.CharField(label="Department", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('^\d*[a-zA-Z_.-@\s][a-zA-Z0-9_.-@\s]*$'), code='invalid')],
                                error_messages = {'invalid': 'Department must be in valid format'})
    mobile = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'popinput'}),required=False,
                                label=_("Mobile"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Mobile must be in valid format'})


    staff_type=forms.ChoiceField(choices=STAFF_CHOICE,
                                 widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop'}),
                                 label=_("Staff Type"))

    status=forms.ChoiceField(choices=STATUS,
                             widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop'}),
                                label=_("Status"))



    def clean_password(self):
        password=self.cleaned_data['password']
        try:
            if not len(self.cleaned_data['id']):
                if not password:
                    raise forms.ValidationError("please enter the password")
        except:
            raise

        return password

    def clean_username(self):
        """ Validates that an active staff exists with the given username address."""
        username = self.cleaned_data["username"]
        try:
            if not len(self.cleaned_data['id']):
                self.staff_cache = User.objects.filter(username__iexact=username,is_active=True)
                if len(self.staff_cache):
                    for user_id in self.staff_cache:
                        staff=StaffModel.objects.filter(user=user_id)
                        if staff:
                            raise forms.ValidationError("The Username already associated with other Staff Account.")

            if self.cleaned_data['id']:
                    staff=StaffModel.objects.filter(id=self.cleaned_data["id"],user__username=self.cleaned_data["username"])
                    if not staff:
                        self.staff_cache = User.objects.filter(username__iexact=username,is_active=True)
                        if len(self.staff_cache):
                            for user_id in self.staff_cache:
                                staff=StaffModel.objects.filter(user=user_id)
                                if staff:
                                    raise forms.ValidationError("The Username already associated with other Staff Account.")
        except:
            raise

        return username
#
    def clean_email(self):
        """ Validates that an active Staff exists with the given email address."""
        email = self.cleaned_data["email"]
        try:
            if not len(self.cleaned_data['id']):
                self.staff_cache = User.objects.filter(email__iexact=email,is_active=True)
                if len(self.staff_cache):
                    for user_id in self.staff_cache:
                        staff=StaffModel.objects.filter(user=user_id)
                        if staff:
                            raise forms.ValidationError("The e-mail address already associated with other Staff Account.")
                        client=ClientModel.objects.filter(user=user_id)
                        if client:
                            raise forms.ValidationError("The e-mail address already associated with other Staff Account.")


            if self.cleaned_data['id']:
                staff=StaffModel.objects.filter(id=self.cleaned_data["id"],user__email=self.cleaned_data["email"])
                if not staff:
                    self.staff_cache = User.objects.filter(email__iexact=email,is_active=True)
                    if len(self.staff_cache):
                        for user_id in self.staff_cache:
                            staff=StaffModel.objects.filter(user=user_id)
                            if staff:
                                raise forms.ValidationError("The e-mail address already associated with other Staff Account.")
                            client=ClientModel.objects.filter(user=user_id)
                            if client:
                                raise forms.ValidationError("The e-mail address already associated with other Staff Account.")
        except:
            raise

        return email



class FilteredSelectMultipleCustom(FilteredSelectMultiple):

    class Media:
        js = ( settings.ADMIN_MEDIA_PREFIX + "js/core.js",
              settings.ADMIN_MEDIA_PREFIX + "js/SelectBox.js",
              settings.ADMIN_MEDIA_PREFIX + "js/SelectFilter2.js" )

    def __init__( self, verbose_name, leftHandSideQuerySet, rightHandSideQuerySet, attrs={} ):
        """
        Takes two queryset as init argument and use those
        """
        self.verbose_name = verbose_name
        self.leftHandQuerySet = leftHandSideQuerySet
        self.rightHandSideQuerySet = rightHandSideQuerySet
        self.attrs = attrs
        super( FilteredSelectMultipleCustom, self ).__init__( verbose_name, False, attrs )


    def render( self, name, values, *args, **kwargs ):
        dictionary = {
            'name':name,
            'left':self.leftHandQuerySet,
            'right':self.rightHandSideQuerySet,
            'verbose_name':self.verbose_name
        }
        s = render_to_string( "widgets/multiple_select.html", dictionary )
        return mark_safe( u''.join( s ) )


class PremissionsForm(forms.Form):
    """
        Form to be used to associate access levels to Account Managers
    """
    view_domain =       forms.BooleanField(label="View Domain", required=False)
    edit_domain =       forms.BooleanField(label="Edit Domain ", required=False)
    order_domain =     forms.BooleanField(label="Order Domains", required=False)
    view_trademark =    forms.BooleanField(label="View Trademark", required=False)
    edit_trademark =    forms.BooleanField(label="Add/Edit", required=False)
    view_contract =     forms.BooleanField(label="View Contract", required=False)
    edit_contract =     forms.BooleanField(label="Add/Edit Contract", required=False)
    view_cases =        forms.BooleanField(label="View Cases", required=False)
    edit_cases =        forms.BooleanField(label="Add/Edit Cases", required=False)

    monitoring_brand =	 forms.BooleanField(label="Brand", required=False)
    monitoring_domain =		forms.BooleanField(label="Domain", required=False)
    monitoring_trademark =		forms.BooleanField(label="Trademark", required=False)

    def setPermissions(self, user):
        """
            Assign Permissions to given user
        """
        def _format_perm_list(permissionmap):
            newdict = {}
            for perm_map in permissionmap:
                newdict[perm_map["name"]] = perm_map["permission"]
            return newdict
            
        permission_map = _format_perm_list(USER_PERMISSION_MAP)
        
        changed_data = self.changed_data
        data = self.cleaned_data
        for elem in permission_map.keys():
#            if elem in changed_data:
            if data[elem]:
                user.user_permissions.add(permission_map[elem])
            else:
                user.user_permissions.remove(permission_map[elem])

#ALERT_FORM_FIELDS = ["domain_renewals", "domain_renewals_choice", "dms_changes", "dms_changes_choice","ssl_renewals",  "ssl_renewals_choice", "trademark_renewals", "trademark_renewals_choice", "contract_changes", "contract_changes_choice"]

def get_values_for_alert_form(user):
    """
        Returns a dict of values for Alert Form for making a bound form
    """
    data ={}
    user_alerts = AlertManager().get_user_alerts(user)
    for alert in user_alerts:
        if alert.name in [name for name, value in FREQUENCY_TYPE]:
            data[alert.name] = True
            data[alert.name + "_choice"] = alert.frequency
        else:
            data[alert.name] = False
            data[alert.name + "_choice"] = alert.frequency

    return data

class DomainCategoryForm(forms.Form):
    """
        To be used to associate domain category to Account Managers
    """
    category1 = forms.BooleanField(label="Category1", required=False)
    category2 = forms.BooleanField(label="Category2", required=False)
    category3 = forms.BooleanField(label="Category3", required=False)
    category4 = forms.BooleanField(label="Category4", required=False)


    def clean(self):
        """ clean method """
        return self.cleaned_data

    def setCategory(self, clientuser):
        """
            Assign domain category to given user
        """
        data = self.cleaned_data
        category = ClientDomainCategory()
        category.client = clientuser
        category.category1 = data['category1']
        category.category2 = data['category2']
        category.category3 = data['category3']
        category.category4 = data['category4']
        category.save()

class AlertForm(forms.Form):
    """
        To be used to associate Alerts to Account Managers
    """
    domain_renewals =       forms.BooleanField(label="Domain Renewals", required=False, widget=forms.CheckboxInput(attrs={'class':"alert_check"}))
    domain_renewals_choice =       forms.ChoiceField(choices=ALERT_TYPE,widget=forms.Select(attrs={'class':'add_use_drop webip_select alert_select webip_select_pop'}), required=False)
    dms_changes =       forms.BooleanField(label="DNS Changes", required=False, widget=forms.CheckboxInput(attrs={'class':"alert_check"}))
    dms_changes_choice =       forms.ChoiceField(choices=ALERT_TYPE,widget=forms.Select(attrs={'class':'add_use_drop webip_select alert_select webip_select_pop'}), required=False)
    ssl_renewals =       forms.BooleanField(label="SSL Renewals", required=False, widget=forms.CheckboxInput(attrs={'class':"alert_check"}))
    ssl_renewals_choice =       forms.ChoiceField(choices=ALERT_TYPE,widget=forms.Select(attrs={'class':'add_use_drop webip_select alert_select webip_select_pop'}), required=False)
    trademark_renewals =       forms.BooleanField(label="Trademark Renewals", required=False, widget=forms.CheckboxInput(attrs={'class':"alert_check"}))
    trademark_renewals_choice =       forms.ChoiceField(choices=ALERT_TYPE,widget=forms.Select(attrs={ 'class':'add_use_drop webip_select alert_select webip_select_pop'}), required=False)
    contract_changes =       forms.BooleanField(label="Contract Changes", required=False, widget=forms.CheckboxInput(attrs={'class':"alert_check"}))
    contract_changes_choice =       forms.ChoiceField(choices=ALERT_TYPE,widget=forms.Select(attrs={'class':'add_use_drop webip_select alert_select webip_select_pop'}), required=False)

    def saveAlerts(self, user):
        """
            Associate alerts to given user
        """
        alerts = {"domain_renewals": FREQUENCY_TYPE[1][0], "dms_changes": FREQUENCY_TYPE[2][0], "ssl_renewals":FREQUENCY_TYPE[3][0], "trademark_renewals":FREQUENCY_TYPE[4][0], "contract_changes":FREQUENCY_TYPE[5][0]}
        alerts_freq = ["domain_renewals_choice", "dms_changes_choice", "ssl_renewals_choice", "trademark_renewals_choice", "contract_changes_choice"]
        def _create_alert(alert_name, user):
            alert = Alert(name = alert_name, frequency=self.cleaned_data[alert_name + "_choice"], user = user)
            try:
                client_user_obj = ClientUser.objects.get(user=user,user_type='superuser')
                if client_user_obj:
                    alert.client=client_user_obj.client
            except:
                  pass
            alert.save()

        def _update_alert(key):
            alert, is_created = Alert.objects.get_or_create(name = alerts[key], user = user)
            if self.cleaned_data[key]:
                alert.frequency = self.cleaned_data[key + "_choice"]
                try:
                    client_user_obj = ClientUser.objects.get(user=user,user_type='superuser')
                    if client_user_obj:
                        alert.client=client_user_obj.client
                except:
                    pass
                alert.save()
            else:
                alert.delete()
                alert.frequency = ""


        selected_alerts = []
        for key, value in self.cleaned_data.iteritems():
            if key in alerts.keys():
                _update_alert(key)


    def clean(self):
        """
            custom validation for Alerts
        """
        cleaned_data = self.cleaned_data
        alerts = [("domain_renewals", "domain_renewals_choice"),
                  ("dms_changes","dms_changes_choice"),
                  ("ssl_renewals","ssl_renewals_choice"),
                  ("trademark_renewals","trademark_renewals_choice"),
                  ("contract_changes", "contract_changes_choice")
                ]

        for alert, choice in alerts:
            if cleaned_data[alert]:
                if not cleaned_data[choice]:
                    self._errors[choice] = self.error_class(["Please select the Frequency."])

                    del(cleaned_data[choice])
        return cleaned_data



class WebMultiSelecField(forms.MultipleChoiceField):

    def validate(self, value):
        if self.required and not value:
            raise ValidationError(self.error_messages['required'])

def _get_managers_4_choice():
    """
        returns list of account managers with id and Name:
        returns: ((id, full_name),)
    """
    managers = StaffModel.objects.select_related("user").filter(emp_type="Account Manager", is_status=True)
    data = [(elem.id, elem.user.get_full_name()) for elem in managers]
    data.insert(0,("", "Please Select.."))
    return tuple(data)

def _get_all_clients(clients=None):
    """
        returns list of all clients to be used for choice
    """
    if not clients:
        clients = ClientModel.objects.filter(is_active = True).values_list("id", "name")
    else:
        clients = clients.values_list("id", "name")

    return clients

class AssignClientForm(AlertForm):
    """
        To be used to assign Clients to Account Maanger
    """
    manager = forms.ChoiceField(widget=forms.Select(attrs={'id':'accontmanagers', 'class':'add_use_drop webip_select'}), choices=_get_managers_4_choice())
    allclients = WebMultiSelecField( required=False,
                                     choices = _get_all_clients(),
                                     widget=forms.SelectMultiple(attrs={'id':"multi-select-left", 'class':"list-bar1"}))
    selectedclients = WebMultiSelecField( required=True,
                                          choices = _get_all_clients(),
                                          widget=forms.SelectMultiple(attrs={'id':"multi-select-right", 'class':"list-bar1"}))


    def __init__(self, *args, **kwargs):
        data = kwargs.get("data", {})
        selected_clients_value = data.pop("selectedclients") if data else ClientModel.objects.none()
        data["selectedclients"] = [i[0] for i in selected_clients_value]
        super( AssignClientForm, self ).__init__(*args, **kwargs)

        self.fields['allclients'].choices = _get_all_clients()
        self.fields['selectedclients'].choices= selected_clients_value
#        self.fields['selectedclients'].initial = [i[0] for i in selected_clients_value]
        self.fields['manager'].choices= _get_managers_4_choice()
        if data:
            if selected_clients_value:
                self.fields['selectedclients'].choices = _get_all_clients(selected_clients_value)
                self.fields['allclients'].choices = _get_all_clients().exclude(id__in= selected_clients_value.values_list("id"))


    def save(self, form=None):
        """
        """
        data = self.cleaned_data
        try:
            manager = StaffModel.objects.get(id = data["manager"])
            self.saveAlerts(manager.user)
#            super(AssignClientForm, self).setPermissions(manager.user)
            self.assignClients(manager)
            return True
        except:
            raise
        #needs to be handlded

    def assignClients(self, manager):
        """
            assign client to user
        """
        if "selectedclients" in self.changed_data:
            clients = ClientModel.objects.filter(id__in = self.cleaned_data['selectedclients'])
            for client in clients:
                if client not in manager.clientmodel_set.all():
                    manager.clientmodel_set.add(client)

            #remove other clients
            other_clients = manager.clientmodel_set.exclude(id__in= clients.values_list("id"))
            for client in other_clients:
                manager.clientmodel_set.remove(client)
