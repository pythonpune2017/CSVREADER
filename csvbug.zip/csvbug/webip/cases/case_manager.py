'''
Created on Apr 7 , 2012

@author: shweta
'''
from django.db.models import Q
from cases.models import *
from client.models import *
from admin_app.models import *
from utils.paginator import paginate
from datetime import datetime
import datetime
import os
import re
from utils.random_generator import RandomGenerator
from django.contrib.auth.models import User
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action

# Values for Milestone model
MILESTONE_ALL = ['id','name','due_date','status']

class CaseManager(object):
    """
        Domain related objects
    """
    def get_all_cases(self,data_dict={}):
        """
            Purpose: To get all domain objects list
        """

        user_id = data_dict['user_id']
        client_id = self.get_client_id(user_id)
        #Check for cases that are not deleted
        cases = CasedetailModel.objects.filter(client__id =client_id ,  is_active = True)
        #Check for Keywords
        if data_dict['keyword']:
            keyword = data_dict['keyword']
            fields_4_keyword_search = ["id","name"]
            q_str = ""
            for element in fields_4_keyword_search:
#                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element, keyword)
                q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)
            cases = cases.filter(eval(q_str))
        #Check for country
        cases = cases.filter(status = data_dict['status']) if data_dict['status'] else cases
        #Check for clients
        cases = cases.filter(case_type = data_dict['case_type']) if data_dict['case_type'] else cases

        if data_dict['expiry_in'] and data_dict['expiry_out']:
            expiry_in_date = datetime.datetime.strptime(str(data_dict['expiry_in']), '%d-%m-%Y')
            expiry_out_date = datetime.datetime.strptime(str(data_dict['expiry_out']), '%d-%m-%Y')
            cases = cases.filter(date_found__range = (datetime.datetime.combine(expiry_in_date, datetime.time.min),
                       datetime.datetime.combine(expiry_out_date, datetime.time.max)))
        elif data_dict['expiry_out']:

            cases=cases.filter(date_found__lte=expiry_out_date)

        elif data_dict['expiry_in']:
            cases=cases.filter(date_found__gte = expiry_in_date)
        else:
            cases=cases
        #Order by Created Date.
        cases = cases.order_by("-created")
        return cases

    def get_client_id(self, userid):
        """
            Get client id from user id
        """
        client_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
#            client_id = user.clientmodel.id
            client_id = user.clientuser.client_id
        return client_id

    def get_user_obj(self, userid):
        """
            Get client id from user id
        """
        User_obj = None
        try:
            User_obj= User.objects.get(id = userid)
        except:
            User_obj = None

        return User_obj

    def get_clientuser_id(self, userid):
        """
            Get client id from user id
        """
        client_id = None
        try:
            user= User.objects.get(id = userid)
        except:
            user = None
        if user:
            client_id = user.clientuser.id
        return client_id

    def export_cases(self, data_dict={}):
        """
            Purpose: 1. Export all the domains present in the database
                     2. Export all the domains on the basis of serach and filter results
            Input: data_dict (having search and filtered results if any)
        """
        cases = self.get_all_cases(data_dict = data_dict)
        cases_info = cases.values("id", "name", "domain__name","trademark","url","case_type","date_found","budget","spent_todate","infringer_name","company", "email","alt_email","phone","alt_phone","fax","notes","address","client","client_user__user__first_name","client_user__user__last_name","is_active","created","updated","status","foundby")
        cases_list = []
        for case in cases_info:
            cases_dict = {}
            for k , v in case.iteritems():
                if k == 'date_found':
                    cases_dict['date_found'] = datetime.datetime.strftime(v , "%d-%m-%Y")
                elif k =='client_user__user__first_name':
                    cases_dict['owner'] = str(v).capitalize()
                else:
                    cases_dict[k] = v
            cases_list.append(cases_dict)
        return cases_list

    def get_by_id(self,data={}):
        """ Method to get CasedetailModel with id
        args : values dict
        return : CasedetailModel object
        """
        status = True
        try :
            case = CasedetailModel.objects.get(id=data['case_id'],is_active=True)
        except Exception, e :
            print e # replace with LOGGING
            status = False
            case = None

        return status, case

    def get_case_info_by_id(self, case_id):
        """
            get case information on the basis of case_id
        """
        cases_dict = {}
        cases = CasedetailModel.objects.filter(id= case_id)
        cases_info = cases.values("id", "name", "domain_name","trademark","url","case_type","date_found","budget","spent_todate","infringer_name","company", "email","alt_email","phone","alt_phone","fax","notes","address","client","client_user__user__first_name","client_user__user__last_name","is_active","created","updated","status","tm_number","tm_name","client_user__clientuserprofile__department","foundby")
        if cases_info:
            cases_info = cases_info[0]
            cases_dict['date_found'] = datetime.datetime.strftime(cases_info['date_found'] , "%d-%m-%Y")
            cases_dict['owner'] = cases_info["client_user__clientuserprofile__department"]
            cases_dict.update(cases_info)
        return cases_dict

    def add_case(self, userid, req_dict, filename):
        """
            modify case details for case4 overview
        """

        client_id = self.get_client_id(userid)
        user_object=self.get_user_obj(userid)
        client_user_obj = user_object.clientuser
        client_user_id = self.get_clientuser_id(userid)
        try:
            cases = CasedetailModel(client_id= client_id, client_user = client_user_obj)
            cases.name = req_dict['name']
            cases.domain_name = req_dict['domain_name']
            cases.case_type = req_dict['case_type']
            cases.budget = req_dict['budget'] if req_dict['budget'] else 0
            cases.status = req_dict['status']
            cases.spent_todate = req_dict['spent_date'] if req_dict['spent_date'] else 0
            cases.notes = req_dict['notes']
            cases.phone = req_dict['phone']
            cases.alt_phone = req_dict['alt_phone']
            cases.fax = req_dict['fax']
            cases.tm_number = req_dict['tm_number']
            cases.infringer_name = req_dict['infringer_name']
            cases.url = req_dict['url']
            cases.company = req_dict['company']
            cases.address = req_dict['address']
            cases.tm_name = req_dict['tm_name']
            cases.alt_email = req_dict['alt_email']
            cases.email = req_dict['email']
            cases.save()
            try:
            	if req_dict.has_key('notes') and req_dict['notes']:
	                notes_obj = InfrigementNotesModel(cases = cases)
	                notes_obj.notes = req_dict['notes']
	                notes_obj.save()
            except:
                pass

            try:
                clent_user_prof = ClientUserProfile.objects.get(client = client_user_obj)
            except:
                clent_user_prof = ClientUserProfile(client = client_user_obj)
            clent_user_prof.department = req_dict['owner']
            clent_user_prof.save()
            if filename:
                try:
                    status, case_attachment_obj = self.add_attachemnt(cases.id, filename)
                except:
                    pass

            status = True
        except Exception , e:
			print "Cases Overview Errors:--",str(e)
   			try:
				cases.delete()
   			except:
   	   			pass
   	   		try:
	   	   		notes_obj.delete()
   	   		except:
   	   			pass
   	   		try:
	   	   		case_attachment_obj.delete()
   	   		except:
   	   			pass
			cases = None
			status = False

        return status, cases

    def modify_case(self, case_id, req_dict, client):
        """
            modify case details for case4 overview
        """
        try:
            cases = CasedetailModel.objects.get(id= case_id)
            cases.name = req_dict['name']

            if cases.case_type == 'brand':
                if req_dict['url']:
                    cases.url = req_dict['url'] if req_dict['url'] else ''
            elif cases.case_type == 'domain':
                if req_dict['domain_name']:
                    cases.domain_name = req_dict['domain_name'] if req_dict['domain_name'] else ''
            elif cases.case_type == 'trademark':
                if req_dict['tm_number'] and req_dict['tm_name']:
                    cases.tm_number = req_dict['tm_number'] if req_dict['tm_number'] else ''
                    cases.tm_name = req_dict['tm_name'] if req_dict['tm_name'] else ''

            #cases.case_type = req_dict['case_type']
            cases.budget = req_dict['budget'] if req_dict['budget'] else 0
            cases.status = req_dict['status']
            cases.foundby = req_dict['foundby'] if req_dict['foundby'] else ''
            cases.spent_todate = req_dict['spent_todate'] if req_dict['spent_todate'] else 0
            cases.save()
            try:
                clent_user_prof = ClientUserProfile.objects.get(client = client)
            except:
                clent_user_prof = ClientUserProfile(client = client)
            clent_user_prof.department = req_dict['owner'] if req_dict['owner'] else ''
            clent_user_prof.save()
            status = True
        except Exception , e:
            print "Cases Overview Errors",str(e)
            status = False
        return status, cases

    def modify_infringer(self, case_id, req_dict):
        """
            modify case infringer details
        """
        try:
            cases = CasedetailModel.objects.get(id= case_id)
        except:
            cases = None
        try:
            cases.infringer_name = req_dict['name']
            cases.company = req_dict['company']
            cases.email = req_dict['email']
            cases.alt_email = req_dict['alt_email']
            cases.phone = req_dict['phone']
            cases.alt_phone = req_dict['alt_phone']
            cases.fax = req_dict['fax']
            cases.address = req_dict['address']
            cases.save()
            status = True
        except Exception , e:
            print "Infriger errors",str(e)
            status = False
        return status, cases

    def add_notes(self,case_id, req_dict):
        """
            add notes for the cases in infringement
        """
        try:
            case_obj = CasedetailModel.objects.get(id= case_id)
        except:
            case_obj = None
        try:
            notes_obj = InfrigementNotesModel(cases = case_obj)
            notes_obj.notes = req_dict['notes']
            notes_obj.save()
            status = True
        except:
            notes_obj, status = None, False
        return status, notes_obj

    def get_case_notes_by_id(self, case_id):
        """
            get notes for the respective case
        """
        notes = InfrigementNotesModel.objects.filter(cases__id= case_id)
        return notes

    def get_all_attachments_by_id(self, case_id):
        """
            get all attachments for the respective case
        """
        attachments = CaseAttachmentDetails.objects.filter(cases__id = case_id)
        return attachments

    def delete_attachments_by_id(self, attachment_id):
        """
            delete attachments on the basis of attachment_id
        """
        try:
            attachments = CaseAttachmentDetails.objects.get(id = attachment_id)
            attachments.delete()
            return True
        except:
            return False

    def add_attachemnt(self, case_id, file):
        """
             add attachment for the respective case
        """
        try:
            case = CasedetailModel.objects.get(id= case_id)
            case_attachment = CaseAttachmentDetails(cases = case)
            case_attachment.attachment = file
            case_attachment.save()
            return True, case_attachment
        except:
            return False, None

    def delete_case(self, case_id):
        """
            delete case by case_id
        """
        try:
            case = CasedetailModel.objects.get(id= case_id)
        except:
            case = None
        if case:
            case.delete()
        return True, case


class MilestoneManage(object):
    """ Class to manupilate with Milestone model"""

    def __init__(self, case_id=None):
        """ Constructor for MilestoneManage """
        self.case_id = case_id

        # get CasedetailModel object
        case_object = CaseManager()
        self.case_status, self.case = case_object.get_by_id(data={'case_id':case_id})
        if not self.case_status :
            self.case = self.case_id

    def save(self,data={}):
        """ Method to save Milestone object
        args : values dict
        return : MilestoneManage object
        """
        status = True
        try :
            milestone = CaseMilestoneModel()

            # set object in dict
            data['milestone'] = milestone

            # push values to model
            milestone = self.to_model(data=data)
            if not milestone:
            	status = False

        except Exception, e :
            print e # replace with LOGGING
            milestone = None
            status = False

        return status,milestone

    def to_model(self,data={}):
        """ Method to push data/ values in MilestoneManage model
        args : values dict
        return : MilestoneManage object
        """
        try :
            # get the object
            milestone = data['milestone']

            # save the values
            milestone.cases = self.case
            milestone.name = data['name']
            # convert to datetime
            milestone.due_date = datetime.datetime.strptime(data['due_date'],"%d-%m-%Y")
            milestone.notes = data['notes']
            milestone.status = data['status']
            milestone.save()

        except Exception, e :
            print e # replace with LOGGING
            milestone = None

        return milestone

    def from_model(self,data={}):
        """ Method to pull data/ values from Milestone model
        args : values dict
        return : dict
        """
        milestone_dict = {}
        try :
            # get object
            milestone = data['milestone']

            # pull values
            milestone_dict['case_id'] = milestone.cases.id
            milestone_dict['name'] = milestone.name
            milestone_dict['due_date'] = milestone.due_date
            milestone_dict['notes'] = milestone.notes
            milestone_dict['status'] = milestone.status
        except Exception, e :
            print e  # replace with LOGGING
            milestone_dict = {}

        return milestone_dict

    def get_by_id(self,data={}) :
        """ Method to get Milestone object by id
        args : values dict
        retrun : Milestone object
        """
        status = True
        try :
            milestone = CaseMilestoneModel.objects.get(id=data['milestone_id'],is_active=True)
        except Exception, e :
            print e # replace with LOGGING
            status = False
            milestone = None

        return status, milestone

    def update(self,data={}):
        """ Method to update Milestone object """
        status = True
        try :
            # push values to model
            milestone = self.to_model(data=data)
            if not milestone:
				status = False
        except Exception, e :
            print e # replace with LOGGING
            status = False
            milestone = None
        return status, milestone

    def delete(self,data={}):
        """ Method to delete Milestone object
        args : values dict
        returns : status
        """
        status = True
        try :
            milestone = data['milestone']

            milestone.delete()

        except Exception,e :
            print e # replace with LOGGING
            status = False

        return status

    def get_by_case(self,data={}):
        """ Method to get Milestone model object with case
        args : values dict
        return : Milestone object
        """
        status = True
        try :
            milestone_list = CaseMilestoneModel.objects.filter(cases=self.case,is_active=True).order_by('created')
        except Exception, e :
            print e # replace with LOGGING
            status = False
            milestone_list = []

        return status,milestone_list


class CaseTeamManager(object):

    """ Class to Manage Case Team Operations"""

    def add_case_team(self,case_id,req_dict):
        """ adde the case team details        """
        # set default values
        team_obj = None
        status = False

        # validate for post fields
        validation_status = self.validate_case_team(req_dict)

        # if validation success processed
        if validation_status :
            try:
                case_obj = CasedetailModel.objects.get(id= case_id)
            except:
                case_obj = None
            try:
                team_obj = CaseTeamModel(cases = case_obj)
                team_obj.name = req_dict['name']
                team_obj.title = req_dict['title']
                team_obj.department = req_dict['department']
                team_obj.company = req_dict['company']
                team_obj.email = req_dict['email']
                team_obj.phone = req_dict['phone']
                team_obj.save()
                status = True
            except:
                team_obj = None
        return status, team_obj

    def restructure_request(self, req_dict):
        """
        """
        data_list = []
        for k , v in req_dict.iteritems():
            data_dict ={}
            if k.startswith("team_id"):
                id = v
                data = [k for k , v in req_dict.iteritems() if str(k).endswith(str(id))]
                for d in data:
                    data_dict[str(d).strip("_"+str(id))]=req_dict[d]
                data_list.append(data_dict)
        return data_list

    def modify_case_team(self,team_id=None, req_dict={}):
        """Update the case team deatails """
        # set default values
        team_obj = None
        status = False

        # validate for post fields
        validation_status = self.validate_case_team(req_dict)

        # if validation success processed
        if validation_status :
            try:
                team_obj = CaseTeamModel.objects.get(id= team_id)
            except:
                team_obj=None
            try:
                team_obj.name = req_dict['name']
                team_obj.title = req_dict['title']
                team_obj.department = req_dict['department']
                team_obj.company = req_dict['company']
                team_obj.email = req_dict['email']
                team_obj.phone = req_dict['phone']
                team_obj.save()
                status = True
            except Exception , e:
                print "Cases Overview Errors",str(e)

        return status, team_obj

    def validate_case_team(self, data):
        """ Method to validate Case Team Data"""
        status = True

        if not data.get('name') or not data.get('email') :
            status = False

        return status

    def get_case_team_info_by_id(self, case_id):
        """
            get case information on the basis of case_id
        """
        cases_dict = {}
        team_cases = CaseTeamModel.objects.filter(cases= case_id)
        team_cases_info = team_cases.values("id", "name", "title","department","company","email","phone")
        return team_cases_info


class TaskManager(object):
    """ Class to manupilate with Task models """

    def save(self,data={}):
        """ Method to save Task model
        args : values dict
        return : Task model object
        """
        status = True
        try :
            task = CaseTaskModel()

            # set in data
            data['task'] = task

            # push in model
            task = self.to_model(data=data)
            if not task:
            	status = False
        except Exception , e :
            print e # replace with LOGGING
            status = False
            task = None

        return status, task

    def to_model(self,data={}):
        """ Method to push data in model
        args : values dict
        return : Task model
        """
        try :
            # get task object
            task = data['task']

            task.name = data['name']
            task.users = data['client_user']
            task.cases = data['milestone']
            task.status = data['status']
            task.save()

        except Exception, e :
            print e # replace with LOGGING
            task = None
        return task

    def get_by_milestone(self,data={}):
        """ Method to get Task model with Milestone
        args : values dict
        return : Task Model object
        """
        status = True
        try :
            task_list = CaseTaskModel.objects.filter(cases=data['milestone'],is_active=True)
        except Exception, e :
            print e # replace with LOGGING
            status = False
            task_list = []

        return status, task_list

    def get_by_id(self,data={}) :
        """ Method to get Task object by id
        args : values dict
        retrun : Task object
        """
        status = True
        try :
            task = CaseTaskModel.objects.get(id=data['task_id'],is_active=True)
        except Exception, e :
            print e # replace with LOGGING
            status = False
            task = None

        return status, task

    def from_model(self,data={}):
        """ Method to pull data/ values from Task model
        args : values dict
        return : dict
        """
        task_dict = {}
        try :
            # get object
            task = data['task']


            # pull values
            task_dict['name'] = task.name
            task_dict['client'] = task.users.id
            task_dict['milestone'] = task.cases.id
            task_dict['status'] = task.status
        except Exception, e :
            print e  # replace with LOGGING
            task_dict = {}

        return task_dict

    def update(self,data={}):
        """ Method to update Task object """
        status = True
        try :
            # push values to model
            task = self.to_model(data=data)
            if not task:
				status = False
        except Exception, e :
            print e # replace with LOGGING
            status = False
            task = None
        return status, task

    def delete(self,data={}):
        """ Method to delete Task object
        args : values dict
        returns : status
        """
        status = True
        try :
            task = data['task']

            task.delete()

        except Exception,e :
            print e # replace with LOGGING
            status = False

        return status

