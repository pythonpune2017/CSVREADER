'''
Created on Apr 7, 2012

@author: shweta
'''
# Create your views here.
import os
import time
import json
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.db.models import Q
from utils.paginator import paginate
from django.contrib.auth.models import User
from datetime import datetime
from django.template import RequestContext
from django.core.urlresolvers import reverse
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.contrib import messages
from django.template.loader import render_to_string
#from domain.domain_manager import DomainManager , SSLManager
from django.forms.formsets import formset_factory
from utils.paginator import paginate
from django.core.servers.basehttp import FileWrapper
from utils import create_spreadsheet as CreateSpreadsheet
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from utils.get_instra_domain import InstraDNSManager
from cases.models import *
from cases.case_manager import CaseManager, MilestoneManage, MILESTONE_ALL,CaseTeamManager,TaskManager
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
from utils.send_mail import SendMail
from settings import DEFAULT_FROM_EMAIL
from cases.models import CASE_STATUS , CASE_TYPE,CaseMilestoneModel,CaseTaskModel
from cases.forms import AddCaseForm, MilestoneAddForm, MILESTONE_STATUS, TaskAddForm
from client.managers import ClientUserManager
from client.models import ClientModel
from object_log.models import LogAction
from object_log.models import LogItem
log = LogItem.objects.log_action
from utils.filewrapper_info import FixedFileWrapper


@login_required
def manage_cases(request):
    """
        renders page to list clients
    """
    context ={}

#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'add_casedetailmodel':False,'change_casedetailmodel':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    if request.method == "POST":
        request.method = "GET"

    if request.method == "GET":
        req_dict = {}
        req_dict['status'] = request.GET.get('status')
        req_dict['case_type'] = request.GET.get('case_type')
        req_dict['expiry_in'], req_dict['expiry_out'], req_dict['per_page'] = request.GET.get('expiry_in'), request.GET.get('expiry_out'),request.GET.get('numOfResults',25)
        req_dict['keyword'] = request.GET.get("keyword")
        req_dict['cur_page']=request.GET.get('page', 1)
        order=request.GET.get('order')
        try:
            req_dict['user_id']=request.user.id
        except:
            req_dict['user_id'] = ''

        obj = CaseManager()
        case_list = obj.get_all_cases(data_dict=req_dict)

        count=case_list.count()
        if req_dict['per_page']=='ALL':
            req_dict['per_page']=count


        #logic for sorting start here

        if request.GET.get('sort') == 'casid':
            if order=='asc':
                case_list = case_list.order_by("id")
            else:
                case_list = case_list.order_by("-id")

        if request.GET.get('sort') == 'casename':
            if order=='asc':
                case_list = case_list.order_by("name")
            else:
                case_list = case_list.order_by("-name")

        if request.GET.get('sort') == 'domain':
            if order=='asc':
                case_list = case_list.order_by("domain__name")
            else:
                case_list = case_list.order_by("-domain__name")

        if request.GET.get('sort') == 'type':
            if order=='asc':
                case_list = case_list.order_by("case_type")
            else:
                case_list = case_list.order_by("-case_type")

        if request.GET.get('sort') == 'datefound':
            if order=='asc':
                case_list = case_list.order_by("date_found")
            else:
                case_list = case_list.order_by("-date_found")

#        if request.GET.get('sort') == 'owner':
#            if order=='asc':
#                case_list = case_list.order_by("id")
#            else:
#                case_list = case_list.order_by("-id")

        if request.GET.get('sort') == 'budget':
            if order=='asc':
                case_list = case_list.order_by("budget")
            else:
                case_list = case_list.order_by("-budget")

        if request.GET.get('sort') == 'spendtodate':
            if order=='asc':
                case_list = case_list.order_by("spent_todate")
            else:
                case_list = case_list.order_by("-spent_todate")
        if request.GET.get('sort') =='status':
            if order=='asc':
                case_list = case_list.order_by("status")
            else:
                case_list = case_list.order_by("-status")

        #Get paginated result
        paginated = paginate(case_list,req_dict['cur_page'], req_dict['per_page'])
        cases = paginated.object_list
        #Get all case objects values
        cases_info = cases.values("id", "name", "domain_name","trademark","url","case_type","date_found","budget","spent_todate","infringer_name","company", "email","alt_email","phone","alt_phone","fax","notes","address","client","client_user__user__first_name","client_user__user__last_name","is_active","created","updated","status")
        paginated.object_list = cases_info


        if req_dict['keyword'] or req_dict['status'] or req_dict['case_type'] or req_dict['expiry_in'] or  req_dict['expiry_out']:
            if not cases_info:
                messages.warning(request,"No Records found!")
        context["is_selected"] = "currnt"
        context['order']="asc" if order=="desc" else "desc"
        context["result_set"] = paginated
        context["case_type"] = CASE_TYPE
        context["case_status"] = CASE_STATUS

    return render(request, "fn/cases/case_management.html", context)

@login_required
def export_cases(request):
    response= None
    if request.method =="GET":
        pass
    if request.method =="POST":
        #request dictionary
        req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
        try:
            req_dict['user_id']=request.user.id
        except:
            req_dict['user_id'] = ''
        data_dict = {}
        search = str(req_dict['search_data'])
        search_data = search.split('&')
        for item in search_data:
            item = item.split('=')
            data_dict[item[0]] = item[1]
        req_dict.update(data_dict)
        #get client information list
        obj = CaseManager()
        cases_data = obj.export_cases(req_dict)
        #Data required for creating spreadsheet
        sequence_list = SpreadsheetMapping.CASE_SEQUENCE_LIST
        title_dict = SpreadsheetMapping.CASE_TITLE_LIST
        #Create XLS
        if request.POST.get("format") == "xls":
            status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, cases_data, "cases_")
            msg = "Case XLS Export Successful." if status else "Error in Case XLS Export."
            try:
                log('EXPORT', request.user, request.user, data={'export':msg})
            except:
                pass
            if not status:
                pass
        #Create CSV
        elif request.POST.get("format") == "csv":
            status , response = CreateSpreadsheet.create_csv_file(sequence_list, title_dict , cases_data , settings.TEMP_DIR  + os.sep + "cases.csv" )
            if status:
                wrapper = FixedFileWrapper(file(settings.TEMP_DIR  + os.sep + "cases.csv"))
                filename = 'attachment; filename=' + str(time.strftime("Cases_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
                response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
                response['Content-Disposition'] = filename
            msg = "Case CSV Export Successful." if status else "Error in Case CSV Export."
            try:
                log('EXPORT', request.user,request.user,data={'export': msg})
            except:
                pass

    return response

@login_required
def add_case(request, **kwargs):
    """
        Add or edit a Client information
    """
 
    context = {}
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    try:
        user_id = request.user.id
    except:
        user_id = ''
    if request.method =='GET':
        addcaseform= AddCaseForm()
        context['addcaseform'] = addcaseform
        context["case_type"] = CASE_TYPE
        context["page_title"] = "File New Case"
        return render_to_response("fn/cases/add_case.html",context,RequestContext(request))

    if request.method=='POST':
        redirect_url = reverse("fn_managecases")
        filename = request.FILES.get("attachment" , '')
        req_dict = dict(zip(request.POST.keys(), request.POST.values()))
        obj = CaseManager()
        status, cases_data = obj.add_case(user_id, req_dict, filename)

        if status:
        	log('CREATE', request.user, cases_data,cases_data)
         	messages.add_message(request, messages.SUCCESS, "Case Successfully Created.")
     	else:
     		messages.add_message(request, messages.ERROR, "Internal error while creating Case.")

        return HttpResponseRedirect(redirect_url)

    return render_to_response("fn/cases/add_case.html",context,RequestContext(request))


@login_required
def view_case(request,case_id):
    """
       view case overview information
    """
    case_obj = CasedetailModel.objects.get(id =case_id)
    context = {}

    context['TOOLTIP_DICT'] = TOOLTIP_DICT
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    try:
        user_id = request.user.id
    except:
        user_id = ''
    try:
        current_user = request.user.first_name + " " +request.user.last_name
    except:
        current_user = ''
    if request.method =='GET':
        obj = CaseManager()
        cases_data = obj.get_case_info_by_id(case_id)
        case_attachments = obj.get_all_attachments_by_id(case_id)
        context['case_attachments'] = case_attachments
        context['case_info'] = cases_data
        context["case_type"] = CASE_TYPE
        context["case_status"] = CASE_STATUS
        context['current_user'] = current_user
        context['case_id'] = case_id
        return render_to_response("fn/cases/case_overview_tab.html",context,RequestContext(request))

    if request.method=='POST':
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        data_dict={}
        obj = CaseManager()
        status, cases_obj = obj.modify_case(case_id , req_dict, request.user.clientuser)
        if status:
        	log('EDIT', request.user, cases_obj, cases_obj,data={})
        	messages.add_message(request, messages.SUCCESS, "Case successfully updated.")
        else:
        	messages.add_message(request, messages.ERROR, "Internal error while updating Case.")

    return HttpResponseRedirect(request.META['HTTP_REFERER'])
#    return render_to_response("fn/cases/add_case.html",context,RequestContext(request))

@login_required
def view_case_infringer(request,case_id):
    """
        view case infringement information
    """
    case_obj = CasedetailModel.objects.get(id =case_id)
    context = {}
    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
    for i in request.user.user_permissions.all():
        if i.codename in permissions_list:
            permissions_list[i.codename] = True
    context['permissions'] = permissions_list
    context['TOOLTIP_DICT'] = TOOLTIP_DICT
    try:
        user_id = request.user.id
    except:
        user_id = ''

    try:
        current_user = request.user.first_name + " " +request.user.last_name
    except:
        current_user = ''
    if request.method =='GET':
        obj = CaseManager()
        cases_data = obj.get_case_info_by_id(case_id)
        case_notes = obj.get_case_notes_by_id(case_id)
        context['case_notes'] = case_notes
        context['case_info'] = cases_data
        context['current_user'] = current_user
        context['case_id'] = case_id
        return render_to_response("fn/cases/case_infringer_tab.html",context,RequestContext(request))

    if request.method=='POST':
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        data_dict={}
        obj = CaseManager()
        status, cases_obj = obj.modify_infringer(case_id , req_dict)
        if status:
			log('EDIT', request.user, case_obj,cases_obj, data={})
			messages.success(request,"Case Infringer successfully Updated.")
        else:
        	messages.error(request,"Internal error while updating Case Infringer.")

    return HttpResponseRedirect(request.META['HTTP_REFERER'])

@login_required
def edit_notes(request,case_id):
    """
        Edit Case Infrigement notes information
    """
    case_obj = CasedetailModel.objects.get(id =case_id)
    req_dict = dict(zip(request.POST.keys() , request.POST.values()))

    obj = CaseManager()
    if not req_dict['notes']:
    	messages.error(request,"Case infringer note is empty.")
    	return HttpResponseRedirect(request.META['HTTP_REFERER'])

    status, notes_obj = obj.add_notes(case_id , req_dict)
    if status:
		log('CREATE',request.user,case_obj, notes_obj)
		messages.success(request,"Case Infringer Note successfully Added.")
    else:
    	messages.error(request,"Internal error while adding Case Infringer Note.")

    return HttpResponseRedirect(request.META['HTTP_REFERER'])

@login_required
def delete_attachement(request, attachment_id):
    """
        Delete Case Attachments   """
    case_attch_obj=CaseAttachmentDetails.objects.get(id = attachment_id)
    case_obj=case_attch_obj.cases
    obj = CaseManager()
    delete_status = obj.delete_attachments_by_id(attachment_id)
    if delete_status:
        log('DELETE', request.user, case_obj, case_attch_obj)
    return HttpResponseRedirect(request.META['HTTP_REFERER'])

@login_required
def add_attachement(request, case_id):
    """
        Add attachments
    """
    case_obj = CasedetailModel.objects.get(id =case_id)
    file = request.FILES.get("attachmnet")
    obj = CaseManager()
    status, case_attachment_obj = obj.add_attachemnt(case_id, file)
    if status:
    	log('CREATE', request.user,case_obj, case_attachment_obj)
    return HttpResponseRedirect(request.META['HTTP_REFERER'])

@login_required
def delete_case(request, case_id):
    """
        renders page to list of users
    """
    context={}
    if request.method == 'GET':
        context['obj']={"id":case_id}
        delete_url = reverse("fn_deletecase", args=[case_id])
        case_obj = CaseManager()
        case = case_obj.get_case_info_by_id(case_id)
        context['post_url'] = delete_url
        context["message"] = "Are you sure you want to delete '"+str(case['name'])+"' case?"
        context['visible']=True

    if request.method == 'POST':
        redirect_url = reverse("fn_managecases")
        clientuser_id = request.POST.get('record_id')
        obj = CaseManager()
        stat, cases_data = obj.delete_case(case_id)
        messages.success(request, 'Case has been deleted successfully.')
        log('DELETE', request.user, cases_data, data = "Case has been deleted successfully.")
        return HttpResponseRedirect(redirect_url)
    return render_to_response('fn/cases/delete_case.html',context,RequestContext(request))

######### Milestone related functions start ###########

@login_required
def view_milestone(request, case_id=None, *args, **kwargs):
    """ Function to display list of milestones for perticular case """

    # define template
    template_name = 'fn/cases/milestone_view.html'
    context = {}
    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
    userpermissions = request.user.user_permissions.all().values_list("codename")
    userpermissions = [i[0] for i in userpermissions]
    for k, v in permissions_list.iteritems():
        if k in userpermissions:
            permissions_list[k] = True
    context['permissions'] = permissions_list

    if request.method == 'GET' :

        # get milestone
        milestone_object = MilestoneManage(case_id=case_id)
        milestone_status, milestone_list = milestone_object.get_by_case()
        milestone_list = milestone_list.values(*MILESTONE_ALL)

        context['milestone_list'] = milestone_list
        context['milestone_status'] = MILESTONE_STATUS

    context['case_id'] = case_id
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def add_milestone(request, case_id=None, *args, **kwargs):
    """ Function to add milestone """
    import ipdb
    ipdb.set_trace()
    case_obj = CasedetailModel.objects.get(id =case_id)
    # define template
    template_name = 'fn/cases/milestone_add.html'
    context = {}

    if request.method == 'GET' :
        milestone_form = MilestoneAddForm()

    if request.method == 'POST' :
        milestone_form = MilestoneAddForm(request.POST)
        if milestone_form.is_valid() :
            # get cleaned data
            data = milestone_form.cleaned_data

            # save milestone
            milestone_object = MilestoneManage(case_id=case_id)
            milestone_status, milestone = milestone_object.save(data=data)
            if milestone_status:
				log('CREATE', request.user, case_obj,milestone)
				messages.success(request,"Milestone successfully added.")
            else:
				messages.error(request,"Internal error while adding Milestone.")

            # set status
            context['status'] = milestone_status
        else:
        	#messages.error(request,"Internal error while adding Milestone.")
        	context['status'] = False

    context['case_id'] = case_id
    context['milestone_form'] = milestone_form
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def update_milestone(request, case_id=None, milestone_id=None, *args, **kwargs):
    """ Function to add milestone """
    # define template
    case_obj = CasedetailModel.objects.get(id =case_id)
    template_name = 'fn/cases/milestone_add.html'
    context = {}

    # create milestone object
    milestone_object = MilestoneManage(case_id=case_id)

    if request.method == 'GET' :
        milestone_dict = {}

        # get milestone object values
        milestone_dict = milestone_object.from_model(data=
                {'milestone': milestone_object.get_by_id(data={'milestone_id':milestone_id})[1]}
                )

        milestone_form = MilestoneAddForm(initial=milestone_dict)

    if request.method == 'POST' :
        milestone_form = MilestoneAddForm(request.POST)

        if milestone_form.is_valid() :
            # get cleaned data
            data = milestone_form.cleaned_data

            # add milestone object to cleaned data
            data['milestone'] = milestone_object.get_by_id(data={'milestone_id':milestone_id})[1]

            # update milestoen
            milestone_status, milestone = milestone_object.update(data=data)
            if milestone_status:
            	log('EDIT', request.user,case_obj,milestone, data={})
            	messages.success(request,"Milestone successfully updated.")
				# set status
                context['status'] = milestone_status
            else:
            	messages.error(request,"Internal error while updating Milestone.")
            	context['status'] = False
        else:
			messages.error(request,"Internal error while updating Milestone.")
			context['status'] = False

    context['update'] = True
    context['case_id'] = case_id
    context['milestone_id'] = milestone_id
    context['milestone_form'] = milestone_form
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def delete_milestone(request,case_id=None, milestone_id=None, *args, **kwargs):
    """ Function to delete Milestone """
    # define template
    case_obj = CasedetailModel.objects.get(id =case_id)
    template_name = 'fn/cases/milestone_view.html'
    context = {}
    data = {}

    if request.method == 'GET' :

        # get milestone object
        milestone_object = MilestoneManage(case_id=case_id)

        # add milestone object to cleaned data
        data['milestone'] = milestone_object.get_by_id(data={'milestone_id':milestone_id})[1]

        # delete milestone
        milestone_status = milestone_object.delete(data=data)

        log('DELETE', request.user,case_obj, data['milestone'], data = "Milestone has been deleted successfully.")

        # redirect
        return view_milestone(request, case_id=case_id)

    if request.method == 'POST' :
        pass

    context['case_id'] = case_id
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def view_case_team(request, case_id=None, *args, **kwargs):
    """ Function to display list of Team for particular case """
    case_obj = CasedetailModel.objects.get(id =case_id)
    context = {}
#    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
#    for i in request.user.user_permissions.all():
#        if i.codename in permissions_list:
#            permissions_list[i.codename] = True
#    context['permissions'] = permissions_list
    obj = CaseManager()
    client=obj.get_client_id(request.user.id)
    client_obj=ClientModel.objects.get(id=client)
    context['brand']=client_obj.name

    account_mgr_data=request.user.clientuser.client.accountmangers.values('user__first_name','user__email','user__userprofilemodel__phone','user__userprofilemodel__mobile', 'user__userprofilemodel__department','user__userprofilemodel__role')
    context['account_mgr_info'] = account_mgr_data[0] if account_mgr_data else {}
    if request.method =='GET':
        if request.GET.get('msg'):
            error_message = "Name & Email is required."
        else:
            error_message= ''
        obj = CaseTeamManager()
        cases_team_data = obj.get_case_team_info_by_id(case_id)

        context['case_id'] = case_id
        context['case_team_info']=cases_team_data
        context['error_message']= error_message
        return render_to_response("fn/cases/case_team_tab.html",context,RequestContext(request))

    if request.method=='POST':
        error_message = ''
        req_dict = dict(zip(request.POST.keys() , request.POST.values()))
        obj = CaseTeamManager()
        if req_dict.has_key('Save'):
            status, case_team_obj = obj.add_case_team(case_id , req_dict)
            if status:
            	log('CREATE', request.user,case_obj,case_team_obj)
                context['message']="Case Team successfully added."
                context['status'] = True
            	messages.add_message(request, messages.SUCCESS, "Team record Successfully Updated !")
            else:
            	messages.error(request,"Internal error while adding Case Team.")
                error_message = '?msg=error'
            context['message'] = "Team record Successfully Created !"
            context['status'] = True
            messages.add_message(request, messages.SUCCESS, "Team record Successfully Created !")
            redirect_url = request.META['HTTP_REFERER'].split('?')[0] + error_message # tmp fix for http referer
            redirect_url = request.META['HTTP_REFERER'] # tmp fix for http referer
            return HttpResponseRedirect(redirect_url)

        elif req_dict.has_key('Update'):
            cases_data = obj.restructure_request(req_dict)
            for data in cases_data:
                status, case_team_obj = obj.modify_case_team(data['team_id'], data)
                if status :
                    log('EDIT', request.user, case_obj,case_team_obj, data={})
                    context['message']="Case Team updated successfully."
                    context['status'] = True
                    messages.success(request,"Case Team updated successfully.")
                else :
                    messages.error(request,"Internal error while updating Case Team.")
                    error_message = '?msg=error'
                    context['message']="Internal error while updating Case Team."

                context['message'] = "Team record Successfully Updated !"
                context['status'] = True
                messages.add_message(request, messages.SUCCESS, "Team record Successfully Updated !")
            redirect_url = request.META['HTTP_REFERER'].split('?')[0] + error_message # tmp fix for http referer
            return HttpResponseRedirect(redirect_url)

        else:
            pass

         #cases_data = obj.restructure_request(req_dict)
#        print "restructured data" ,  cases_data
#        context['message'] = "Team record Successfully Created !"
        context['status'] = True
#        messages.add_message(request, messages.SUCCESS, "Team record Successfully Created !")
        redirect_url = request.META['HTTP_REFERER']
        return HttpResponseRedirect(redirect_url)


######### Milestone related functions end ###########

######### Task related functions start ###########

@login_required
def add_task(request, case_id=None,milestone_id=None, *args, **kwargs):
    """ Function to add task """
    case_obj = CasedetailModel.objects.get(id =case_id)
    # define template
    template_name = 'fn/cases/task_add.html'
    context = {}

    if request.method == 'GET' :
        task_form = TaskAddForm(case_id=case_id,client_id=request.user.clientuser.client_id)

    if request.method == 'POST' :
        task_form = TaskAddForm(request.POST,case_id=case_id,client_id=request.user.clientuser.client_id)

        if task_form.is_valid() :
            # get cleaned data
            data = task_form.cleaned_data

            data['milestone']=milestone_id
            # get milestone object
            milestone_object = MilestoneManage(case_id=case_id)
            milestone_status, milestone = milestone_object.get_by_id(data={'milestone_id':data['milestone']})

            # get client user object
            client_user_object = ClientUserManager()
            client_user_status, client_user = client_user_object.get_by_id(data={'client_user_id':data['client']})

            if milestone_status and client_user_status :
                # add to data
                data['milestone'] = milestone
                data['client_user'] = client_user

                # save milestone
                task_object = TaskManager()
                task_status, task = task_object.save(data=data)
                if task_status:
                	log('CREATE', request.user,case_obj,task)

            # set status
            context['status'] = True

    context['task_form'] = task_form
    context['case_id'] = case_id
    context['milestone_id'] = milestone_id
    return render_to_response(template_name,context,RequestContext(request))

def view_check_task(request,task_id):
    if task_id:
        task_object=CaseTaskModel.objects.get(id=task_id)
        task_object.status='1'
        task_object.save()

    return HttpResponse("True")

@login_required
def view_task(request, case_id=None, milestone_id=None, *args, **kwargs):
    """ Function to display list of milestones for perticular case """

    # define template
    template_name = 'fn/cases/task_view.html'
    context = {}
    permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'view_case':False,'change_case':False}
    for i in request.user.user_permissions.all():
        if i.codename in permissions_list:
            permissions_list[i.codename] = True
    context['permissions'] = permissions_list

    if request.method == 'GET' :
        # get tasks
        task_object = TaskManager()
        task_status, task_list = task_object.get_by_milestone(data={'milestone':milestone_id})



        #get a notes details of milstone
        milestone_object=CaseMilestoneModel.objects.get(id=milestone_id)
        notes=milestone_object.notes
        task_list = task_list.values('id','name','users__user__username','status','cases')

        # render task list
        context['task_list'] = task_list
        context['notes']=notes

#
    context['case_id'] = case_id
    context['milestone_id'] = milestone_id
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def update_task(request, case_id=None, milestone_id=None, task_id=None, *args, **kwargs):
    """ Function to update task """
    case_obj = CasedetailModel.objects.get(id =case_id)

    # define template
    template_name = 'fn/cases/task_add.html'
    context = {}

    # create milestone object
    task_object = TaskManager()

    if request.method == 'GET' :
        task_dict = {}

        # get task object values
        task_dict = task_object.from_model(data=
                {'task': task_object.get_by_id(data={'task_id':task_id})[1]}
                )

        task_form = TaskAddForm(initial=task_dict,case_id=case_id,client_id=request.user.clientuser.client_id)

    if request.method == 'POST' :
        task_form = TaskAddForm(request.POST,case_id=case_id,client_id=request.user.clientuser.client_id)

        if task_form.is_valid() :
            # get cleaned data
            data = task_form.cleaned_data

            data['milestone']=milestone_id
            # get milestone object
            milestone_object = MilestoneManage(case_id=case_id)
            milestone_status, milestone = milestone_object.get_by_id(data={'milestone_id':data['milestone']})

            # get client user object
            client_user_object = ClientUserManager()
            client_user_status, client_user = client_user_object.get_by_id(data={'client_user_id':data['client']})

            if milestone_status and client_user_status :
                # add to data
                data['milestone'] = milestone
                data['client_user'] = client_user

                # save milestone
                task_object = TaskManager()
                data['task'] = task_object.get_by_id(data={'task_id':task_id})[1]
                task_status, task = task_object.update(data=data)
                if task_status:
                	log('EDIT',request.user,case_obj,task, data={})


            # set status
            context['status'] = True

    context['update'] = True
    context['milestone_id'] = milestone_id
    context['task_id'] = task_id
    context['case_id'] = case_id
    context['task_form'] = task_form
    return render_to_response(template_name,context,RequestContext(request))

@login_required
def delete_task(request,case_id=None, task_id=None, *args, **kwargs):
    """ Function to delete Milestone """
    case_obj = CasedetailModel.objects.get(id =case_id)
    # define template
    template_name = 'fn/cases/milestone_view.html'
    context = {}
    data = {}

    if request.method == 'GET' :

        # get task object
        task_object = TaskManager()

        # add task object to cleaned data
        data['task'] = task_object.get_by_id(data={'task_id':task_id})[1]

        # delete task
        task_status  = task_object.delete(data=data)

        log('DELETE', request.user,case_obj, data['task'], data = "Task has been deleted successfully.")

        # redirect
        return view_milestone(request, case_id=case_id)

    if request.method == 'POST' :
        pass

    context['case_id'] = case_id
    return render_to_response(template_name,context,RequestContext(request))
######### Task related functions end ###########


def case_view_history(request, case_id=None, *args, **kwargs):
	"""
		Function to render the case HISTORY	"""
    	context={}
    	show=True
    	template_name = 'fn/cases/case_history_tab.html'

        log_items = LogItem.objects.filter(object_id1=case_id).order_by("-timestamp")
        per_page=int(request.GET.get('numOfResults',25))
    	cur_page = request.GET.get('page', 1)

    	paginated = paginate(log_items,cur_page, per_page)

    #	context['order']="asc" if order=="desc" else "desc"
    	context['case_id'] = case_id
    	context['result_set']=paginated
    	context['show']=show
    	context['context']=context
    	return render_to_response(template_name,context,RequestContext(request))
