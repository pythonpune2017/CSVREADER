'''
Created on 06-Jan-2012

@author: pritesh
'''
from models import *
from django.contrib import admin

admin.site.register(CasedetailModel)
admin.site.register(InfrigementNotesModel)
admin.site.register(CaseMilestoneModel)
admin.site.register(CaseTaskModel)

admin.site.register(CaseTeamModel)
admin.site.register(CaseAttachmentDetails)
