'''
Created on Apr 7, 2012

@author: shweta
'''
from django.conf.urls.defaults import patterns, include, url

urlpatterns = patterns('cases.views',
     url(r'^manage/$',                                  'manage_cases',               name="fn_managecases"),
     url(r'^add/$',                                     'add_case',                   name="fn_addcase"),
     url(r'^view/(?P<case_id>\d+)/$',                   'view_case',                  name="fn_viewcase"),
     url(r'^infringer/(?P<case_id>\d+)/$',              'view_case_infringer',        name="fn_viewcaseinfringer"),
     url(r'^team/(?P<case_id>\d+)/$',              'view_case_team',        name="fn_viewcaseteam"),
     url(r'^notes/(?P<case_id>\d+)/$',                  'edit_notes',                 name="fn_editnotes"),
     url(r'^attachement/add/(?P<case_id>\d+)/$',        'add_attachement',            name="fn_addattachment"),
     url(r'^attachement/delete/(?P<attachment_id>\d+)/$','delete_attachement',         name="fn_deleteattachements"),
     url(r'^export/$',                                  'export_cases',               name="fn_exportcases"),
     url(r'^delete/(?P<case_id>\d+)/$',                   'delete_case',                  name="fn_deletecase"),
     # url for milestone
     url(r'^(?P<case_id>\d+)/milestone/view/','view_milestone',name="fn_view_milestone"),
     url(r'^(?P<case_id>\d+)/milestone/add/','add_milestone',name="fn_add_milestone"),
     url(r'^(?P<case_id>\d+)/milestone/update/(?P<milestone_id>\d+)/','update_milestone',name="fn_update_milestone"),
     url(r'^(?P<case_id>\d+)/milestone/delete/(?P<milestone_id>\d+)/','delete_milestone',name="fn_delete_milestone"),

     # url for task
     url(r'^check/(?P<task_id>\d+)','view_check_task',name="fn_task_check"),
     url(r'^(?P<case_id>\d+)/(?P<milestone_id>\d+)/task/add/','add_task',name="fn_add_task"),
     #url(r'^(?P<case_id>\d+)/task/add/','add_task',name="fn_add_task"),
     url(r'^(?P<case_id>\d+)/(?P<milestone_id>\d+)/task/view/','view_task',name="fn_view_task"),
     url(r'^(?P<case_id>\d+)/(?P<milestone_id>\d+)/(?P<task_id>\d+)/task/update/','update_task',name="fn_update_task"),
     url(r'^(?P<case_id>\d+)/(?P<task_id>\d+)/task/delete/','delete_task',name="fn_delete_task"),
#     url(r'^import/$',                                  'import_vendors',               name="fn_importvendor"),
#     url(r'^download/(?P<format>\w+)/$',                'download_vendor_spreadsheet',  name="fn_downloadvendorformat"),

      # url for history
      url(r'^(?P<case_id>\d+)/history/view/','case_view_history',name="fn_view_case_history"),


     )

