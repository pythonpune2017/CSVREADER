# Create your views here.
from django.views.decorators.csrf import csrf_protect, csrf_exempt
import os
import time
from django.shortcuts import render_to_response,render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import RequestContext
from django.db.models import Q
from django.conf import settings
from client.models import ClientModel, ClientUser
from django.db import models
from trademark.models import *
from domain.models import GlobalDomains

CASE_STATUS = (
(u'open', u'Open'),
(u'pursuing', u'Pursuing'),
(u'onhold', u'On Hold'),
(u'closed', u'Closed')
)

CASE_TYPE = (
(u'brand', u'BRAND'),
(u'trademark', u'TRADEMARK'),
(u'domain', u'DOMAIN')
)

from django.core.files.storage import FileSystemStorage

fs = FileSystemStorage(location=settings.MEDIA_ROOT)

import os


# Create your models here.
class CasedetailModel(models.Model) :
    """Case Overview Details """

    name= models.CharField("Case name",max_length=50)
    domain = models.ForeignKey(GlobalDomains, blank=True,null=True)
    trademark = models.ForeignKey(Trademark , blank=True,null=True)
    domain_name= models.CharField("Domain name",max_length=100, blank=True,null=True)  # if domain is there.
    tm_number=models.CharField(max_length=10, db_index=True,blank=True,null=True)   # if trademark is there
    tm_name=models.TextField(max_length=2000, blank=True,null=True)   #  if trademark is there
    url=models.URLField("URL",verify_exists=False) # brand is there

    case_type = models.CharField(max_length=10,choices=CASE_TYPE)  # case_type
    date_found=models.DateTimeField(auto_now_add = True)
    budget=models.DecimalField(max_digits=9, decimal_places=2,blank=True,null=True)
    spent_todate=models.DecimalField(max_digits=9, decimal_places=2,blank=True,null=True)
    infringer_name=models.CharField("InfringerName",max_length=50,blank=True,null=True)
    company=models.CharField("Company name",max_length=50,blank=True,null=True)
    email=models.CharField("Email", max_length=100,blank=True,null=True)
    alt_email=models.CharField("Email", max_length=100,blank=True,null=True)
    phone=models.CharField(max_length=20,blank=True,null=True)
    alt_phone=models.CharField(max_length=20,blank=True,null=True)
    fax=models.CharField(max_length=20, blank=True,null=True)
    notes = models.TextField(max_length=500 ,blank=True,null=True)
    address=models.CharField(max_length=50,blank=True,null=True)
    client = models.ForeignKey(ClientModel)
    client_user = models.ForeignKey(ClientUser)
    status = models.CharField(max_length=10,choices=CASE_STATUS)
    foundby=models.CharField(max_length=50,blank=True,null=True)

    is_active = models.BooleanField(default=True, help_text="is case is active")
    is_deleted = models.BooleanField(default=False, help_text="")
    created = models.DateTimeField('Created Date' ,auto_now_add = True)
    updated = models.DateTimeField('Updated' ,auto_now = True)

    def __unicode__(self):
        return u'%s' % (self.name)



class CaseAttachmentDetails(models.Model):
    """ Case Attachment Details """

    def get_upload_path(self, filename):
        """Upload path  """

        return os.path.join("cases/%d" % self.cases.id,filename)

    cases=models.ForeignKey(CasedetailModel)
    attachment = models.FileField(storage=fs, upload_to=get_upload_path, null=True, blank = True)
    def __unicode__(self):
        return u'%s' % (self.cases)


class InfrigementNotesModel(models.Model):

    """ Infrigement Notes Detail """
    notes = models.TextField(max_length=500 ,blank=True,null=True)
    cases=models.ForeignKey(CasedetailModel)
    created = models.DateTimeField('Created Date' ,auto_now_add = True)
    updated = models.DateTimeField('Updated' ,auto_now = True)
    def __unicode__(self):
        return str(self.cases)


class CaseTeamModel(models.Model):
    """ Case Team Details """

    cases=models.ForeignKey(CasedetailModel)
    name=models.CharField("Name",max_length=80)
    title=models.CharField("Title",max_length=80)
    department=models.CharField("Department",max_length=80)
    company=models.CharField("Company name",max_length=50)
    email=models.CharField("Email", max_length=100)
    phone=models.CharField("Phone No",max_length=20,blank=True,null=True)


class CaseMilestoneModel(models.Model):
    """ Case MilestoneDetail """
    MILSTONE_STATUS = (
                                    (u'0', u'Closed'),
                                    (u'1', u'Open'),
                                    (u'2', u'In Progress')
                                )
    cases=models.ForeignKey(CasedetailModel)
    name= models.CharField("Name",max_length=80)
    due_date=models.DateTimeField("Due Date")
    notes = models.TextField(max_length=500 ,blank=True,null=True)
    status=models.CharField(max_length=10,choices=MILSTONE_STATUS)
    is_active = models.BooleanField(default=True, help_text="is Milestone is active")
    is_deleted = models.BooleanField(default=False, help_text="is Milestone is delete")
    created = models.DateTimeField('Created Date' ,auto_now_add = True)
    updated = models.DateTimeField('Updated' ,auto_now = True)

    def __unicode__(self):
        return u'%s' % (self.name)

class CaseTaskModel(models.Model):
    """ Case MilestoneTask Details """
    TASK_STATUS = (
                                (u'0', u'Open'),
                                (u'1', u'Close')
                                )
    name= models.CharField("Name",max_length=80)
    users=models.ForeignKey(ClientUser)
    cases=models.ForeignKey(CaseMilestoneModel)
    status=models.CharField(max_length=10,choices=TASK_STATUS)
    is_active = models.BooleanField(default=True, help_text="is Milestone is active")
    is_deleted = models.BooleanField(default=False, help_text="is Milestone is delete")
    created = models.DateTimeField('Created Date' ,auto_now_add = True)
    updated = models.DateTimeField('Updated' ,auto_now = True)

    def __unicode__(self):
        return str(self.name)


