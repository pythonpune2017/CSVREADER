from django import forms
from django.contrib.auth.models import User
from django.utils.translation import ugettext, ugettext_lazy as _
from django.contrib.auth import authenticate
from django.core import validators
import re
from cases.models import *
from cases.case_manager import CaseManager, MilestoneManage
from client.managers import ClientUserManager


OWNER = [('','Select'), (1,'ALL')]
STATUS = [('','Select'),(u'open', u'Open'),(u'pursuing', u'Pursuing'),(u'onhold', u'On Hold'),(u'closed', u'Closed')]
MILESTONE_STATUS = [('','Select'),('0','Closed'),('1','Open'),('2','In Progress')]
TASK_STATUS =[('','Select'),('0', 'Open'),('1','Close')]


class AddCaseForm(forms.Form):
    """
    'id':'speedD',
    """
    name = forms.CharField(label="Case Name:", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                error_messages = {'invalid': 'This field is required.'}
                                )
    owner = forms.ChoiceField(choices=OWNER,
                             widget=forms.Select(attrs={ 'class':'add_use_drop_SSL webip_select_pop','id':"speedA"}),
                             label=_("Case Owner:"),required = False,
                             error_messages = {'invalid': 'This field is required.'}
                             )
    budget = forms.DecimalField(label="Budget:", required = False, max_digits=9, decimal_places=2,
                             widget=forms.TextInput(attrs={'class':'file_inputsmall'}),
                             error_messages = {'invalid': 'This field is required.'}
                             )
    spent_date = forms.DecimalField(label="Spent To Date :", required = False,max_digits=9, decimal_places=2,
                                    widget=forms.TextInput(attrs={'class':'file_inputsmall'}),
                                    error_messages = {'invalid': 'This field is required.'}
                                    )
    status = forms.ChoiceField(choices=STATUS, label="Status:", required = True,
                             widget=forms.Select(attrs={'class':'add_use_drop_SSL webip_select_pop','id':"speedA"}),
                             error_messages = {'invalid': 'This field is required.'}
                             )
    infringer_name = forms.CharField(label="Infringer Name:", max_length=50, required = False,
                                     widget=forms.TextInput(attrs={'class':'login_input'}),
                                     error_messages = {'invalid': 'This field is required.'}
                                     )
    company = forms.CharField(label="Company:", max_length=50, required = False,
                              widget=forms.TextInput(attrs={'class':'login_input '}),
                              error_messages = {'invalid': 'This field is required.'}
                              )
    email = forms.EmailField(widget=forms.TextInput(attrs={'class':'login_input'}), max_length=75,label=_("Email:"),required = False,
                             error_messages={'required':"This field is required."})
    alt_email = forms.EmailField(widget=forms.TextInput(attrs={'class':'login_input'}), max_length=75,label=_("Alt Email:"),
                                 required=False)

    phone = forms.CharField(max_length=15,widget=forms.TextInput(attrs={'class':'login_input'}),required=False,
                                label=_("Phone:"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Phone must be numeric'}
                                )
    alt_phone = forms.CharField(max_length=15,widget=forms.TextInput(attrs={'class':'login_input'}),required=False,
                                label=_("Alt Phone:"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')]
                                )
    fax = forms.CharField(label="Fax:", max_length=50, required = False,
                          widget=forms.TextInput(attrs={'class':'login_input'})
                          )
    address = forms.CharField(label="Address:", max_length=50, required = False,
                              widget=forms.TextInput(attrs={'class':'login_input'}),
                              error_messages = {'invalid': 'This field is required.'}
                              )
    notes = forms.CharField(label="Notes:", max_length=50, required = False,
                              widget=forms.Textarea(attrs={'class':'cases_notes_textarea'})
                              )

    def __init__(self, *args, **kwargs):
        super(AddCaseForm, self).__init__(*args, **kwargs)

    def clean(self):
        """ Clean add case form """
        return self.cleaned_data

class MilestoneAddForm(forms.Form):
    """ Class for Milestone Add Form """

    def __init__(self,data=None, initial=None, case_id=None,client_id=None):
        """ Constructor for MilestoneAddForm """

        if initial :
            # convert date
            initial['due_date'] = initial['due_date'].strftime("%d-%m-%Y")

        # override forms.Form constructor
        super(MilestoneAddForm,self).__init__(data=data,initial=initial)


    name = forms.CharField(label="Name:", max_length=100, required = True,
            widget=forms.TextInput(attrs={'class':'login_input'}),
            error_messages = {'required': 'Name is required.'}
            )
    due_date = forms.CharField(label="Due Date:", max_length=50, required = True,
            widget=forms.TextInput(attrs={'class':'txtbox_cale datepicker'}),
            error_messages = {'required': 'Due date is required.'}
            )
    notes = forms.CharField(label="Notes:", max_length=100, required = False,
            widget=forms.Textarea(attrs={'class':'textarea'}),
            )
    status = forms.ChoiceField(choices=MILESTONE_STATUS,label="Status",widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL'}),
            required = False,
            )

    def clean(self):
        """ Method for form validation """
        error_message = ''

        # validate status
        status = self.cleaned_data['status']
        if status not in [ str(i[0]) for i in MILESTONE_STATUS[1:] ] :
            error_message = "Please select valid option."
            self._errors['status'] = error_message

        return self.cleaned_data

class TaskAddForm(forms.Form):
    """ Class for Milestone Add Form """

    def __init__(self,data=None, initial=None, case_id=None,client_id=None):
        """ Constructor for TaskAddForm """

        # override forms.Form constructor
        super(TaskAddForm,self).__init__(data=data,initial=initial)

        self.client_id = client_id
        self.case_id = case_id

        if self.case_id :
            # get CasedetailModel object
            case_object = CaseManager()
            self.case_status, self.case = case_object.get_by_id(data={'case_id':self.case_id})
            if not self.case_status :
                self.case = self.case_id

            # get Milestone objects
#            milestone_object = MilestoneManage(case_id=self.case_id)
#            milestone_list = milestone_object.get_by_case()[1]
            # get values
#            milestone_list = list (milestone_list.values_list('id','name'))
            # add default
#            milestone_list.insert(0, ('','Select') )
            # assign to milestone list
#            self.fields['milestone'].choices = milestone_list

        if self.client_id :
            # create client user object
            client_user_object = ClientUserManager()
            client_user_list = client_user_object.get_by_client(data={'client':self.client_id})[1]
            # get values
            client_user_list = list (client_user_list.values_list('id','user__username'))
            # add default
            client_user_list.insert(0, ('', 'Select'))
            # assign to client
            self.fields['client'].choices = client_user_list



    name = forms.CharField(label="Name", max_length=100, required = True,
            widget=forms.Textarea(attrs={'class':'textarea'}),
            error_messages = {'required': 'Name is required.'}
            )
    client = forms.ChoiceField(label="Assigned",widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL'}),
            required = False,
            )
#    milestone = forms.ChoiceField(label="Milestone",widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL'}),
 #           required = False,
  #          )
    status = forms.ChoiceField(choices=TASK_STATUS,label="Status",widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop_SSL'}),
            required = False,
            )


    def clean(self):
        """ Method for form validation """
        error_message = ''

        # validate client
        client = self.cleaned_data['client']
        if client not in [ str(i[0]) for i in self.fields['client'].choices[1:] ] :
            error_message = "Please select valid option."
            self._errors['client'] = error_message

        # validate milestone
#        milestone = self.cleaned_data['milestone']
#        if milestone not in [ str(i[0]) for i in self.fields['milestone'].choices[1:] ] :
#            error_message = "Please select valid option."
#            self._errors['milestone'] = error_message

        return self.cleaned_data
