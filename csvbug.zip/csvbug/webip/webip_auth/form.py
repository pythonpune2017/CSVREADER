from django import forms
from django.contrib.auth.models import User
from django.utils.translation import ugettext, ugettext_lazy as _
from django.contrib.auth import authenticate
from utils.random_generator import RandomGenerator
from django.forms.util import flatatt
from django.template import loader
from django.utils.encoding import smart_str
from django.utils.http import int_to_base36
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext, ugettext_lazy as _
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from datetime import date
from dateutil.relativedelta import relativedelta
#from django.contrib.auth.hashers import UNUSABLE_PASSWORD, is_password_usable, get_hasher
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.models import get_current_site
from django.utils.translation import ugettext_lazy as _
from client.models import *
from django import forms
from django.core import validators
import re
from captcha.fields import CaptchaField
from  authmanager import RegistrationManager
import ast
from admin_app.form import AlertForm, PremissionsForm, DomainCategoryForm
from admin_app.models import *
import os
import json

#attrs_dict = {'class': 'required'}
class LoginForm(forms.Form):
    username = forms.CharField(max_length=100)
    password = forms.CharField(widget=forms.PasswordInput(render_value=False),max_length=100 )

    def clean(self):

        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')
        error_message = ''
        if not username and not password:
            raise forms.ValidationError("Please enter the Email Address and Password")
        if not username:
            raise forms.ValidationError( "Email Address is required")
        if not password:
            raise forms.ValidationError("Password is required")

       

        if username and password:
            self.user = authenticate(username=username, password=password)
            if self.user is None:
                raise forms.ValidationError("Your Email Address or password is incorrect.")
            elif not self.user.is_active:
                raise forms.ValidationError("Your account is inactive.")

        return self.cleaned_data

class PasswordResetForm(forms.Form):
        error_messages = {
            'unknown': _("That e-mail address doesn't have an associated "
                         "user account."),
           'unusable': _("The user account associated with this e-mail "
                          "address cannot reset the password."),
        }
        email = forms.EmailField(label=_("E-mail"), max_length=75)

        def clean_email(self):
            """ Validates that an active user exists with the given email address."""
            email = self.cleaned_data["email"]
            self.users_cache = User.objects.filter(email__iexact=email,
                                                       is_active=True)
            if not len(self.users_cache):
                raise forms.ValidationError("That e-mail address doesn't have an associated user account.")
            return email


class ResetNewPasswordForm(forms.Form):

    new_password1 = forms.CharField(widget=forms.PasswordInput, label=_("Password"))
    new_password2 = forms.CharField(widget=forms.PasswordInput, label=_("Password (again)"))

    def clean(self):
        """
        Verify that the 2 passwords fields are equal
        """
        if self.cleaned_data.get("new_password1") == self.cleaned_data.get("new_password2"):
            return self.cleaned_data
        else:
            raise forms.ValidationError(_("The passwords inserted are different."))

class RegisterAccountForm(forms.Form):

    company_name = forms.CharField(label="Brand Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z]'), code='invalid')],
                                error_messages = {'invalid': 'CompanyName must be alphabetic'}
                                )

    country = forms.ModelChoiceField(queryset = CountryModel.objects.all().order_by('country_name'),label=_("Country") )

    first_name = forms.CharField(label="First Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Client First Name must be alphanumeric'} ,


                                )

    last_name = forms.CharField(label="Last Name", max_length=50, required = True,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Client Last Name must be alphanumeric'},

                                )



    email = forms.EmailField(widget=forms.TextInput(attrs={'class':'login_input'}), max_length=75,label=_("E-mail"),
                             error_messages={'required':"Email is required"})
    email1 = forms.EmailField(widget=forms.TextInput(attrs={'class':'login_input'}), max_length=75,label=_("Conform E-mail"),
                             error_messages={'required':"Email is required"})


    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'login_input'}, render_value=False),
                                label=_(u'password'))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'class':'login_input'}, render_value=False),
                                label=_(u'Conform password '))

    captcha = CaptchaField()

    tos = forms.BooleanField(widget=forms.CheckboxInput(attrs={'class':'login_chk'}),
                             label=_(u'I have read and agree to the Terms of Service'),
                             error_messages={ 'required': u"You must agree to the terms to register" })


    def __init__(self, *args, **kwargs):
        super(RegisterAccountForm, self).__init__(*args, **kwargs)
        self.fields['country'].empty_label = 'Please Select'


#    def clean_email(self):
#        """  Validates that an active client exists with the given email address."""
#        email = self.cleaned_data["email"]
#        try:
#            if not len(self.cleaned_data['id']):
#                self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
#                if len(self.client_cache):
#                    for user_id in self.client_cache:
#                        client=ClientUser.objects.filter(user=user_id)
#                        if client:
#                            raise forms.ValidationError("The e-mail address already associated with other Client Account.")
#                if self.cleaned_data['id']:
#                    client=ClientUser.objects.filter(user__email=self.cleaned_data["email"])
#                    if not client:
#                        self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
#                    if len(self.client_cache):
#                        for user_id in self.client_cache:
#                            client=ClientUser.objects.filter(user=user_id)
#                            if client:
#                                raise forms.ValidationError("The e-mail address already associated with other Client Account.")
#        except:
#            raise
#
#        return email


    def clean(self):
        """
        Verifiy that the values entered into the two password fields
        match. Note that an error here will end up in
        ``non_field_errors()`` because it doesn't apply to a single
        field.

        """
        if self.cleaned_data.has_key('email'):
            try:
                user_obj = User.objects.get(email=self.cleaned_data.get('email'))
                if user_obj:
                    self._errors['email'] = 'Email ID is already exist.'
            except:
                pass

        if 'email' in self.cleaned_data and 'email1' in self.cleaned_data:
            if self.cleaned_data['email'] != self.cleaned_data['email1']:
                self._errors['email'] = 'You must type the same Email each time'


        if 'password1' in self.cleaned_data and 'password2' in self.cleaned_data:
            password1 = self.cleaned_data['password1']
            password2 = self.cleaned_data['password2']
            if password1 != password2:
                self._errors['password1'] = 'You must type the same Password each time'

        return self.cleaned_data

    def save(self, form=None):
        """ registration form save method """
        data = self.cleaned_data
        try:
            reg_profile_obj=RegistrationManager()
            username = RandomGenerator().username_generator()
            new_user=reg_profile_obj.create_inactive_user(username=username,
                                                                    password=self.cleaned_data['password1'],
                                                                    email=self.cleaned_data['email'],
                                                                    first_name=self.cleaned_data['first_name'],
                                                                    last_name=self.cleaned_data['last_name']
                                                                    )

            #logic to create a client
            try:
                country_obj=CountryModel.objects.get(id=self.cleaned_data['country'].id)
                currency_obj=CurrencyModel.objects.get(currency_code='AUD')
                client_record=ClientModel(name=self.cleaned_data['company_name'],country=country_obj,currency=currency_obj,user=new_user,is_active=False)
                client_record.save()
                user_profile_obj = UserProfileModel(user=new_user)
                user_profile_obj.save()
                clientuser_record=ClientUser(user=new_user,client=client_record,user_type='superuser')
                clientuser_record.save()
                clientprofile_obj=ClientUserProfile(client=clientuser_record)
                clientprofile_obj.save()
                plan=SubcriptionPlan.objects.get(name='30 Day Trail')
                start_date = date.today()
                expiry_date = start_date + relativedelta(days = +30 )
#                datetimeobj = datetime.strptime(expiry_date, '%d-%m-%y')
                client_plan = ClientSubscription(client=client_record, plan=plan)
                client_plan.expiry_date=expiry_date
                client_plan.is_active = True
                client_plan.save()
            except Exception, e:
                print "exceptio",str(e)
                client_record.delete()
                clientuser_record.delete()
                clientprofile_obj.delete()
                client_plan.delete()
                pass
                
    #logic to create client end
            
            
            return new_user
        except:
            raise
        #needs to be handlded


class ChangeUsernameForm(forms.Form): # Inherit SSL Form
    """ Form used to change username """

    def __init__(self, *args, **kwargs) :
        """ Constructor for AddForm """
        forms.Form.__init__(self,*args, **kwargs)

    Email = forms.EmailField(widget=forms.TextInput(attrs={'class':'popinput'}), required = False, max_length=75,label=_("E-mail"),
                             error_messages={'required':"Email is required"})
    Username = forms.CharField(label="UserName", required =True, max_length=50,
                                widget=forms.TextInput(attrs={'class':'popinput'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Username must be alphanumeric'})


class ChangePasswordForm(forms.Form): # Inherit SSL Form
    """ Form used to add event """

    def __init__(self, *args, **kwargs) :
        """ Constructor for AddForm """
        forms.Form.__init__(self,*args, **kwargs)

    currentpassword = forms.CharField(label="Current Password", max_length=50, required = False,
                                widget=forms.PasswordInput(attrs={'class':'login_input'}))
    newpassword = forms.CharField(label="New Password", required = False, max_length=50,
                                widget=forms.PasswordInput(attrs={'class':'login_input'}))
    confirmpassword = forms.CharField(label="Confirm Password", max_length=50, required = False,
                                widget=forms.PasswordInput(attrs={'class':'login_input'}))


    def clean(self):
        """ Method to validation form
          add a json.dump as ast.evl required python expresssion in string"""

        error_message = ''
        #currentpassword = ast.literal_eval(self.cleaned_data.get('currentpassword'))[0]
        currentpassword = ast.literal_eval(json.dumps(self.cleaned_data.get('currentpassword')))
        user = self.data.get('user')
        if not currentpassword:
            error_message = "Current Password is required"
            self._errors['currentpassword'] = error_message
        else:
            if not user.check_password(currentpassword):
                error_message = "Current Password does not exist."
                self._errors['currentpassword'] = error_message

#        newpassword = ast.literal_eval(self.cleaned_data.get('newpassword'))[0]
        newpassword = ast.literal_eval(json.dumps(self.cleaned_data.get('newpassword')))
        if not newpassword:
            error_message = "New Password is required"
            self._errors['newpassword'] = error_message

#        confirmpassword = ast.literal_eval(self.cleaned_data.get('confirmpassword'))[0]
        confirmpassword = ast.literal_eval(json.dumps(self.cleaned_data.get('confirmpassword')))
        if not currentpassword:
            error_message = "Confirm Password is required"
            self._errors['confirmpassword'] = error_message

        if not newpassword == confirmpassword:
            error_message = "New Password and Confirm Password are not matched !"
            self._errors['newpassword'] = error_message
        return self.cleaned_data


class AddUserForm(AlertForm, PremissionsForm):

    STATUS = (
    (True, "Active"),
    (False,"Inactive")
    )

    USER_TYPE = (
#    ("superuser","superuser"),
    ("subuser","subuser"),
    )


    STAFF_CHOICE = (
    ('admin', 'Admin.'),
    ('accountmanager', 'Account Manager'),
    )

    frequency_list = (
    ('none','please select'),
    ('daily', 'Once in Day'),
    ('weekly', 'Once in Week'),
    ('monthly', 'Once in Month'),
    ('yearly', 'Once in Year'),
)




    id = forms.CharField(label="id",widget=forms.HiddenInput(),required = False)
    username = forms.CharField(label="Username", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}))
    role = forms.CharField(label="Role", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                )
    department = forms.CharField(label="Department", max_length=50, required = False,
                                widget=forms.TextInput(attrs={'class':'login_input'}),
                                validators=[validators.RegexValidator(regex=re.compile('[A-Za-z0-9]'), code='invalid')],
                                )
    email = forms.EmailField(widget=forms.TextInput(attrs={'class':'login_input'}), max_length=75,label=_("E-mail"),required=False)
    password = forms.CharField(required = False, widget=forms.PasswordInput(attrs={'class':'file_inputsmall2'}), label=_("Password"))
    phone = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'login_input'}),required=True,
                                label=_("Phone"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                error_messages = {'invalid': 'Phone must be numeric'}
                                )
    mobile = forms.CharField(max_length=15,
                                widget=forms.TextInput(attrs={'class':'login_input'}),required=False,
                                label=_("Mobile"),validators=[validators.RegexValidator(regex=re.compile('[0-9]'), code='invalid')],
                                )
    status=forms.ChoiceField(choices=STATUS,
                             widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop webip_select_pop'}),
                                label=_("Status"),required = False)
    user_type=forms.ChoiceField(choices=USER_TYPE,
                             widget=forms.Select(attrs={'id':'speedD', 'class':'add_use_drop webip_select_pop'}),
                                label=_("User Type"),required = False)

#    domain_category=forms.MultipleChoiceField( label=_("Domain Category"),required = False,choices=('',''))
    upload_image = forms.CharField(label="Photo", required = False,
                                widget=forms.FileInput(attrs={'class':'myacc_input font_size_11'}))

    def __init__(self, *args, **kwargs):
        self.edit = kwargs.pop('edit',False)
        super(AddUserForm, self).__init__(*args, **kwargs)
        #AlertForm.__init__(self)
        #self.fields['currency'].empty_label = 'Please Select'

    def clean(self):
        """ Method to validation form"""
        error_message = ''
        AlertForm.clean(self)
        username = self.cleaned_data.get('username')
        email = self.cleaned_data.get('email')
        password = self.cleaned_data.get('password')
        try :
            user_name = User.objects.get(username=username)
        except :
            user_name = None
        try :
            user_email = User.objects.get(email=email)
        except :
            user_email = None
        if not self.edit:
            if user_name:
                error_message = "Username is already exist"
                self._errors['username'] = error_message
            if user_email:
                error_message = "Email is already exist"
                self._errors['email'] = error_message
            if not email:
                error_message = "Email ID is required"
                self._errors['email'] = error_message
            if not password:
                error_message = "Password is required"
                self._errors['password'] = error_message
            if not username:
                error_message = "Username is required"
                self._errors['username'] = error_message
        return self.cleaned_data

    def clean_password(self):
        password=self.cleaned_data['password']
        try:
            if not self.edit:
                if not len(self.cleaned_data['id']):
                    if not password:
                        raise forms.ValidationError("please enter the password")
        except:
            raise

        return password
    """
    def clean_email(self):
        email = self.cleaned_data["email"]
        try:
            if not len(self.cleaned_data['id']):
                self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
                if len(self.client_cache):
                    for user_id in self.client_cache:
                        client=ClientUser.objects.filter(user=user_id)
                        if client:
                            raise forms.ValidationError("The e-mail address already associated with other Client Account.")
                if self.cleaned_data['id']:
                    client=ClientUser.objects.filter(user__email=self.cleaned_data["email"])
                    if not client:
                        self.client_cache = User.objects.filter(email__iexact=email,is_active=True)
                    if len(self.client_cache):
                        for user_id in self.client_cache:
                            client=ClientUser.objects.filter(user=user_id)
                            if client:
                                raise forms.ValidationError("The e-mail address already associated with other Client Account.")
        except:
            raise

        return email
        """

class EditProfilerForm(AddUserForm):
        """ Render the Edit profile form for the frontend application """

        STAFF_CHOICE = (
        ('admin', 'Admin.'),
        ('accountmanager', 'Account Manager'),
        )

        frequency_list = (
        ('none','please select'),
        ('daily', 'Once in Day'),
        ('weekly', 'Once in Week'),
        ('monthly', 'Once in Month'),
        ('yearly', 'Once in Year'),
        )

        id = forms.CharField(label="id",widget=forms.HiddenInput(),required = False)
        name = forms.CharField(label="Name", max_length=50, required = False,
                                    widget=forms.TextInput(attrs={'class':'login_input'}))

        def __init__(self, *args, **kwargs):
            self.editprofile = kwargs.get('edit', False)
            super(EditProfilerForm, self).__init__(*args, **kwargs)
            #AlertForm.__init__(self)
            #self.fields['currency'].empty_label = 'Please Select'


        def clean(self):
            """ Method to validation form"""
            error_message = ''
            AlertForm.clean(self)
            username = self.cleaned_data.get('username')
            email = self.cleaned_data.get('email')
            password = self.cleaned_data.get('password')
            try :
                user_name = User.objects.get(username=username, is_deleted=True)
            except :
                user_name = None
            try :
                user_email = User.objects.get(email=email)
            except :
                user_email = None
            if not self.editprofile:
                if user_name:
                    error_message = "Username is already exist"
                    self._errors['username'] = error_message
                else:
                    if user_email:
                        error_message = "Email is already exist"
                        self._errors['email'] = error_message
                if not email:
                    error_message = "Email ID is required"
                    self._errors['email'] = error_message
                if not password:
                    error_message = "Password is required"
                    self._errors['password'] = error_message
                if not username:
                    error_message = "Username is required"
                    self._errors['username'] = error_message
            return self.cleaned_data
