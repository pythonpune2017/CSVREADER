from django.conf.urls.defaults import patterns, include, url


urlpatterns = patterns('webip_auth.views',
    
    url(r'^$','login',{'template':'fn/login.html'},name="index"),
    url(r'^passwordreset/$','user_password_reset',name="password_reset"),
    url(r'^passwordreset/done/$','user_password_reset_done',name="password_reset_done"), 
    url(r'^password/reset/confirm/(?P<uidb36>[0-9A-Za-z]+)-(?P<token>.+)/$','user_password_reset_confirm',name="password_reset_conform"),
    url(r'^password/reset/confirm/done/$','user_password_reset_complete',name="resetdone"),
    url(r'^logout/$','logout_view',{'redirect_to':'index'},name="logout"),
    
     )
