# Create your views here.
from django.shortcuts import render_to_response
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User,check_password,Group
from django.template import RequestContext
from django.contrib.auth import logout
from django.contrib.auth import login as auth_login
from django.shortcuts import render_to_response
from django.core.urlresolvers import reverse
from webip_auth.form import LoginForm
from webip_auth.form import PasswordResetForm
from webip_auth.form import ResetNewPasswordForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm, SetPasswordForm
from django.contrib.auth.views import password_reset,password_reset_done,password_reset_confirm, password_reset_complete
from django.contrib.auth.tokens import default_token_generator
from django.views.decorators.csrf import csrf_protect
from webip_auth.form import RegisterAccountForm
from django.contrib import messages
from django.conf import settings
from webip_auth.models import RegistrationProfile
from  authmanager import RegistrationManager
from datetime import datetime

class EmailAuthBackend(object):
    """
    Email Authentication Backend
    
    Allows a user to sign in using an email/password pair rather than
    a username/password pair.
    """

    def authenticate(self, username=None, password=None):
        """ Authenticate a user based on email address as the user name. """
        try:
            user = User.objects.get(email=username)
            if user.check_password(password):
                return user
        except User.DoesNotExist:
            return None 

    def get_user(self, user_id):
        """ Get a User object from the user_id. """
        try:
            return User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return None


def get_redirect_url(user):
    """
        returns the url  to which the user should be directed on successfull login
    """

    user_groups = user.groups.all().only("name")
    user_groups = set(map(lambda x: x.name, user_groups))
    if user_groups & set(["webip_admin", "webip_acc_manager"]):
        url = reverse("controlpanel")
    elif user_groups & set(["all_clients"]):
        url = reverse("client_home_page")
    else: url = reverse("controlpanel")
    
    return url

def login(request, *args, **kwargs):
    def errorHandle(error,form=None):
        if not form:
            form = LoginForm()

        return render_to_response(kwargs.get('template'), {
                'errors' : error,
                'form' : form,},RequestContext(request))
    
    if request.method == 'POST': # If the form has been submitted...
        form = LoginForm(request.POST) # A form bound to the POST data
        if form.is_valid(): # All validation rules pass
            username = request.POST['username']
            password = request.POST['password']
            remember_user = request.POST.get('remember_user','')
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active:
                    auth_login(request,user)
                    request.session['last_activity'] = datetime.now()
                    try:
                        permissions_list = {'view_domain':False,'change_domain':False,'add_domain':False,'view_trademark':False,'change_trademark':False,'view_contract':False,'change_contract':False,'add_casedetailmodel':False,'change_casedetailmodel':False,'monitoring_brand':False,'monitoring_domain':False,'monitoring_trademark':False}
                        for i in request.user.user_permissions.all():
                            if i.codename in permissions_list:
                                request.session[i.codename] = True
                    except:
                        pass
                    # Redirect to a success page.
                    redirect_url = reverse('managestaff')
                    redirect_url = get_redirect_url(request.user)
                    return HttpResponseRedirect(redirect_url)
                else:
                    # Return a 'disabled account' error message
                    error = u'account disabled'
                    return errorHandle(error)
            else:
                # Return an 'invalid login' error message.
                error = u'invalid login'
                return errorHandle(error)
        else:

            error = u'Please Enter the Username and Password'
            return errorHandle(error,form)
    else:
        form = LoginForm() # An unbound form
        return render_to_response(kwargs.get("template"), {
            'form': form,
        },RequestContext(request))
        
@login_required
def logout_view(request, *args, **kwargs):
    logout(request)
    redirect_url = reverse(kwargs['redirect_to'])
    return HttpResponseRedirect(redirect_url)



def user_password_reset(request):
    
    """reset view method for  forgotten password on Staff type admin and accountmanager. This  method will send an e-mail to user's email-id which is entered in password_reset_form"""
    
    if request.method=='POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            redirect=reverse("password_reset_done")
            response =  password_reset(request,template_name='webip_auth/password_reset_form.html',
            email_template_name='webip_auth/password_reset_email.html',
            post_reset_redirect=redirect,from_email=settings.EMAIL_HOST_USER,token_generator=default_token_generator)
            return response
#            form.save()
        else:
            pass
        return render_to_response('webip_auth/password_reset_form.html', {'form': form},RequestContext(request))    
    else:
        form=PasswordResetForm() 
        return render_to_response('webip_auth/password_reset_form.html', {'form': form},RequestContext(request))


def user_password_reset_done(request):

    """This will show acknowledge message to user who is seeking to reset his/her password."""

    return password_reset_done(request,template_name='webip_auth/password_reset_done.html')
#
#    else:
#
#        redirect_url = reverse('index')
#        return HttpResponseRedirect(redirect_url)

def user_password_reset_confirm(request, uidb36=None, token=None):

    """ This will allow user to reset his/her password for the system"""
    

    if request.method=='POST':
        form = ResetNewPasswordForm(request.POST)
        if form.is_valid():
            redirect_to=reverse('resetdone')
            return password_reset_confirm(request, uidb36=uidb36, token=token,
            template_name='webip_auth/password_reset_confirm.html',
            post_reset_redirect=redirect_to,token_generator=default_token_generator)
           
        else:
            pass
        return render_to_response('webip_auth/password_reset_confirm.html', {'form': form},RequestContext(request))    
    else:
        form=ResetNewPasswordForm() 
        return render_to_response('webip_auth/password_reset_confirm.html', {'form': form},RequestContext(request))

    

def user_password_reset_complete(request):

    """This will show acknowledge message to user after successfully resetting his/her password for the system."""
    return password_reset_complete(request,template_name='webip_auth/password_reset_complete.html')

#    else:
#        redirect_url = reverse('index')
#        return HttpResponseRedirect(redirect_url)



def registration(request):
    """ A function for create a new account from front end site """ 
    
    if request.method=='GET':
        form=RegisterAccountForm()
        
    if request.method=='POST':
        form=RegisterAccountForm(request.POST)
        if form.is_valid():
            new_user=form.save()
#            messages.success(request,"Account created Successfully!")
            redirect=reverse("success_registration")
            return HttpResponseRedirect(redirect)
        else:
            pass 
    return render_to_response('fn/create_account.html',{'form': form}, RequestContext(request))


def activate(request, activation_key,
             template_name='webip_auth/activate.html',
             extra_context=None):
    """
    Activate a ``User``'s account from an activation key, if their key
    is valid and hasn't expired.
    
    By default, use the template ``registration/activate.html``; to
    change this, pass the name of a template as the keyword argument
    ``template_name``.
    
    **Required arguments**
    
    ``activation_key``
       The activation key to validate and use for activating the
       ``User``.
    
    **Optional arguments**
       
    ``extra_context``
        A dictionary of variables to add to the template context. Any
        callable object in this dictionary will be called to produce
        the end result which appears in the context.
    
    ``template_name``
        A custom template to use.
    
    **Context:**
    
    ``account``
        The ``User`` object corresponding to the account, if the
        activation was successful. ``False`` if the activation was not
        successful.
    
    ``expiration_days``
        The number of days for which activation keys stay valid after
        registration.
    
    Any extra variables supplied in the ``extra_context`` argument
    (see above).
    
    **Template:**
    
    registration/activate.html or ``template_name`` keyword argument.
    
    """
    activation_key = activation_key.lower() # Normalize before trying anything with it.
    reg_profile_obj=RegistrationManager()
    account = reg_profile_obj.activate_user(activation_key)
    
    if extra_context is None:
        extra_context = {}
    context = RequestContext(request)
    for key, value in extra_context.items():
        context[key] = callable(value) and value() or value
    return render_to_response(template_name,
                              { 'account': account,
                                'expiration_days': settings.ACCOUNT_ACTIVATION_DAYS },
                              context_instance=context)


def registration_complete(request):
    
    return render_to_response('webip_auth/registration_complete.html',RequestContext(request))
    

