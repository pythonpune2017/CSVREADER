from sys import modules

from django.db import models

from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.generic import GenericForeignKey
from django.db import transaction
from django.db.utils import DatabaseError
from django.template.loader import get_template
from django.template import Context
from django.utils import simplejson


class LogActionManager(models.Manager):
    _cache = {}
    _SYNCED = False
    _DELAYED = []

    def register(self, key, template, build_cache=None):
        if LogActionManager._SYNCED:
            return LogAction.objects._register(key, template, build_cache)
        else:
            self._DELAYED.append((key, template, build_cache))

    @transaction.commit_manually
    def _register(self, key, template, build_cache=None):
        """
        Registers and caches an LogAction type
        
        @param key : Key identifying log action
        @param template : template associated with key
        """
        try:
            try:
                action = self.get_from_cache(key)
                action.template = template
                action.save()
            except LogAction.DoesNotExist:
                action, new = LogAction.objects.get_or_create(name=key, \
                template=template)
                self._cache.setdefault(self.db, {})[key] = action
                action.save()
            action.build_cache = build_cache
            return action
        except:
            transaction.rollback()
        finally:
            transaction.commit()

#    def _register_delayed(self, sender='', **kwargs):
#        """
#        Register all permissions that were delayed waiting for database tables to
#        be created.
#        
#        Don't call this from outside code.
#        """
#        try:
#            for args in LogActionManager._DELAYED:
#                LogAction.objects._register(*args)
#            models.signals.post_syncdb.disconnect(LogActionManager._register_delayed)
#            LogActionManager._SYNCED = True
#        except DatabaseError:
#            # still waiting for models in other apps to be created
#            pass
#
#    # connect signal for delayed registration.  Filter by this module so that
    # it is only called once
#    models.signals.post_syncdb.connect(_register_delayed, \
#                                       sender=modules['object_log.models'])

    def get_from_cache(self, key):
        """
        Attempts to retrieve the LogAction from cache, if it fails, loads
        the action into the cache.
        
        @param key : key passed to LogAction.objects.get
        """
        try:
            action = self._cache[self.db][key]
        except KeyError:
            action = LogAction.objects.get(name=key)
            self._cache.setdefault(self.db, {})[key]=action

            # update build_cache function if needed
            for key_, template, build_cache in LogActionManager._DELAYED:
                if key == key_:
                    action.build_cache = build_cache

        return action


class LogAction(models.Model):
    """
    Type of action of log entry (for example: addition, deletion)

    @param name           string  verb (for example: add)
    """
    
    name = models.CharField(max_length=128, unique=True, primary_key=True)
    template = models.CharField(max_length=128)
    objects = LogActionManager()
    
    def __str__(self):
        return 'LogAction: %s Template: %s \n'%(self.name, self.template)
    

class LogItemManager(models.Manager):
    
    def _get_user_type(self, user):
        user_type = None
        if user.is_superuser:
            user_type = "superuser"
        elif hasattr(user, "clientmodel"):
            user_type = "client"
        elif hasattr(user, "staffmodel"):
            user_type = user.staffmodel.emp_type
        return user_type
            
    def log_action(self, key, user, object1, object2=None, object3=None, data=None):
        """
        Creates new log entry

        @param user             Profile
        @param affected_object  any model
        @param key              string (LogAction.name)
        """
        # Want to use unicode?
        # Add this at import section of the file
        #from django.utils.encoding import smart_unicode
        # Uncomment below:
        #key = smart_unicode(key)
       
        action = LogAction.objects.get_from_cache(key)
        entry = self.model(action=action, user=user, object1=object1,changed_data=data, user_type=self._get_user_type(user))
#        object2=None
#        object3=None
      
        if object2 is not None:
            entry.object2 = object2
        
        if object3 is not None:
            entry.object3 = object3
         
        # build cached data and or arbitrary data.
        if action.build_cache is not None:
            entry.data = action.build_cache(user, object1, object2, object3,data)
        elif data is not None:
            entry.data = data

        entry.save(force_insert=True)
        return entry
        try:
	        action = LogAction.objects.get_from_cache(key)
	        entry = self.model(action=action, user=user, object1=object1,changed_data=data, user_type=None)
	        
	      
	        if object2 is not None:
	            entry.object2 = object2
	        
	        if object3 is not None:
	            entry.object3 = object3
	         
	        # build cached data and or arbitrary data.
	        if action.build_cache is not None:
	            entry.data = action.build_cache(user, object1, object2, object3,data)
	        elif data is not None:
	            entry.data = data
	
	        entry.save(force_insert=True)
	        return entry
        except:
        	return None



class LogItem(models.Model):
    """
    Single entry in log
    """
    action = models.ForeignKey(LogAction, related_name="entries")
    user_type = models.CharField(max_length=128,blank=True,null=True)
    timestamp = models.DateTimeField(auto_now_add=True, )
    user = models.ForeignKey(User, related_name='log_items')
    
    object_type1 = models.ForeignKey(ContentType, \
    related_name='log_items1', null=True)
    object_id1 = models.PositiveIntegerField(null=True)
    object1 = GenericForeignKey("object_type1", "object_id1")
    
    object_type2 = models.ForeignKey(ContentType, \
    related_name='log_items2', null=True)
    object_id2 = models.PositiveIntegerField(null=True)
    object2 = GenericForeignKey("object_type2", "object_id2")
    
    object_type3 = models.ForeignKey(ContentType, \
    related_name='log_items3', null=True)
    object_id3 = models.PositiveIntegerField(null=True)
    object3 = GenericForeignKey("object_type3", "object_id3")
    
    serialized_data = models.TextField(null=True)
    changed_data = models.TextField(null=True)

    objects = LogItemManager()
    _data = None

    class Meta:
        ordering = ("timestamp", )

    @property
    def data(self):
        if self._data is None and not self.serialized_data is None:
            self._data = simplejson.loads(self.serialized_data)
        return self._data

    @data.setter
    def data(self, value):
        self._data = value
        self.serialized_data = None

    @property
    def template(self):
        """
        retrieves template for this log item
        """
        action = LogAction.objects.get_from_cache(self.action_id)
        return get_template(action.template)

    def save(self, *args, **kwargs):
        if self._data is not None and self.serialized_data is None:
            self.serialized_data = simplejson.dumps(self._data)
        super(LogItem, self).save(*args, **kwargs)

    def render(self, **context):
        """
        render this LogItem

        @param context: extra kwargs to add to the context when rendering
        """
        msg2=''
        context['log_item'] = self
        try: 
            msg = 'from '+str(eval(self.changed_data)['old'])+'to'+str(eval(self.changed_data)['new'])
        except: 
            msg = ''
                                
        try:
            data_dict=eval(self.changed_data)
            if data_dict.has_key('import'):
                msg2=data_dict['import']
        except:
            msg2=''
                                     
        try:
            data_dict=eval(self.changed_data)
            if data_dict.has_key('export'):
                msg2=data_dict['export']
        except:
            msg2=''
        
        try:
            data_dict=eval(self.changed_data)
            if data_dict.has_key('mail'):
                msg2=data_dict['mail']
        except:
            msg2=''  
        try:
            data_dict=eval(self.changed_data)
            if data_dict.has_key('dns'):
                msg=data_dict['dns']
        except:
            msg=''   
        
        if msg2:
            context['message'] = msg2
        context['changed_value'] = msg
#        print "context",context
        
        action = LogAction.objects.get_from_cache(self.action_id)
        template = get_template(str(action.template))
        return template.render(Context(context))

    def __repr__(self):
        return 'time: %s user: %s object_type1: %s'%(self.timestamp, self.user, self.object_type1)
    
    def __str__(self):
        """
        Renders single line log entry to a string, 
        containing information like:
        - date and extensive time
        - user who performed an action
        - action itself
        - object affected by the action
        """
        return self.render()


#def build_default_cache(user, obj1, obj2, obj3, data):
#    """ build cache for default log types """
#    return {'object1_str':str(obj1)}


def build_default_cache(user, obj1, obj2, obj3, data):
    """ build cache for default log types """
    return {'object1_str':str(obj1),'object2_str':obj2.__doc__}

#Most common log types, registered by default for convenience
def create_defaults():
   
    LogAction.objects.register('EDIT', 'object_log/BE-Log.html', build_default_cache)
    LogAction.objects.register('CREATE', 'object_log/add.html', build_default_cache)
    LogAction.objects.register('DELETE', 'object_log/delete.html', build_default_cache)
    LogAction.objects.register('ERROR', 'object_log/error.html', build_default_cache)
    LogAction.objects.register('EXPORT', 'object_log/export.html', build_default_cache)
    LogAction.objects.register('IMPORT', 'object_log/import.html', build_default_cache)
    LogAction.objects.register('SENDMAIL','object_log/sendmail.html', build_default_cache)
create_defaults()
