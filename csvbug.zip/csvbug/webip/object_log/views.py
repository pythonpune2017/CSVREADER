from django.contrib.auth.models import User, Group
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, HttpResponseRedirect
from django.http import HttpResponse, Http404
from django.template.context import RequestContext
from django.db.models.query_utils import Q
from django.shortcuts import render_to_response, get_object_or_404
from utils.paginator import paginate
from object_log.models import LogItem
from admin_app.models import *
from client.models import *
from datetime import datetime
from utils import create_spreadsheet as CreateSpreadsheet
from utils.tooltips_info import tooltip_dict as TOOLTIP_DICT
import os
import time
from object_log.object_log_manager import ObjectLogManager
from django.core.servers.basehttp import FileWrapper
from utils import spreadsheet_mapping_info as SpreadsheetMapping
from utils.spreadsheet_to_dictionary import SpreadSheetDictonaryConversion
from utils.csv_to_dictionary import CSVDictionaryConversion
from django.conf import settings
from django.template import Context
from django.contrib import messages
from utils.filewrapper_info import FixedFileWrapper

def list_for_object(request, obj):
    """
    Lists all actions that involve a given object.  This will check
    LogItem.object1, LogItem.object2, and LogItem.object3.

    This view does not
    include any permission checks as it is intend

    @param request: http request
    @param obj: object to retrieve log items for
    """
    content_type = ContentType.objects.get_for_model(obj)

    q = Q(object_type1=content_type, object_id1=obj.pk) \
        | Q(object_type2=content_type, object_id2=obj.pk) \
        | Q(object_type3=content_type, object_id3=obj.pk) \

    log = LogItem.objects.filter(q).select_related('user').distinct()

    return render_to_response('object_log/log.html',
        {'log':log,
         'context':{'user':request.user , 'TOOLTIP_DICT': TOOLTIP_DICT, },
         
         },
        context_instance=RequestContext(request))


@login_required
def list_for_user(request, pk):
    """
    Provided view for listing actions performed on a user.

    This may only be used by superusers
    """
#    if not request.user.is_superuser:
#        return HttpResponseForbidden('You are not authorized to view this page')

    user = get_object_or_404(User, pk=pk)
    return list_for_object(request, user)


@login_required
def list_for_group(request, pk):
    """
    Provided view for listing actions performed on a group.

    This may only be used by superusers
    """
#    if not request.user.is_superuser:
#        return HttpResponseForbidden('You are not authorized to view this page')

    group = get_object_or_404(Group, pk=pk)
    return list_for_object(request, group)


#@login_required
#def list_user_actions(request, pk):
#    """
#    List all actions a user has performed.  This view can only be used by
#    superusers.
#
#    @param request: HttpRequest
#    @param pk: Primary Key of User to get log for.
#    """
##    if not request.user.is_superuser:
##        return HttpResponseForbidden('You are not authorized to view this page')
#
#    user = get_object_or_404(User, pk=pk)
#    log_items = LogItem.objects.filter(user=user).select_related('user')
#
#    return render_to_response('object_log/log.html',
#        {'log':log_items, 'context':{'user':request.user}},
#        context_instance=RequestContext(request))

def filter_logs_by_user_type(logs, user_type):
    user_type_dict = {'0':'admin',
                      '1':'accountmanager',
                      '2':'client',
                      '3': 'superuser'}
    
#    user_type_name = user_type_dict.get(user_type)
#    if user_type_name in ["admin", "accountmanager"]:
#        userids = StaffModel.objects.filter(emp_type=user_type_name).values_list("user").distinct()
#        logs = logs.filter(user__in = userids)
#    
#    elif user_type_name == "client":
#        user_ids = ClientUser.objects.all().values_list("user").distinct()
#        logs = logs.filter(user__in = userids)
#        
#    elif user_type_name == "superuser":
#        logs = logs.filter(user__in = User.objects.filter(is_superuser=True))

    

def list_all_log_actions(request):
    """
    List all actions perform on all the backend admin module has performed.     """

#    log_items = LogItem.objects.select_related("user").all()
#    for log in log_items:
#        try:
#            user_obj=User.objects.get(id=log.user.id)
#            staff_user_obj=StaffModel.objects.get(user=user_obj.id)
#            staff_type=staff_user_obj.emp_type
#            logitem_obj.user_type=staff_type
#            logitem_obj.save()
#        except:
#            staff_user_obj=None
#        try:
#            user_obj=User.objects.get(id=log.user.id)
#            client_user_obj=ClientUser.objects.get(user=user_obj.id)
#            staff_type="client"
#            logitem_obj.user_type=staff_type
#            logitem_obj.save()
#        except:
#            client_user_obj=None
#        try:
#            if not staff_user_obj and not client_user_obj:
#                if user_obj.is_superuser:
#                    user_type="superuser"
#                    logitem_obj.user_type=user_type
#                    logitem_obj.save()
#        except:
#            user_obj=None
#            client_user_obj=None
            
    log_items = LogItem.objects.select_related("user").all()
    keyword = request.GET.get("keyword")
    if keyword:
        if keyword=='Added':
            log_items = log_items.filter(action='CREATE')
           
        elif keyword=='Updated':
            log_items = log_items.filter(action="EDIT")

        elif keyword=='deleted':
            log_items = log_items.filter(action="DELETE") 
            
        else:
            log_items
        
        fields_4_keyword_search = ["user_type","user__username"]
        q_str = ""
        for element in fields_4_keyword_search:
            q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element+"__icontains", keyword)

            log_items = log_items.filter(eval(q_str))
#        log_items = log_items.filter(user=keyword)
            
    user_type  = request.GET.get('user_type')
    activity_from, activity_to, per_page = request.GET.get('fromactivitydate'), request.GET.get('toactivitydate'),request.GET.get('numOfResults',25)
    activity=request.GET.get("activity")
    cur_page=request.GET.get('page', 1)
    
    activity_action_dict = {'0':'CREATE', '1':'EDIT', '2':'DELETE'}
    if activity in activity_action_dict.keys():
        log_items = log_items.filter(action=activity_action_dict[activity])
    
    if user_type:
        user_type_dict = {'0':'admin',
                      '1':'accountmanager',
                      '2':'client',
                      '3': 'superuser'}
        log_items = log_items.filter(user_type=user_type_dict[user_type])
    
#    if user_type in user_type_dict.keys():
#        log_items = log_items.filter(user_type = user_type_dict[user_type])
    
    if activity_from and activity_to:
        activity_from_date = datetime.strptime(activity_from, '%d-%m-%Y').strftime('%Y-%m-%d %H:%M:%S')
        activity_to_date = datetime.strptime(activity_to,'%d-%m-%Y').strftime('%Y-%m-%d 12:%M:%S')
        log_items=log_items.filter(timestamp__gt = activity_from_date,timestamp__lt=activity_to_date)
              
    elif activity_to:
        activity_to_date = datetime.strptime(activity_to,'%d-%m-%Y').strftime('%Y-%m-%d 12:%M:%S')        
        log_items=log_items.filter(timestamp__lt=activity_to_date)
        
    elif activity_from:
        activity_from_date = datetime.strptime(activity_from, '%d-%m-%Y').strftime('%Y-%m-%d %H:%M:%S')       
        log_items=log_items.filter(timestamp__gt = activity_from_date)
        
    log_items = log_items.order_by("-timestamp")
    order=request.GET.get('order')
    if request.GET.get('sort') =='timestamp':
        if order=='asc':
            log_items = log_items.order_by("timestamp")
        else:
            log_items = log_items.order_by("-timestamp")
    
    if request.GET.get('sort') =='username':
        if order=='asc':
            log_items = log_items.order_by("user__username")
        else:
            log_items = log_items.order_by("-user__username")
    
    if request.GET.get('sort') =='usertype':
        if order=='asc':
            log_items = log_items.order_by("user_type")
        else:
            log_items = log_items.order_by("-user_type")
    context ={}
    
    if per_page=='ALL':
        count=log_items.count()
        per_page=count
    cur_page = request.GET.get('page', 1)
    paginated = paginate(log_items,cur_page, per_page)

#    if keyword or activity_from or activity_to or user_type or activity:
    if not paginated.object_list.exists():
        messages.warning(request,"No Records found!")
 
    context['order']="asc" if order=="desc" else "desc"
    context['user']=request.user
#    context['countall']=count
    context['TOOLTIP_DICT']=TOOLTIP_DICT
    
   
    return render_to_response('object_log/BE-Log.html',{'log':paginated,'context':context},RequestContext(request))


def export_logs_details(request):
    """
        Purpose: Export user log details on the basis of filtered results
    """
    response= None
    if request.method =="GET":
        pass
    if request.method =="POST":
        #request dictionary
        req_dict = dict(zip(request.REQUEST.keys(),request.REQUEST.values()))
        data_dict = {}
        log_obj = ObjectLogManager()
        log_data = log_obj.get_all_log_items(req_dict)
        #Data required for creating spreadsheet
        sequence_list = SpreadsheetMapping.USERLOGS_SEQUENCE_LIST
        title_dict = SpreadsheetMapping.USERLOGS_TITLE_LIST
        #Create XLS
        #Create XLS
        if request.POST.get("format") == "xls":
            status, response = CreateSpreadsheet.create_xls_file(sequence_list,title_dict, log_data, "log_")
            if not status:
                pass
        elif request.POST.get("format") == "csv":
            status , response = CreateSpreadsheet.create_csv_file(sequence_list,title_dict , log_data , settings.TEMP_DIR  + os.sep + "log.csv" )
            if status:
                wrapper = FixedFileWrapper(file(settings.TEMP_DIR  + os.sep + "log.csv"))
                filename = 'attachment; filename=' + str(time.strftime("Log_%Y%m%d" + "_%H%M%S", time.localtime()) + ".csv")
                response = HttpResponse( wrapper , mimetype="application/vnd.ms-excel")
                response['Content-Disposition'] = filename
    return response



def object_detail(request, content_type_id, pk):
    """
    Generic view for displaying a detail page for an object.  ContentTypes are
    used to find a detail url through get_absolute_url().  This isn't the most
    efficient way to display a detail page, but it will scale well with log
    messages that might not have the full item loaded.
    """
    ct = ContentType.objects.get(pk=content_type_id)
    obj = ct.get_object_for_this_type(pk=pk)
    return HttpResponseRedirect(obj.get_absolute_url())


def list_all_logs(request):
    
    context = {"logs": log_items}
    render(request, "xcbvjxfg", RQ)
