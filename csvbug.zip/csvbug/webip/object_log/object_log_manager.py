from object_log.models import LogItem
from admin_app.models import *
from client.models import *
from datetime import datetime
from django.template import Context
from datetime import datetime
import re

class ObjectLogManager(object):
    """
    """
    def get_all_log_items(self,data_dict):
        """
            get all the logs on the basis of searched data
        """
        log_items = LogItem.objects.all()
        keyword = data_dict.get("keyword")
        if keyword:
            if keyword=='Added':
                log_items = log_items.filter(action='CREATE')
               
            elif keyword=='Updated':
                log_items = log_items.filter(action="EDIT")
    
            elif keyword=='deleted':
                log_items = log_items.filter(action="DELETE") 
            else:
                fields_4_keyword_search = ["user_type","user__username"]
                q_str = ""
                for element in fields_4_keyword_search:
                    q_str += (" | " if q_str else "")+"Q(%s='%s')"%(element, keyword)
                log_items = log_items.filter(eval(q_str))
        user_type  = data_dict.get('user_type')
        activity_from, activity_to, per_page = data_dict.get('fromactivitydate'), data_dict.get('toactivitydate'),data_dict.get('numOfResults', 10)
        activity=data_dict.get("activity")
        cur_page=data_dict.get('page', 1)
        
        if user_type=='0':
            log_items=log_items.filter(user_type='admin')
        elif user_type=='1':
            log_items=log_items.filter(user_type='accountmanager')
        elif user_type=='2':
            log_items=log_items.filter(user_type='client')
        else:
            log_items=log_items
        
        if activity_from and activity_to:
            activity_from_date = datetime.strptime(activity_from, '%d-%m-%Y').strftime('%Y-%m-%d %H:%M:%S')
            activity_to_date = datetime.strptime(activity_to,'%d-%m-%Y').strftime('%Y-%m-%d 12:%M:%S')
            log_items=log_items.filter(timestamp__gt = activity_from_date,timestamp__lt=activity_to_date)
        elif activity_to:        
            log_items=log_items.filter(timestamp__lt=activity_to_date)
        elif activity_from:       
            log_items=log_items.filter(timestamp__gt = activity_from_date)
        else:
            log_items=log_items
        activity_list = []   
        for item in log_items.iterator():
            try:
                activity = item.template.render(Context({"log_item": item}))
            except:
                activity = ''
            new_act =  self.process_activity(activity) 
            activity_list.append({"activity": str(new_act)})
            
        log_items_info = log_items.values("user__username", "user_type", "timestamp")
        for index, log_items in enumerate(log_items_info):
            log_items.update(activity_list[index])
            
        new_log_items_info = []
        for logs in log_items_info:
            logs_dict = {}
            for k , v in logs.iteritems():
                if k == "timestamp":
                    nv = datetime.strftime(v ,'%d-%m-%Y' )
                    logs_dict[k] = nv
                else:
                    logs_dict[k] = v
            new_log_items_info.append(logs_dict)
            
        return new_log_items_info
    
    def process_activity(self , activity_data):
        """
            Remove html tags from activity_data
        """
        try:
            p = re.compile(r'<.*?>')
            data = p.sub('', activity_data)
            t = re.compile(r'\s+')
            activity = t.sub(' ', data)
            activity = str(activity).title()
        except:
            activity = ''
            pass
        return activity

