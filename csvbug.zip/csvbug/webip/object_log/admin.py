'''
Created on Feb 15, 2012

@author: arun
'''
from django.contrib import admin

from object_log.models import *

admin.site.register(LogItem)
admin.site.register(LogAction)
