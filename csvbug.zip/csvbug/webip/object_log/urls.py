from django.conf.urls.defaults import url, patterns

urlpatterns = patterns('object_log.views',
#    url(r'^user/(?P<pk>\d+)/actions/?$', 'list_user_actions', name="user-object_log-actions"),
   url(r'^logs/?$', 'list_all_log_actions', name="view_logs"),
   url(r'^user/exportuserlog/$','export_logs_details',name="exportuserlogs"),
   
   url(r'^user/(?P<pk>\d+)/object_log/?$', 'list_for_user', name="user-object_log"),
   url(r'^group/(?P<pk>\d+)/object_log/?$', 'list_for_group', name="group-object_log"),
   url(r'object/(?P<content_type_id>\d+)/(?P<pk>\d+)/?$', 'object_detail', name='object-detail'),
   
   
   
   
#   url(r'^logs/?$', 'list_all_logs', name="view_logs"),
   
)