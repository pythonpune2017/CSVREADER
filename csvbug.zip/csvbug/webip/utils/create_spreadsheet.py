"""
    Purpose: To create csv and xls
    Created on : Feb 6 2012
    Created by : Shweta Mishra
"""

import csv
from django.http import HttpResponse
from xlwt import Workbook

def create_xls_file(sequence_list, mapping_dict, temp_lst, file_name):
    """
        Create XLS File using xlwt.
       will be required in future =  {'Nameserver 1':"",'Nameserver 2':"",'Nameserver 3':"",
       'Nameserver 4':"",'Nameserver 5':"",'Nameserver 6':"",,'DNS Details':"dns_details"}
    """
    try:
        if sequence_list:
            #-- Create A New WorkBook And Add A WorkSheet.
            wb = Workbook(encoding='utf-8')
            ws = wb.add_sheet('0',cell_overwrite_ok=True)
            count = 0
            for i in sequence_list:
                #-- Add MD Field Names.
                ws.write(0,count,str(i))
                count1 = 1
                for temp_dict in temp_lst:
                    if temp_dict.has_key(mapping_dict[i]):
                        #-- Add MD Field Values.
                        ws.write(count1, count,temp_dict[mapping_dict[i]])
                    count1 +=1
                count +=1

            ts = getTimeStamp()
            response = HttpResponse(mimetype="application/vnd.ms-excel")
            response["Content-Disposition"] = "attachment; filename="+file_name + ts + ".xls"
            wb.save(response)
            return True, response
        else:
            return False,'Mandatory Column MetaData Field(s) Missing.'
    except Exception,e:
        raise
        return False, str(e)

def getTimeStamp():
    """
        get datetime stamp
    """
    from time import strftime
    return str(strftime("%d-%m-%Y %H:%M:%S")).replace('-','').replace(' ','').replace(':','')

def create_csv_file(sequence_list, title_dict , data_dict, temp_path):
    """
        Purpose : To create a csv file
        Input : list of dictionary
    """
    try:
        if title_dict:
            writer = csv.DictWriter(open(temp_path,'w'), delimiter=',', fieldnames=sequence_list)
            # headers must be a dict (since it is a DictWriter)
            headers = {}
            for n in writer.fieldnames:
                headers[n] = n
            writer.writerow(headers)
            #writing rows
            for row in data_dict:
                #creating row according to Title dictionary
                new_row = {}
                for key , val in title_dict.iteritems():
                    if row.has_key(val):
                        new_row[key] = row[val]
                writer.writerow(new_row)
            return True ,''
        else:
            return False, "Mandatory fields missing"
    except Exception , e:
        raise
        return False , str(e)


















