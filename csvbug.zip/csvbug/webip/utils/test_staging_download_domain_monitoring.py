#!/usr/bin/env python
"""
1. Download the zip file from the given server to a particular given local directory
2. Unzip the zip files
3. Process the files grep and get seperate files containing .com , .net and .edu domains without having the extensions.
4. Read the domain listing files add the extensions and feel the Global domains table of Web IP.
"""

#===============================================================================
# To download file from server
#===============================================================================
#import sys
#from ftplib import FTP
#
##ftphost, file_to_retrieve, output_path = sys.argv[1:4]
##ftphost = "rz.verisign-grs.com"
##file_to_retrieve = "com.zone.gz"
##output_path = "/home/shweta/Desktop/com.zone.gz"
##username = "tball"
##password = "73%CBMR"
#
#ftphost = "172.16.0.53"
#file_to_retrieve = "/home/projects/webip_env/code/webip/constants.py"
#output_path = "/home/shweta/Desktop/constants.py"
#username = "shweta"
#password = "shweta#123"
#
#
#print "Retreiving %(file_to_retrieve)s from FTP host %(ftphost)s, saving to %(output_path)s" % locals()
#
#ftp = FTP(ftphost)
#ftp.login(username , password)
#
#outfile = None
#def data_callback(data):
#    global outfile
#    if outfile is None:
#        outfile = open(output_path, 'w')
#
#    outfile.write(data)
#
#ftp.retrbinary("RETR %s" % file_to_retrieve, data_callback)
#
#if outfile is not None:
#    outfile.close()
#  
##===========================================================================
## To unzip the downloaded fle
##===========================================================================
#
#import gzip
#import os
#
#def extractVerisignZoneFiles(location):
#    """
#    """
#    if os.direxists(location):
#        os.chdir(location)
#        try:
#            os.system("gzip -cd net.zone.gz >> net.zone")
#            os.system("gzip -cd com.zone.gz >> com.zone")
#            os.system("gzip -cd edu.zone.gz >> edu.zone")
#            return True , "All Zone files successfully extracted"
#        except Exception , e:
#            return False , str(e)
#            pass
#    else:
#        return False , "Directory does not exist"
#    
#def getAllZoneFiles(location):
#    """
#    """
#    zone_file_name = []
#    for file in os.listdir("/home/shweta/domain monitoring files"):
#        if fnmatch.fnmatch(file, '*.zone'):
#            zone_file_name.append(file)
#    return zone_file_name

#===============================================================================
# Extract ".com", ".edu" and ".net" domains after reading the verisign zips and
# make seperate files for the same
#===============================================================================
import set_django_env
import os
import fnmatch
import shutil
import re
import datetime
from domain.models import *
import tempfile, os, lxml, shutil
from datetime import datetime


class FileSplitterException(Exception):
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)
class VerisignzoneFileProcessing(object):
    """VerisignzoneFileProcessing Initialization    """
    def __init__(self, zipfile_location):
        """        """
          # cache filename
        self.__filename = ''
        # number of equal sized chunks
        self.__numchunks = 5
        # Size of each chunk
        self.__chunksize = 0
        # Optional postfix string for the chunk filename
        self.__postfix = 'com'
        # Action
        self.__action = 0 # split
        self.zipfile_location = zipfile_location
        #status, message =self.extractVerisignZoneFiles()
        #print "Status" ,  status
        #print "Message" , message
        #self.readVerisignZip()
        print "START SPIL THE TXT FILES"
#        spilit_status=self.split()
        print "end the split the txt files"
        
    def extractVerisignZoneFiles(self):
        """
        """
        if os.path.exists(self.zipfile_location):
            os.chdir(self.zipfile_location)
            try:
                os.system("gzip -cd net.zone.gz >> net.zone")
                os.system("gzip -cd com.zone.gz >> com.zone")
                os.system("gzip -cd edu.zone.gz >> edu.zone")
                print "All Zone files successfully extracted.."
                return True , ''
            except Exception , e:
                print "Exception while extracting files :----" , str(e)
                return False , str(e)
        else:
            return False , "Directory does not exist"

    def readVerisignZip(self):
        """
        """
        try:
            orig_wd = os.getcwd()
            os.chdir(self.zipfile_location)
            os.system("""grep "^[a-zA-Z0-9-]\+ NS .*" net.zone|sed "s/NS .*//"|uniq >> netdomains.txt""")
            os.system("""grep "^[a-zA-Z0-9-]\+ NS .*" com.zone|sed "s/NS .*//"|uniq >> comdomains.txt""")
            os.system("""grep "^[a-zA-Z0-9-]\+ NS .*" edu.zone|sed "s/NS .*//"|uniq >> edudomains.txt""")
            #os.system("chown stagingw.webip *")
            #os.system("chmod 777 -R *")
            print "Successfully created text files containing domain names"
            return True , ""
        except Exception , e:
            print "Exception while creating text files containing domain names :----", str(e)
            return False , str(e)
    
    def split(self):
        """ Split the file and save chunks
        to separate files """
        txt_file_name = []
        for file in os.listdir(self.zipfile_location):
           self.__filename = file
           if fnmatch.fnmatch(file, '*.txt'):
               try:
                   f = open(self.__filename, 'rb')
               except (OSError, IOError), e:
                   raise FileSplitterException, str(e)
               bname = (os.path.split(self.__filename))[1]
               # Get the file size
               fsize = os.path.getsize(self.__filename)
               # Get size of each chunk
               self.__chunksize = int(float(fsize)/float(self.__numchunks))
    
               chunksz = self.__chunksize
               total_bytes = 0
               for x in range(self.__numchunks):
                   chunkfilename = bname + '-' + self.__postfix
    
                # if reading the last section, calculate correct
                # chunk size.
                   if x == self.__numchunks - 1:
                       chunksz = fsize - total_bytes
                   try:
                        print 'Writing file',chunkfilename
                        data = f.read(chunksz)
                        total_bytes += len(data)
                        chunkf = file(chunkfilename, 'wb')
                        chunkf.write(data)
                        chunkf.close()
                   except (OSError, IOError), e:
                       print e
                       continue
                   except EOFError, e:
                        print e
                        break
    
               print 'Done.'
        
    def getAllTxtFiles(self):
        """read all the txt extensions files from the zip locations """
        txt_file_name = []
        for file in os.listdir(self.zipfile_location):
           print "FILLEE",file
           if fnmatch.fnmatch(file, '*.txt*'):
                txt_file_name.append(file)
#                print "txxxx",txt_file_name
        return txt_file_name
       
    def readFiles(self):
        """
        """
        print "IN THE READFILES"
        txt_file_name = self.getAllTxtFiles()
        print "GET ALL FILE NAME",txt_file_name
#        d_obj = deleteExistingData()
        postfix="-com"
        for filename in txt_file_name:
            if filename.endswith(postfix):
                print "if filename equals"
                ext = ".COM" 
            elif filename.endswith(postfix):
                ext = ".COM"
            elif filename.endswith(postfix):
                ext = ".COM"
            else:
                ext = ''  
            obj = DomainImportManager(self.zipfile_location + filename , ext)
            obj.main()

        return True
    
    
#===============================================================================
# Read files and fill in the database
#===============================================================================


def deleteExistingData():
    """
    """
    try:
        global_domain = GlobalDomains.objects.all().delete()
#        for obj in global_domain:
#            try:
#                obj.delete()
#            except:
#                pass
        print "Successfully cleaned the database"
        return True , "Successfully cleaned the database"
    except Exception , e:
        print "Exeception while cleaning GlobalDomains table :-------", str(e)
        return False , str(e)

    
class DomainImportManager(object):
    """
        Read text from given text file and convert into list
    """
    def __init__(self, filename, ext= None):
        """
        """
        self.filename = filename
        self.ext = ext
        
    def read_file(self):
        """
            Read the given filename
        """
#        print "Processing file : --------" , str(self.filename)
        fp = open(self.filename,"r")
        contents = fp.readlines()
        fp.close()
        return contents
    
    def process_contents(self, contents):
        """
            Purpose : Process the text contents to convet into a list
            Input : file_contents(string)
            Output : List
        """
        new_content = []
        for item in contents:
            new_item = item.strip().strip("\n").strip("\n").strip("\n")
            if not new_item == "" :
                new_content.append(new_item)
        return new_content
    
    def update_domains(self, name):
        """
        """
        from django.conf import settings

        ext = self.ext.strip('.').lower()
        domain_type = [i[0] for i in settings.DOMAIN_TYPES if ext == i[1]][0]
        
        new_name = ''
        
        if name:
            new_name = name + self.ext
        try:
            global_domain = GlobalDomains.objects.get(name=new_name)
            global_domain.save()
            print "INSERT----->"
        except Exception , e:
            global_domain = GlobalDomains(name = new_name)
            global_domain.domain_type = domain_type
            global_domain.save()
            print "EXISTING UPDATE----->"
#            print "%s successfully added to the databse"%(new_name)
        return True
    
#    def write_log(self, data):
#        """
#        function to write a log of all domain is importing
#        """
#        fp = open("/home/pritesh/Desktop/domainmonitoring/updatedomainlog.log", "a")
#        fp.write("\n"+str(datetime.strftime(datetime.now() , "%d-%m-%Y | %H-%M-%S"))+" | "+str(data)+"\n")
#        fp.close()
#        return True
    

    def read_in_chunks(self,file_object, chunk_size=2048):
        """ Lazy function (generator) to read a file piece by piece.
            Default chunk size: 1k. """
        while True:
            data = file_object.readlines(chunk_size)
            if not data:
                break
            yield data
    def main(self):
        """ main function execution start """
#        contents = self.read_file()
        print "in the main function start---->"
        f = open(self.filename,"r")
        for piece in self.read_in_chunks(f):
            domains_data = self.process_contents(piece)
            print "domain_data",domains_data
            self.count = 0
            for item in domains_data:
                print "item",item
                if self.count == 10000:
                        self.count = 0
                        import time
                        print "Sleeping Now........."
                        time.sleep(60)
                        print"DD",item
                        self.update_domains(item)
                else:
                    print "In Else Loop:---",item
                    self.update_domains(item)
                    self.count +=1
        return True

    def deleteContents(self, folder_path):

        """
        """
        for root, dirs, files in os.walk(folder_path):
            for f in files:
                os.unlink(os.path.join(root, f))
            for d in dirs:
                shutil.rmtree(os.path.join(root, d))
        print "Files deleted"
        return True
    


zipfile_location = "/home/ashish/Videos/domainmonitoring/testing/splitcomdomains/"
obj = VerisignzoneFileProcessing(zipfile_location)
obj.readFiles()