import datetime

def getDateObject(datestring):
    """
        Takes a string as input and returns the datetime object
        datestring can be in 2 formats mm-dd-yy or mm-dd-YYYY
    """
    if datestring:
        try:
            datetimeobj = datetime.datetime.strptime(datestring, '%d-%m-%y')
        except ValueError as ve:
            try:
                datetimeobj = datetime.datetime.strptime(datestring, '%d-%m-%Y')
            except:
                datetimeobj = None
        except:
            datetimeobj = None
        return datetimeobj