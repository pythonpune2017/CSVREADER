import PIL
from PIL import Image
import os

def resize_image(in_path, out_path=None, height=20, width=40):
	"""
		Resizes original image to the given size.
	"""
	
	try:
		file_name= os.path.basename(in_path)
		if out_path:
			out_path = out_path.rstrip(os.sep)
			out_path = out_path + os.sep + "m_" +file_name
		
		in_img = Image.open(in_path)
		in_img.thumbnail((width, height), Image.ANTIALIAS)
		img_path = (out_path or in_path)
		in_img.save(img_path)
		return True, img_path
	except Exception, e:
		return False, str(e)
