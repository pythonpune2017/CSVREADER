'''
Created on Jan 31, 2012

@author: arun

Put all the Permissions Releated Code 

'''
from django.contrib.auth.models import Permission, PermissionManager
#from admin_app.form import PremissionsForm

#for Assign Client form


class UserPermissionsMap(object):
    
    __permission_map = None

    @staticmethod
    def get_permission_map():
        if not UserPermissionsMap.__permission_map:
            UserPermissionsMap.__permission_map = UserPermissionsMap.__get_permission()
        return UserPermissionsMap.__permission_map
    
    @staticmethod
    def __get_permission():
        permission_name_list = {"view_domain":"view_domain", "edit_domain":"change_domain", "order_domain":"add_domain", "view_trademark":"view_trademark", 
                        "edit_trademark":"change_trademark", "view_contract":"view_contract",
                         "edit_contract":"change_contract", "view_cases": "add_casedetailmodel", "edit_cases":"change_casedetailmodel", 
                         "monitoring_brand":"monitoring_brand", "monitoring_domain":"monitoring_domain", "monitoring_trademark":"monitoring_trademark"}

        permission_objs = Permission.objects.filter(codename__in = permission_name_list.values())
        
        permissions_map = [{"name": "view_domain", "label":"View Domain"},
                               {"name": "edit_domain", "label":"Edit Domain (inc DMS)"},
                               {"name": "order_domain", "label":"Order Domains"},
                               {"name": "view_trademark", "label":"View Trademark"},
                               {"name": "edit_trademark", "label":"Add/Edit Trademark"},
                               {"name": "view_contract", "label":"View vendor"},
                               {"name": "edit_contract", "label":"Add/Edit vendor"},
                               {"name": "view_cases", "label":"View Cases"},
                               {"name": "edit_cases", "label":"Add/Edit Cases"},
        
                               {"name": "monitoring_brand", "label":"Brand"},
                               {"name": "monitoring_domain", "label":"Domain"},
                               {"name": "monitoring_trademark", "label":"Trademark"}
                               
                               ]
        
        for elem in permissions_map:
            for perm in permission_objs:
                if perm.codename==permission_name_list[elem["name"]]:
                    elem["permission"] = perm

                
        return permissions_map

USER_PERMISSION_MAP = UserPermissionsMap.get_permission_map()

class WebipPermissionManager:
    """
        To manager User Permissions
    """
    
    
    def __ini__(self):
        pass
    
    
    def get_acc_manager_permissions(self, user):
        """
            From all the permissions user have, extract the permissions required for Assing Client form(Assign Client to Account Manager)
        """
        pass
#        permission_map = {'view_domain': Permission.objects.get(codename="add_domain"),
#                          'edit_domain': Permission.objects.get(codename="change_domain"),
#                          'order_domain': Permission.objects.get(codename="delete_domain") ,
#                          'view_trademark': Permission.objects.get(codename="add_domain"),
#                          'edit_trademark': Permission.objects.get(codename="add_domain"),
#                          'view_contract' : Permission.objects.get(codename="add_domain"),
#                          'edit_contract' : Permission.objects.get(codename="add_domain"),
#                          'view_cases' : Permission.objects.get(codename="add_domain"),
#                          'edit_cases':Permission.objects.get(codename="add_domain"), 
#                          }
                        
