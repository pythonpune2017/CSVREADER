from admin_app.models import *
from domain.models import *
from client.models import *
from monitoring.models import *
from trademark.models import *
from cases.models import *


class GetDataInfo():
    """
    """
    def main(self):
        """
        """
  
        data_dict = {}
        client_count = self.get_total_count_of_clients()
        subscriptiin_details = self.get_subscription_data()
        domain_count = self.get_total_domain_count()
        trademark_count = self.get_total_count_of_trademark()
        cases_count = self.get_total_cases_count()
        
        data_dict['client_count'] = client_count
        data_dict['subscription_details'] = subscriptiin_details
        data_dict['domain_count'] = domain_count
        data_dict['client_count'] = client_count
        data_dict['trademark_count'] = trademark_count
        data_dict['cases_count'] = cases_count
        return data_dict
        
        
    def get_total_count_of_clients(self):
        """
        """
        client_count= ClientModel.objects.filter(is_deleted = False).count()
        return client_count
    
    def get_subscription_data(self):
        """
        """
        data_list = []
        subscription = self.get_all_subscription_plan()
        for plan in subscription:
            client_count = ClientSubscription.objects.filter(plan = plan).count()
            data_list.append((plan.name , client_count))
        return data_list
        
    def get_all_subscription_plan(self):
        """
        """
        subscription = SubcriptionPlan.objects.all()
        return subscription
    
    def get_total_domain_count(self):
        """
        """
        domain_count = Domain.objects.filter(is_deleted = False).count()
        webip_domain_count = Domain.objects.filter(registrar = "WebIp").count()
        other_domain_count  = domain_count - webip_domain_count
        domain_dict = {"webip_domain" :webip_domain_count, "other_domain": other_domain_count,"total_domain": domain_count}
        return domain_dict
    
    def get_total_cases_count(self):
        """
        """
        case_count = CasedetailModel.objects.filter(is_deleted = False).count()
        return case_count 
    
    def get_total_count_of_trademark(self):
        """
        """
        trademark_count = Trademark.objects.all().count()
        return trademark_count