import urlparse
try:
    from functools import wraps
except ImportError:
    from django.utils.functional import wraps  # Python 2.4 fallback.
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.conf import settings
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.utils.decorators import available_attrs
from django.core.urlresolvers import reverse

def LoginRedirect(method):
    wraps(method)
    def wrapper(request, *args, **kwargs):
        if request.user:
            if not request.user.groups.exists():
                redirect_to = reverse("fn_login")
                return HttpResponseRedirect(redirect_to)
        return method(request, *args, **kwargs)
    return wrapper

def AdminLoginRedirect(method):
    wraps(method)
    def wrapper(request, *args, **kwargs):
        if request.user:
            if request.user.groups.exists():
                redirect_to = reverse("index")
                return HttpResponseRedirect(redirect_to)
        return method(request, *args, **kwargs)
    return wrapper
