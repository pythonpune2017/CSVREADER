import urllib
import urllib2
import httplib2
from urllib2 import Request,URLError,HTTPError
import json
from cases.models import CasedetailModel,CaseAttachmentDetails,InfrigementNotesModel,CaseTeamModel,CaseMilestoneModel,CaseTaskModel
class TrademarkAPIManager():
     
     
     def __init__(self):
#        print "in the init"
        self.partner='webip'
        self.url= 'http://search.remarqueble.com/RestService/TrademarkService'
        self.user_agent='Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'

     def get_tradmarkInfo(self,trademark_search,include_list=None,exclude_list=None,tclass_list=None,client_obj=None,per_page=None,qstr=None,country=None):
        """ Get Trademark Infor from API for given serach keyword """
        try:    
            #code to make regular expression           
            values ={
                 'partner' :self.partner,
                 '$format':'json',
                 '$top':100, 
#                 'searchType':searchType,
#                 '$inlinecount':'max1000'
             }
            if trademark_search and include_list and not exclude_list and not tclass_list:
                tpattern=r'(%s)'%(str(include_list))
                searchType='regex'
                values.update({
                               'search':r"(%s)"%(str(include_list)),
                               'searchType':searchType,
                               '$inlinecount':'max1000'
                               })
            if trademark_search and include_list and exclude_list and not tclass_list:
                tpattern='(%s)[^%s^]'%(str(include_list),exclude_list)
                searchType='regex'
                values.update({
                               'search':r"(%s)[^%s]"%(str(include_list),exclude_list),
                               'searchType':searchType,
                               '$inlinecount':'max1000'
                               })
            
            if trademark_search and include_list and not exclude_list and tclass_list:
                tpattern='(%s)[^%s^]'%(str(include_list),exclude_list)
                searchType='regex'
                values.update({
                               'search':r"(%s)"%(str(include_list)),
                               'searchType':searchType,
                               '$inlinecount':'max1000',
                                'classCode':tclass_list,
                               })
            
            if trademark_search and include_list and exclude_list and tclass_list:
                searchType='regex'
                values.update({
                               'search':r"(%s)[^%s]"%(str(include_list),str(exclude_list)),
                               'searchType':searchType,
                               'classCode':tclass_list,
                               '$inlinecount':'max1000'
                               })
            
                
            if trademark_search and not include_list and exclude_list and not tclass_list:
                tpattern='(%s)[^%s^]'%(str(trademark_search),exclude_list)
                searchType='regex'
                values.update({
                               'search':r"(%s)[^%s]"%(str(trademark_search),exclude_list),
                               'searchType':searchType,
                               '$inlinecount':'max1000'
                               })
            
            
            if trademark_search and not include_list and exclude_list and tclass_list:
                tpattern='(%s)[^%s^]'%(str(trademark_search),exclude_list)
                searchType='regex'
                values.update({
                               'search':r"[^%s]"%(str(exclude_list)),
                               'searchType':searchType,
                               'classCode':tclass_list,
                               '$inlinecount':'max1000'
                               })
                
            
            if trademark_search and not include_list and not exclude_list and tclass_list:
                #tpattern='(%s)[^%s^]'%(str(trademark_search),exclude_list)
                searchType='contains'
                values.update({
                               'search':trademark_search,
                               'searchType':searchType,
                               'classCode':tclass_list,
                               '$inlinecount':'max1000'
                               })
          
                
            if trademark_search and not include_list and not exclude_list and not tclass_list:
                tpattern=str(trademark_search)
                values.update({
                               'search' :tpattern,
                               'searchType':'contains'
                               })
            
            if trademark_search and country:
                tpattern=str(trademark_search)
                values.update({
                               'search' :tpattern,
                               'searchType':'contains',
                               'countryCode':country
                               })
                
            headers = { 'User-Agent' : self.user_agent }
            data = urllib.urlencode(values,headers)
            full_url = self.url + '?' + data 
            try:
#                print "URLL",full_url
                response_data = urllib2.urlopen(full_url).read()
                results = json.loads(response_data)
                #print "RESULTS before process",results
                if results:
                    temp=[]
                    temp.append(results['results'])
                    results =self.process_results(temp[0],client_obj)
                    #print "RESULTS after process",results
            except Exception,e:
                print "EXCEPTION ERRORS",str(e)
                return []

        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
    
        return results
    
    
     def process_results(self,results,client_obj):
        """ process the defaults results given by trademark api to restructre to pass it back to view function"""
        
        new_result2=[]
       
        q_lst = []
        for i in results:
            class_list=[]
            new_results={}
            if i['applicationNumber']:
                new_results['number']=i['applicationNumber']
                q_lst.append(i['applicationNumber'])
            if i['applicationDate']:
                new_results['renewal_date']=i['applicationDate']
               
            if i['trademark']:
                new_results['name']=i['trademark']['text']
                new_results['image']=i['trademark']['imageURL']
            if i['statusDetail']:
                new_results['status']=i['statusDetail']['text']
                new_results['renewal_date']=i['statusDetail']['date']
            if i['specification']:
                for j in i['specification']:
                    if j['classCode']:
                        class_list.append(j['classCode'])
                class_list=str(class_list).strip('[]')
                new_results['t_class']=class_list
            
#            try:
#                casedetailobject = CasedetailModel.objects.get(tm_number=i['registrationNumber'],tm_name=i['trademark']['text'],client=client_obj)
#            except:
#                casedetailobject = None
#            if casedetailobject:
#                new_results['action']='view'
#            else:
#                new_results['action']='add'
                
            new_result2.append(new_results)
#        print "NEW RESULTS",new_result2
        casedetailobject = CasedetailModel.objects.filter(tm_number__in=q_lst,client=client_obj).values_list('tm_number',)
#        print "casedetailobject:-----------",casedetailobject
        tn_num_lst = [i[0] for i in casedetailobject if i]
#        print tn_num_lst
#        print new_result2
        final_result_lst = []
        for i in new_result2:
            dct = {}
            if i.has_key('number') and i['number'] in tn_num_lst:
                dct.update(i)
                dct['action'] = 'view'
                final_result_lst.append(dct)
            else:
                dct.update(i)
                dct['action'] = 'add'
                final_result_lst.append(dct)
                 
        return final_result_lst
                
     def search_tradmarkInfo(self,trademark_search,country=None):
        """ Get Trademark Infor from API for given serach keyword """
        try:    
            #code to make regular expression           
            values ={
                 'partner' :self.partner,
                 '$format':'json',
                 '$top':100, 
#                 'searchType':searchType,
#                 '$inlinecount':'max1000'
             }                    
                
            if trademark_search and not country:
                tpattern=str(trademark_search)
                values.update({
                               'search' :tpattern,
                               'searchType':'contains'
                               })
            
            if trademark_search and country:
                tpattern=str(trademark_search)   
                values.update({
                               'search' :tpattern,
                               'searchType':'contains',
                               'countryCode':country
                               })
                
            headers = { 'User-Agent' : self.user_agent }
            data = urllib.urlencode(values,headers)
            if country=='AU':
                self.url= 'http://ausearch.remarqueble.com/RestService/TrademarkService'
            full_url = self.url + '?' + data 
            try:
                print "URLL",full_url
                response_data = urllib2.urlopen(full_url).read()
                results = json.loads(response_data)
                #print "RESULTS before process",results
                if results:
                    temp=[]
                    temp.append(results['results'])
                    results =self.search_process_results(temp[0])
                    #print "RESULTS after process",results
            except Exception,e:
                print "EXCEPTION ERRORS",str(e)
                return []

        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
    
        return results
    
     def search_process_results(self,results):
        """ process the defaults results given by trademark api to restructre to pass it back to view function"""
        
        new_result2=[]
        q_lst = []
        for i in results:
            class_list=[]
            new_results={}
            if i['applicationNumber']:
                new_results['number']=i['applicationNumber']
                q_lst.append(i['applicationNumber'])
            if i['countryCode']:
                new_results['countryCode']=i['countryCode']
                q_lst.append(i['countryCode'])
            if i['applicationDate']:
                new_results['renewal_date']=i['applicationDate']
               
            if i['trademark']:
                new_results['name']=i['trademark']['text']
                new_results['image']=i['trademark']['imageURL']
            if i['statusDetail']:
                new_results['status']=i['statusDetail']['text']
                new_results['renewal_date']=i['statusDetail']['date']
            if i['specification']:
                for j in i['specification']:
                    if j['classCode']:
                        class_list.append(j['classCode'])
                class_list=str(class_list).strip('[]')
                new_results['t_class']=class_list
                
            new_result2.append(new_results)
           
##        print "NEW RESULTS",new_result2
#        casedetailobject = CasedetailModel.objects.filter(tm_number__in=q_lst,client=client_obj).values_list('tm_number',)
##        print "casedetailobject:-----------",casedetailobject
#        tn_num_lst = [i[0] for i in casedetailobject if i]
##        print tn_num_lst
##        print new_result2
#        final_result_lst = []
#        for i in new_result2:
#            dct = {}
#            if i.has_key('number') and i['number'] in tn_num_lst:
#                dct.update(i)
#                dct['action'] = 'view'
#                final_result_lst.append(dct)
#            else:
#                dct.update(i)
#                dct['action'] = 'add'
#                final_result_lst.append(dct)
              
        return new_result2