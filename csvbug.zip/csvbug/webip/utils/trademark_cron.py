'''
Created on Feb 17, 2012

@author: arun

@Purpose: Script to initiate the Trademark Import Process.
'''
import set_django_env

from trademark.import_export import TrademarkImportManager

if __name__ == "__main__":
    td = TrademarkImportManager()
    td.start_processing_trademarks()