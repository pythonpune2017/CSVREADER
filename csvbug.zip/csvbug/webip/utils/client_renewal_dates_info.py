"""
    Updated by : pritesh modi
    Date : 23 July 2012
    Purpose : To check the domain, ssl and trademark renewal dates for the clients and send them mail about the same.
    Dependency : python-dateutil
"""
import set_django_env
from datetime import date
from dateutil.relativedelta import relativedelta
from webip.client.models import ClientModel
from webip.client.models import *
from webip.domain.models import *
from webip.trademark.models import *
from webip.utils.send_mail import SendMail
from django.conf import settings

class GetRenewalInfo(object):
    """
        To get all the information about clients domain, ssl and trademark renewal dates
    """
    def __init__(self):
        """
        """
        start_date , end_date = self.getDatesInfo()
        self.start_date = start_date
        self.end_date = end_date
        
    def getDatesInfo(self):
        """
            start_time = current_time
            end_time = 90 days after  the current_time
        """
        start_date = date.today()
        end_date = start_date + relativedelta( months = +3 )
        return start_date , end_date
    
    
    def getDatesdiffInfo(self,expiry_date):
        """
            start_time = current_time
            end_time = 90 days after  the current_time
        """
        start_date = date.today()
        diff=expiry_date-start_date
        return diff.days
    
    
    def getAllClients(self):
        """
            Get all active clients in the system
        """
        active_clients = ClientModel.objects.filter(is_active = True,id=186)
        #active_clients = ClientModel.objects.filter(id=40)
        return active_clients
    
    def getDomainExpiryDate(self, client):
        """
            Get all the active domains having domain_renewals as alert between the given date range.
        """
        ssl_info = []
        domain_list = Domain.objects.filter(client = client, client__alert__name = "domain_renewals", expiry_date__range=(self.start_date,self.end_date)).values("name", "expiry_date", "client__name","client__alert__name", "client__alert__frequency")
        return domain_list
    
    def getSSLExpiryDate(self, client):
        """
            Get all the SSL information having ssl_renewals as alert between the given date range.
        """
        ssl_info = SSLDetails.objects.filter(domain__client = client, domain__client__alert__name = "ssl_renewals", expiry_date__range=(self.start_date,self.end_date)).values("ssl_common_name", "expiry_date", "domain__client__name","domain__client__alert__name", "domain__client__alert__frequency")
        return ssl_info
    
    def getTrademarkExpiryDate(self, client):
        """
            Get all the SSL information having trademark_renewals as alert between the given date range.
        """
        trademark_list = Trademark.objects.filter(client = client , client__alert__name = "trademark_renewals", renewal_date__range=(self.start_date,self.end_date)).values("name" , "client__name", "renewal_date","client__alert__name", "client__alert__frequency")
        return trademark_list
    
    def getClientSuperuserEmailID(self, client):
        """
            Get clients email_id
        """
        try:
            clientuser = ClientUser.objects.get(client = client , user_type = "superuser")
            superuser = clientuser.user.first_name + clientuser.user.last_name
            email = clientuser.user.email
        except Exception , e:
            print str(e)
            superuser = ''
            email = ''
        return (superuser,email)
    
    def process(self):
        """
            Process all the client information about domain, ssl and trademark as seperate list
        """
        client_info_dict = {}
        client_list = self.getAllClients()
        for client in client_list:
            client_info =  self.getClientSuperuserEmailID(client)
            domain = self.getDomainExpiryDate(client)
            ssl = self.getSSLExpiryDate(client)
            trademark = self.getTrademarkExpiryDate(client)
            client_info_dict[client_info] = {"domain_renewals" : domain ,"ssl_renewals" : ssl, "trademark_renewals" : trademark }               
        return client_info_dict
    
    def check_mail_send(self,k):
        """"function to check client alert type and expiry date to deside mail send or not"""
        info_send=False
        expiry_date=None
        
        if k.has_key('client__alert__name'):            
            if k['client__alert__name'] == 'trademark_renewals':
                expiry_date=k['renewal_date']
                frequency=k['client__alert__frequency']
                
            if k['client__alert__name'] == 'domain_renewals':
                expiry_date=k['expiry_date']
                frequency=k['client__alert__frequency']
                
        if k.has_key('domain__client__alert__name'):
            if k['domain__client__alert__name'] == 'ssl_renewals':
                expiry_date=k['expiry_date']
                frequency=k['domain__client__alert__frequency']
                
        if expiry_date:
            diff_days=self.getDatesdiffInfo(expiry_date)
            if frequency == 'daily':
                if diff_days!=0:
                    info_send=True
                else:
                    pass
            if frequency == 'monthly':
                if diff_days in (30,60,90):
                    info_send=True
                else:
                    pass
            if frequency == 'Weekly':
                if diff_days in (7,14,21,28,35,42,49,56,63,70,77,84):
                    info_send=True
                else:
                    pass
            if frequency == 'yearly':
                if diff_days == 365:
                    info_send=True
                else:
                    pass
        
        return info_send    
   
  
    
    def sendMail(self, client_info_dict):
        """       """
        for client , info in client_info_dict.iteritems():
            subject = "Renewal Reminder Information"
            mail_send=False
            trademark_final_message=''
            domain_final_message=''
            ssl_final_message=''
            for i in info:
                if i=='trademark_renewals':
                    val=info[i]
                    for k in val:
                        info_send=self.check_mail_send(k)
                        if info_send:
                            trademark_message="""
                                 <p>Your Trademark Name details=%s\n</p>
                                <p>Your Trademark Renewal Alert details=%s\n</p>
                                <p>Your Trademark Renewal Date details=%s\n</p>
                                <br>
                                <br>
                            """%(k['name'],k['client__alert__frequency'],k['renewal_date'])
                            trademark_final_message+=trademark_message
                            mail_send=True
                        else:
                            pass
            
                if i=='domain_renewals':
                    val=info[i]
                    for k in val:
                        info_send=self.check_mail_send(k)
                        if info_send:
                            domain_message="""
                                <p>Your Domain Renewal Alert details=%s\n</p>
                                <p>Your Renewal details for Domain name=%s\n</p>
                                <p>Your Domain Renewal Date details=%s\n</p>
                                <br>
                                <br>
                            """%(k['client__alert__frequency'],k['name'],k['expiry_date'])
                            domain_final_message+=domain_message
                            mail_send=True
                        else:
                            pass       
                if i=='ssl_renewals':
                        val=info[i]
                        for k in val:
                            info_send=self.check_mail_send(k)
                            if info_send:
                                ssl_message="""
                                    <p>Your SSL Renewal Alert details=%s\n</p>
                                    <p>Your SSL Common name details=%s\n</p>
                                    <p>Your SSL Renewal Date details=%s\n</p>
                                    <br>
                                    <br>
                                """%(k['domain__client__alert__frequency'],k['ssl_common_name'],k['expiry_date'])
                                ssl_final_message+=ssl_message
                                mail_send=True
                            else:
                                pass
                        

            if mail_send:
                message = """<p>Hello %s,</p>
                <p>Your Renewal Details are as Follows:  </p>
                <br>"""%(client[0])
                if trademark_final_message:
                    message+="""
                    <b>Trademark Renewals :</b>%s
                    <br>
                    <br>"""%(trademark_final_message)
                if domain_final_message:
                    message+="""
                            <b>Domain Renewals :</b>%s
                            <br>
                            <br>
                            """%(domain_final_message)
                if ssl_final_message:
                    message+="""
                        <b>SSL Renewals :</b>%s
                        <br>
                        <br> """%(ssl_final_message)
                
                if message:
                    message+="""
                            <p>Thanks,</p>
                            <p>Web Ip Support.</p>"""
                
                to_list=[]
                to_list.append(str(client[1]))
                bcc_list=["priteshm@leosys.in","gauravm@leosys.in"]
                from_email =settings.DEFAULT_FROM_EMAIL
                cc_list =[]
#                cc_list =['tyron.ball@webip.com.au','nicholas.boyd@webip.com.au']
                filepath = '' , #settings.MESSAGE_TEMPLATE_PATH
                f_obj=SendMail()
                try:
                    f_obj._send_mail(subject, message, from_email, to_list,[],bcc_list, '', content_subtype='html')
                except:
                   pass
            #mail_obj._send_mail(subject, message, from_id, to_list, cc_list)
        return True
    
    
obj = GetRenewalInfo()
client_info_dict  = obj.process()
if client_info_dict:
    obj.sendMail(client_info_dict)
