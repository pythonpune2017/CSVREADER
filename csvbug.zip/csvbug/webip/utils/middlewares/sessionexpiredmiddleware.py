from datetime import datetime
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.contrib import messages
from django.conf import settings

class SessionExpiredMiddleware(object):
    def process_request(self, request):
        # Timeout is done only for authenticated logged in users.
        if request.user.is_authenticated():
            last_activity = request.session.get('last_activity')
            now = datetime.now()
            
            # Timeout if idle time period is exceeded.
            if request.session.has_key('last_activity') and \
                (now - request.session['last_activity']).seconds > \
                settings.SESSION_IDLE_TIMEOUT:
                request.session.delete()
                messages.warning(request, "Your session has been timed out.")
                redirect_to = reverse("fn_login")
                return HttpResponseRedirect(redirect_to)
            # Set last activity time in current session.
            else:
                request.session['last_activity'] = now
        return None
