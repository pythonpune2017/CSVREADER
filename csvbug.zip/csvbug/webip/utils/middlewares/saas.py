'''
Created on 10-Sep-2012

@author: arun
'''
from django.contrib.auth.models import User
from client.models import ClientUser

class SaasMiddleware(object):
    
    def process_request(self, request):
        """
            Adds client object to request
        """
        request.client = None
        if request.user.is_authenticated():
            try:
                puser = ClientUser.objects.get(user= request.user)
                client = puser.client
            except:
                client = None
        
            request.client = client
    