"""
    Updated by : pritesh modi
    Date : 23 July 2012
    Purpose : To check the domain, ssl and trademark renewal dates for the clients and send them mail about the same.
    Dependency : python-dateutil
"""
import set_django_env
from datetime import date
from dateutil.relativedelta import relativedelta
from webip.client.models import ClientModel
from webip.client.models import *
from webip.domain.models import *
from webip.trademark.models import *
from webip.utils.send_mail import SendMail
from django.conf import settings
from client.managers import AlertManager

class GetRenewalInfo(object):
    """
        To get all the information about clients domain, ssl and trademark renewal dates
    """
    def __init__(self):
        """
        """
        start_date , end_date = self.getDatesInfo()
        self.start_date = start_date
        self.end_date = end_date
        
    def getDatesInfo(self):
        """
            start_time = current_time
            end_time = 90 days after  the current_time
        """
        start_date = date.today()
        end_date = start_date + relativedelta( months = +3 )
        return start_date , end_date
    
    
    def getDatesdiffInfo(self,expiry_date):
        """
            start_time = current_time
            end_time = 90 days after  the current_time
        """
        start_date = date.today()
        diff=expiry_date-start_date
        return diff.days
    
    
    def get_managers_clients(self):
        "  returns the  account manager User Alerts with their frequency "
     
        clients = ClientModel.objects.filter(is_active=True).exclude(accountmangers=None).select_related("accountmangers")
#        clients = clients.values("id", "accountmangers__id", "accountmangers__user__first_name","accountmangers__user__last_name", "name")
        managers = StaffModel.objects.filter(emp_type ='Account Manager')
        manager_details={}
        for mgr in managers:
            
            alerts=[]
            al_dict = {}
            alerts = AlertManager().get_user_alerts(mgr.user)
            manager_info =  self.getmanagerSuperuserEmailID(mgr.user)
            for i in alerts:
                al_dict[i.name] = i.frequency
            manager_details[manager_info]=al_dict
        print "MANGERS_DETAIL",manager_details
        return manager_details
        #context = {"managers": list(userclients), "alerts" : al_dict}

    def getAllClients(self):
        """
            Get all active clients in the system
        """
        managers = StaffModel.objects.filter(emp_type ='Account Manager')
        manager_details={}
        for mgr in managers:
            alerts=[]
            al_dict = {}
            userclients = ClientModel.objects.filter(is_active=True, accountmangers=mgr.id)
            alerts = AlertManager().get_user_alerts(mgr.user)
            manager_info =  self.getmanagerSuperuserEmailID(mgr.user)
            for i in alerts:
                al_dict[i.name] = i.frequency
            al_dict['assign_clients']=userclients
            manager_details[manager_info]=al_dict
#        context = {"all": list(otherclients), "managers": list(userclients), "alerts" : al_dict}
    
#        clients = ClientModel.objects.filter(is_active=True).exclude(accountmangers=None).select_related("accountmangers")
#        clients = clients.values("id", "accountmangers__id", "accountmangers__user__first_name","accountmangers__user__last_name", "name")
        #active_clients = ClientModel.objects.filter(id=40)
        return manager_details
    
    def getDomainExpiryDate(self, client):
        """
            Get all the active domains having domain_renewals as alert between the given date range.
        """
        ssl_info = []
        domain_list = Domain.objects.filter(client = client, client__alert__name = "domain_renewals", expiry_date__range=(self.start_date,self.end_date)).values("name", "expiry_date", "client__name","client__alert__name", "client__alert__frequency")
        return domain_list
    
    def getSSLExpiryDate(self, client):
        """
            Get all the SSL information having ssl_renewals as alert between the given date range.
        """
        ssl_info = SSLDetails.objects.filter(domain__client = client, domain__client__alert__name = "ssl_renewals", expiry_date__range=(self.start_date,self.end_date)).values("ssl_common_name", "expiry_date", "domain__client__name","domain__client__alert__name", "domain__client__alert__frequency")
        return ssl_info
    
    def getTrademarkExpiryDate(self, client):
        """
            Get all the SSL information having trademark_renewals as alert between the given date range.
        """
        trademark_list = Trademark.objects.filter(client = client , client__alert__name = "trademark_renewals", renewal_date__range=(self.start_date,self.end_date)).values("name" , "client__name", "renewal_date","client__alert__name", "client__alert__frequency")
        return trademark_list
    
    def getmanagerSuperuserEmailID(self, user):
        """

        """
        try:
            superuser = user.first_name + user.last_name
            email = user.email
        except Exception , e:
            print str(e)
            superuser = ''
            email = ''
        return (superuser,email)
    
    def getClientSuperuserEmailID(self, client):
        """
            Get clients email_id
        """
        try:
            clientuser = ClientUser.objects.get(client = client , user_type = "superuser")
            superuser = clientuser.user.first_name + clientuser.user.last_name
            email = clientuser.user.email
        except Exception , e:
            print str(e)
            superuser = ''
            email = ''
        return (superuser,email)
    def process(self):
        """
            Process all the client information about domain, ssl and trademark as seperate list
        """
        client_info_dict = {}
        client_list = self.getAllClients()
        for key,value in client_list.iteritems():
            if value['assign_clients']:
                val_list=value['assign_clients']
                if val_list:
                    for i in val_list:
                        client_info =  self.getClientSuperuserEmailID(i)
                        domain = self.getDomainExpiryDate(i)
                        ssl = self.getSSLExpiryDate(i)
                        trademark = self.getTrademarkExpiryDate(i)
                        value['data'] = {"domain_renewals" : domain ,"ssl_renewals" : ssl, "trademark_renewals" : trademark }               
        return client_list
    
#    def check_mail_send(self,k):
#        """"function to check client alert type and expiry date to deside mail send or not"""
#        info_send=False
#        expiry_date=None
#        
#        if k.has_key('client__alert__name'):            
#            if k['client__alert__name'] == 'trademark_renewals':
#                expiry_date=k['renewal_date']
#                frequency=k['client__alert__frequency']
#                
#            if k['client__alert__name'] == 'domain_renewals':
#                expiry_date=k['expiry_date']
#                frequency=k['client__alert__frequency']
#                
#        if k.has_key('domain__client__alert__name'):
#            if k['domain__client__alert__name'] == 'ssl_renewals':
#                expiry_date=k['expiry_date']
#                frequency=k['domain__client__alert__frequency']
#                
#        if expiry_date:
#            diff_days=self.getDatesdiffInfo(expiry_date)
#            if frequency == 'daily':
#                if diff_days!=0:
#                    info_send=True
#                else:
#                    pass
#            if frequency == 'monthly':
#                if diff_days in (30,60,90):
#                    info_send=True
#                else:
#                    pass
#            if frequency == 'Weekly':
#                if diff_days in (7,14,21,28,35,42,49,56,63,70,77,84):
#                    info_send=True
#                else:
#                    pass
#            if frequency == 'yearly':
#                if diff_days == 365:
#                    info_send=True
#                else:
#                    pass
#        
#        return info_send
#    
    def check_mail_send(self,k,alert):
        """"function to check client alert type and expiry date to deside mail send or not"""
        info_send=False
        expiry_date=None
        if k.has_key('client__alert__name'):
            if k['client__alert__name']=='trademark_renewals':                         
                expiry_date=k['renewal_date']
                frequency=alert
                    
            if k['client__alert__name'] == 'domain_renewals':
                expiry_date=k['expiry_date']
                frequency=alert
                    
            if k.has_key('domain__client__alert__name'):
                if k['domain__client__alert__name'] == 'ssl_renewals':
                    expiry_date=k['expiry_date']
                    frequency=alert
                
        if expiry_date:
            diff_days=self.getDatesdiffInfo(expiry_date)
            if frequency == 'daily':
                if diff_days!=0:
                    info_send=True
                else:
                    pass
            if frequency == 'monthly':
                if diff_days in (30,60,90):
                    info_send=True
                else:
                    pass
            if frequency == 'Weekly':
                if diff_days in (7,14,21,28,35,42,49,56,63,70,77,84):
                    info_send=True
                else:
                    pass
            if frequency == 'yearly':
                if diff_days == 365:
                    info_send=True
                else:
                    pass
        
        return info_send
    
  
    
    def sendMail(self, client_info_dict):
        """       """
        for client , info in client_info_dict.iteritems():
            subject = "Renewal Reminder Information"
            mail_send=False
            trademark_final_message=''
            domain_final_message=''
            ssl_final_message=''
            if info['data']['trademark_renewals']:
                  trademark_list=info['data']['trademark_renewals']
                  alert_value=info['trademark_renewals']
                  for k in trademark_list:
                        info_send=self.check_mail_send(k,alert_value)
                        if info_send:
                                trademark_message="""
                                     <p>Your Client name details=%s\n</p>
                                     <p>Your Trademark Name details=%s\n</p>
                                    <p>Your Trademark Renewal Alert details=%s\n</p>
                                    <p>Your Trademark Renewal Date details=%s\n</p>
                                    <br>
                                    <br>
                                """%(k['client__name'],k['name'],alert_value,k['renewal_date'])
                                trademark_final_message+=trademark_message
                                mail_send=True
                        else:
                            pass
            
            if info['data']['domain_renewals']:
                domain_list=info['data']['domain_renewals']
                alert_value=info['domain_renewals']
                for k in domain_list:
                        info_send=self.check_mail_send(k,alert_value)
                        if info_send:
                            domain_message="""
                                     <p>Your Client name details=%s\n</p>
                                    <p>Your Domain Renewal Alert details=%s\n</p>
                                    <p>Your Renewal details for Domain name=%s\n</p>
                                    <p>Your Domain Renewal Date details=%s\n</p>
                                    <br>
                                    <br>
                                """%(k['client__name'],alert_value,k['name'],k['expiry_date'])
                            domain_final_message+=domain_message
                            mail_send=True
                        else:
                            pass
                
                       
            if info['data']['ssl_renewals']:
                ssl_list=info['data']['ssl_renewals']
                alert_value=info['ssl_renewals']
                for k in ssl_list:
                        info_send=self.check_mail_send(k,alert_value)
                        if info_send:
                            ssl_message="""
                                    <p>Your Client name details=%s\n</p>
                                    <p>Your SSL Renewal Alert details=%s\n</p>
                                    <p>Your SSL Common name details=%s\n</p>
                                    <p>Your SSL Renewal Date details=%s\n</p>
                                    <br>
                                    <br>
                                """%(k['client__name'],alert_value,k['ssl_common_name'],k['expiry_date'])
                            ssl_final_message+=ssl_message
                            mail_send=True
                        else:
                            pass
                        
            
            #code for account manager get a email
            
            
            #code end for account manager geta a email or not.
            
            
            
            
            if mail_send:
                message = """<p>Hello %s,</p>
                <p>Your Renewal Details are as Follows:  </p>
                <br>"""%(client[0])
                if trademark_final_message:
                    message+="""
                    <b>Trademark Renewals :</b>%s
                    <br>
                    <br>"""%(trademark_final_message)
                if domain_final_message:
                    message+="""
                            <b>Domain Renewals :</b>%s
                            <br>
                            <br>
                            """%(domain_final_message)
                if ssl_final_message:
                    message+="""
                        <b>SSL Renewals :</b>%s
                        <br>
                        <br> """%(ssl_final_message)
                
                if message:
                    message+="""
                            <p>Thanks,</p>
                            <p>Web Ip Support.</p>"""
                
                to_list=[]
                to_list.append(str(client[1]))
                bcc_list=["priteshm@leosys.in","gauravm@leosys.in"]
                from_email =settings.DEFAULT_FROM_EMAIL
                cc_list =[]
#                cc_list =['tyron.ball@webip.com.au','nicholas.boyd@webip.com.au']
                filepath = '' , #settings.MESSAGE_TEMPLATE_PATH
                f_obj=SendMail()
                try:
                    f_obj._send_mail(subject, message, from_email, to_list,[],bcc_list, '', content_subtype='html')
                except:
                   pass
            #mail_obj._send_mail(subject, message, from_id, to_list, cc_list)
        return True
    
    
obj = GetRenewalInfo()

client_info_dict  = obj.process()
#alert_manager_details=obj.get_managers_clients()
if client_info_dict:
    obj.sendMail(client_info_dict)
#if alert_manager_details:
#    obj.sendMail(alert_manager_details)
