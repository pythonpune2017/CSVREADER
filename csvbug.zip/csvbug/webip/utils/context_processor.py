from django.core.urlresolvers import reverse, resolve
import re
from datetime import datetime
from django.conf import settings
from django.core.cache import cache
import twitter
UPLOAD_MEDIA_URL = settings.UPLOAD_MEDIA_URL

# dict of url strings to detec9t active selection
ACTIVE_URL = {
        reverse("controlpanel"): "active_controlpanel",
        reverse("managestaff"): "active_manage_staff",
        reverse("manageclients"): "active_manage_staff",
        reverse("assignclient"):"active_manage_staff",
        reverse("managedomains"): "active_manage_domains",
        reverse("manage_keywords"): "active_monitoring",
        reverse("manage_domainmonitoring"): "active_monitoring",
        reverse("trademark_page"): "active_monitoring",
        reverse("view_logs"): "active_logs",
        reverse("client_home_page"): "active_client_home",
        reverse("domain_home_page"): "active_domain_mgmt",
        reverse("manage_trademark"): "active_trademark_mgmt",
        reverse("trademark_page_underconstruction"): "active_trade_mgmt",
        reverse("monitoring_home_page"): "active_monitor_mgmt",
        reverse("monitoring_domain"): "active_monitor_mgmt",
        reverse("monitoring_trademark"): "active_monitor_mgmt",
        reverse("fn_managevendors"): "active_contracts_mgmt",
        reverse("fn_importvendor"): "active_contracts_mgmt",
        reverse("fn_managecases"): "active_infrigement_mgmt",
        reverse("help_pageunderconstrunction"): "active_help_mgmt",
        reverse("manageusers"): "active_user_mgmt",
        reverse("fn_registerdomain"): "active_domain_mgmt",
        reverse("fn_importdomain"): "active_domain_mgmt",
        "fn/cases/view/(?P<case_id>\d+)/": "active_infrigement_mgmt",
        "fn/cases/infringer/(?P<case_id>\d+)/": "active_infrigement_mgmt",
        "fn/cases/team/(?P<case_id>\d+)/": "active_infrigement_mgmt",
        "fn/cases/(?P<case_id>\d+)/milestone/view/": "active_infrigement_mgmt",
        "fn/cases/(?P<case_id>\d+)/history/view/": "active_infrigement_mgmt",
        reverse("fn_order_domain"): "active_domain_mgmt",
        }

def active_url(request) :
    """ function to check for active urls """
    context = {}
    active_dict = {}
    for url,value in ACTIVE_URL.items() :
        if re.search(url,request.path) :
            active_dict[value] = "nav_active"
#            break
    # resolve request path
    if active_dict :
        context = dict( context.items() + active_dict.items() )
    context['UPLOAD_MEDIA_URL'] = UPLOAD_MEDIA_URL
    return context


def latest_tweet( request ):
    #tweet = cache.get( 'tweet' )
    try:
        #if tweet:
        #    return {"tweet": tweet}
        tweet = twitter.Api().GetUserTimeline( settings.TWITTER_USER )
        #print "TWEET",tweet
        for i in tweet:
            i.date = datetime.strptime( i.created_at, "%a %b %d %H:%M:%S +0000 %Y" )
            cache.set('tweet', i, settings.TWITTER_TIMEOUT )
    except:
        tweet=None
    return {"tweet": tweet[0:4]}

def Diff_match(dict_obj, data):
    """
        Matched changed data
    """
    old_patch = {}
    new_patch = {}
    for i,j in dict_obj.items():
        try:
            if not data.get(str(i)) == dict_obj[str(i)]:
                new_patch.update({str(i):data.get(str(i))})
                old_patch.update({str(i):dict_obj.get(str(i))})
        except:
            pass
        else:
            pass
    return new_patch, old_patch

def Diff_filename(oldfilename,newfilename):
    ''
#    import ipdb
#    ipdb.set_trace()
    old_patch = {}
    new_patch = {}
    try:
        if not newfilename == oldfilename:
            new_patch.update({'filename':newfilename})
            old_patch.update({'filename':oldfilename})
    except:
        pass
    else:
        pass

    return new_patch, old_patch
#    oldfilename
#    newfileobj.name

def Permission_match(obj_info,data):
    """
        Matched permission data
    """
    result_array_new = {}
    result_array_old = {}
    perms_data = {'edit_domain': True, 'view_contract': True, 'edit_contract': True, 'edit_trademark': True, 'view_domain': True, 'order_domain': True, 'view_trademark': True,'monitoring_brand':False,'monitoring_domain':False,'monitoring_trademark':False}
    for i,j in perms_data.items():
        if i in data.keys() and not i in obj_info:
            result_array_new.update({i:True})
            result_array_old.update({i:False})
        elif not i in data.keys() and i in obj_info:
            result_array_new.update({i:False})
            result_array_old.update({i:True})
    return result_array_new, result_array_old

def Date_match(ex_date,new_date):
    """
        Mached date
    """
    result_array_new = {}
    result_array_old = {}
    #plan_id=client_subscription_object.plan_id
    ex_date_list=ex_date.split('-')
    new_date_list=new_date.split('-')
    for i in new_date_list:
        if not str(i) == ex_date_list[new_date_list.index(i)]:
            result_array_new.update({'expiry_date':new_date})
            result_array_old.update({'expiry_date':ex_date})
            break
    return result_array_new, result_array_old

def Alert_match(alertformdata, data):
    """
        Alerts matching information
    """
    result_array_new = {}
    result_array_old = {}
    alert_data = ['domain_renewals', 'dms_changes', 'ssl_renewals', 'trademark_renewals', 'contract_changes']
    for i in alert_data:
        if i in alertformdata and not i in data.keys():
            result_array_new.update({i:True})
            result_array_old.update({i:False})
        elif not i in alertformdata and i in data.keys():
            result_array_new.update({i:False})
            result_array_old.update({i:True})
        elif i in alertformdata and i in data.keys():
            value = str(i)+'_choice'
            if not alertformdata[value] == data.get(value):
                 result_array_new.update({value:data.get(value)})
                 result_array_old.update({value:alertformdata[value]})
    return result_array_new, result_array_old
