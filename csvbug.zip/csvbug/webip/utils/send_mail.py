"""
	This Module is Responsible for handling all common code resources
	required in this project.
"""
import os
import sys
import set_django_env
from django.conf import settings
from django.core.mail import EmailMessage

class FixedEmailMessage(EmailMessage):
    def __init__(self, subject='', body='', from_email=None, to=None, cc=None,
                 bcc=None, connection=None, attachments=None, headers=None):
        """
        Initialize a single email message (which can be sent to multiple
        recipients).

        All strings used to create the message can be Unicode strings (or UTF-8
        bytestrings). The SafeMIMEText class will handle any necessary encoding
        conversions.
        """
        to_cc_bcc_types = (type(None), list, tuple)
        # test for typical error: people put strings in to, cc and bcc fields
        # see documentation at http://www.djangoproject.com/documentation/email/
        assert isinstance(to, to_cc_bcc_types)
        assert isinstance(cc, to_cc_bcc_types)
        assert isinstance(bcc, to_cc_bcc_types)
        super(FixedEmailMessage, self).__init__(subject, body, from_email, to,
                                           bcc, connection, attachments, headers)
        if cc:
            self.cc = list(cc)
        else:
            self.cc = []

    def recipients(self):
        """
        Returns a list of all recipients of the email (includes direct
        addressees as well as Bcc entries).
        """
        return self.to + self.cc + self.bcc

    def message(self):
        msg = super(FixedEmailMessage, self).message()
        del msg['Bcc'] # if you still use old django versions
        if self.cc:
            msg['Cc'] = ', '.join(self.cc)
        return msg


class SendMail:
	"""
	"""
	def _send_mail(self, subject, message, from_id, to_list, cc_list=[],bcc=[], filepath='', content_subtype=None):
		"""Sends Mail"""
		try:
			mail_obj=FixedEmailMessage(subject, message, from_id, to_list, cc_list,bcc)

			# check for attachments.
			if filepath:
				if isinstance(filepath, list):
					for file in filepath:
						mail_obj.attach_file(file)
				else:
					mail_obj.attach_file(filepath)

			# defines MIME type of the body parameter
			# default is text and for html content ,value is html.
			if content_subtype:
				mail_obj.content_subtype = content_subtype
			status=mail_obj.send(fail_silently=False)
			print "status",status
			return (True,'')
		except Exception,e:
			return (False,str(e))

##
#obj = SendMail()
#print obj._send_mail("Test Mail","Hi guys","tushart@leosys.in",["tushart@leosys.in"],[], '')

