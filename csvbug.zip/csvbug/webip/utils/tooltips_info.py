"""
    This file contains all the mapping dictionaries for the tooltips on all the templates of the Web IP project
    
    Created on : March 9 2012
    Created by : Shweta Mishra
"""

tooltip_dict = {
                #Staff related tooltips
                'add_staff' : "Click to add new staff",
                'import_staff' : "Click to bulk import staff data by uploading xls or csv file",
                'export_staff' : "Click to export staff information into xls or csv format",
                'download_staff_format' : "Click to download import formats for staff data both in xls and csv format",
                'search_staff' : "Search staff on the basis of keywords, client , staff type and status",
                'edit_staff' : "Click to edit this staff details",
                'delete_staff' : "Click to delete this staff",
                'clear_fields' : "Clear the search selections",
                
                #Assign Client related tooltips
                'assign_client' : "Click to add new client",
                'search_assign_client' : "Search client on the basis of accountmanagers and client",
                'edit_assign_client' : "Click to edit this client details",
                'delete_assign_client' : "Click to delete this client",
                
                #Client related tooltips
                'add_client' : "Click to add new client",
                'import_client' : "Click to bulk import client data by uploading xls or csv file",
                'export_client' : "Click to export client information into xls or csv format",
                'download_client_format' : "Click to download import formats for client data both in xls and csv format",
                'edit_client' : "Click to edit this client details",
                'delete_client' : "Click to delete this client",
                'search_client' : "Search staff on the basis of keywords, client , client type and status",
                
                #Domain related tooltips
                'add_domain' : "Click to add new domain",
                'view_domain' : "Click to view the domain details",
                'import_domain' : "Click to bulk import domain data by uploading xls or csv file",
                'export_domain' : "Click to export domain information into xls or csv format",
                'download_domain_format' : "Click to download import formats for domain data both in xls and csv format",
                'edit_domain' : "Click to edit this domain details",
                'delete_domain' : "Click to delete this domain",
                'edit_ssl' : "Click to edit SSL details",
                'edit_dns' : "Click to edit DNS details",
                'edit_notes' : "Click to edit notes",
                'search_domain' : "Search staff on the basis of keywords, client , domain type and status",
                
                #Log related tooltips
                'export_log' : "Click to export log information into xls or csv format",
                'search_log' : "Search log on the basis of keywords, type , activity and activity date",
                
                "instra_not_available" : "Service not available please try after some time"
                
                }