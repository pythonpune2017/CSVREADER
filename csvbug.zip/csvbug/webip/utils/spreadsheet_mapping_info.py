"""
    This file contains all the mapping dictionaries for the import and export 
    functionality in the project
    
    Created on : Feb 6 2012
    Created by : Shweta Mishra
"""

#Staff Mappings
STAFF_SEQUENCE_LIST = ['Username','Name','Email Address','Phone Number','Staff Type','Status']
STAFF_TITLE_LIST = {'Username':'user__username','Name':"user__first_name","Email Address":"user__email",
                  'Phone Number':"user__userprofilemodel__phone","Staff Type":"emp_type"
                  ,'Status':"user__is_active"}


#Client Mappings
CLIENT_SEQUENCE_LIST = ['Name','Username','Country','Email Address','Phone Number','Subscription',
                        'Status','Domain Renewals','DNS Changes','SSL Renewals','Trademark Renewals',
                        'Contract Changes']
        
CLIENT_TITLE_LIST = {'Username':'clientuser__user__username', 'Status':'is_active',
                'Subscription':'subscription', 'Phone Number':'clientuser__user__userprofilemodel__phone',
                'Email Address':'clientuser__user__email', 'Name':'name', 'Country':'country__country_name',
                'Domain Renewals':'Domain Renewals','DNS Changes':'DNS Changes','SSL Renewals':'SSL Renewals',
                "Trademark Renewals":"Trademark Renewals",'Contract Changes':'Contract Changes'
            } 

 
#Domain Mappings
DOMAIN_SEQUENCE_LIST =['Domain Name','Client','Brand Name','Country','Cost Centre','Registrar',
                       'Renewal Date','Notes','Cost Per Annum','Auto renew','SSL Details']
DOMAIN_TITLE_LIST = {'Domain Name':"name",'Client':"client__name",
                        'Brand Name':"client__name",'Country':"country__country_name",
                        'Cost Centre':"costcentre",'Registrar':"registrar",'Renewal Date':"expiry_date",
                        'Notes':"notes",'Cost Per Annum':"cost_per_annum",'Auto renew':"auto_renew",
                        'SSL Details':"ssl_details"
                    }


#Userlog Mappings
USERLOGS_SEQUENCE_LIST =['Datetime','Username','Type','Activity']
USERLOGS_TITLE_LIST = {'Datetime':"timestamp",'Username':"user__username",
                        'Type':"user_type",'Activity':"activity"}


#Vendor Mappings
VENDOR_SEQUENCE_LIST = ["Title", "Vendor Name", "Domain Name", "Owner", "Start Date", "End Date","Value Inc"]
VENDOR_TITLE_LIST ={"Title":"title", "Vendor Name":"name", "Domain Name":"domain_name",
                     "Owner":"owner", "Start Date":"start_date", "End Date":"end_date",
                     "Value Inc":"value_inc"
                    }


#Trademark Mappings
TRADEMARK_SEQUENCE_LIST = ["TM Number", "TM Name", "Class","Type","Status", "Renewal Date","Renewal Cost(inc)", "Business Unit","Vendor",]
TRADEMARK_TITLE_LIST ={"TM Number":"number", "TM Name":"name", "Class":"t_class","Type":"t_type",
                     "Status":"status", "Renewal Date":"renewal_date", "Renewal Cost(inc)":"renewal_cost","Business Unit":"business_unit",
                     "Vendor":"vendor"
                    }


#Cases Mappings
CASE_SEQUENCE_LIST = ["Case ID","Name","Domain","Type","Date Found","Owner","Budget","Spend To-Date","Status"]
CASE_TITLE_LIST = {"Case ID":"id","Name":"name","Domain":"domain__name","Type":"case_type",
                   "Date Found":"date_found","Owner":"owner","Budget":"budget","Spend To-Date":"spent_todate",
                   "Status":"status"
                   }