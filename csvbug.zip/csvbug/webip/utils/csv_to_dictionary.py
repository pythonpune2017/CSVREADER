"""
    Purpose : To read a csv file and convert it into dictionary
    For now it only supports 
            1. Field Delimiters ==> "/t"
            2. Text Delimiter ==> '"'
    
    Since csv reader only support single delimiter at a time, multiple delimiters are not supported.
    So the csv file to be read should only have the above mentioned delimiters.
    
    This module does not support other delimiters.
"""

import csv

class CSVDictionaryConversion():
    """
        To read and process a csv file and make a dictionary out of it
    """
    def csvConverter(self, csv_location):
        """
            Purpose: Function to generate Python Dictionary from CSV . This function inturn calls 
                    subsequent functions to generate the Python Dictionary.
            Input: Input CSV
            Output: Python Dictionary
            Dependency: csv
        """
        
        self.csv_location = csv_location
        result_list = self.processCsvToDictionary()
        return result_list
    

    
    def processCsvToDictionary(self):
        """
            Process csv file to get a dictionary
        """
        result_list = []
        file_data = open(self.csv_location, 'rt')
        dialect = csv.Sniffer().sniff(file_data.read(1024))
        file_data.seek(0)
        try:
#            try:
#                reader = csv.DictReader(file_data, dialect="excel", delimiter = '\t', quotechar = '"')
#            except:
#                reader = csv.DictReader(file_data, dialect="excel", delimiter = ';', quotechar = '"')
            reader = csv.DictReader(file_data)
           
            for row in reader:
                new_row =  dict(zip(row.keys() , row.values()))
                result_list.append(new_row)
        finally:
            file_data.close()
        return result_list
    
#obj = CSVDictionaryConversion()
#data = obj.csvConverter("/home/shweta/Desktop/test.csv")
#print data
