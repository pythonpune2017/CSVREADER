'''
Created on Jan 12, 2012

@author: arun
'''
from django.core.paginator import Paginator, InvalidPage, EmptyPage

def paginate( objects, page, obj_per_page=5 ):
    """
        Uses the django paginator.
        By default it will create paginator with 5 elements, we can increase the count by passing the value to obj_per_page
    
    """
    obj_per_page = int(obj_per_page)
    
    paginator_obj = Paginator(objects, obj_per_page )

    try:
        page = int( page )
    except ValueError:
        page = 1
    except TypeError:
        page = 1

    try:
        page_objs = paginator_obj.page( page )
    except ( InvalidPage, EmptyPage ):
        page_objs = paginator_obj.page( paginator_obj.num_pages )

    return page_objs
