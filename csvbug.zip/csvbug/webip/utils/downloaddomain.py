
import sys
from ftplib import FTP

#ftphost, file_to_retrieve, output_path = sys.argv[1:4]
ftphost = "rz.verisign-grs.com"
file_to_retrieve = "com.zone.gz"
output_path = "/home/ashish/Videos/download/"
username = "tball"
password = "73%CBMR"

#ftphost = "172.16.0.53"
#file_to_retrieve = "/home/projects/webip_env/code/webip/constants.py"
#output_path = "/home/shweta/Desktop/constants.py"
#username = "shweta"
#password = "shweta#123"


print "Retreiving %(file_to_retrieve)s from FTP host %(ftphost)s, saving to %(output_path)s" % locals()

ftp = FTP(ftphost)
ftp.login(username , password)

outfile = None
def data_callback(data):
    global outfile
    if outfile is None:
        outfile = open(output_path, 'w')

    outfile.write(data)

ftp.retrbinary("RETR %s" % file_to_retrieve, data_callback)

if outfile is not None:
    outfile.close()
  