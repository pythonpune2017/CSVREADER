"""
    This module gives the randomly generated username and passwords
"""
import random
import string
from django.contrib.auth.models import User


class RandomGenerator():
    """
        To generate random usernames and passwords
    """

    def username_generator(self):
        """
            Purpose: To generate random usernames
        """
        username = "".join(random.sample(string.ascii_lowercase, 6))
        status = self.user_existance(username)
        if status == True:
            self.username_generator()
        return username
    
    def password_generator(self):
        """
            Purpose: To generate random passwords
        """
        password = User.objects.make_random_password(10)
        return password
    
    def user_existance(self, username):
        """
            Check for unique username
        """
        status = User.objects.filter(username = username).exists()
        return status

