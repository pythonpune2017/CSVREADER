# Globals projects settings values for JS

from django.conf import settings
from django.template import TemplateSyntaxError, VariableDoesNotExist, Node
from django.template import Library, Variable, loader, Context
from django.utils.safestring import mark_safe
register = Library()

class LoadGlobalJs( Node ):
    """Set certain settings as JS Global varialbes"""

    def render( self, context ):
        request = context['request']
        t = loader.get_template( 'global_js.html' )
        globals ={'MEDIA_URL': settings.MEDIA_URL,
                  'STATIC_URL': settings.STATIC_URL
                }
        code_context = Context( 
                            {'wjs_settings':globals}
                            , autoescape=context.autoescape )
        return t.render( code_context )


def global_js_settings( parser, token ):
    """Set certain settings as JS Global varialbes"""
    return LoadGlobalJs()


    # register the tag
register.tag( 'js_settings', global_js_settings )