import httplib2
import urllib
import urllib2
from urllib2 import Request,URLError,HTTPError


class InstraDomainManager():
    
    def __init__(self):
        print "in the init"
        self.user='webip'
        self.password='Woodfish501'
        self.url= 'https://api.instra.com:8443/InstraAPI/InstraPostAPI.do'
        #self.password='Webip1234'
        #self.url= 'http://api-ote.instra.com:8080/InstraAPI/InstraPostAPI.do'
    
    def create_domain(self,kwargs, nameserverdict, ipaddressdict = {}):
        """ create a domain in instra api """
        try:
            http = httplib2.Http()
            values ={
                 'user' :self.user,
                 'pw' :self.password,
                 'command' :'CreateDomain',
                 'domain':kwargs.get('domain',None),
                 'period':kwargs.get('period',None),
                 'registrantcontact':kwargs.get('registrantcontact',None),
                 'admincontact':kwargs.get('admincontact',None),
                 'techcontact':kwargs.get('techcontact',None),
                 'billingcontact':kwargs.get('billingcontact',None),
             }
            values.update(nameserverdict)
            if ipaddressdict:
                values.update(ipaddressdict)
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(content)
            else:
                contents = {}
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
    
        return response, contents
    
    def check_nameserver_availability(self, nameserver_dict):
        """check domain available in instra api """
        region_dict = {}
        domain_dict ={}
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'CheckNameserverHost',
            }
            values.update(nameserver_dict)
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, data = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(data)
            else:
                contents = data
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
        return response , contents
    
    def _process_domain_name(self, domain_name):  
        """
            Processing the input given for the structuring the url given to instra api for checking the domain availability
        """
        domain_dict = {}
        count = 0
        if type(domain_name) == type([]):
            for name in domain_name:
                if count==1000:
                    break
                count +=1
                domain_dict["domain"+str(count)] = name
        else:
            domain_dict["domain1"] = domain_name
        return domain_dict
    
    def _process_region(self, region):  
        """
            Processing the input given for the structuring the url given to instra api for checking the domain availability
        """
        region_dict = {}
        count = 0
        if type(region) == type(list):
            for r in region:
                count +=1
                region_dict["region"+str(count)] = r
        else:
            region_dict["region1"] = region
        return region_dict
    
    def check_domain_available(self, domain_name, region=None):
        """check domain available in instra api """
        region_dict = {}
        domain_dict ={}
        domain_dict = self._process_domain_name(domain_name)
        if region:
            region_dict = self._process_region(region)
        Instra = True
        response , contents = None, {}
        try:
        	if Instra:
	            http = httplib2.Http()
	            values ={
	                     'user' :self.user,
	                     'pw' :self.password,
	                     'command' :'CheckDomain',
	            }
	            values.update(domain_dict)
	            if region_dict:
	                values.update(region_dict)
	            else: values.update({'region':'ALL'})
	            headers = {'Content-type': 'application/x-www-form-urlencoded'}
#                print "values",values
                data = urllib.urlencode(values)
#                print "DATA",data
#                f = urllib.urlopen("http://api-ote.instra.com:8080/InstraAPI/InstraPostAPI.do? %s" % data)
#                print "FINAL URL",f.geturl()
                response, data = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
#                print "response", str(response)
                
                contents = self._status_restructure_contents(data , len(domain_dict))
               
        except URLError, e:
            pass
        return response , contents
    
    def _status_restructure_contents(self, content , domain_length):
        """
            Restructuring the contents returned by the url call to instara api
        """

        #print "In restructure contents"
        count = 0
        content_dict ={}
#        print "content", content
        content_list = content.split('\n')
        for item in content_list:
            if item.__contains__('='):
                try:
                    data = str(item).split('=')
                except Exception , e:
                    print str(e)
                try:
                    content_dict[str(data[0]).strip().lower()] = str(data[1]).strip().lower()
                except:
                    pass
#        print "content_dict", content_dict
        data_list = []
        content_keys = content_dict.keys()
        for i in range (int(domain_length)+1):
            data_dict ={}
            data = [str(item) for item in content_keys if str(item).endswith(str(i))]
            data_dict= {}
            for d in data:
#                print "d", d
                data_dict.update({str(d).strip(str(i)):content_dict[d]})
            if data_dict:
                data_list.append(data_dict)
#        print "data_list", data_list
        #print "\n============================================================================"
        return data_list
    
    def _restructure_contents(self, content , domain_length):
        """
            Restructuring the contents returned by the url call to instara api
        """
        #print "In restructure contents"
        
        count = 0
        content_dict ={}
#        print "content", content
        content_list = content.split('\n')
        for item in content_list:
            if item.__contains__('='):
                try:
                    data = str(item).split('=')
                except Exception , e:
                    print str(e)
                try:
                    content_dict[str(data[0]).strip().lower()] = str(data[1]).strip().lower()
                except:
                    pass
#        print "content_dict", content_dict
        data_list = []
        content_keys = content_dict.keys()
        for i in range (int(domain_length)+1):
            data_dict ={}
            data = [str(item) for item in content_keys if str(item).endswith(str(i))]
            data_dict = [{d:content_dict[d]} for d in data]
            data_list.append(data_dict)
        #print "data_list", data_list
        #print "\n============================================================================"
        return data_list
    
    def delete_domain(self,domain_name):
        """delete domain from instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'DeleteDomain',
                     'domain':domain_name # N is number from 1 up to unlimited
                     
            }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(content)
            else:
                contents = content
        
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
        return response, contents
    
    def set_domain_autorenew(self,domain_name,renewalmode):
        """set domain autorenew value in instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'SetDomainAutoRenew',
                     'domain':domain_name,
                     'renewalmode':renewalmode #Renewal mode is "1"(default) means AUTO-RENEW or "0" meansAUTO-DELETE

                     
            }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
    
        return response
   
    def update_domain(self,kwargs, nameserverdict, ipaddressdict = {}):
        """ update  a domain in instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'UpdateDomain',
                     'domain':kwargs.get('domain',None),
                     'registrantcontact':kwargs.get('registrantcontact',None),
                     'admincontact':kwargs.get('admincontact',None),
                     'techcontact':kwargs.get('techcontact',None),
                     'billingcontact':kwargs.get('billingcontact',None),
             }
            values.update(nameserverdict)
            if ipaddressdict:
                values.update(ipaddressdict)
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(content)
            else:
                contents = {}
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
    
        return response, contents
    
    def get_domain_info(self,domain_name):
        """ get a domain info from instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'InfoDomain',
                     'domain':domain_name
            }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(content)
            else:
                contents = {}
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
        #print "RESPONSE*****************444",response
        #print "content******************44",(content)
        return response , contents

    def query_domainlist(self,**kwargs):
        """ In the query domain list from INSTRA API"""
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'QueryDomainList',
                     'domain':kwargs.get('domain',None),
                     'domainhandleridN':kwargs.get('domainhandleridN',None),
                     'registrantcontact':kwargs.get('registrantcontact',None),
                     'admincontact':kwargs.get('admincontact',None),
                     'techcontact':kwargs.get('techcontact',None),
                     'billingcontact':kwargs.get('billingcontact',None),
                     'mincreateddate':kwargs.get('mincreateddate',None),
                     'maxcreateddate':kwargs.get('maxcreateddate',None),
                     'minupdateddate':kwargs.get('minupdateddate',None),
                     'maxupdateddate':kwargs.get('maxupdateddate',None),
                     'minexpirydate':kwargs.get('minexpirydate',None),
                     'maxexpirydate':kwargs.get('maxexpirydate',None),
                     'domainstatus':kwargs.get('domainstatus',None),
                     'domainstatus':kwargs.get('domainstatus',None),
                     'domainstatus':kwargs.get('domainstatus',None),
                     'domainstatus':kwargs.get('domainstatus',None)
                     
             }
            
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
        return response    

    def create_contact(self,kwargs):
        """ create a domain in instra api """
        try:
            http = httplib2.Http()
            values = {'user' : 'webip',
                      'pw' : 'Woodfish501',
                      'command' : 'CreateContact',
                      'firstname':kwargs.get('clientuser__user__first_name',None),
                      'lastname':kwargs.get('clientuser__user__last_name',None),
                      'street':kwargs.get('street',"ABC"),
                      'city':kwargs.get('city',"Pune"),
                      'state':kwargs.get('state',"Maharashtra"),
                      'zip':kwargs.get('zip',"411043"),
                      'country':kwargs.get('country__country_code',None),
                      'phone':str("+91.")+str(kwargs.get('clientuser__user__userprofilemodel__phone',None)),
                      'email':kwargs.get('clientuser__user__email',None),
                     }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response and response['status'] == '200':
                contents = self._get_content_dict(content)
                contacthandleid = contents.get('contacthandleid','') 
            else:
                contacthandleid = ''
        except URLError, e:
            if hasattr(e, 'reason'):
                print 'We failed to reach a server.'
                print 'Reason: ', e.reason
            elif hasattr(e, 'code'):
                print 'The server couldn\'t fulfill the request.'
                print 'Error code: ', e.code
        return response, contacthandleid
    
    def _get_content_dict(self, content):
        """
            Restructuring the contents returned by the url call to instara api
        """
        count = 0
        content_dict ={}
        content_list = content.split('\n')
        #content_list = content.split('\r\n')
        
        for item in content_list:
            if item.__contains__('='):
                try:
                    data = str(item).split('=')
                except Exception , e:
                    print str(e)
                try:
                    content_dict[str(data[0]).strip().lower()] = str(data[1]).strip()
                except:
                    pass
        return content_dict
    
    
class InstraDNSManager():
    """
    """
    def __init__(self):
        print "in the init"
        self.user='webip'
        self.password='Woodfish501'
        self.url= 'https://api.instra.com:8443/InstraAPI/InstraPostAPI.do'
        
    def get_domain_info(self,domain_name):
        """ get a domain info from instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'InfoDnsRecords',
                     'product':domain_name
            }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            print "infocontent" , content
            if response and response['status'] == '200':
                contents = self._restructure_contents(content, 20)
            else:
                contents = []
        except URLError, e:
            response = False
            contents = "Server Not foumd Please try later."
        return response , contents
    
    def _restructure_contents(self, content , domain_length):
        """
            Restructuring the contents returned by the url call to instara api
        """
        count = 0
        content_dict ={}
        content_list = content.split('\n')
        for item in content_list:
            if item.__contains__('='):
                try:
                    data = str(item).split('=')
                except Exception , e:
                    print str(e)
                try:
                    content_dict[str(data[0]).strip().lower()] = str(data[1]).strip()
                except:
                    pass
        data_list = []
        content_keys = content_dict.keys()
        for i in range (1 , int(domain_length)):
            data_dict ={}
            data = [str(item) for item in content_keys if str(item).endswith(str(i))]
            print "\ndata",  data
            for d in data:
                data_dict.update({d.rstrip(str(i)):content_dict[d]})
            if data_dict:
                data_list.append(data_dict)
        return data_list
    
    def add_dns(self,dns_dict):
        """ get a domain info from instra api """
        status = ''
        message =''
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'AddDnsRecord',
                     'product':str(dns_dict.get('domain_name', '')),
                     'host' : str(dns_dict.get('host', '')),
                     'type':str(dns_dict.get('type', '')),
                     'content':str(dns_dict.get('content', '')),
            }
            #print "values", values
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response:
                contents = self._get_content_dict(content)
            if contents.has_key('code'):
                if contents['code'] == "200":
                    status = True
                    message = "DNS successfully added"
                if contents['code'] == "541":
                    status = False
                    message = str(contents['reason']).title()
        except URLError, e:
            status = False
            message = "Please try again later."
        return status , message
    
    def update_dns(self,dns_dict):
        """ get a domain info from instra api """
        message= ''
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'UpdateDnsRecord',
                     'product':dns_dict.get('domain_name', ''),
                     'recordid':dns_dict.get('recordid', ''),
                     'host' : dns_dict.get('host', ''),
                     'type':dns_dict.get('type', ''),
                     'content':dns_dict.get('content', ''),
            }
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            
            if response:
                contents = self._get_content_dict(content)
            if contents.has_key('code'):
                if contents['code'] == "200":
                    status = True
                    message = "DNS successfully updated"
                if contents['code'] == "541":
                    status = False
                    message = str(contents['reason']).title()
        except URLError, e:
            status = False
            message = "Please try again later."
        return status , message
    
    def delete_dns(self,dns_dict):
        """ get a domain info from instra api """
        try:
            http = httplib2.Http()
            values ={
                     'user' :self.user,
                     'pw' :self.password,
                     'command' :'DeleteDnsRecord',
                     'product':str(dns_dict.get('domain_name', '')),
                     'recordid':str(dns_dict.get('recordid', '')),
            }
            #print "values", values
            headers = {'Content-type': 'application/x-www-form-urlencoded'}
            response, content = http.request(self.url, 'POST', headers=headers, body=urllib.urlencode(values))
            if response:
                contents = self._get_content_dict(content)
            if contents.has_key('code'):
                if contents['code'] == "200":
                    status = True
                    message = "DNS Deleted"
                if contents['code'] == "541":
                    status = False
                    message = str(contents['reason']).title()
        except URLError, e:
            status = False
            message = "Please try again later."
        return status , message
    
    def _get_content_dict(self, content):
        """
            Restructuring the contents returned by the url call to instara api
        """       
        count = 0
        content_dict ={}
        content_list = content.split('\n')
        for item in content_list:
            if item.__contains__('='):
                try:
                    data = str(item).split('=')
                except Exception , e:
                    print str(e)
                try:
                    content_dict[str(data[0]).strip().lower()] = str(data[1]).strip()
                except:
                    pass
        return content_dict
