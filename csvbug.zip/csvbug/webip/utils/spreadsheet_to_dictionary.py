import xlrd
from datetime import datetime

class SpreadSheetDictonaryConversion:
    def spreadsheet_converter(self, spreadsheet_location , column_list):
        """
            Purpose: Function to generate Python Dictionary from XLS Spreadsheet. This function inturn calls 
                    subsequent functions to generate the Python Dictionary.
            Input: Input Spreadsheet
            Output: Python Dictionary
            Dependency: xlrd python library
        """
        
        self.spreadsheet_location = spreadsheet_location
        self.column_list = column_list
        self.process_sheet_names()
        result_dict = self.process_spreadsheet_to_Dictionary()
        return result_dict
        
    def process_sheet_names(self):
        """
            Purpose: Function to read the spreadsheet using xlrd and generate a list of sheet names in the 
                    spreadsheet.
            Input: Spreadsheet Location
            Output: List of sheet names
            Dependency: xlrd python library
        """
        self.sheet_names = []
        
        try:
            self.book = xlrd.open_workbook(self.spreadsheet_location)
        except Exception , e:
            print "Exception", str(e)
            self.book = None
        
        if self.book:
            for num in range(self.book.nsheets):
                sheet = self.book.sheet_by_index(num)
                self.sheet_names.append(sheet.name)

    def process_spreadsheet_to_Dictionary(self):
        """
            Purpose: Function to process separate sheets and generate a Python Dictionary
            Input: Spreadsheet file handler object, List of sheet names
            Output: Python Dictionary
            Dependency: xlrd python library
        """
        result_dict = {}
        for sheet_name in self.sheet_names:
            sh = self.book.sheet_by_name(sheet_name)
            
            details = []
            for rownum in range(sh.nrows):
                if rownum in [0]:
                    pass
                else:
                    row_detail = sh.row_values(rownum)
                    count = 0
                    row_dict = {}
                    for items in self.column_list:                
                        try:
                            if items.lower().__contains__('date'):
                                print "row_detail[count]",row_detail[count] 
                                if str(row_detail[count]).find('/') > 0 :
                                    value = str(row_detail[count])
                                
                                if str(row_detail[count]).find('-') > 0 :
                                    value = str(row_detail[count])
                                else:
                                    try: 
                                        _value = xlrd.xldate_as_tuple(int(row_detail[count]), self.book.datemode)
                                        value = self.processDate(_value)
                                    except Exception,e:
                                        ''' if date is like 'u20/8/2012'(dd/mm/yyyy) format then first converted into string and then change format to dd-mm-yy '''
                                        row_detail[count]=row_detail[count].encode()
                                        date_value=datetime.strptime(row_detail[count],"%d/%m/%Y").strftime("%d-%m-%y") 
                                        value=date_value
                            else:
                                try:
                                    value = str(row_detail[count])
                                except Exception,e:
                                    print str(e)
                                    value=row_detail[count]
                        except IndexError,e:
                            value = ""    
                        count += 1                                               
                        row_dict[items] = value
                    details.append(row_dict)
                result_dict[sheet_name] = details
        print "\n\n"
        print "*"*100
        print result_dict
        print "*"*100
        print "\n\n"
#        return {}
        return result_dict


    def processDate(self, value):
        """
            (2011, 8, 2, 0, 0, 0)
            dd-mm-yy
        """
        return str(value[2]) + "-" + str(value[1]) + "-" + str(str(value[0])[2:])
    
#obj = SpreadSheetDictonaryConversion()
##
###cloumn_list = ['Staff Name', 'Username', 'password', 'Email Address', 'phone', 'Staff type', 'status']
###result_dict = obj.spreadsheet_converter("/home/tushar/Desktop/Skype/Import Staff.xls" , cloumn_list)
###print result_dict
###print "\n\n"
##
#cloumn_list = ['Domain Name','Country','Cost Centre','Registrar',
#               'Expiry Date','Notes','Cost Per Annum','Auto Renew',
#               "Company Name",'First Name','Last Name','Phone',
#               'Email','Currency','SSL Details']
#result_dict = obj.spreadsheet_converter("/home/shweta/Desktop/domain_import1.xls" , cloumn_list)
#
#print result_dict